# SpringFX — spring / jiggle bone dynamics for animation.
# Package layout:
#   core.py       — physics engine, frame handlers, colliders, helpers setup
#   presets.py    — built-in Hair/Clothing/Body library + user preset ops
#   properties.py — PropertyGroups and all sb_* property registration
#   operators.py  — bake, groups, bulk apply, smart convert, noise, NLA
#   ui.py         — N-panel layout (View3D > Sidebar > SpringFX); 8.2: Add/Clean
#                   Physics + renamable group list, Bake last
#   export_engines.py — VRChat PhysBones export (game-engine bridge)

bl_info = {
    "name": "SpringFX",
    "author": "Auron3d",
    # NOTE: 8.3.0 = mesh colliders solved in the compiled core (lazy BVH with
    # refit), rigs with Euler / Lag chains stay compiled for the rest
    # ("mixed" rigs), and the optional "Ignore Own Mesh" collision rule.
    # NOTE: 8.4.0 = update notices and one-click updates inside Blender
    # through the store's remote repository (updates.py), and the compiled
    # core is released on disable so Windows lets an update replace it.
    # NOTE: 8.4.2 = frame handlers no longer write the Scene datablock (the
    # Python solver state moved to module dicts); that per-frame Scene write
    # crashed threaded playback in BKE_object_eval_eval_base_flags.
    # NOTE: 8.4.3 = the bake replaces only the bake range; keyframes and NLA
    # animation outside it keep playing (they were deleted or masked).
    # NOTE: 8.4.4 = exhaustive-test fixes: axis-angle bones, same-frame
    # re-evaluation in the compiled core, Location Influence 0, "Reacts to
    # Colliders" on rotation springs, undo, duplicated rigs, exact baked cache.
    # NOTE: 8.5.0 = external impulse channel per group (sb_impulse): ImpactFX
    # or plain keyframes can kick a group's springs; no effect when unused.
    # NOTE: 8.5.1 = group keyframes / drivers stay on their group when a group
    # is baked, removed or renamed (they used to stay on the slot index).
    # NOTE: 8.5.2 = Python solver on unanimated quaternion rigs, impulse read
    # through the NLA, nested location springs after a timeline jump, cache
    # switch out of sync after opening another file.
    # NOTE: 8.5.3 = stays dormant when another add-on (Advanced Character
    # Suite) already runs an embedded copy, instead of simulating twice.
    # NOTE: 8.5.4 = render crash fix: frame handlers never touch the viewport
    # depsgraph, create objects or register timers during a render; Lock
    # Interface is enabled for scenes with springs; renders use Render
    # Quality and read mesh colliders from the render's own depsgraph.
    # NOTE: 8.5.5 = verified on Blender 5.3 (bit-identical simulation and bake
    # against 5.2 LTS, compiled core included). No change to the solver.
    # NOTE: 8.5.6 = one start for every path. The first playback after Add
    # Physics (and the frame cache replaying it), Bake to Cache and a file
    # just opened integrated one step on their first frame; a jump back, a
    # loop, Bake to Keyframes and renders did not. Playback and bake were one
    # frame of inertia apart (4.7 cm on a 1.2 m chain). Bake output unchanged.
    "version": (8, 5, 6),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > SpringFX",
    "description": "Spring dynamics for bones: location + inertia rotation "
                   "springs, hair/clothing presets, wind, full collision "
                   "system (body capsules, meshes, self-collision), chains, "
                   "groups, bake",
    "category": "Animation",
}

# Support live reloading during development: if the package was already
# imported, `import ...` alone would reuse the stale modules.
if "core" in locals():
    import importlib
    core       = importlib.reload(core)        # noqa: F821
    presets    = importlib.reload(presets)     # noqa: F821
    operators  = importlib.reload(operators)   # noqa: F821
    properties = importlib.reload(properties)  # noqa: F821
    ui         = importlib.reload(ui)          # noqa: F821
    export_engines = importlib.reload(export_engines)  # noqa: F821
    xpbd       = importlib.reload(xpbd)        # noqa: F821
    native     = importlib.reload(native)      # noqa: F821
    updates    = importlib.reload(updates)     # noqa: F821
else:
    from . import core, presets, operators, properties, ui, export_engines, xpbd, native, updates

import bpy  # noqa: F401  (kept for scripts that poke springfx.bpy)


# Registration order matters:
#   properties first (PropertyGroups + sb_* props the rest depend on),
#   then operator/preset/ui classes, then the frame handlers last so the
#   simulation never runs against a half-registered addon.
_register_order = (properties, presets, operators, export_engines, updates, ui, core)


_dormant = False


def _wake():
    """Timer of a copy left dormant by ANOTHER add-on that includes SpringFX:
    take over as soon as that add-on is disabled, instead of staying off
    until the user re-enables this one by hand."""
    global _dormant
    if not _dormant:
        return None
    if not updates.claim_single_copy():
        return 2.0
    _dormant = False
    for mod in _register_order:
        mod.register()
    print("[SpringFX] %s is active now" % __package__)
    return None


def register():
    global _dormant
    # NOTE: never run two copies at once (see updates.claim_single_copy).
    _dormant = not updates.claim_single_copy()
    if _dormant:
        # NOTE: 8.5.3 -- only a namespace owned by a different add-on is
        # waited for; a store copy that beats this one stays the owner.
        if updates._state.get("shadowed_by", "").startswith("another add-on"):
            bpy.app.timers.register(_wake, first_interval=2.0, persistent=True)
        return
    for mod in _register_order:
        mod.register()


def unregister():
    if bpy.app.timers.is_registered(_wake):
        bpy.app.timers.unregister(_wake)
    if _dormant:
        return
    for mod in reversed(_register_order):
        mod.unregister()


if __name__ == "__main__":
    register()
