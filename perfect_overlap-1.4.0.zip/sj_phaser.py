# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

__author__ = "Sanku Venkatesh"
__copyright__ = "Copyright 2021-2026, CaptainHansode, sakaiden.com; 2026 Sanku Venkatesh"
__credits__ = ["Sanku Venkatesh", "CaptainHansode (original author)"]
__license__ = "GPL"
__maintainer__ = "Sanku Venkatesh"
__status__ = "Production"


import bpy
import mathutils
import copy
import numpy as np


class SJPhaserModule(object):
    r"""Perfect-overlap phase calculation core."""

    def __init__(self, *args, **kwargs):
        self.delay = 5.0
        self.recursion = 5.0
        self.strength = 1.0
        self.threshold = 0.001
        self.sf = 0
        self.ef = 10
        self.debug = False

        # --- options -----------------------------------------------------
        # Expand the selection down the bone hierarchy: selecting only the
        # parent controller picks up every child controller under it.
        self.hierarchy = False
        # Bake location channels as well as rotation.
        self.animate_translate = False
        # Restore scale (and location, when Translate is off) to the values the
        # bone already had, every frame. This is what stops the armature from
        # scaling.
        self.reset_values = True

    # ------------------------------------------------------------------
    # selection
    # ------------------------------------------------------------------
    def get_selection(self):
        r"""Pose bones to operate on.

        With `hierarchy` on, every descendant of a selected bone is added, so
        the user only has to select the top controller of a chain."""
        selected = list(bpy.context.selected_pose_bones or [])
        if not self.hierarchy:
            return selected

        out = []
        seen = set()

        def walk(pbn):
            if pbn.name in seen:
                return
            seen.add(pbn.name)
            out.append(pbn)
            for child in pbn.children:
                walk(child)

        for pbn in selected:
            walk(pbn)
        return out

    def get_hierarchy_count(self, obj):
        r"""Depth of the bone in the hierarchy."""
        obj = obj.parent
        cnt = 0
        while obj is not None:
            obj = obj.parent
            cnt += 1
        return cnt

    def get_default_data_table(self):
        return {
            "obj_list": [],
            "pre_mt": [],
            "obj_length": [],
            "old_vec": []
        }

    def get_tree_list(self):
        r"""Collect the selected (or hierarchy-expanded) connected bone chains."""
        sel_bones = self.get_selection()
        sel_names = {pbn.name for pbn in sel_bones}

        # A bone can only be simulated if it has a parent to hang from - the
        # parent supplies the driving motion.
        sim_names = {pbn.name for pbn in sel_bones if pbn.parent is not None}

        tree_roots = []
        obj_trees = {}

        for pbn in sel_bones:
            if pbn.name not in sim_names:
                # Parentless bone (e.g. the root controller the user clicked on
                # with Hierarchy enabled). It drives the chain but is not
                # simulated itself.
                continue

            parent = pbn.parent
            # If the parent is simulated too, this bone is only a chain root
            # when it is a branch (i.e. not the parent's first child).
            if parent.name in sim_names and parent.name in sel_names:
                if parent.children and parent.children[0].name == pbn.name:
                    continue
            tree_roots.append(pbn)

        t_cnt = 0
        for root_obj in tree_roots:
            depth_cnt = self.get_hierarchy_count(root_obj)
            tree = []
            t_name = "tree{}".format(t_cnt)

            if depth_cnt not in obj_trees:
                obj_trees[depth_cnt] = {}

            # No children: this is a one-bone chain.
            if len(root_obj.children) == 0:
                tree.append(root_obj)
                obj_trees[depth_cnt][t_name] = self.get_default_data_table()
                obj_trees[depth_cnt][t_name]["obj_list"] = tree
                t_cnt += 1
                continue

            # A chain always follows the first ("0 index") child.
            tree.append(root_obj)
            c_obj = root_obj.children[0]

            while c_obj.name in sel_names:
                tree.append(c_obj)
                if len(c_obj.children) == 0:
                    break
                c_obj = c_obj.children[0]

            obj_trees[depth_cnt][t_name] = self.get_default_data_table()
            obj_trees[depth_cnt][t_name]["obj_list"] = tree
            t_cnt += 1

        return obj_trees

    def iter_bones(self, obj_trees):
        r"""Every pose bone in every chain, shallowest chain first."""
        for k in sorted(obj_trees.keys()):
            for t in obj_trees[k]:
                for pbn in obj_trees[k][t]["obj_list"]:
                    yield pbn

    # ------------------------------------------------------------------
    # matrices
    # ------------------------------------------------------------------
    def get_bone_length_matrix(self, pbn):
        r"""World-space matrix representing this bone's length/direction relative to its parent."""
        amt = bpy.context.active_object
        wmt = amt.matrix_world @ pbn.matrix

        p_wmt = amt.matrix_world @ pbn.parent.matrix
        len_mt = wmt.transposed() @ p_wmt.transposed().inverted()
        return len_mt.transposed()

    def get_bone_pre_matrix(self, pbn):
        r"""Bone's initial world matrix."""
        amt = bpy.context.active_object
        return amt.matrix_world @ pbn.matrix

    def get_end_pos_from_bonelength(self, pbn):
        r"""World matrix at the bone's tip."""
        amt = bpy.context.active_object
        wmt = amt.matrix_world @ pbn.matrix

        x = mathutils.Vector((1.0, 0.0, 0.0, 0.0))
        y = mathutils.Vector((0.0, 1.0, 0.0, pbn.length))
        z = mathutils.Vector((0.0, 0.0, 1.0, 0.0))
        w = mathutils.Vector((0.0, 0.0, 0.0, 1.0))
        len_mt = mathutils.Matrix([x, y, z, w])
        len_mt = len_mt.transposed() @ wmt.transposed()
        return len_mt.transposed()

    def normalize(self, vec):
        r"""Normalize a numpy vector."""
        return vec / np.linalg.norm(vec)

    def set_pre_data(self, obj_trees):
        dct_k = sorted(obj_trees.keys())  # process shallowest chains first
        for k in dct_k:
            for t in obj_trees[k]:
                obj_count = len(obj_trees[k][t]["obj_list"])
                cnt = 1
                for pbn in obj_trees[k][t]["obj_list"]:
                    obj_trees[k][t]["pre_mt"].append(
                        self.get_bone_pre_matrix(pbn))

                    obj_trees[k][t]["obj_length"].append(
                        self.get_bone_length_matrix(pbn))

                    obj_trees[k][t]["old_vec"].append(
                        mathutils.Vector((0.0, 0.0, 0.0)))

                    # The last bone in the chain also needs its tip position tracked.
                    if cnt == obj_count:
                        amt = bpy.context.active_object
                        wmt = amt.matrix_world @ pbn.matrix

                        end_mt = self.get_end_pos_from_bonelength(pbn)
                        obj_trees[k][t]["pre_mt"].append(end_mt)

                        len_mt = end_mt.transposed() @ wmt.transposed().inverted()
                        obj_trees[k][t]["obj_length"].append(len_mt.transposed())
                    cnt += 1
        return obj_trees

    # ------------------------------------------------------------------
    # keyframes
    # ------------------------------------------------------------------
    def rotation_data_path(self, pbn):
        if pbn.rotation_mode == 'QUATERNION':
            return 'rotation_quaternion'
        if pbn.rotation_mode == 'AXIS_ANGLE':
            return 'rotation_axis_angle'
        return 'rotation_euler'

    def _key_delete_safe(self, pbn, data_path, frame):
        r"""keyframe_delete raises when there is no key on that frame - that is
        not an error, and it must NOT abort the rest of the cleanup."""
        try:
            pbn.keyframe_delete(data_path=data_path, frame=frame)
        except (RuntimeError, TypeError):
            pass

    def del_animkey(self, obj_trees):
        r"""Remove existing keys in [sf, ef] and (re)key the start frame."""
        paths = ['rotation_euler', 'rotation_quaternion',
                 'rotation_axis_angle', 'scale']
        if self.animate_translate:
            paths.append('location')

        for pbn in self.iter_bones(obj_trees):
            for f in range(self.sf, self.ef + 1):
                for dp in paths:
                    # Each channel is deleted independently: a missing key on
                    # one channel used to abort the whole cleanup loop, which
                    # left stale keys behind and broke looping.
                    self._key_delete_safe(pbn, dp, f)

        # Needed so the bones' evaluated state reflects the deleted keys.
        bpy.context.view_layer.update()

        for pbn in self.iter_bones(obj_trees):
            if self.animate_translate:
                pbn.keyframe_insert(data_path='location', frame=self.sf)
            pbn.keyframe_insert(
                data_path=self.rotation_data_path(pbn), frame=self.sf)

        self.remove_cyclic_modifiers(obj_trees)
        return None

    def set_animkey(self, obj):
        f = bpy.context.scene.frame_current
        if self.animate_translate:
            obj.keyframe_insert(data_path='location', frame=f)
        obj.keyframe_insert(data_path=self.rotation_data_path(obj), frame=f)
        # Scale is deliberately never keyed - baking scale here is what made
        # armatures grow/shrink during the simulation.
        return None

    # ------------------------------------------------------------------
    # f-curves
    # ------------------------------------------------------------------
    def _get_fcurves(self, id_data):
        r"""Return the id_data's F-Curves, compatible with both the legacy
        Action API (Blender <= 4.3) and the slotted Action API (4.4+, where
        Action.fcurves was removed entirely in 5.0)."""
        adt = id_data.animation_data
        if adt is None or adt.action is None:
            return []
        action = adt.action
        try:
            from bpy_extras import anim_utils
            channelbag = anim_utils.action_get_channelbag_for_slot(action, adt.action_slot)
            return list(channelbag.fcurves) if channelbag else []
        except (ImportError, AttributeError):
            # Blender 4.3 and earlier still expose fcurves directly.
            return list(action.fcurves)

    def _chain_data_paths(self, obj_trees):
        r"""data_path prefixes ("pose.bones[\"Bone\"]") for every bone we keyed."""
        return [pbn.path_from_id() for pbn in self.iter_bones(obj_trees)]

    def _chain_fcurves(self, obj_trees):
        amt = bpy.context.active_object
        prefixes = self._chain_data_paths(obj_trees)
        return [fc for fc in self._get_fcurves(amt)
                if any(fc.data_path.startswith(p) for p in prefixes)]

    def add_cyclic_modifiers(self, obj_trees):
        r"""Add a Cycles F-Curve modifier to every channel we keyed, so the
        action repeats automatically past the end frame (used by Loop)."""
        for fcurve in self._chain_fcurves(obj_trees):
            if not any(m.type == 'CYCLES' for m in fcurve.modifiers):
                fcurve.modifiers.new('CYCLES')

    def remove_cyclic_modifiers(self, obj_trees):
        r"""Remove Cycles F-Curve modifiers previously added by Loop."""
        for fcurve in self._chain_fcurves(obj_trees):
            for m in list(fcurve.modifiers):
                if m.type == 'CYCLES':
                    fcurve.modifiers.remove(m)

    def smooth_loop_seam(self, obj_trees):
        r"""Give the first and last key of the range auto handles, so the curve
        does not kick as it wraps around the seam."""
        for fcurve in self._chain_fcurves(obj_trees):
            for kp in fcurve.keyframe_points:
                if int(round(kp.co[0])) in (self.sf, self.ef):
                    kp.interpolation = 'BEZIER'
                    kp.handle_left_type = 'AUTO_CLAMPED'
                    kp.handle_right_type = 'AUTO_CLAMPED'
            fcurve.update()

    # ------------------------------------------------------------------
    # loop
    # ------------------------------------------------------------------
    def _pose_snapshot(self, obj_trees):
        pose = {}
        for pbn in self.iter_bones(obj_trees):
            pose[pbn.name] = {
                'location': pbn.location.copy(),
                'rotation_quaternion': pbn.rotation_quaternion.copy(),
                'rotation_euler': pbn.rotation_euler.copy(),
                'rotation_axis_angle': [v for v in pbn.rotation_axis_angle],
                'scale': pbn.scale.copy(),
            }
        return pose

    def loop_blend_tail(self, obj_trees, loop_frames):
        r"""Ease the last `loop_frames` frames of the range back toward the
        start-frame pose. The final frame is written as an exact copy of the
        start pose, so frame `ef` and frame `sf` are identical and the action
        can be played on a loop without a pop at the seam."""
        scene = bpy.context.scene
        loop_frames = max(1, min(int(loop_frames), self.ef - self.sf))

        # Collect the start-frame pose - this is the loop target.
        scene.frame_set(self.sf)
        bpy.context.view_layer.update()
        start_pose = self._pose_snapshot(obj_trees)

        for i in range(loop_frames):
            f = self.ef - loop_frames + 1 + i
            factor = (i + 1) / float(loop_frames)
            exact = (f == self.ef)

            scene.frame_set(f)
            bpy.context.view_layer.update()

            for pbn in self.iter_bones(obj_trees):
                target = start_pose[pbn.name]
                mode = pbn.rotation_mode

                if self.animate_translate:
                    if exact:
                        pbn.location = target['location'].copy()
                    else:
                        pbn.location = pbn.location.lerp(
                            target['location'], factor)

                if mode == 'QUATERNION':
                    if exact:
                        pbn.rotation_quaternion = target['rotation_quaternion'].copy()
                    else:
                        cur = pbn.rotation_quaternion.normalized()
                        tgt = target['rotation_quaternion'].normalized()
                        # Take the short way round the hypersphere.
                        if cur.dot(tgt) < 0.0:
                            tgt = mathutils.Quaternion(
                                (-tgt.w, -tgt.x, -tgt.y, -tgt.z))
                        pbn.rotation_quaternion = cur.slerp(tgt, factor)
                elif mode == 'AXIS_ANGLE':
                    tgt = target['rotation_axis_angle']
                    if exact:
                        pbn.rotation_axis_angle = tgt
                    else:
                        pbn.rotation_axis_angle = [
                            pbn.rotation_axis_angle[a] +
                            (tgt[a] - pbn.rotation_axis_angle[a]) * factor
                            for a in range(4)]
                else:
                    tgt = target['rotation_euler']
                    if exact:
                        pbn.rotation_euler = mathutils.Euler(
                            (tgt[0], tgt[1], tgt[2]), tgt.order)
                    else:
                        pbn.rotation_euler = mathutils.Euler(
                            [pbn.rotation_euler[a] +
                             (tgt[a] - pbn.rotation_euler[a]) * factor
                             for a in range(3)],
                            pbn.rotation_euler.order)

                if self.reset_values:
                    pbn.scale = target['scale'].copy()

                if self.animate_translate:
                    pbn.keyframe_insert(data_path='location', frame=f)
                pbn.keyframe_insert(
                    data_path=self.rotation_data_path(pbn), frame=f)

        self.smooth_loop_seam(obj_trees)
        scene.frame_set(self.sf)
        return None

    def check_loop_match(self, obj_trees):
        r"""Largest channel difference between frame sf and frame ef.
        Returns (bone_name, difference)."""
        scene = bpy.context.scene
        cur = scene.frame_current

        scene.frame_set(self.sf)
        bpy.context.view_layer.update()
        pose_a = self._pose_snapshot(obj_trees)

        scene.frame_set(self.ef)
        bpy.context.view_layer.update()
        pose_b = self._pose_snapshot(obj_trees)

        scene.frame_set(cur)

        worst_name = ""
        worst = 0.0
        for name, a in pose_a.items():
            b = pose_b[name]
            keys = ['rotation_quaternion', 'rotation_euler',
                    'rotation_axis_angle']
            if self.animate_translate:
                keys.append('location')
            for key in keys:
                for va, vb in zip(a[key], b[key]):
                    d = abs(va - vb)
                    if d > worst:
                        worst = d
                        worst_name = name
        return worst_name, worst

    # ------------------------------------------------------------------
    # simulation
    # ------------------------------------------------------------------
    def clamp(self, n, minn=0.0, maxn=1.0):
        return max(min(maxn, n), minn)

    def rotate_matrix(self, mtx, rot_mt):
        r"""Rotate matrix `mtx` by rotation matrix `rot_mt`, keeping its scale/location parts."""
        loc, r_mt, s_mt = mtx.decompose()

        pos = mathutils.Matrix.Translation(loc)
        rot = r_mt.to_matrix().to_4x4()
        scl = (mathutils.Matrix.Scale(s_mt[0], 4, (1, 0, 0)) @
               mathutils.Matrix.Scale(s_mt[1], 4, (0, 1, 0)) @
               mathutils.Matrix.Scale(s_mt[2], 4, (0, 0, 1))
               )
        return pos @ rot_mt @ rot @ scl

    def create_test_empty(self, e_name, mtx):
        r"""Debug helper: drop an empty at a given matrix, only when `debug` is on."""
        if self.debug is False:
            return None
        emp = bpy.data.objects.new(e_name, None)
        bpy.context.selected_objects[0].users_collection[0].objects.link(emp)
        emp.empty_display_size = 0.2
        emp.empty_display_type = 'ARROWS'
        emp.matrix_world = copy.copy(mtx)
        return None

    def calculate(self, obj_data):
        r"""Advance one chain's phase simulation by one frame."""
        amt = bpy.context.active_object

        cur_p_mt = amt.matrix_world @ obj_data["obj_list"][0].parent.matrix
        strgh = self.strength     # overlap amplitude - larger = stronger wobble
        trshd = self.threshold    # noise floor for the phase vector

        for i in range(len(obj_data["obj_list"])):
            # Order per bone: 1) current axis, 2) roll, 3) phase (overlap).

            obj = obj_data["obj_list"][i]

            # Values the bone already has on this frame. The simulation builds
            # an orthonormal world matrix, so assigning it would otherwise
            # bake 1/armature-scale into the bone's local scale - that is the
            # "armature is scaling" bug. We put these back afterwards.
            orig_loc = obj.location.copy()
            orig_scale = obj.scale.copy()

            # 1) current axis
            tag_mt = obj_data["obj_length"][i].transposed() @ cur_p_mt.transposed()
            tag_mt = tag_mt.transposed()
            pre_mt = copy.copy(obj_data["pre_mt"][i])
            new_mt = copy.copy(obj_data["pre_mt"][i])
            tag_pos = tag_mt.translation

            pre_y_vec = pre_mt.transposed().to_3x3()[1].normalized()
            tag_y_vec = tag_mt.transposed().to_3x3()[1].normalized()
            y_diff = np.arccos(self.clamp(np.dot(pre_y_vec, tag_y_vec)))
            axis_vec = mathutils.Vector(np.cross(pre_y_vec, tag_y_vec))
            new_mt = self.rotate_matrix(
                new_mt,
                (mathutils.Matrix.Rotation(y_diff, 4, axis_vec.normalized())))
            new_mt.translation = copy.copy(tag_pos)  # re-apply position just in case

            # 2) roll
            new_x_vec = new_mt.transposed().to_3x3()[0].normalized()
            tag_x_vec = tag_mt.transposed().to_3x3()[0].normalized()
            dot_val = np.dot(new_x_vec, tag_x_vec)

            if dot_val > 1.0:
                roll = 0.0
            else:
                roll = np.arccos(dot_val)
            roll = roll / self.delay

            check_vec = np.cross(new_x_vec, tag_x_vec)
            if np.dot(check_vec, tag_y_vec) < 0.0:
                roll = -roll

            axis_vec = new_mt.transposed().to_3x3()[1].normalized()
            new_mt = self.rotate_matrix(
                new_mt,
                (mathutils.Matrix.Rotation(roll, 4, axis_vec)))
            new_mt.translation = tag_pos

            # 3) phase (overlap) vector
            c_pos = obj_data["pre_mt"][i + 1].translation
            y_vec = self.normalize(c_pos - tag_pos)
            new_y_vec = new_mt.transposed().to_3x3()[1].normalized()
            rcs_vec = (obj_data["old_vec"][i] * self.recursion)
            phase_vec = ((new_y_vec - (y_vec * strgh)) / self.delay) + rcs_vec

            if phase_vec.length < trshd:
                phase_vec = mathutils.Vector((0.0, 0.0, 0.0))

            y_vec = y_vec + phase_vec
            obj_data["old_vec"][i] = phase_vec

            new_z_vec = new_mt.transposed().to_3x3()[2].normalized()
            y_vec = mathutils.Vector(self.normalize(y_vec))
            x_vec = mathutils.Vector(self.normalize(np.cross(y_vec, new_z_vec)))
            z_vec = mathutils.Vector(self.normalize(np.cross(x_vec, y_vec)))

            new_mt = mathutils.Matrix([x_vec, y_vec, z_vec])
            new_mt = new_mt.transposed().to_4x4()
            new_mt.translation = copy.copy(tag_pos)

            # Keying: view_layer.update() is required so pose_bone.matrix reflects
            # the change before the next bone in the chain reads it.
            # https://blender.stackexchange.com/questions/132403/
            obj.matrix = amt.matrix_world.inverted() @ new_mt
            bpy.context.view_layer.update()

            if self.reset_values:
                obj.scale = orig_scale
                if not self.animate_translate:
                    obj.location = orig_loc
                bpy.context.view_layer.update()
                # Re-read the corrected world matrix so the rest of the chain
                # is built from what the bone actually is, not what we asked for.
                new_mt = amt.matrix_world @ obj.matrix

            self.set_animkey(obj)

            obj_data["pre_mt"][i] = copy.copy(new_mt)
            cur_p_mt = copy.copy(new_mt)
            len_mt = obj_data["obj_length"][i + 1].transposed() @ new_mt.transposed()
            obj_data["pre_mt"][i + 1].translation = len_mt.transposed().translation

    def message_box(self, message="", title="Message", icon='INFO'):
        def draw(self, context):
            self.layout.label(text=message)
        bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)

    def excute(self, obj_trees):
        r"""Run the simulation for every frame in [sf+1, ef]."""
        dct_k = sorted(obj_trees.keys())
        for f in range(self.sf + 1, self.ef + 1):
            bpy.context.scene.frame_set(f)
            for k in dct_k:
                for t in obj_trees[k]:
                    self.calculate(obj_trees[k][t])
        return True
