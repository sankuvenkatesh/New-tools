# SpringFX — presets.py
# Built-in preset library (Body / Hair / Clothing), user presets
# (save / rename / delete / favorite) and the enum builders the UI uses.
#
# A preset is just a dict of group-parameter values. Built-ins ship with the
# addon; user presets are stored in the scene (scene.sb_user_presets) so they
# travel with the .blend. Favorites are a scene-level name list that works for
# BOTH built-in and user presets.

import bpy


# Every parameter a preset stores. sb_user_preset (properties.py) MUST define
# a property for each of these keys — keep the two in sync.
SB_PARAM_KEYS = (
    'sb_stiffness', 'sb_damp', 'sb_loc_speed', 'sb_gravity',
    'sb_loc_influence', 'sb_max_distance', 'sb_loc_range',
    'sb_rot_stiffness', 'sb_rot_damp', 'sb_rot_influence', 'sb_rot_range',
    'sb_rot_speed',   # rotspeed
    'sb_noise_enable', 'sb_noise_loc', 'sb_noise_rot',
    'sb_noise_speed', 'sb_noise_seed',
    # advanced dynamics (v7)
    'sb_stiff_axis', 'sb_air_drag', 'sb_wind_influence',
    'sb_smooth', 'sb_lag', 'sb_chain_falloff', 'sb_auto_length',
    # collision response (v7.1)
    'sb_collide_margin', 'sb_collide_stiffness', 'sb_collide_damping',
    'sb_collide_friction_mult', 'sb_self_collision',
)


def _mk(loc_stiff, loc_damp, rot_stiff, rot_damp, rot_range, gravity,
        effects='BOTH', **extra):
    """Compact builder for the preset table below. Fills the common defaults
    so each entry only spells out what makes it different."""
    d = dict(
        sb_stiffness=loc_stiff, sb_damp=loc_damp,
        sb_loc_speed=0.0, sb_gravity=gravity,
        sb_loc_influence=1.0, sb_max_distance=0.0, sb_loc_range=1.0,
        sb_rot_stiffness=rot_stiff, sb_rot_damp=rot_damp,
        sb_rot_influence=1.0, sb_rot_range=rot_range, sb_rot_speed=0.0,
        sb_noise_enable=False, sb_noise_loc=0.0, sb_noise_rot=0.0,
        sb_noise_speed=1.0, sb_noise_seed=0,
        sb_stiff_axis=(1.0, 1.0, 1.0), sb_air_drag=0.0,
        sb_wind_influence=1.0, sb_smooth=0.0, sb_lag=0.0,
        sb_chain_falloff=0.0, sb_auto_length=False,
        sb_collide_margin=0.0, sb_collide_stiffness=1.0,
        sb_collide_damping=0.2, sb_collide_friction_mult=1.0,
        sb_self_collision=False,
    )
    # preseteffects: which spring(s) this preset drives. Not a physics
    # parameter -- it is read by preset_effects() and skipped by
    # _apply_preset_values (the group has no attribute of this name).
    d['_effects'] = effects
    d.update(extra)
    return d


# Recommended collision response per material family, merged into the
# hair/cloth presets below. Hair slides (low friction, small margin);
# cloth grips and settles (more friction, damping and margin).
_COL_HAIR  = dict(sb_collide_margin=0.008, sb_collide_stiffness=1.0,
                  sb_collide_damping=0.25, sb_collide_friction_mult=0.6)
_COL_CLOTH = dict(sb_collide_margin=0.015, sb_collide_stiffness=0.9,
                  sb_collide_damping=0.35, sb_collide_friction_mult=1.2)


# ------------------------------------------------------------------ #
#  BUILT-IN LIBRARY
#  Tuned for the corrected physics (relative damping = deviation responds
#  to body ACCELERATION). Amplitude comes from Stiffness (lower = bigger
#  lag); Speed is a pure frequency boost.
#  Hair/Clothing entries assume ROTATION springs on bone chains (the usual
#  rig for hair strands and cloth panels) and lean on the v7 dynamics:
#  chain falloff, wind influence, air drag, lag and auto bone-size tuning.
# ------------------------------------------------------------------ #

SB_BUILTIN_PRESETS = {
    # ---- Body ----
    "Breast":   _mk(0.25, 0.30, 0.25, 0.30, 1.0, 0.0, effects='BOTH'),
    "Glute":    _mk(0.40, 0.40, 0.38, 0.40, 0.8, 0.0,
                    sb_rot_influence=0.9, effects='BOTH'),
    "Thigh":    _mk(0.50, 0.45, 0.45, 0.45, 0.7, 0.0,
                    sb_loc_influence=0.9, sb_rot_influence=0.85, effects='BOTH'),

    # ---- Hair ----
    # ONE hair preset. It carries the values measured on the 8-bone / 3.04 m
    # reference chain: enough secondary motion to read as hair (0.41 m of tip
    # travel, ~40 deg of chain bend) at a normalised jerk of 0.049 -- smoother
    # than the cloth-goal reference -- and returning to the authored pose to
    # within 0.5 mm once the parent stops.
    #
    # Why these and not the old six: settling is carried by AIR DRAG (absolute
    # velocity) instead of rot damping (relative to the parent). Rot damping
    # kills the response to the parent's motion, which is the effect itself;
    # drag only removes leftover energy. That is what allows stiffness this
    # low. Gravity is 0 on purpose -- any non-zero value settles the chain to
    # a hanging pose instead of the pose it had before physics were applied.
    # auto_length keeps the numbers meaningful away from the 25 cm reference
    # bone (these are 38 cm).
    "Hair":     _mk(0.08, 0.35, 0.08, 0.35, 1.00, 0.0,
                    sb_rot_speed=0.0, sb_air_drag=0.60,
                    sb_chain_falloff=0.70, sb_wind_influence=0.9,
                    sb_smooth=0.0, sb_lag=0.0,
                    sb_auto_length=True, effects='ROT', **_COL_HAIR),

    # ---- Clothing ----
    "Cloth - Shirt":   _mk(0.45, 0.50, 0.42, 0.48, 0.7, 0.20,
                           sb_chain_falloff=0.15, sb_wind_influence=0.5,
                           sb_air_drag=0.10, sb_auto_length=True, effects='ROT', **_COL_CLOTH),
    "Cloth - Skirt":   _mk(0.20, 0.32, 0.19, 0.31, 1.2, 0.50,
                           sb_chain_falloff=0.35, sb_wind_influence=0.9,
                           sb_air_drag=0.20, sb_auto_length=True, effects='ROT', **_COL_CLOTH),
    "Cloth - Cape":    _mk(0.10, 0.25, 0.09, 0.24, 1.5, 0.60,
                           sb_chain_falloff=0.50, sb_wind_influence=1.5,
                           sb_air_drag=0.30, sb_lag=0.20, sb_auto_length=True, effects='ROT', **_COL_CLOTH),
    "Cloth - Jacket":  _mk(0.40, 0.45, 0.38, 0.44, 0.8, 0.30,
                           sb_chain_falloff=0.20, sb_wind_influence=0.6,
                           sb_air_drag=0.12, sb_auto_length=True, effects='ROT', **_COL_CLOTH),
    "Cloth - Pants":   _mk(0.50, 0.50, 0.47, 0.50, 0.6, 0.25,
                           sb_chain_falloff=0.15, sb_wind_influence=0.3,
                           sb_auto_length=True, effects='ROT', **_COL_CLOTH),
    "Cloth - Dress":   _mk(0.18, 0.30, 0.17, 0.29, 1.25, 0.55,
                           sb_chain_falloff=0.40, sb_wind_influence=1.0,
                           sb_air_drag=0.25, sb_lag=0.10, sb_auto_length=True, effects='ROT', **_COL_CLOTH),
}

# Display order: body first, then hair, then clothing (dict order above).


# ------------------------------------------------------------------ #
#  APPLY / LOOKUP HELPERS
# ------------------------------------------------------------------ #

def _apply_preset_values(grp, values):
    """Write a dict of parameter values onto a group (tolerant: silently
    skips keys the target doesn't have, so old presets stay loadable)."""
    for key, val in values.items():
        if hasattr(grp, key):
            setattr(grp, key, val)


SB_PRESET_ALIASES = {
    "Hair - Short":    "Hair",
    "Hair - Medium":   "Hair",
    "Hair - Long":     "Hair",
    "Hair - Ponytail": "Hair",
    "Hair - Bangs":    "Hair",
    "Hair - Loose":    "Hair",
    "Clothes":         "Cloth - Shirt",
}

_SB_DEFAULT_EFFECTS = 'BOTH'


def resolve_preset_name(name):
    """Map a retired preset name onto the one that replaced it."""
    return SB_PRESET_ALIASES.get(name, name)


def preset_effects(scene, identifier):
    """Which spring(s) a preset drives -> ('ROT',) / ('LOC',) / ('LOC','ROT').
    None when it can't be resolved, so callers leave the toggles alone."""
    values = preset_values_from_id(scene, identifier)
    if not values:
        return None
    eff = values.get('_effects', _SB_DEFAULT_EFFECTS)
    if eff == 'ROT':
        return ('ROT',)
    if eff == 'LOC':
        return ('LOC',)
    return ('LOC', 'ROT')


def preset_values_from_id(scene, identifier):
    """Resolve a 'BUILTIN::name' / 'USER::name' identifier to a value dict,
    or None."""
    if identifier.startswith("BUILTIN::"):
        raw = identifier[len("BUILTIN::"):]
        return (SB_BUILTIN_PRESETS.get(raw)
                or SB_BUILTIN_PRESETS.get(resolve_preset_name(raw)))
    if identifier.startswith("USER::"):
        name = identifier[len("USER::"):]
        for up in scene.sb_user_presets:
            if up.name == name:
                d = {k: getattr(up, k) for k in SB_PARAM_KEYS}
                d['_effects'] = getattr(up, 'sb_effects', _SB_DEFAULT_EFFECTS)
                return d
    return None


def _is_favorite(scene, identifier):
    return any(f.name == identifier for f in scene.sb_preset_favorites)


# Blender does NOT keep references to the strings a dynamic enum callback
# returns — if Python garbage-collects them the dropdown shows corrupted
# entries (and assigning by identifier fails). Stash the last list here so
# every string stays alive for as long as the enum can reference it.
_enum_items_cache = []


def _preset_enum_items(self, context):
    """Dropdown items: favorites first (★), then built-ins, then user
    presets (marked with a bullet)."""
    scn = context.scene if context else bpy.context.scene
    items = [("NONE", "Choose Preset…", "Pick a preset to apply to this group")]
    if scn is None:
        return items

    favs, builtins, users = [], [], []
    for name in SB_BUILTIN_PRESETS:
        ident = f"BUILTIN::{name}"
        entry = (ident, name, f"Apply the {name} preset")
        (favs if _is_favorite(scn, ident) else builtins).append(entry)
    for up in scn.sb_user_presets:
        ident = f"USER::{up.name}"
        entry = (ident, f"• {up.name}", "User preset")
        (favs if _is_favorite(scn, ident) else users).append(entry)

    for ident, label, desc in favs:
        items.append((ident, f"★ {label}", desc))
    items.extend(builtins)
    items.extend(users)

    # keep the strings referenced (see note above) and return the cached list
    _enum_items_cache.clear()
    _enum_items_cache.extend(items)
    return _enum_items_cache


def _force_group_effects(grp, context, want_loc, want_rot):
    """Set the group's effect toggles AND push them onto the member bones.

    Assigning a property its current value does not fire its update callback,
    so relying on `grp.enable_rot = True` alone silently does nothing whenever
    the toggle already reads True while the bones are off -- which is exactly
    the state Remove Physics leaves behind. Propagate explicitly instead.
    """
    from . import properties as _props
    grp.enable_loc = want_loc
    grp.enable_rot = want_rot
    ctx = context or bpy.context
    _props._group_propagate_effect(grp, ctx, 'sb_bone_spring_loc', want_loc)
    _props._group_propagate_effect(grp, ctx, 'sb_bone_spring_rot', want_rot)


def _on_group_preset_selected(self, context):
    """Update callback when a group's preset dropdown changes."""
    sel = self.preset
    if not sel or sel == "NONE":
        return
    scn = context.scene if context else bpy.context.scene
    values = preset_values_from_id(scn, sel)
    if values:
        _apply_preset_values(self, values)
        # a preset also declares WHICH springs it drives, so picking "Hair"
        # turns rotation on and location off across the group instead of
        # leaving whatever happened to be set before.
        eff = preset_effects(scn, sel)
        if eff is not None:
            _force_group_effects(self, context,
                                 'LOC' in eff, 'ROT' in eff)


# ------------------------------------------------------------------ #
#  OPERATORS
# ------------------------------------------------------------------ #

class SB_OT_preset_save(bpy.types.Operator):
    """Save the active group's current parameters as a new user preset"""
    bl_idname = "sb.preset_save"
    bl_label = "Save Preset"
    bl_options = {'REGISTER', 'UNDO'}

    name: bpy.props.StringProperty(name="Preset Name", default="My Preset")
    group_index: bpy.props.IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        return len(context.scene.sb_bone_groups) > 0

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        scene = context.scene
        idx = self.group_index if self.group_index >= 0 else scene.sb_active_group_index
        if not (0 <= idx < len(scene.sb_bone_groups)):
            self.report({'WARNING'}, "Group not found.")
            return {'CANCELLED'}
        grp = scene.sb_bone_groups[idx]

        base = self.name.strip() or "My Preset"
        existing = {up.name for up in scene.sb_user_presets}
        name = base
        idx = 1
        while name in existing:
            idx += 1
            name = f"{base}.{idx:03d}"

        up = scene.sb_user_presets.add()
        up.name = name
        for k in SB_PARAM_KEYS:
            setattr(up, k, getattr(grp, k))
        if grp.enable_loc and grp.enable_rot:
            up.sb_effects = 'BOTH'
        elif grp.enable_rot:
            up.sb_effects = 'ROT'
        elif grp.enable_loc:
            up.sb_effects = 'LOC'
        else:
            up.sb_effects = 'BOTH'
        self.report({'INFO'}, f"Saved preset '{name}'")
        return {'FINISHED'}


class SB_OT_preset_delete(bpy.types.Operator):
    """Delete a saved user preset"""
    bl_idname = "sb.preset_delete"
    bl_label = "Delete User Preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset_name: bpy.props.StringProperty(default="")

    @classmethod
    def poll(cls, context):
        return len(context.scene.sb_user_presets) > 0

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop_search(self, "preset_name", context.scene, "sb_user_presets", text="Preset")

    def execute(self, context):
        scene = context.scene
        for i, up in enumerate(scene.sb_user_presets):
            if up.name == self.preset_name:
                scene.sb_user_presets.remove(i)
                # drop a stale favorite entry, if any
                ident = f"USER::{self.preset_name}"
                for j, f in enumerate(scene.sb_preset_favorites):
                    if f.name == ident:
                        scene.sb_preset_favorites.remove(j)
                        break
                self.report({'INFO'}, f"Deleted preset '{self.preset_name}'")
                return {'FINISHED'}
        self.report({'WARNING'}, "Preset not found")
        return {'CANCELLED'}


class SB_OT_preset_rename(bpy.types.Operator):
    """Rename a saved user preset (built-in presets can't be renamed)"""
    bl_idname = "sb.preset_rename"
    bl_label = "Rename User Preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset_name: bpy.props.StringProperty(name="Preset", default="")
    new_name:    bpy.props.StringProperty(name="New Name", default="")

    @classmethod
    def poll(cls, context):
        return len(context.scene.sb_user_presets) > 0

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop_search(self, "preset_name", context.scene, "sb_user_presets", text="Preset")
        layout.prop(self, "new_name")

    def execute(self, context):
        scene = context.scene
        new = self.new_name.strip()
        if not new:
            self.report({'WARNING'}, "New name is empty.")
            return {'CANCELLED'}
        if any(up.name == new for up in scene.sb_user_presets):
            self.report({'WARNING'}, f"A preset named '{new}' already exists.")
            return {'CANCELLED'}
        for up in scene.sb_user_presets:
            if up.name == self.preset_name:
                old_ident = f"USER::{up.name}"
                up.name = new
                # keep the favorite flag attached through the rename
                for f in scene.sb_preset_favorites:
                    if f.name == old_ident:
                        f.name = f"USER::{new}"
                        break
                self.report({'INFO'}, f"Renamed to '{new}'")
                return {'FINISHED'}
        self.report({'WARNING'}, "Preset not found")
        return {'CANCELLED'}


class SB_OT_preset_favorite(bpy.types.Operator):
    """Mark / unmark the group's currently selected preset as a favorite.
    Favorites are listed first (★) in the preset dropdown"""
    bl_idname = "sb.preset_favorite"
    bl_label = "Toggle Favorite"
    bl_options = {'REGISTER', 'UNDO'}

    group_index: bpy.props.IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        return len(context.scene.sb_bone_groups) > 0

    def execute(self, context):
        scene = context.scene
        idx = self.group_index if self.group_index >= 0 else scene.sb_active_group_index
        if not (0 <= idx < len(scene.sb_bone_groups)):
            self.report({'WARNING'}, "Group not found.")
            return {'CANCELLED'}
        grp = scene.sb_bone_groups[idx]
        ident = grp.preset
        if ident == "NONE":
            self.report({'WARNING'}, "Pick a preset first.")
            return {'CANCELLED'}
        for i, f in enumerate(scene.sb_preset_favorites):
            if f.name == ident:
                scene.sb_preset_favorites.remove(i)
                self.report({'INFO'}, "Removed from favorites.")
                return {'FINISHED'}
        f = scene.sb_preset_favorites.add()
        f.name = ident
        self.report({'INFO'}, "Marked as favorite ★")
        return {'FINISHED'}


classes = (
    SB_OT_preset_save,
    SB_OT_preset_delete,
    SB_OT_preset_rename,
    SB_OT_preset_favorite,
)


def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)


def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
