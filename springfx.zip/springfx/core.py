# SpringFX — core.py
# The simulation engine: physics, frame handlers, colliders, geometry,
# setup/teardown of helpers, runtime state and the viewport overlay.
# No UI code lives here; panels/operators import from this module.

import bpy, time
import sys
import contextlib
import numpy as np
import math
from bpy.app.handlers import persistent
from mathutils import Vector, Matrix, Quaternion, Euler
from mathutils.bvhtree import BVHTree

try:
    import numpy
    from numpy import dot
except Exception:          # numpy is bundled with Blender, but stay safe
    numpy = None
from math import sqrt


# ================================================================== #
#  UTILITIES
# ================================================================== #

def get_pose_bone(name):
    try:
        return bpy.context.object.pose.bones[name]
    except Exception:
        return None


def lerp_vec(vec_a, vec_b, t):
    return vec_a * t + vec_b * (1 - t)


def relative_matrix(m1, m2):
    """Return m2 expressed in m1's space (borrowed from Wiggle 2)."""
    return (m2.inverted() @ m1).inverted()


def _smooth_noise_1d(t, seed):
    """Smooth, continuous pseudo-noise in roughly [-1, 1] as a function of time.
    Sums a few sine waves at incommensurate frequencies so the result looks
    organic and non-repeating rather than a single obvious sine. `seed` shifts
    the phases so different bones move independently."""
    s = seed * 12.9898
    return (
        0.55 * math.sin(t * 1.0 + s)
        + 0.30 * math.sin(t * 2.17 + s * 1.7 + 1.3)
        + 0.15 * math.sin(t * 4.31 + s * 0.9 + 2.6)
    )


def _noise_vector(frame, speed, seed, channel):
    """A smooth 3D noise vector (each component in ~[-1, 1]) evolving with the
    timeline. `channel` offsets loc vs rot so they don't move identically."""
    t = frame * 0.15 * max(speed, 0.0)
    base = seed * 7 + channel * 31
    return Vector((
        _smooth_noise_1d(t,        base + 1),
        _smooth_noise_1d(t + 11.0, base + 2),
        _smooth_noise_1d(t + 23.0, base + 3),
    ))


def flatten(mat):
    dim = len(mat)
    return [mat[j][i] for i in range(dim) for j in range(dim)]


# ================================================================== #
#  PARAMETER RESOLUTION (group vs per-bone)
# ================================================================== #

def get_bone_group(scene, group_name):
    for grp in scene.sb_bone_groups:
        if grp.name == group_name:
            return grp
    return None


def resolve_param(scene, pose_bone, attr):
    grp_name = pose_bone.sb_group
    if grp_name and grp_name != "NONE":
        grp = get_bone_group(scene, grp_name)
        if grp is not None and grp.drive_params and hasattr(grp, attr):
            return getattr(grp, attr)
    return getattr(pose_bone, attr)


def resolve_noise_param(scene, pose_bone, attr):
    """Noise is a group-level *feature* (added after creating a group), so when
    a bone belongs to a group whose noise is enabled, the group's noise settings
    win regardless of drive_params. Otherwise fall back to the bone's own."""
    grp_name = pose_bone.sb_group
    if grp_name and grp_name != "NONE":
        grp = get_bone_group(scene, grp_name)
        if grp is not None and grp.sb_noise_enable and hasattr(grp, attr):
            return getattr(grp, attr)
    return getattr(pose_bone, attr)


# ================================================================== #
#  ROTATION SPRING — Wiggle-2-style direct matrix simulation
# ================================================================== #
# Instead of empties + constraints, the rotation spring simulates a
# world-space target point at the bone's tail. Each frame the bone is
# reset to its animated rest pose, the simulated point lags behind with
# spring inertia, and we derive the bone rotation that aims Y toward that
# lagging point — then write it straight into b.matrix. This is the exact
# approach Wiggle 2 uses and it does not fight the rig or lose parenting.

def _bone_rest_matrix_world(pose_bone):
    """World matrix of the bone at its CLEAN animated pose.
    Because the rotation handler resets rotation_quaternion in the pre-frame
    handler before the rig evaluates, pose_bone.matrix here reflects the
    animation/parent only, with NO spring rotation fed back in."""
    return pose_bone.id_data.matrix_world @ pose_bone.matrix


def _rot_tail_world(mat_world, length):
    return mat_world @ Vector((0, length, 0))


# ================================================================== #
#  ROTATION CHANNEL I/O — rotation-mode aware  (v8.0.2, _SB_ROTMODE_PATCH_V1)
# ================================================================== #
# A pose bone keeps its LOCAL rotation in one of three mutually exclusive
# channels and Blender evaluates only the one that matches
# pose_bone.rotation_mode:
#
#     'QUATERNION'  -> rotation_quaternion   (w, x, y, z)
#     'AXIS_ANGLE'  -> rotation_axis_angle   (angle, x, y, z)
#     'XYZ' ...     -> rotation_euler        (x, y, z)
#
# The other two are stored but IGNORED. That is why the batched writes below
# used to be silent no-ops on rigs imported from DAZ / Genesis / Mixamo,
# which arrive in Euler mode: the springs solved correctly, the quaternions
# were written correctly, and nothing moved on screen until a bake — because
# only the bake operator flipped the bones to quaternion mode first.
#
# Every realtime rotation write in this module now goes through these three
# helpers, so a spring behaves identically in every rotation mode.


def _sb_read_local_rot(pose_bone):
    """The bone's current LOCAL rotation as a Quaternion, whatever its mode."""
    mode = pose_bone.rotation_mode
    if mode == 'QUATERNION':
        return Quaternion(pose_bone.rotation_quaternion)
    if mode == 'AXIS_ANGLE':
        aa = pose_bone.rotation_axis_angle
        axis = Vector((aa[1], aa[2], aa[3]))
        if axis.length_squared < 1e-12:
            return Quaternion()
        return Quaternion(axis, aa[0])
    return pose_bone.rotation_euler.to_quaternion()


def _sb_write_local_rot(pose_bone, quat):
    """Write an absolute LOCAL rotation into the channel the bone evaluates."""
    mode = pose_bone.rotation_mode
    if mode == 'QUATERNION':
        pose_bone.rotation_quaternion = quat
    elif mode == 'AXIS_ANGLE':
        axis, angle = quat.to_axis_angle()
        pose_bone.rotation_axis_angle = (angle, axis.x, axis.y, axis.z)
    else:
        # to_euler(order, reference) returns the compatible solution closest
        # to what is already in the channel, so a swing crossing a gimbal
        # boundary does not jump by 2*pi between two frames.
        pose_bone.rotation_euler = quat.to_euler(mode, pose_bone.rotation_euler)


def _sb_apply_local_swing(pose_bone, swing):
    """Compose a bone-LOCAL swing onto the bone's CLEAN local rotation.

    Equivalent to `pose_bone.matrix = pose_bone.matrix @ swing` for the
    rotation part, but writing the local channel directly is better on three
    counts: it works in every rotation mode, it never contaminates the
    location channel (the matrix setter decomposes into loc+rot+scale), and
    it does not read the parent's pose matrix — which, mid-chain, is still
    one depsgraph evaluation behind.
    """
    _sb_write_local_rot(pose_bone, _sb_read_local_rot(pose_bone) @ swing)


@persistent
def spring_bone_pre(scene):
    """Before the rig evaluates each frame, restore rotation-spring bones to
    their base pose (custom pose / animation) so the simulation reads a clean
    pose with no spring feedback, and runs ON TOP of whatever pose is set.

    Also decides — for BOTH handlers — whether this whole frame is skipped
    by the Update Rate throttle: when skipping, the reset must NOT run
    either, or the bones would snap to their springless pose for one frame."""
    global _sb_skip_frame
    if not len(scene.sb_spring_bones):
        return
    # SUBFRAME GUARD (v7.3.3): Eevee's motion blur steps the scene time to
    # FRACTIONAL frames several times per rendered frame, firing this handler
    # from the render thread while the UI thread keeps drawing. Writing pose
    # data during those extra evaluations both corrupts the whole-frame
    # simulation stepping and races the threaded depsgraph — observed as an
    # EXCEPTION_ACCESS_VIOLATION in mesh_batch_cache_clear under
    # eevee::MotionBlurModule::init during RE_RenderAnim. The springs advance
    # ONLY on whole frames; subframe steps reuse the already-written pose.
    if getattr(scene, "frame_subframe", 0.0) != 0.0:
        return
    global _sb_skip_state
    try:
        rate = getattr(scene, 'sb_update_rate', 1)
        _sb_skip_frame = (rate > 1 and not _sb_bake_mode
                          and _sb_playback_active()
                          and scene.frame_current % rate != 0)
        if _sb_skip_frame:
            return
        # v8.0: in mode 1 the compiled core rebuilds each driven bone's clean
        # pose itself, so there is nothing to restore -- and skipping the
        # write is worth ~0.12 ms/frame, because a foreach_set on the
        # rotation channel costs that much of Blender-side work even when it
        # writes byte-identical values. _sb_native_skip_restore() is False
        # for anything the reconstruction does not model.
        #
        # Nothing reads the skip state in that configuration either (the
        # per-bone loop is what consults it, and it does not run), so it is
        # parked at its neutral value rather than rebuilt every frame.
        if _sb_native_skip_restore() and (not _sb_has_loc or _sb_loc_all_native):
            _sb_skip_state = (frozenset(), None)
            return
        _sb_build_skip_state(scene)
        if not (_sb_use_xpbd and not _sb_solver_dirty
                and _sb_batch_capture_reset(scene)):
            _reset_rot_bones(scene)
    except Exception as e:
        _report_handler_error("spring_bone_pre", e)


# basefix3: cache of "does this pose bone have its OWN animation?" Keyed by
# (armature name, bone name). Cleared by _sb_base_pose_dirty().
_SB_ANIMATED_CH = {}


def _sb_bone_self_animated(armature, bone_name):
    """True if this pose bone's own rotation/location channels are driven by
    keyframes or drivers.

    Only such a bone needs its base pose re-read every frame. A bone that is
    moved purely by its PARENT (every hair/cloth chain) has a constant base,
    and re-reading it is what let the spring's own output become the new rest
    pose. Result is cached: this walks the action once per bone, not per frame.
    """
    key = (armature.name, bone_name)
    hit = _SB_ANIMATED_CH.get(key)
    if hit is not None:
        return hit
    prefix = 'pose.bones["%s"].' % bone_name
    wanted = ("rotation_quaternion", "rotation_euler",
              "rotation_axis_angle", "location")
    found = False
    ad = armature.animation_data
    if ad is not None:
        for drv in ad.drivers:
            dp = drv.data_path
            if dp.startswith(prefix) and dp[len(prefix):] in wanted:
                found = True
                break
        act = ad.action
        if not found and act is not None:
            fcurves = []
            # Blender 4.4+/5.x layered actions: layers -> strips -> channelbags
            layers = getattr(act, "layers", None)
            if layers:
                for layer in layers:
                    for strip in layer.strips:
                        for cb in getattr(strip, "channelbags", ()):
                            fcurves.extend(cb.fcurves)
            else:
                fcurves = list(getattr(act, "fcurves", ()))
            for fc in fcurves:
                dp = fc.data_path
                if dp.startswith(prefix) and dp[len(prefix):] in wanted:
                    found = True
                    break
    _SB_ANIMATED_CH[key] = found
    return found


def _capture_rot_base(scene):
    """Capture each rotation-spring bone's CURRENT rotation as its base pose.
    Call this when the channel holds the pure posed/animated value (e.g. right
    after frame_set, before any spring write this frame)."""
    for bone in scene.sb_spring_bones:
        if bone.sb_bone_collider:
            continue
        armature = _sb_armature_of(bone)
        if armature is None:
            continue
        pose_bone = armature.pose.bones.get(bone.name)
        if pose_bone is None:
            continue
        # basefix3: a bone with no animation of its own has a base pose that
        # never changes. Re-reading the channel here is unsafe -- this runs in
        # frame_change_post and fires whenever the solver is dirty (i.e. right
        # after ANY slider move), at which point the channel can still hold
        # the spring's own output. That is what latched a bent pose as the new
        # rest pose and produced the permanent lean + exaggerated swing.
        # basefix4: skip unconditionally, not "only if rot_base_set". That
        # flag is cleared and re-set by the rebuild/restore round-trip, so it
        # is False for long stretches while a valid base IS in use -- gating
        # on it let this recapture through anyway. A bone with no animation of
        # its own has a constant base; it is captured (once, guarded) by
        # _sb_batch_capture_reset / update_bone, and must never be re-read
        # here, where the channel can hold the spring's own output.
        if not _sb_bone_self_animated(armature, bone.name):
            continue
        if pose_bone.sb_bone_spring_rot:
            if pose_bone.rotation_mode == 'QUATERNION':
                bone.rot_base_quat = pose_bone.rotation_quaternion[:]
            else:
                bone.rot_base_quat = pose_bone.rotation_euler.to_quaternion()[:]
            # the rot spring writes pose_bone.matrix, which also decomposes
            # into the LOCATION channel — capture its clean base too so both
            # channels can be restored exactly (per frame and on removal)
            bone.loc_base = pose_bone.location[:]
            bone.rot_base_set = True


def _reset_rot_bones(scene):
    """Restore each rotation-spring bone to its BASE pose rotation (the user's
    custom pose / animation) before the rig evaluates, so the simulation reads
    a clean pose WITHOUT the previous frame's spring rotation fed back in.

    Crucially we reset to the stored base pose, NOT to identity — that's what
    lets the simulation run on top of any custom pose instead of snapping the
    bones back to rest."""
    touched = False
    for bone in scene.sb_spring_bones:
        if bone.sb_bone_collider:
            continue
        armature = _sb_armature_of(bone)
        if armature is None:
            continue
        pose_bone = armature.pose.bones.get(bone.name)
        if pose_bone is None:
            continue
        if _sb_bone_skipped(scene, bone, armature, pose_bone):
            continue        # frozen: keep the last spring pose in the channel
        if pose_bone.sb_bone_spring_rot and bone.rot_base_set:
            if pose_bone.rotation_mode == 'QUATERNION':
                pose_bone.rotation_quaternion = Quaternion(bone.rot_base_quat)
            else:
                pose_bone.rotation_euler = Quaternion(bone.rot_base_quat).to_euler(
                    pose_bone.rotation_mode)
            # the matrix write also contaminated the location channel —
            # restore it so unkeyed locations never accumulate spring offset
            pose_bone.location = Vector(bone.loc_base)
            touched = True
    # NOTE (v7.3): the historic view_layer.update() here forced a FULL extra
    # depsgraph evaluation every frame — the single most expensive line in
    # the addon on heavy rigs. It is redundant in the frame-change flow: the
    # pre handler runs BEFORE the frame's own evaluation, which already picks
    # up the channel writes above. Kept behind a debug flag just in case a
    # future Blender changes that ordering.
    if touched and _SB_PRE_VIEW_UPDATE:
        bpy.context.view_layer.update()


# Debug/back-compat flag for the extra pre-handler depsgraph update above.
_SB_PRE_VIEW_UPDATE = False


@persistent
def spring_bone_frame_mode(scene):
    # ALWAYS-ON: the simulation runs whenever the timeline advances and there
    # are spring bones configured. No modes, no start/stop buttons — enabling
    # a spring on a bone is all it takes; press play and it simulates.
    global _sb_perf_ms
    if not len(scene.sb_spring_bones):
        return
    # subframe guard — see spring_bone_pre for the full rationale (v7.3.3)
    if getattr(scene, "frame_subframe", 0.0) != 0.0:
        return
    if _sb_skip_frame:
        return              # Update Rate throttle (pre handler decided)
    try:
        t0 = time.perf_counter()
        # capture the freshly-evaluated animated pose as the base, then apply
        # the spring on top — this keeps animated bones tracking their keyframes
        if not (_sb_use_xpbd and _sb_chains and not _sb_solver_dirty):
            _capture_rot_base(scene)
        spring_bone(bpy.context)
        ms = (time.perf_counter() - t0) * 1000.0
        # exponential moving average keeps the readout steady
        _sb_perf_ms = ms if _sb_perf_ms == 0.0 else _sb_perf_ms * 0.9 + ms * 0.1
    except Exception as e:
        _report_handler_error("spring_bone_frame_mode", e)


# Error reporting for frame handlers: an exception inside a handler would
# otherwise spam the console every frame. Print the full traceback ONCE per
# session per handler, then stay silent (the sim keeps trying each frame).
_sb_handler_errors = set()


def _report_handler_error(where, exc):
    if where in _sb_handler_errors:
        return
    _sb_handler_errors.add(where)
    import traceback
    print(f"[SpringFX] error in {where} (reported once): {exc}")
    traceback.print_exc()


# ================================================================== #
#  PERFORMANCE / QUALITY (v7.3)
# ================================================================== #
# One dial controls how much physics accuracy costs per frame:
#   substep_base   — minimum physics substeps per frame step
#   substep_target — accuracy target in rad of spring phase per substep
#                    (smaller = more substeps for stiff springs)
#   substep_cap    — hard ceiling on substeps
#   citer_mult     — multiplies the collision resolve iterations
# HIGH reproduces the pre-7.3 behavior exactly.
_SB_QUALITY_PARAMS = {
    'LOW':    dict(substep_base=1, substep_target=0.90, substep_cap=12, citer_mult=0.5),
    'MEDIUM': dict(substep_base=2, substep_target=0.50, substep_cap=24, citer_mult=1.0),
    'HIGH':   dict(substep_base=4, substep_target=0.30, substep_cap=96, citer_mult=1.0),
    'ULTRA':  dict(substep_base=8, substep_target=0.15, substep_cap=192, citer_mult=2.0),
}

# Rolling performance stats shown in the panel (module-level, no scene writes
# from handlers — writing IDs from a frame handler would re-trigger updates).
_sb_perf_ms = 0.0          # exponential moving average of sim time per frame
_sb_perf_bones = 0         # bones simulated last frame
_sb_perf_skipped = 0       # bones skipped last frame (hidden / far / rate)

# Set by the PRE handler each frame; the POST handler honors it. Both must
# agree, otherwise the pre-reset would snap rot-spring bones to their base
# pose on frames the simulation skips.
_sb_skip_frame = False
# Per-frame skip context shared pre->post: (hidden_armatures, view_origin)
_sb_skip_state = (frozenset(), None)

# When a bake (or render) is running we force full quality and no skipping;
# operators toggle this via set_bake_mode().
_sb_bake_mode = False


def set_bake_mode(value):
    global _sb_bake_mode
    _sb_bake_mode = bool(value)
    invalidate_cache()      # bake resets state and strips springs


def get_perf_stats():
    """(ms_per_frame, simulated_bones, skipped_bones) for the UI readout."""
    return _sb_perf_ms, _sb_perf_bones, _sb_perf_skipped


def _sb_quality(scene):
    """Effective quality parameters for THIS evaluation. Bake/render use the
    dedicated render quality regardless of the viewport setting."""
    if _sb_bake_mode:
        q = getattr(scene, 'sb_render_quality', 'HIGH')
    else:
        q = getattr(scene, 'sb_quality', 'HIGH')
    p = dict(_SB_QUALITY_PARAMS.get(q, _SB_QUALITY_PARAMS['HIGH']))
    override = getattr(scene, 'sb_substeps_override', 0)
    if override > 0 and not _sb_bake_mode:
        p['substep_base'] = override
        p['substep_cap'] = max(p['substep_cap'], override)
    return p


def _sb_playback_active():
    """True while the viewport is actually PLAYING animation (not scrubbing,
    not baking, not rendering). Handlers can run without a screen (render /
    background) — treat that as not playing."""
    try:
        scr = bpy.context.screen
        return bool(scr is not None and scr.is_animation_playing)
    except Exception:
        return False


def _sb_view_origin():
    """World-space origin of the active 3D viewport, or None when there is
    no viewport (render, background)."""
    try:
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                r3d = area.spaces.active.region_3d
                if r3d is not None:
                    return r3d.view_matrix.inverted().translation
    except Exception:
        pass
    return None


_SB_ARM_NAMES = None            # cached armature names for the skip test


def _sb_skip_armatures(scene):
    """Every distinct armature driven by the spring-bone list.

    Cached by NAME and re-resolved through bpy.data each call: caching the
    objects themselves would survive an undo that has already freed them.
    """
    global _SB_ARM_NAMES
    if _SB_ARM_NAMES is None:
        seen = []
        for it in scene.sb_spring_bones:
            a = _sb_armature_of(it)
            if a is not None and a.name not in seen:
                seen.append(a.name)
        _SB_ARM_NAMES = tuple(seen)
    objs = bpy.data.objects
    out = []
    for nm in _SB_ARM_NAMES:
        o = objs.get(nm)
        if o is not None:
            out.append(o)
    return out


def _sb_build_skip_state(scene):
    """Per-frame context for Skip Hidden / Skip Far, computed ONCE in the pre
    handler and reused by the post handler. During bake/render nothing is
    ever skipped."""
    global _sb_skip_state
    if _sb_bake_mode:
        _sb_skip_state = (frozenset(), None)
        return
    hidden = frozenset()
    if getattr(scene, 'sb_skip_hidden', False):
        names = set()
        # v8.0: ask each ARMATURE once, not once per spring bone. On a 24-bone
        # rig this was 24 _sb_armature_of() resolutions per frame to answer a
        # question with one distinct answer. Names (not object references) are
        # cached, so an undo that reallocates the object cannot leave a stale
        # pointer here. 0.069 -> 0.004 ms/frame.
        for arm in _sb_skip_armatures(scene):
            try:
                if not arm.visible_get():
                    names.add(arm.name)
            except Exception:
                pass
        hidden = frozenset(names)
    origin = None
    if getattr(scene, 'sb_skip_far', False):
        origin = _sb_view_origin()
    _sb_skip_state = (hidden, origin)


def _sb_bone_skipped(scene, item, armature, pose_bone):
    """Shared skip predicate (pre reset + post simulate must agree). Skipped
    bones FREEZE at their last simulated pose instead of snapping to rest.

    Only the ARMATURE's visibility counts. An individually hidden bone
    (bone.hide) still DEFORMS the visible mesh — riggers hide helper deform
    bones like pectorals all the time — so its physics must keep running.
    (v7.3.0 skipped those too, which silently froze hidden spring bones.)"""
    hidden, origin = _sb_skip_state
    if armature.name in hidden:
        return True
    if origin is not None:
        head_w = armature.matrix_world @ pose_bone.head
        if (head_w - origin).length > getattr(scene, 'sb_far_distance', 50.0):
            return True
    return False


# ================================================================== #
#  PHYSICS CORE — critically-dampable spring-mass-damper
# ================================================================== #
# A real spring-damper gives natural, organic motion (the kind soft tissue
# like breasts has). The motion is governed by:
#     a = k*(target - pos) - c*vel      (Hooke's law + viscous damping)
# We integrate semi-implicitly with sub-steps so high stiffness stays stable
# and the result is framerate-independent and smooth.

SUBSTEPS = 4  # sub-steps per frame: more = smoother & more stable

def _sb_speed_freq_mult(stiffness, speed, dt):
    """Effective frequency multiplier for the Speed slider, SHARED by the
    physics (simulate_spring_point) and the amplitude compensation in
    spring_bone so they always match.

    Speed raises the spring's natural frequency (faster settle, snappier).
    BUT: at a given frame rate there is a hard visual limit — once the
    oscillation period drops below ~6 frames, per-frame sampling aliases the
    motion into ugly random-looking zigzag. So the multiplier is capped so the
    EFFECTIVE frequency never exceeds ~1 rad/frame (period >= ~6.3 frames)."""
    if speed <= 0.0:
        return 1.0
    k_base = 40.0 + stiffness * 500.0
    omega_base = math.sqrt(k_base)
    desired = 1.0 + speed * 2.0          # up to 3x faster
    omega_cap = 1.0 / max(dt, 1e-6)      # ~1 rad/frame -> period ~6.3 frames
    cap = omega_cap / max(omega_base, 1e-6)
    if cap < 1.0:
        cap = 1.0                        # never slow a spring below base
    return min(desired, cap)


def _sb_rot_speed_stiffness(eff, speed, dt):
    """rotspeed: fold the rotation Speed slider into the effective stiffness.

    Speed is a pure FREQUENCY boost: k *= m^2. Both solvers derive k from the
    0..1 stiffness the same way (k = 40 + s*500) and set the damper to
    c = 2*sqrt(k)*(0.15 + damp), so scaling k leaves the damping RATIO
    untouched -- which is exactly what a frequency boost must do. Expressing
    Speed as a remapped stiffness therefore drives the compiled core too,
    without adding a slot to the C ABI.

    Ceiling: stiffness saturates at 1.0 (k = 540), so the usable boost shrinks
    as base stiffness rises -- ~2.6x at s=0.08, ~1.6x at s=0.35. The frame-rate
    aliasing cap in _sb_speed_freq_mult applies on top of that.
    """
    if speed <= 0.0:
        return eff
    m = _sb_speed_freq_mult(eff, speed, dt)
    k = (40.0 + eff * 500.0) * m * m
    return min(max((k - 40.0) / 500.0, 0.0), 1.0)


def simulate_spring_point(pos, vel, target, stiffness, damping, gravity_vec, dt,
                          speed=0.0, target_prev=None,
                          drag=0.0, axis_basis=None, axis_mult=None,
                          substep_base=SUBSTEPS, substep_target=0.30,
                          substep_cap=96):
    """Advance a point under a spring-damper toward a MOVING `target`.
    Returns (new_pos, new_vel). All vectors are mathutils.Vector.

    stiffness: 0..1 slider -> spring constant (frequency)
    damping:   0..1 slider -> damping ratio (1 = critically damped)
    speed:     0..1 slider -> extra frequency multiplier (smooth-capped)
    target_prev: the target's position on the PREVIOUS step. Enables the two
        things that make the motion read as real flesh instead of drag:
          1. RELATIVE damping — the damper acts on (vel - target_vel), i.e.
             against the body the flesh is attached to, not against the world.
             The deviation responds only to body ACCELERATION — flesh rides
             along at constant velocity and only lags/bounces when the body
             speeds up, slows down, or turns. That is natural inertia.
          2. The target moves THROUGH the substeps (linear) instead of sitting
             at its end position, so each physics substep chases where the
             body actually was.
        None = static target (relative damping degenerates to absolute).
    drag: 0..1 -> air resistance. Unlike the main damper (which is RELATIVE
        to the moving target), drag acts on the ABSOLUTE world velocity —
        this is exactly what air does to hair/cloth: it resists motion
        through the air regardless of what the body underneath is doing.
    axis_basis: optional (R, R_inv) pair of 3x3 matrices (bone local->world
        rotation and its inverse). When given together with axis_mult, the
        spring FORCE is scaled per LOCAL axis — anisotropic stiffness, e.g.
        cloth that swings freely forward/back but resists sideways stretch.
    axis_mult: per-axis stiffness multipliers (x, y, z) in bone local space.
    """
    k = 40.0 + stiffness * 500.0
    freq_mult = _sb_speed_freq_mult(stiffness, speed, dt)
    k *= freq_mult * freq_mult
    # damping scales with sqrt(k) -> constant damping RATIO across frequencies
    c = 2.0 * math.sqrt(k) * (0.15 + damping * 1.0)
    c_air = drag * 12.0

    # target velocity over this step (world units / second)
    if target_prev is not None and dt > 1e-9:
        v_t = (target - target_prev) * (1.0 / dt)
    else:
        v_t = Vector((0.0, 0.0, 0.0))
        target_prev = target

    aniso = axis_basis is not None and axis_mult is not None
    if aniso:
        R, R_inv = axis_basis
        ax, ay, az = axis_mult

    # v8.0.1: the spring is LINEAR, so it is solved rather than integrated.
    # Working relative to the moving target, e = pos - T(t), the system is
    #     e'' + C e' + K e = G,  C = c + air drag,  K = k,  G = g - c_air*v_T
    # which has a closed form. Semi-implicit Euler at the old default ran at
    # omega*dt ~ 0.58 with two substeps; the per-frame residual of that error
    # is high-frequency, which is exactly what a jerk metric picks up.
    # Measured on the bench: normalised jerk 0.2738 -> 0.1722, converging to
    # the same value 256 Euler substeps reach, at a fraction of the cost.
    if not aniso and _SB_OPT[0] > 0.5 and dt > 1e-12:
        C = c + c_air
        e = pos - target_prev
        ed = vel - v_t
        disc = C * C - 4.0 * k
        out_e = Vector((0.0, 0.0, 0.0))
        out_v = Vector((0.0, 0.0, 0.0))
        if disc < -1e-12:                      # underdamped
            al = 0.5 * C
            w = math.sqrt(k - 0.25 * C * C)
            ex = math.exp(-al * dt)
            ca, sa = math.cos(w * dt), math.sin(w * dt)
            for i in range(3):
                ss = (gravity_vec[i] - c_air * v_t[i]) / k
                u0 = e[i] - ss
                v0 = ed[i]
                out_e[i] = ex * (u0 * ca + ((v0 + al * u0) / w) * sa) + ss
                out_v[i] = ex * (v0 * ca
                                 - (w * u0 + (al / w) * (v0 + al * u0)) * sa)
        elif disc > 1e-12:                     # overdamped
            sq = math.sqrt(disc)
            l1, l2 = 0.5 * (-C + sq), 0.5 * (-C - sq)
            e1, e2 = math.exp(l1 * dt), math.exp(l2 * dt)
            for i in range(3):
                ss = (gravity_vec[i] - c_air * v_t[i]) / k
                u0 = e[i] - ss
                v0 = ed[i]
                q1 = (v0 - l2 * u0) / (l1 - l2)
                q2 = u0 - q1
                out_e[i] = q1 * e1 + q2 * e2 + ss
                out_v[i] = q1 * l1 * e1 + q2 * l2 * e2
        else:                                  # critically damped
            al = 0.5 * C
            ex = math.exp(-al * dt)
            for i in range(3):
                ss = (gravity_vec[i] - c_air * v_t[i]) / k
                u0 = e[i] - ss
                v0 = ed[i]
                out_e[i] = (u0 + (v0 + al * u0) * dt) * ex + ss
                out_v[i] = (v0 - al * (v0 + al * u0) * dt) * ex
        return out_e + target, out_v + v_t

    # Fallback: adaptive substepping. Enough steps to keep the spring phase
    # advance per substep under `substep_target` radians, bounded by the
    # quality floor and ceiling. Still used for anisotropic stiffness, which
    # is not a constant-coefficient system.
    omega = math.sqrt(k)
    substeps = max(substep_base, int(omega * dt / substep_target) + 1)
    if substeps > substep_cap:
        substeps = substep_cap
    sub_dt = dt / substeps
    for j in range(substeps):
        # target position advances linearly across the step
        t_frac = (j + 1) / substeps
        tgt = target_prev.lerp(target, t_frac)
        disp = tgt - pos
        if aniso:
            # scale the restoring force per LOCAL axis, then back to world
            dl = R_inv @ disp
            spring_acc = R @ Vector((dl.x * ax, dl.y * ay, dl.z * az)) * k
        else:
            spring_acc = disp * k
        accel = spring_acc - (vel - v_t) * c + gravity_vec
        if c_air > 0.0:
            accel -= vel * c_air
        vel = vel + accel * sub_dt
        pos = pos + vel * sub_dt
    return pos, vel


# ================================================================== #
#  WIND
# ================================================================== #

def _sb_wind_force(scene, frame):
    """World-space wind force for this frame, or None when wind is off.
    Turbulence adds smooth gusting (strength modulation) plus a small
    lateral component so the wind direction itself wavers organically."""
    if not getattr(scene, 'sb_wind_enable', False):
        return None
    strength = scene.sb_wind_strength
    if abs(strength) < 1e-9:
        return None
    d = Vector(scene.sb_wind_vector)
    if d.length < 1e-9:
        return None
    d.normalize()
    turb = scene.sb_wind_turbulence
    if turb > 0.0:
        n = _noise_vector(frame, scene.sb_wind_speed, 7, channel=2)
        gust = 1.0 + turb * 0.8 * n.x
        lateral = (n - d * n.dot(d)) * (turb * 0.5)
        return (d * gust + lateral) * strength
    return d * strength


# ================================================================== #
#  MAIN SIMULATION
# ================================================================== #

# Frame-rate-independent stepping state.
# The frame-change handler is called a DIFFERENT number of times depending on
# the playback sync mode: "Play Every Frame" fires once per frame, while
# "Frame Dropping" skips frames (fewer calls) to keep real-time. We track the
# last simulated frame and integrate exactly one physics step PER FRAME
# ELAPSED, so the result depends only on the frame number, never on how the
# handler was called. Play Every Frame, Frame Dropping and the bake match.
_sb_sim_last_frame = None
# Previous per-bone target positions, used to reconstruct the target's path
# across dropped frames (linear interpolation) so catch-up matches every-frame.
_sb_prev_target = {}
_sb_prev_rot_target = {}
# Lag (delayed target) smoothed state per bone, and output smoothing state.
_sb_lag_loc = {}
_sb_lag_rot = {}
_sb_smooth_loc = {}
_sb_smooth_rot = {}
# Never catch up more than this many frames in one call; a larger jump (scrub,
# loop-around, timeline jump) resets the sim instead of integrating a huge burst.
_SB_MAX_CATCHUP = 6


# ------------------------------------------------------------------ #
#  SIMULATION CACHE  (v7.4)
# ------------------------------------------------------------------ #
# The solver is stateful: before v7.4 the pose at frame N depended on the
# integration HISTORY, not on N alone. frame_change_post fires on every
# frame_set() -- including ones that do not change the frame -- so parking on
# a frame, jogging back and forth, or rendering out of order kept integrating
# forward. Measured on a 6-bone hair chain: 0.30 m of tip drift after 40
# re-evaluations of the same frame, 0.60 m after jogging 59<->60 twenty times.
#
# Two structures fix that, deliberately kept separate:
#
#   _sb_last_swing / _sb_last_out_pos
#       The pose we most recently WROTE, per bone. Tiny, always maintained.
#       Used when the solver decides not to step (delta == 0): spring_bone_pre
#       has already reset the bones to their base pose, so we must re-apply
#       this or the rig pops to its springless pose for that evaluation.
#
#   _sb_frame_cache
#       A full state snapshot per frame, so a BACKWARD scrub restores the
#       exact state that frame had instead of integrating across the
#       discontinuity. Capped and evictable; this is the optional one.
#
# Auto-invalidation: rather than wiring update= onto all 83 properties, the
# cache carries a fingerprint of everything that affects the result and drops
# itself when that changes. See _sb_param_signature().

_sb_last_swing = {}           # (arm_name, bone_name) -> (w, x, y, z)
_sb_last_out_pos = {}         # (arm_name, bone_name) -> (x, y, z)

_sb_frame_cache = {}          # frame:int -> {(arm_name, bone_name): snapshot}
_sb_xpbd_cache = {}
_sb_native_cache = {}       # frame -> compiled-core state snapshot
_SB_NATIVE_ONLY = object()  # marker: this frame's state lives in the C arrays


def _sb_scene_dt():
    """rotspeed: seconds per frame from the scene, for the Speed frequency cap."""
    scn = bpy.context.scene
    try:
        return scn.render.fps_base / max(scn.render.fps, 1)
    except Exception:
        return 1.0 / 24.0


def _sb_native_owns_all():
    """True when every spring on the scene is driven by the compiled core.

    A single LOCATION spring, or any rotation spring the compiled path
    rejected, sends the frame back to the full per-bone snapshot.
    """
    if not _sb_nat or _sb_nat_dirty:
        return False
    n = 0
    for st in _sb_solver_state:
        if st.loc_on:
            return False
        if st.rot_on:
            n += 1
    return n > 0 and n == sum(r.n_states for r in _sb_nat)           # frame:int -> {chain_key: (P_tuples, V_tuples)}
_sb_cache_signature = None    # fingerprint the cached frames were built with
_sb_cache_enabled = True
_SB_CACHE_MAX_FRAMES = 2000   # ceiling on cached frames; oldest evicted first
# Memory is bounded by bone-states, not frames: 120 bones x 120 frames is
# ~18 MB, so a frame-only cap would let a heavy rig eat hundreds of MB.
# ~1.3 KB per bone-state -> 50k entries is a ~64 MB budget.
_SB_CACHE_MAX_ENTRIES = 50000


def _sb_cache_key(bone):   # DEPRECATED: superseded by _sb_state_key
    """Cache key for a spring-bone entry.

    Includes the armature name: two rigs in one scene routinely share bone
    names (hair_00 on every character), and the legacy per-bone dicts below
    key on bone.name alone, which silently mixes their state.
    """
    return (bone.armature, bone.name)


def set_cache_enabled(value):
    """Enable/disable the frame cache (UI toggle). Disabling frees it."""
    global _sb_cache_enabled
    _sb_cache_enabled = bool(value)
    if not _sb_cache_enabled:
        invalidate_cache()


def invalidate_cache():
    """Drop every cached frame.

    Call whenever anything that changes the simulation result changes:
    physics parameters, colliders, chain structure, the driving animation or
    the spring-bone list itself.
    """
    global _sb_cache_signature
    _sb_frame_cache.clear()
    _sb_xpbd_cache.clear()
    _sb_native_cache.clear()
    _SB_ITEM_MAP.clear()
    _sb_base_pose_dirty()
    _sb_last_swing.clear()
    _sb_last_out_pos.clear()
    _sb_cache_signature = None


def get_cache_info():
    """(n_frames, first_frame, last_frame, n_bone_entries) for the UI."""
    if not _sb_frame_cache:
        return (0, None, None, 0)
    ks = _sb_frame_cache.keys()
    return (len(_sb_frame_cache), min(ks), max(ks),
            sum(len(v) for v in _sb_frame_cache.values()))


def _sb_param_signature(scene):
    """Fingerprint of every input that changes the simulation result.

    Computed only when a cache session STARTS and when a restore is attempted
    (both rare), never in the per-frame hot path. If it differs from the one
    the cache was built with, the cache is stale and gets dropped.
    """
    parts = [scene.render.fps, scene.render.fps_base,
             tuple(scene.gravity),
             getattr(scene, "sb_collision_enable", True),
             getattr(scene, "sb_collide_bounce", 0.0),
             getattr(scene, "sb_collide_friction", 0.5),
             getattr(scene, "sb_collide_iterations", 2),
             getattr(scene, "sb_self_collision_enable", False),
             getattr(scene, "sb_collide_use_physics_objects", True),
             getattr(scene, "sb_wind_enable", False),
             tuple(getattr(scene, "sb_wind_vector", (0.0, 0.0, 0.0))),
             getattr(scene, "sb_wind_strength", 0.0),
             getattr(scene, "sb_wind_turbulence", 0.0),
             getattr(scene, "sb_wind_speed", 1.0),
             getattr(scene, "sb_quality", "HIGH"),
             getattr(scene, "sb_substeps_override", 0)]
    for g in scene.sb_bone_groups:
        parts.append((g.name, g.drive_params, g.enable_loc, g.enable_rot,
                      g.sb_stiffness, g.sb_damp, g.sb_loc_speed, g.sb_gravity,
                      g.sb_loc_influence, g.sb_max_distance, g.sb_loc_range,
                      g.sb_rot_stiffness, g.sb_rot_damp, g.sb_rot_influence,
                      g.sb_rot_speed,
                      g.sb_rot_range, g.sb_air_drag, g.sb_wind_influence,
                      g.sb_smooth, g.sb_lag, g.sb_chain_falloff,
                      g.sb_auto_length, tuple(g.sb_stiff_axis),
                      g.sb_noise_enable, g.sb_noise_loc, g.sb_noise_rot,
                      g.sb_noise_speed, g.sb_noise_seed,
                      g.sb_collide_margin, g.sb_collide_stiffness,
                      g.sb_collide_damping, g.sb_collide_friction_mult,
                      g.sb_self_collision))
    for bone in scene.sb_spring_bones:
        arm = bpy.data.objects.get(bone.armature)
        pb = arm.pose.bones.get(bone.name) if arm is not None else None
        if pb is None:
            parts.append((bone.name, None))
            continue
        parts.append((bone.armature, bone.name, bone.sb_bone_collider,
                      bone.chain_depth, bone.chain_len,
                      pb.sb_bone_spring_loc, pb.sb_bone_spring_rot,
                      pb.sb_group, pb.sb_stiffness, pb.sb_damp,
                      pb.sb_loc_speed, pb.sb_gravity, pb.sb_loc_influence,
                      pb.sb_max_distance, pb.sb_loc_range,
                      pb.sb_rot_stiffness, pb.sb_rot_damp, pb.sb_rot_speed,
                      pb.sb_rot_influence, pb.sb_rot_range,
                      pb.sb_air_drag, pb.sb_wind_influence, pb.sb_smooth,
                      pb.sb_lag, pb.sb_chain_falloff, pb.sb_auto_length,
                      tuple(pb.sb_stiff_axis), pb.sb_lock_axis,
                      pb.sb_collide, pb.sb_colliding_dist,
                      pb.sb_include_only, pb.sb_collide_exclude,
                      pb.sb_collide_margin, pb.sb_collide_stiffness,
                      pb.sb_collide_damping, pb.sb_collide_friction_mult,
                      pb.sb_self_collision,
                      pb.sb_noise_enable, pb.sb_noise_loc, pb.sb_noise_rot,
                      pb.sb_noise_speed, pb.sb_noise_seed,
                      round(pb.bone.length, 6)))
    for o in scene.objects:
        if getattr(o, "sb_object_collider", False) or _sb_obj_has_physics_collision(o):
            # AUTHORED collider settings only -- deliberately NOT the world
            # matrix. Colliders are normally parented to bones, so their
            # transform changes every frame by design; including it would
            # make the signature frame-dependent and the cache would never
            # match itself. Moving a collider by hand therefore needs an
            # explicit cache clear (see the Clear Cache operator).
            parts.append((o.name, o.sb_collider_shape, o.sb_collider_dist,
                          o.sb_collider_force,
                          o.sb_collider_use_own_response,
                          o.sb_collider_bounce, o.sb_collider_friction))
    return hash(repr(parts))


def _sb_dict_set(d, key, value):
    """Restore a per-bone Vector entry, or remove it when it was unset."""
    if value is None:
        d.pop(key, None)
    else:
        d[key] = Vector(value)


def _sb_cache_store_frame(scene, frame):
    """Snapshot the complete solver state for `frame`."""
    global _sb_cache_signature
    if not _sb_cache_enabled or _sb_bake_mode:
        return
    # v8.0 fast path: when the compiled core owns every spring and no bone
    # runs a LOCATION spring, its flat arrays already hold the complete
    # solver state. The per-bone snapshot below is ~10 RNA reads x 24 bones
    # per frame and was costing 0.30 ms/frame to duplicate state nothing
    # reads back. The native arrays are snapshotted separately, just below.
    if _sb_native_owns_all():
        _sb_frame_cache[frame] = _SB_NATIVE_ONLY
        if _sb_cache_signature is None:
            _sb_cache_signature = _sb_param_signature(scene)
        _sb_native_cache[frame] = _sb_native_snapshot()
        _sb_cache_evict(frame)
        return

    snap = {}
    for bone in scene.sb_spring_bones:
        if bone.sb_bone_collider:
            continue
        k = _sb_state_key(bone)
        n = k
        pt = _sb_prev_target.get(n)
        prt = _sb_prev_rot_target.get(n)
        ll = _sb_lag_loc.get(n)
        lr = _sb_lag_rot.get(n)
        sl = _sb_smooth_loc.get(n)
        sr = _sb_smooth_rot.get(n)
        snap[k] = (
            tuple(bone.speed), tuple(bone.loc_raw), bone.loc_raw_set,
            tuple(bone.rot_position), tuple(bone.rot_velocity),
            tuple(bone.rot_head_last), bone.rot_initialized,
            tuple(pt) if pt is not None else None,
            tuple(prt) if prt is not None else None,
            tuple(ll) if ll is not None else None,
            tuple(lr) if lr is not None else None,
            tuple(sl) if sl is not None else None,
            tuple(sr) if sr is not None else None,
            _sb_last_swing.get(k), _sb_last_out_pos.get(k),
        )
    if not snap:
        return
    if _sb_cache_signature is None:
        _sb_cache_signature = _sb_param_signature(scene)
    _SB_N_PER_FRAME[0] = max(len(snap), 1)
    _sb_frame_cache[frame] = snap
    _sb_xpbd_cache[frame] = {k: ([tuple(v) for v in P], [tuple(v) for v in _sb_xpbd_V[k]])
                             for k, P in _sb_xpbd_P.items()}
    _sb_native_cache[frame] = _sb_native_snapshot()
    _sb_cache_evict(frame)


def _sb_cache_evict(keep_frame):
    """Trim the cache to its frame and memory budgets.

    Evicts whichever cached frames are FURTHEST from the one just written, so
    the window follows the playhead instead of always dropping the beginning
    of the timeline (which is what a plain oldest-first policy does, and it
    throws away exactly the frames you scrub back to).
    """
    if (len(_sb_frame_cache) <= _SB_CACHE_MAX_FRAMES
            and len(_sb_frame_cache) * _SB_N_PER_FRAME[0] <= _SB_CACHE_MAX_ENTRIES):
        return
    ordered = sorted(_sb_frame_cache, key=lambda f: -abs(f - keep_frame))
    for f in ordered:
        if (len(_sb_frame_cache) <= _SB_CACHE_MAX_FRAMES
                and len(_sb_frame_cache) * _SB_N_PER_FRAME[0] <= _SB_CACHE_MAX_ENTRIES):
            break
        if f != keep_frame:
            del _sb_frame_cache[f]


_SB_N_PER_FRAME = [1]      # bone-states in the last snapshot (mutable holder)


def _sb_cache_restore_frame(scene, frame):
    """Restore the solver state saved for `frame`.

    Returns True only if EVERY active spring bone was present in the snapshot
    and the parameters still match. A partial restore would blend states from
    different frames, which is worse than a clean reset.
    """
    if not _sb_cache_enabled or _sb_bake_mode:
        return False
    snap = _sb_frame_cache.get(frame)
    if not snap:
        return False
    if _sb_cache_signature is not None:
        if _sb_param_signature(scene) != _sb_cache_signature:
            invalidate_cache()          # something changed; the cache is stale
            return False
    if snap is _SB_NATIVE_ONLY:
        ns = _sb_native_cache.get(frame)
        if ns is None:
            return False
        _sb_native_restore(ns)
        return True
    active = [b for b in scene.sb_spring_bones if not b.sb_bone_collider]
    if not active:
        return False
    for b in active:
        if _sb_state_key(b) not in snap:
            return False
    for bone in active:
        k = _sb_state_key(bone)
        n = k
        (speed, loc_raw, loc_raw_set,
         rot_pos, rot_vel, rot_head, rot_init,
         pt, prt, ll, lr, sl, sr, swing, outp) = snap[k]
        bone.speed = speed
        bone.loc_raw = loc_raw
        bone.loc_raw_set = loc_raw_set
        bone.rot_position = rot_pos
        bone.rot_velocity = rot_vel
        bone.rot_head_last = rot_head
        bone.rot_initialized = rot_init
        _sb_dict_set(_sb_prev_target, n, pt)
        _sb_dict_set(_sb_prev_rot_target, n, prt)
        _sb_dict_set(_sb_lag_loc, n, ll)
        _sb_dict_set(_sb_lag_rot, n, lr)
        _sb_dict_set(_sb_smooth_loc, n, sl)
        _sb_dict_set(_sb_smooth_rot, n, sr)
        if swing is not None:
            _sb_last_swing[k] = swing
        if outp is not None:
            _sb_last_out_pos[k] = outp
    xs = _sb_xpbd_cache.get(frame)
    if xs:
        for k, (Ps, Vs) in xs.items():
            _sb_xpbd_P[k] = [Vector(v) for v in Ps]
            _sb_xpbd_V[k] = [Vector(v) for v in Vs]
    ns = _sb_native_cache.get(frame)
    if ns is not None:
        _sb_native_restore(ns)
    return True


def _sb_reapply_last_pose(scene):
    """Re-write the last computed spring pose WITHOUT integrating.

    Mandatory on every no-step evaluation: spring_bone_pre already restored
    each rotation-spring bone to its base pose, so returning without writing
    would drop the swing and pop the rig for that evaluation.
    """
    # The compiled core keeps its swing in its own buffer rather than
    # publishing 24 tuples into _sb_last_swing every frame, so it replays
    # itself. Location springs still go through the loop below.
    _nat = _sb_native_reapply() if _sb_native_ok else False
    for bone in scene.sb_spring_bones:
        if bone.sb_bone_collider:
            continue
        armature = _sb_armature_of(bone)
        if armature is None:
            continue
        pose_bone = armature.pose.bones.get(bone.name)
        if pose_bone is None:
            continue
        k = _sb_state_key(bone, armature)
        if pose_bone.sb_bone_spring_loc:
            outp = _sb_last_out_pos.get(k)
            if outp is not None:
                emp_head, _ = _sb_loc_helpers(pose_bone, armature)
                if emp_head is not None:
                    emp_head.location = Vector(outp)
        if pose_bone.sb_bone_spring_rot and not _nat:
            q = _sb_last_swing.get(k)
            if q is not None:
                if pose_bone.rotation_mode == 'QUATERNION':
                    pose_bone.matrix = (pose_bone.matrix
                                        @ Quaternion(q).to_matrix().to_4x4())
                else:
                    # Euler / axis-angle: the matrix setter decomposes into a
                    # quaternion this bone does not evaluate, so the replay
                    # would be lost and the rig would pop on every scrub.
                    _sb_apply_local_swing(pose_bone, Quaternion(q))



# Guard to suspend the property-update callback during bulk flag changes
# (e.g. the bake disabling 20+ bones at once) so the list rebuild runs once.
_sb_update_suspended = False


def set_update_suspended(value):
    """Module-safe setter used by operators doing bulk property writes.

    Kept for backward compatibility. Prefer the sb_bulk() context manager:
    a bare True/.../False pair leaks the flag for the rest of the session if
    anything raises in between.
    """
    global _sb_update_suspended
    _sb_update_suspended = value


# Re-entrant bulk-edit depth, and whether a rebuild was requested while
# deferred. See sb_bulk().
_sb_bulk_depth = 0
_sb_bulk_dirty = False

# Viewport pre-roll: True while the next simulated frame still owes its
# settle pass. Set on every state reset, consumed once.
_sb_preroll_pending = True


@contextlib.contextmanager
def sb_bulk(force=False):
    """Defer the spring-bone list rebuild until the whole block is done.

    update_bone() runs from the update= callback of EVERY property, so
    enabling N bones fired N full rebuilds -- O(N^2) -- and printed two
    console lines per bone. Worse, each rebuild clears and re-adds
    scene.sb_spring_bones, so any code that writes properties WHILE iterating
    that collection corrupts its own loop mid-flight.

    Re-entrant and exception-safe: the rebuild still runs on the way out even
    if the block raises.

    force=True rebuilds on exit even if nothing requested one.
    """
    global _sb_bulk_depth, _sb_bulk_dirty
    _sb_bulk_depth += 1
    try:
        yield
    finally:
        _sb_bulk_depth = max(_sb_bulk_depth - 1, 0)
        if _sb_bulk_depth == 0:
            pending = _sb_bulk_dirty or force
            _sb_bulk_dirty = False
            if pending:
                update_bone(None, bpy.context)


def reset_transient_state():
    """Clear every per-session simulation cache (target history, lag/smooth
    filters, frame counter, collider BVH cache). Used by the bake for a
    deterministic clean start and by the discontinuity logic."""
    global _sb_sim_last_frame, _sb_preroll_pending
    _sb_sim_last_frame = None
    _sb_preroll_pending = True
    _sb_prev_target.clear()
    _sb_prev_rot_target.clear()
    # v7.5: the XPBD particle state IS the simulation state now. Leaving
    # it out of the reset made a jog drift 0.41 m while every other test
    # still passed, because the old rot_position/rot_velocity fields the
    # cache does track are no longer what the solver reads.
    _sb_xpbd_P.clear()
    _sb_xpbd_V.clear()
    _sb_native_reset()
    _sb_lag_loc.clear()
    _sb_lag_rot.clear()
    _sb_smooth_loc.clear()
    _sb_smooth_rot.clear()
    _sb_bvh_cache.clear()


def _sb_reset_sim_state(scene):
    """Snap every spring bone back to its rest state. Used when the timeline
    jumps (scrub backward, loop restart, big jump) so the sim starts clean
    instead of integrating across a discontinuity."""
    reset_transient_state()
    invalidate_cache()
    mark_solver_dirty()
    for b in scene.sb_spring_bones:
        if b.sb_bone_collider:
            continue
        b.speed = (0.0, 0.0, 0.0)
        b.loc_raw = (0.0, 0.0, 0.0)
        b.loc_raw_set = False
        b.rot_position = (0.0, 0.0, 0.0)
        b.rot_velocity = (0.0, 0.0, 0.0)
        b.rot_head_last = (0.0, 0.0, 0.0)
        b.rot_initialized = False
        # v7.5: the BASE POSE has to come back too. Leaving rot_base_quat in
        # place meant the next pass started from whatever pose the previous
        # one ended on -- invisible without contacts (3e-5 m of noise) but
        # amplified to centimetres once collision, a discontinuous
        # non-linearity, is in the loop.
        arm = _sb_armature_of(b)
        pb = arm.pose.bones.get(b.name) if arm is not None else None
        if pb is not None and b.rot_base_set:
            if pb.rotation_mode == 'QUATERNION':
                pb.rotation_quaternion = Quaternion(b.rot_base_quat)
            else:
                pb.rotation_euler = Quaternion(b.rot_base_quat).to_euler(
                    pb.rotation_mode)
            pb.location = Vector(b.loc_base)
        # basefix2: do NOT clear rot_base_set here. The clean base pose was
        # just written back into the channel above, but this runs inside
        # frame_change_post -- the solver then simulates this frame and
        # overwrites the channel with spring output. The next frame's
        # capture (which fires only when rot_base_set is False) would read
        # THAT and freeze it as the new rest pose. Since the base is
        # captured-once by design, keeping the flag set is correct: the
        # stored rot_base_quat is already the pose we want to keep.
        emp_head, emp_tail = _sb_loc_helpers(pb, arm) if pb else (None, None)
        if emp_head is not None and emp_tail is not None:
            emp_head.location = emp_tail.matrix_world.translation


# ------------------------------------------------------------------ #
#  FLAT SOLVER STATE  (v7.4, P1.1)
# ------------------------------------------------------------------ #
# The hot loop used to resolve ~28 RNA properties per bone per frame. At 120
# bones and 24 fps that is ~80k RNA lookups a second, and RNA access -- not
# the spring integration -- was the actual bottleneck (LOW and ULTRA quality
# measured within 3% of each other, i.e. substep count barely mattered).
#
# _sb_solver_state holds one plain-Python _SolverBone per simulated bone with
# every parameter already resolved. It is rebuilt only when something marks
# it dirty, which is what the update= callbacks on the properties are for.
_sb_solver_state = []
_sb_solver_dirty = True
# v7.5: XPBD chain solve for rotation springs. The legacy per-bone
# pendulum stays reachable for A/B measurement.
_sb_use_xpbd = True


def set_use_xpbd(value):
    global _sb_use_xpbd
    _sb_use_xpbd = bool(value)
    mark_solver_dirty()
    invalidate_cache()


def mark_solver_dirty():
    """Flag the flat solver state stale; it rebuilds on the next sim frame.

    O(1) on purpose: this fires from property update= callbacks, which run
    continuously while the user drags a slider.
    """
    global _sb_solver_dirty
    _sb_solver_dirty = True
    _sb_base_pose_dirty()


def _sb_armature_of(item):
    """Resolve a spring-bone entry's armature object.

    Reads the PointerProperty first, falling back to the legacy name string
    and migrating the entry on the way. Deliberately does NOT rewrite the
    name mirror: this runs per bone per frame, and the mirror only has to be
    CONSISTENT (it is used as an identity token), not current. Renames are
    reconciled by _sb_sync_armature_names() at rebuild / load time.
    """
    obj = item.armature_obj
    if obj is not None:
        return obj
    name = item.armature
    if not name:
        return None
    obj = bpy.data.objects.get(name)
    if obj is not None:
        item.armature_obj = obj          # lazy migration of a pre-7.4 file
    return obj


def _sb_state_key(item, armature=None):
    """Rename-proof, collision-proof identity for a spring-bone entry.

    The per-bone solver dicts (_sb_prev_target, _sb_lag_*, _sb_smooth_*) were
    keyed on bone.name ALONE. Two rigs in one scene routinely share bone names
    -- every character has a hair_00 -- so their spring state silently
    cross-contaminated. session_uid is unique per datablock and, unlike the
    name, stable across renames for the whole session.
    """
    if armature is None:
        armature = _sb_armature_of(item)
    if armature is None:
        return (item.armature, item.name)      # unresolvable: best effort
    return (armature.session_uid, item.name)


def _sb_sync_armature_names(scene=None):
    """Re-point every entry at its armature and refresh the name mirror.

    Runs on file load and on every list rebuild, so entries authored before
    7.4 gain their pointer and entries whose rig was renamed get a fresh
    mirror without the user ever noticing anything happened.
    """
    scenes = [scene] if scene is not None else list(bpy.data.scenes)
    migrated = 0
    for sc in scenes:
        for item in getattr(sc, "sb_spring_bones", ()):
            obj = item.armature_obj
            if obj is None:
                obj = bpy.data.objects.get(item.armature)
                if obj is None:
                    continue
                item.armature_obj = obj
                migrated += 1
            if item.armature != obj.name:
                item.armature = obj.name
    return migrated


def _sb_purge_orphans(scene=None):
    """Drop spring-bone entries whose armature no longer exists.

    Deleting a rig used to leave its entries behind for good: the 7.3.3 audit
    found all 24 entries still sitting in scene.sb_spring_bones after the
    armature was removed. They are inert (the solver skips anything that will
    not resolve) but they accumulate, show up in the UI and get saved into the
    .blend forever.
    """
    scenes = [scene] if scene is not None else list(bpy.data.scenes)
    removed = 0
    for sc in scenes:
        dead = [i for i, item in enumerate(sc.sb_spring_bones)
                if _sb_armature_of(item) is None]
        for i in reversed(dead):
            sc.sb_spring_bones.remove(i)
            removed += 1
    if removed:
        mark_solver_dirty()
        invalidate_cache()
    return removed


@persistent
def _sb_migrate_on_load(dummy):
    """load_post: migrate legacy string refs and start from a clean cache."""
    reset_transient_state()
    invalidate_cache()
    mark_solver_dirty()
    for sc in bpy.data.scenes:
        _sb_sync_armature_names(sc)
        _sb_purge_orphans(sc)


def _sb_catchup_steps(scene):
    """How many physics frame-steps to integrate this call.

    Returns 0 to mean "do NOT integrate -- re-apply the last pose instead".

    Contract (v7.4): the pose at frame N depends only on N and on the forward
    history that reached it, never on how many times Blender happened to
    evaluate N. Blender fires frame_change_post on every frame_set(),
    including ones that do not change the frame, so delta == 0 must be inert.

      delta == 0                 -> 0   same frame re-evaluated, no-op
      delta == 1                 -> 1   normal forward playback
      1 < delta <= MAX_CATCHUP   -> delta   catch up dropped frames
      delta < 0 / big jump       -> restore from cache (0), else clean reset (1)

    Before v7.4 every one of these branches returned 1, which is what made
    jogging 59<->60 drift ~0.60 m and left viewport and render disagreeing.
    """
    global _sb_sim_last_frame
    cur = scene.frame_current
    if _sb_sim_last_frame is None:
        _sb_sim_last_frame = cur
        return 1

    delta = cur - _sb_sim_last_frame

    # Same frame, re-evaluated. Never integrate: doing so makes the pose a
    # function of the evaluation count instead of the frame number.
    if delta == 0:
        return 0

    if delta == 1:
        _sb_sim_last_frame = cur
        return 1

    if 1 < delta <= _SB_MAX_CATCHUP:
        _sb_sim_last_frame = cur
        return delta          # catch up the skipped frames deterministically

    # Backward scrub, loop wrap or a big jump. Prefer an EXACT restore from
    # the frame cache -- that is what makes scrubbing repeatable. Only fall
    # back to a clean reset; integrating one step across the discontinuity
    # (the pre-7.4 behavior) is precisely what accumulated drift.
    if _sb_cache_restore_frame(scene, cur):
        _sb_sim_last_frame = cur
        return 0

    _sb_reset_sim_state(scene)        # clears _sb_sim_last_frame internally
    _sb_sim_last_frame = cur
    return 1


def _sb_self_collide(point, my_r, arm_name, bone_name, parent_name, pts):
    """Sequential sphere-sphere self-collision: push `point` out of every
    already-processed spring point this frame. Direct parent/child pairs are
    skipped (they are permanently adjacent by construction and would fight).
    Sequential resolution (each bone yields to the ones before it) is the
    same scheme cloth solvers use — cheap and stable, with a tiny order bias
    that is invisible in practice."""
    for (o_name, o_arm, o_pos, o_r, o_parent) in pts:
        if o_arm == arm_name and (o_parent == bone_name or parent_name == o_name):
            continue
        d = point - o_pos
        dist = d.length
        rad = my_r + o_r
        if dist < rad:
            if dist > 1e-9:
                point = o_pos + d * (rad / dist)
            else:
                point = o_pos + Vector((0.0, 0.0, rad))
    return point


def _sb_chain_mult(item, falloff):
    """Stiffness multiplier from the bone's position along its spring chain:
    the root keeps full stiffness, the tip loses up to 85% of it. This is what
    makes a ponytail whip more at the end than at the scalp."""
    if falloff <= 0.0 or item.chain_len <= 1:
        return 1.0
    depth_norm = item.chain_depth / max(item.chain_len - 1, 1)
    return max(1.0 - falloff * depth_norm * 0.85, 0.15)


def _sb_length_mult(bone_len_world, enabled):
    """Auto stiffness compensation by bone size: long bones (slow, heavy
    pendulums) get proportionally softer springs, short bones stiffer ones,
    so one preset reads the same on a 5 cm strand and a 60 cm cape bone.
    Normalized so a 25 cm bone keeps exactly its preset value."""
    if not enabled:
        return 1.0
    L = min(max(bone_len_world, 0.02), 4.0)
    return min(max(math.sqrt(0.25 / L), 0.6), 1.6)


class _SolverBone:
    """One simulated bone with every parameter already resolved.

    __slots__ matters here: attribute access on a slotted object is roughly
    an order of magnitude cheaper than an RNA property read, and the hot loop
    does ~28 of these per bone per frame.
    """
    __slots__ = ("item", "arm", "pb", "key", "loc_on", "rot_on",
                 "params", "noise", "c_excl", "rest_len", "chain_mult",
                 "collide", "coll_dist", "incl", "lock_axis", "bidx",
                 "quat_mode")


def _sb_rebuild_solver_state(scene):
    """Resolve every bone's parameters ONCE into plain Python objects.

    Runs on the first simulated frame after anything marks the state dirty:
    a property update= callback, a list rebuild, or a file load. Group
    resolution and the per-source parameter tuples are shared exactly like
    the old per-frame caches did, so bones driven by one group still cost a
    single read of its ~25 parameters.
    """
    global _sb_solver_state, _sb_solver_dirty
    groups = {g.name: g for g in scene.sb_bone_groups}
    pcache = {}
    ncache = {}
    out = []
    for item in scene.sb_spring_bones:
        if item.sb_bone_collider:
            continue
        arm = _sb_armature_of(item)
        if arm is None:
            continue
        pb = arm.pose.bones.get(item.name)
        if pb is None:
            continue
        loc_on = pb.sb_bone_spring_loc
        rot_on = pb.sb_bone_spring_rot
        if not loc_on and not rot_on:
            continue

        gname = pb.sb_group
        grp = groups.get(gname) if gname and gname != "NONE" else None
        src = grp if (grp is not None and grp.drive_params) else pb
        nsrc = grp if (grp is not None and grp.sb_noise_enable) else pb

        pk = src.as_pointer()
        pv = pcache.get(pk)
        if pv is None:
            pv = (src.sb_stiffness, src.sb_damp, src.sb_loc_speed,
                  src.sb_gravity, src.sb_loc_influence,
                  src.sb_max_distance, src.sb_loc_range,
                  src.sb_rot_stiffness, src.sb_rot_damp,
                  src.sb_rot_influence, src.sb_rot_range,
                  src.sb_air_drag, src.sb_wind_influence, src.sb_smooth,
                  src.sb_lag, src.sb_chain_falloff, src.sb_auto_length,
                  tuple(src.sb_stiff_axis),
                  src.sb_collide_margin, src.sb_collide_stiffness,
                  src.sb_collide_damping, src.sb_collide_friction_mult,
                  src.sb_self_collision,
                  src.sb_rot_speed)                       # rotspeed -> p[23]
            pcache[pk] = pv
        nk = nsrc.as_pointer()
        nv = ncache.get(nk)
        if nv is None:
            nv = (nsrc.sb_noise_enable, nsrc.sb_noise_loc,
                  nsrc.sb_noise_rot, nsrc.sb_noise_speed,
                  nsrc.sb_noise_seed)
            ncache[nk] = nv

        s = _SolverBone()
        s.item = item
        s.arm = arm
        s.pb = pb
        s.key = _sb_state_key(item, arm)
        s.loc_on = loc_on
        s.rot_on = rot_on
        s.params = pv
        s.noise = nv
        s.c_excl = pb.sb_collide_exclude
        s.rest_len = pb.bone.length
        s.chain_mult = _sb_chain_mult(item, pv[15])     # pv[15] = chain_falloff
        # per-bone collision settings: resolved here instead of ~8 RNA reads
        # per bone per frame inside the physics body
        s.collide = pb.sb_collide
        s.coll_dist = pb.sb_colliding_dist
        s.incl = pb.sb_include_only
        s.lock_axis = pb.sb_lock_axis
        s.bidx = arm.pose.bones.find(pb.name)
        # Which local channel does Blender evaluate for this bone? Only
        # quaternion bones can ride the batched foreach write below; the
        # rest are written one at a time through _sb_apply_local_swing().
        s.quat_mode = (pb.rotation_mode == 'QUATERNION')
        out.append(s)
    _sb_solver_state = out
    _sb_solver_dirty = False
    _sb_build_chains(scene)
    global _sb_has_loc
    _sb_has_loc = any(s.loc_on for s in _sb_solver_state)



def _sb_capture_unset_bases():
    """Capture the base pose of any rotation-spring bone that still has none.

    Runs right after a solver rebuild, inside the post handler and BEFORE the
    first spring write of that frame, so the channel holds the evaluated
    (clean) pose. Until 8.2.3 an entry that reached its first simulated frame
    without a base was only captured by the NEXT frame's pre handler -- one
    spring write too late -- and the latched swing became a permanent lean.
    """
    pending = [st for st in _sb_solver_state
               if st.rot_on and not st.item.rot_base_set]
    if not pending:
        return
    # A compiled-core rig may still carry last frame's output in its
    # channels (mode 1 skips the pre-handler restore); put the clean pose
    # back before reading it.
    if _sb_native_unapply():
        bpy.context.view_layer.update()
    for st in pending:
        it = st.item
        it.rot_base_quat = _sb_read_local_rot(st.pb)[:]
        it.loc_base = st.pb.location[:]
        it.rot_base_set = True


def _sb_solver_state_live():
    """Cheap liveness probe for the cached bpy_structs.

    Undo/redo and file loads free the underlying datablocks; touching a freed
    bpy_struct raises ReferenceError. Undo invalidates everything at once, so
    probing one entry is representative and costs a single attribute read.
    """
    if not _sb_solver_state:
        return True
    try:
        _sb_solver_state[0].pb.bone.length
        return True
    except Exception:
        return False


# Cap on how far one collision pass may move a bone's tail point.
# Tunable while we characterise the penetration/stability trade-off.
_SB_PUSH_LEN_MULT = 0.35
_SB_PUSH_RADIUS_MULT = 0.0


def _sb_max_push(bone_len_world, bone_r):
    """Positional-correction budget for one collision pass.

    The cap keeps the pushout from fighting the pendulum constraint hard
    enough to yank a bone across a collider in a single frame.

    MEASURED (v7.4): raising or removing this cap changes nothing. Sweeping
    0.35x bone length, 1.0x, radius-scaled and unlimited over a 24-bone rig
    for 120 frames gave 251 / 249 / 247 / 251 penetrating samples and the
    same max penetration to four decimals. The residual penetration comes
    from geometry, not from this budget -- see the note on segment collision
    in spring_bone(). Kept tunable so the next person does not have to
    re-run that sweep to find out.
    """
    return max(bone_len_world * _SB_PUSH_LEN_MULT,
               bone_r * _SB_PUSH_RADIUS_MULT)


# ------------------------------------------------------------------ #
#  XPBD ROTATION PASS  (v7.5)
# ------------------------------------------------------------------ #
# Replaces the per-bone pendulum for rotation springs. See xpbd.py for why.
#
# The whole chain is solved at once, so nothing is written to the rig until
# the solve finishes -- which is also what lets the final write go through a
# single foreach_set (measured 26x faster than per-bone matrix assignment).

_sb_xpbd_P = {}          # chain key -> [Vector] joint positions
_sb_xpbd_V = {}          # chain key -> [Vector] joint velocities
_sb_chains = []          # rebuilt with the flat solver state
_sb_root_warnings = {}   # chain key -> collider name whose inside the root is


class _SBChain:
    __slots__ = ("arm", "states", "key", "n", "root_pb")


def _sb_build_chains(scene):
    """Group the flat solver state into chains, root -> tip.

    A chain root is a rotation-spring bone whose parent is not one. Bones are
    ordered by walking down, which is the order the Gauss-Seidel sweep needs.
    """
    global _sb_chains
    by_bone = {}
    for st in _sb_solver_state:
        if st.rot_on:
            by_bone[(st.arm.name, st.pb.name)] = st
    chains = []
    claimed = set()
    pending = [st for st in _sb_solver_state if st.rot_on and
               (st.pb.parent is None or
                (st.arm.name, st.pb.parent.name) not in by_bone)]
    # Queue every side branch. Previously only the first child was walked,
    # then every other child was skipped because it had a spring parent.
    for st in pending:
        k = (st.arm.name, st.pb.name)
        if k in claimed:
            continue
        seq = []
        cur = st
        while cur is not None:
            seq.append(cur)
            claimed.add((cur.arm.name, cur.pb.name))
            nxt = None
            for ch in cur.pb.children:
                cand = by_bone.get((cur.arm.name, ch.name))
                if cand is not None and (cur.arm.name, ch.name) not in claimed:
                    if nxt is None:
                        nxt = cand
                    else:
                        pending.append(cand)
            cur = nxt
        c = _SBChain()
        c.arm = st.arm
        c.states = seq
        c.root_pb = st.pb
        c.n = len(seq)
        c.key = (st.arm.session_uid, st.pb.name)
        chains.append(c)
    _sb_chains = chains
    _sb_xpbd_P.clear()
    _sb_xpbd_V.clear()
    _sb_root_warnings.clear()
    return chains


# Batched capture/reset. Measured on this rig: the two per-bone passes cost
# 0.47 ms/frame between them, while foreach_get + foreach_set over the whole
# armature cost 0.0016 + 0.0023 ms. They only differ when a bone is skipped
# (hidden / far), so the slow path is kept for that case.
_SB_QBUF = {}
_SB_ITEM_MAP = {}
_SB_BASE_READY = set()          # armature names whose _SB_QBUF is frozen
_SB_OUTBUF = {}                 # armature -> scratch buffer for the batched write
_SB_BY_ARM = None               # QUATERNION states, grouped by armature
_SB_BY_ARM_SLOW = None          # Euler / axis-angle states: per-bone path


def _sb_base_pose_dirty():
    """Drop the frozen base-pose buffers and the armature grouping.

    Anything that can change what the base pose IS -- a reset, a solver
    rebuild, a new spring-bone list -- must call this, or the restore below
    keeps replaying a stale pose forever.
    """
    global _SB_BY_ARM, _SB_ARM_NAMES, _SB_BY_ARM_SLOW
    _SB_BASE_READY.clear()
    _SB_OUTBUF.clear()
    _SB_ANIMATED_CH.clear()          # basefix3
    _sb_collider_sources_dirty()
    _SB_BY_ARM = None
    _SB_BY_ARM_SLOW = None
    _SB_ARM_NAMES = None
    _sb_native_invalidate()


def _sb_capture_reset_slow(scene, states):
    """Capture-once / restore-every-frame for bones the batched quaternion
    path cannot address — i.e. Euler and axis-angle rotation modes.

    Exactly the same contract as the foreach fast path below, one bone at a
    time: the first frame stores the clean animated pose as the base, every
    later frame writes that base back so the spring integrates on top of the
    animation instead of on top of its own previous output.
    """
    item_by_name = _SB_ITEM_MAP.get(id(scene))
    if item_by_name is None or len(item_by_name) != len(scene.sb_spring_bones):
        item_by_name = {_sb_state_key(it): it for it in scene.sb_spring_bones}
        _SB_ITEM_MAP[id(scene)] = item_by_name
    for st in states:
        pb = st.pb
        it = item_by_name.get(st.key)
        if it is None:
            continue
        if it.rot_base_set:
            _sb_write_local_rot(pb, Quaternion(it.rot_base_quat))
        else:
            it.rot_base_quat = _sb_read_local_rot(pb)[:]
            it.loc_base = pb.location[:]
            it.rot_base_set = True


def _sb_batch_capture_reset(scene):
    """Restore every rotation-spring bone's clean base pose.

    v8.0 fast path: a bone's base quaternion is captured once and never
    changes again -- the capture happens before any spring write, and the
    springs only ever write on top of it. So once every driven bone on an
    armature has been captured the whole buffer is frozen, and each later
    frame is one foreach_set with no per-bone RNA at all. Measured on the
    24-bone bench: 0.111 -> 0.013 ms/frame. _sb_base_pose_dirty() unfreezes.
    """
    global _SB_BY_ARM, _SB_BY_ARM_SLOW
    hidden, origin = _sb_skip_state
    if hidden or origin is not None:
        return False                       # someone is being skipped: slow path
    by_arm = _SB_BY_ARM
    slow = _SB_BY_ARM_SLOW
    if by_arm is None or slow is None:
        by_arm = {}
        slow = []
        for st in _sb_solver_state:
            if not st.rot_on:
                continue
            # The batched path indexes the rotation_quaternion array by bone
            # index, so it can only carry bones Blender evaluates from that
            # channel. Euler / axis-angle bones go to the per-bone path --
            # writing their quaternion channel would be a silent no-op.
            if st.quat_mode and st.bidx >= 0:
                by_arm.setdefault(st.arm, []).append(st)
            else:
                slow.append(st)
        _SB_BY_ARM = by_arm
        _SB_BY_ARM_SLOW = slow
    if slow:
        _sb_capture_reset_slow(scene, slow)
    if not by_arm:
        return True
    for arm, states in by_arm.items():
        n = len(arm.pose.bones)
        buf = _SB_QBUF.get(arm)
        if (buf is not None and len(buf) == n * 4
                and arm.name in _SB_BASE_READY):
            arm.pose.bones.foreach_set("rotation_quaternion", buf)
            continue
        if buf is None or len(buf) != n * 4:
            buf = _SB_QBUF[arm] = np.empty(n * 4, dtype=np.float32)
        arm.pose.bones.foreach_get("rotation_quaternion", buf)
        item_by_name = _SB_ITEM_MAP.get(id(scene))
        if item_by_name is None or len(item_by_name) != len(scene.sb_spring_bones):
            item_by_name = {_sb_state_key(it): it for it in scene.sb_spring_bones}
            _SB_ITEM_MAP[id(scene)] = item_by_name
        _all_set = True
        for st in states:
            j = st.bidx * 4
            it = item_by_name.get(st.key)
            if it is None:
                _all_set = False
                continue
            if it.rot_base_set:
                buf[j] = it.rot_base_quat[0]; buf[j+1] = it.rot_base_quat[1]
                buf[j+2] = it.rot_base_quat[2]; buf[j+3] = it.rot_base_quat[3]
            else:
                it.rot_base_quat = (float(buf[j]), float(buf[j+1]),
                                    float(buf[j+2]), float(buf[j+3]))
                it.loc_base = st.pb.location[:]
                it.rot_base_set = True
        arm.pose.bones.foreach_set("rotation_quaternion", buf)
        if _all_set:
            # The buffer now holds the captured base for every driven bone and
            # the untouched live values for the rest: safe to freeze.
            _SB_BASE_READY.add(arm.name)
    return True


# ================================================================== #
#  COMPILED SOLVER CORE (v8.0)
# ================================================================== #
#
# The whole per-frame rotation-spring pipeline lives in C: geometry rebuild,
# spring prediction, XPBD distance + segment/sphere collision, contact
# velocity response, and the conversion to local swing quaternions. Python
# does three things per frame -- one foreach_get of the pose matrices, one
# foreach_get/foreach_set of the quaternion channel, and one ctypes call.
#
# The boundary is crossed ONCE for the whole rig on purpose. The first
# compiled build called into C once per chain and measured SLOWER than pure
# Python (1.497 vs 1.396 ms/frame): the solve was never the bottleneck,
# marshalling mathutils objects into flat arrays was.
#
# Everything degrades gracefully. _sb_native_layout() returns None for any
# rig the compiled path does not fully support -- non-sphere colliders, a
# bone outside the armature's buffer, a non-quaternion rotation mode -- and
# the pure-Python solver below runs instead, unchanged.

try:
    from . import native as _sb_native
    _sb_native_ok = _sb_native.available()
except Exception:                                   # pragma: no cover
    _sb_native = None
    _sb_native_ok = False

_SB_PRM_N = 10          # keep in sync with the enum in springfx_step.c

# whyreport: why the compiled core declined this scene, "" when it is running.
# Surfaced in the Performance panel so a silent drop to the Python solver --
# and the frame-rate cost that comes with it -- is visible instead of puzzling.
_sb_native_why = ""


def get_solver_status():
    """(compiled_active, reason). reason is "" while the compiled core runs."""
    return (bool(_sb_native_ok and _sb_nat and not _sb_native_why),
            _sb_native_why)
_SB_LPRM_N = 13         # location-spring params; keep in sync with LP_* in C

# Solver options handed to the compiled core as a flat array, so the policy
# can change without another ABI break.
#   [0] integrator: 0 = semi-implicit Euler, 1 = exact closed form
#   [1] substep floor   [2] substep target (rad/substep)   [3] substep cap
_SB_OPT = np.array([1.0, 4.0, 0.10, 64.0], dtype=np.float64)
# The substep fields only bite on the numeric fallback (anisotropic
# stiffness), which is not a constant-coefficient system and so cannot
# use the closed form. base 1 / target 0.30 / cap 8 was measured at
# normalised jerk 0.2738; 4 / 0.10 / 64 lands at 0.1997, and in C the
# extra substeps cost microseconds.
_SB_OPT_PTR = None


def _sb_opt_ptr():
    global _SB_OPT_PTR
    if _SB_OPT_PTR is None and _sb_native_ok:
        _SB_OPT_PTR = _sb_native.ptr_d(_SB_OPT)
    return _SB_OPT_PTR
_SB_MAX_SPHERES = 512   # per-frame sphere buffer; more than this -> Python path
_SB_FORCE_MODE = None   # None = auto; 0 = always restore; 1 = always reconstruct
                        # (escape hatch + A/B handle; not exposed in the UI)

_sb_nat = None          # cached layout, one entry per armature
_sb_nat_dirty = True
_SB_NATIVE_FRAME_ACTIVE = False


def _sb_native_invalidate():
    """Drop the compiled-core layout; it rebuilds on the next simulated frame."""
    global _sb_nat_dirty
    _sb_nat_dirty = True


class _NativeRig:
    """Flat, contiguous layout for one armature's chains.

    Built once per solver rebuild and reused every frame. Every array here is
    handed to C as a raw pointer, so none of them may be reallocated while a
    frame is in flight -- they are only ever written in place.
    """

    __slots__ = ("arm", "nb", "n_states", "n_chains", "states", "keys",
                 "bidx", "chain_off", "root_bidx", "brest", "prm",
                 "bmat", "qbuf", "mw", "mw_view",
                 "P", "V", "prevT", "smoothq", "inited", "outq", "scratch",
                 "cstiff", "cdamp", "gravity", "wind", "spheres", "ptr",
                 # clean-pose reconstruction (mode 1)
                 "mode", "offs", "offs_ready", "bloc", "bscl", "bparent",
                 "anchors",
                 # native LOCATION springs
                 "n_loc", "loc_keys", "loc_bidx", "loc_prm", "loc_parents", "loc_ppose",
                 "lclean", "loc_lastw", "linited", "locP", "locV",
                 "loc_prevT", "locbuf", "loc_all_native", "lptr",
                 "lastw", "prevsw", "haveprev", "wpose", "cleanq", "why",
                 "_snaplen")

    def snapshot(self):
        """Whole solver state as ONE flat array.

        The cache stores one of these per frame, so six separate .copy()
        calls meant six allocations every frame for the lifetime of a
        playthrough. One buffer, six memcpys.
        """
        parts = (self.P, self.V, self.prevT, self.smoothq, self.outq,
                 self.locP, self.locV, self.loc_prevT, self.lclean, self.loc_lastw)
        out = np.empty(self._snaplen, dtype=np.float64)
        o = 0
        for a in parts:
            n = a.size
            out[o:o + n] = a
            o += n
        out[o:o + self.inited.size] = self.inited
        o += self.inited.size
        out[o:o + self.linited.size] = self.linited
        return out

    def restore(self, s):
        parts = (self.P, self.V, self.prevT, self.smoothq, self.outq,
                 self.locP, self.locV, self.loc_prevT, self.lclean, self.loc_lastw)
        o = 0
        for a in parts:
            n = a.size
            a[:] = s[o:o + n]
            o += n
        self.inited[:] = s[o:o + self.inited.size]
        o += self.inited.size
        self.linited[:] = s[o:o + self.linited.size]

    def reset(self):
        self.linited[:] = 0
        self.locP[:] = 0.0
        self.locV[:] = 0.0
        self.loc_prevT[:] = 0.0
        self.loc_lastw[:] = 0.0
        self.P[:] = 0.0
        self.V[:] = 0.0
        self.prevT[:] = 0.0
        self.smoothq[:] = 0.0
        self.inited[:] = 0
        self.outq[:] = 0.0
        self.outq[0::4] = 1.0           # identity swing


def _sb_clear_native_why():          # whyreport
    global _sb_native_why
    _sb_native_why = ""


def _sb_build_native_layout():
    """Group the live chains by armature into compiled-core layouts.

    Returns None if the rig cannot be driven by the compiled path, which is
    not an error: the caller falls back to the Python solver.
    """
    _sb_clear_native_why()          # whyreport
    if not _sb_native_ok:
        return None
    by_arm = {}
    for ch in _sb_chains:
        by_arm.setdefault(ch.arm, []).append(ch)
    # An armature can carry LOCATION springs and no rotation chain at all
    # (a jiggle-only rig), so it has to get a layout too.
    for st in _sb_solver_state:
        if st.loc_on and st.arm is not None:
            by_arm.setdefault(st.arm, [])
    if not by_arm:
        return None

    rigs = []
    _SB_LOC_NATIVE.clear()
    for arm, chains in by_arm.items():
        pbs = arm.pose.bones
        nb = len(pbs)
        order = {pb.name: i for i, pb in enumerate(pbs)}
        n_states = sum(ch.n for ch in chains)
        n_chains = len(chains)
        nc_alloc = max(n_chains, 1)
        r = _NativeRig()
        r.arm = arm
        r.nb = nb
        r.n_states = n_states
        r.n_chains = n_chains
        r.states = []
        r.bidx = np.empty(max(n_states, 1), dtype=np.int32)
        r.chain_off = np.empty(nc_alloc + 1, dtype=np.int32)
        r.root_bidx = np.empty(nc_alloc, dtype=np.int32)
        r.cstiff = np.empty(nc_alloc, dtype=np.float64)
        r.cdamp = np.empty(nc_alloc, dtype=np.float64)
        r.brest = np.zeros(nb, dtype=np.float64)
        r.prm = np.zeros(max(n_states, 1) * _SB_PRM_N, dtype=np.float64)
        for i, pb in enumerate(pbs):
            r.brest[i] = pb.bone.length

        k = 0
        for ci, ch in enumerate(chains):
            r.chain_off[ci] = k
            rb = order.get(ch.root_pb.name, -1)
            if rb < 0:
                return None
            r.root_bidx[ci] = rb
            r.cstiff[ci] = ch.states[0].params[19]
            r.cdamp[ci] = ch.states[0].params[20]
            for st in ch.states:
                if st.bidx < 0 or st.bidx >= nb:
                    return None
                if st.pb.rotation_mode != 'QUATERNION':
                    return None
                if st.params[14] > 0.0:
                    global _sb_native_why
                    _sb_native_why = ("Lag > 0 is not supported by the "
                                      "compiled core (Python solver in use)")
                    # lagfix: there is no prm slot for Lag in ABI 8, so the
                    # compiled core cannot honour it. Decline the rig and let
                    # the Python chain solver run instead -- same policy the
                    # location path already uses for Lag/Smooth/Noise.
                    return None
                p = st.params
                o = k * _SB_PRM_N
                # rotspeed: Speed folded into the stiffness handed to C.
                # dt comes from the scene fps -- the aliasing cap is a
                # frame-rate limit, and prm is rebuilt whenever a
                # parameter changes, so a fps change re-derives it.
                r.prm[o + 0] = _sb_rot_speed_stiffness(
                    p[7] * st.chain_mult, p[23], _sb_scene_dt())
                r.prm[o + 1] = p[8]                      # rot damping
                r.prm[o + 2] = p[3]                      # gravity
                r.prm[o + 3] = p[11]                     # air drag
                r.prm[o + 4] = p[12]                     # wind influence
                r.prm[o + 5] = p[9]                      # rot influence
                r.prm[o + 6] = p[10]                     # rot range
                r.prm[o + 7] = p[13]                     # smooth
                r.prm[o + 8] = 1.0 if p[16] else 0.0     # auto length
                r.prm[o + 9] = max(st.coll_dist, 0.0)    # collision radius
                r.bidx[k] = st.bidx
                r.states.append(st)
                k += 1
        r.chain_off[n_chains] = k

        npart = max(n_states + n_chains, 1)
        r.P = np.zeros(npart * 3, dtype=np.float64)
        r.V = np.zeros(npart * 3, dtype=np.float64)
        r.prevT = np.zeros(max(n_states, 1) * 3, dtype=np.float64)
        r.smoothq = np.zeros(max(n_states, 1) * 4, dtype=np.float64)
        r.inited = np.zeros(nc_alloc, dtype=np.int32)
        r.outq = np.zeros(max(n_states, 1) * 4, dtype=np.float64)
        # lengths + radii + rdirs(3) + rframes(9) per state, then cdelta
        r.scratch = np.zeros(max(n_states, 1) * 14 + npart * 3, dtype=np.float64)
        r.bmat = np.empty(nb * 16, dtype=np.float64)
        r.qbuf = np.empty(nb * 4, dtype=np.float32)
        r.mw = np.empty(16, dtype=np.float64)
        r.mw_view = r.mw.reshape(4, 4)
        r.gravity = np.zeros(3, dtype=np.float64)
        r.wind = np.zeros(3, dtype=np.float64)
        r.spheres = np.zeros(_SB_MAX_SPHERES * 4, dtype=np.float64)
        r.keys = [st.key for st in r.states]

        # --- clean-pose reconstruction state ---
        r.offs = np.zeros(nb * 16, dtype=np.float64)
        r.offs_ready = False
        r.bloc = np.zeros(nb * 3, dtype=np.float64)
        r.bscl = np.ones(nb * 3, dtype=np.float64)
        r.bparent = np.full(nb, -1, dtype=np.int32)
        for i, pb in enumerate(pbs):
            if pb.parent is not None:
                r.bparent[i] = order.get(pb.parent.name, -1)
        r.lastw = np.zeros(max(n_states, 1) * 4, dtype=np.float32)
        r.prevsw = np.zeros(max(n_states, 1) * 4, dtype=np.float64)
        r.prevsw[0::4] = 1.0
        r.haveprev = np.zeros(max(n_states, 1), dtype=np.int32)
        r.wpose = np.zeros(nb * 16, dtype=np.float64)
        r.cleanq = np.zeros(max(n_states, 1) * 4, dtype=np.float64)
        r.mode, r.why = _sb_native_mode(r, chains, order)
        # In mode 1 every driven bone's pose is rebuilt in C, so the only
        # pose matrix that still has to come from Blender is each chain's
        # ANCHOR -- the first non-driven bone above the root. Reading those
        # four individually beats a foreach_get over the whole armature
        # (0.0011 vs 0.017 ms on this rig).
        anc = []
        for ci in range(n_chains):
            b = int(r.root_bidx[ci])
            pi = int(r.bparent[b])
            if pi >= 0 and pi not in anc:
                anc.append(pi)
        r.anchors = [(i, pbs[i]) for i in anc]

        # ---- native LOCATION springs ----------------------------------
        # Each one used to need two empties and a COPY_LOCATION constraint:
        # three datablocks of scene footprint per bone. The C solver derives
        # the rigid target from the bone's own rest offset and writes
        # pose_bone.location directly, so location springs become
        # zero-footprint as well.
        driven_rot = set()
        for ch in chains:
            for st in ch.states:
                driven_rot.add(st.pb.name)
        loc_states, loc_reject = [], []
        for st in _sb_solver_state:
            if not st.loc_on or st.arm is not arm:
                continue
            why = _sb_loc_native_ok(st, order, driven_rot)
            if why:
                loc_reject.append((st.pb.name, why))
            else:
                loc_states.append(st)
        r.loc_all_native = not loc_reject
        if loc_reject:
            r.why = (r.why or "") + "; ".join(
                "%s: %s" % (n, w) for n, w in loc_reject[:3])
        r.n_loc = len(loc_states)
        r.loc_keys = {st.key for st in loc_states}
        nl = max(r.n_loc, 1)
        r.loc_bidx = np.zeros(nl, dtype=np.int32)
        r.loc_prm = np.zeros(nl * _SB_LPRM_N, dtype=np.float64)
        r.loc_parents = []
        r.loc_ppose = np.zeros(nl * 16, dtype=np.float64)
        r.lclean = np.zeros(nl * 3, dtype=np.float64)
        r.loc_lastw = np.zeros(nl * 3, dtype=np.float32)
        r.linited = np.zeros(nl, dtype=np.int32)
        r.locP = np.zeros(nl * 3, dtype=np.float64)
        r.locV = np.zeros(nl * 3, dtype=np.float64)
        r.loc_prevT = np.zeros(nl * 3, dtype=np.float64)
        r.locbuf = np.zeros(nb * 3, dtype=np.float32)
        for i, st in enumerate(loc_states):
            p = st.params
            o = i * _SB_LPRM_N
            r.loc_bidx[i] = st.bidx
            r.loc_prm[o + 0] = p[0]        # stiffness
            r.loc_prm[o + 1] = p[1]        # damping
            r.loc_prm[o + 2] = p[2]        # speed
            r.loc_prm[o + 3] = p[3]        # gravity
            r.loc_prm[o + 4] = p[4]        # influence
            r.loc_prm[o + 5] = p[5]        # max distance
            r.loc_prm[o + 6] = p[6]        # move range
            r.loc_prm[o + 7] = p[11]       # air drag
            r.loc_prm[o + 8] = max(st.coll_dist, 0.0) if st.collide else -1.0
            r.loc_prm[o + 9] = p[18]       # collision margin
            r.loc_prm[o + 10] = p[19]      # collision stiffness
            r.loc_prm[o + 11] = p[20]      # damping on collision
            r.loc_prm[o + 12] = p[21]      # friction multiplier
            r.loc_parents.append(st.pb.parent)
        r._snaplen = (r.P.size + r.V.size + r.prevT.size
                      + r.smoothq.size + r.outq.size + r.inited.size
                      + r.locP.size + r.locV.size + r.loc_prevT.size
                      + r.lclean.size + r.linited.size + r.loc_lastw.size)

        # Raw pointers are resolved ONCE. numpy's .ctypes.data_as() costs
        # 3.4 us per call; at ~20 arrays that was 0.068 ms of every frame
        # spent re-deriving addresses that never change. None of these
        # arrays is ever reallocated -- they are only written in place.
        pd, pi, pf = _sb_native.ptr_d, _sb_native.ptr_i, _sb_native.ptr_f
        r.ptr = (pd(r.mw), pd(r.bmat), pd(r.brest),
                 pi(r.bidx), pi(r.chain_off), pi(r.root_bidx),
                 pd(r.prm),
                 pd(r.P), pd(r.V), pd(r.prevT), pd(r.smoothq), pi(r.inited),
                 pd(r.gravity), pd(r.wind),
                 pd(r.spheres), pd(r.cdamp), pd(r.cstiff),
                 pf(r.qbuf), pd(r.outq), pd(r.scratch),
                 pd(r.offs), pd(r.bloc), pd(r.bscl), pi(r.bparent),
                 pf(r.lastw), pd(r.prevsw), pi(r.haveprev),
                 pd(r.wpose), pd(r.cleanq))
        r.lptr = (pd(r.loc_ppose), pi(r.loc_bidx), pd(r.loc_prm),
                  pd(r.lclean), pf(r.loc_lastw), pi(r.linited),
                  pd(r.locP), pd(r.locV), pd(r.loc_prevT), pf(r.locbuf))
        rigs.append(r)
    global _sb_loc_all_native
    _sb_loc_all_native = all(x.loc_all_native for x in rigs)
    return rigs


def _sb_native_mode(rig, chains, order):
    """Decide whether this rig can skip the base-pose restore write.

    Mode 1 rebuilds each driven bone's clean pose_mat in C instead of asking
    Blender to produce one, which removes a foreach_set from every frame
    (~0.10 ms). It is only valid when the reconstruction is guaranteed to
    reproduce what Blender would have evaluated, so anything it does not
    model sends the rig back to mode 0 -- correctness first, and the reason
    is reported in the Performance panel rather than silently swallowed.

    Returns (mode, reason).
    """
    if _SB_FORCE_MODE is not None:
        return _SB_FORCE_MODE, "forced by _SB_FORCE_MODE"
    driven = set()
    for ch in chains:
        for st in ch.states:
            driven.add(st.pb.name)

    for ch in chains:
        prev = None
        for st in ch.states:
            pb = st.pb
            if pb.rotation_mode != 'QUATERNION':
                return 0, "bone '%s' is not in quaternion rotation mode" % pb.name
            if len(pb.constraints):
                return 0, "bone '%s' has constraints" % pb.name
            if prev is not None and (pb.parent is None or pb.parent.name != prev):
                return 0, "chain at '%s' is not a strict parent chain" % pb.name
            prev = pb.name
        root = ch.states[0].pb
        if root.parent is not None and root.parent.name in driven:
            return 0, "chain root '%s' hangs off another spring bone" % root.name

    scene = bpy.context.scene
    for it in scene.sb_spring_bones:
        if it.sb_bone_collider and it.name in driven:
            return 0, "'%s' is both a spring bone and a bone collider" % it.name
    for ob in scene.objects:
        if not getattr(ob, 'sb_object_collider', False):
            continue
        if ob.parent_type == 'BONE' and ob.parent_bone in driven:
            return 0, "collider '%s' is parented to spring bone '%s'" % (
                ob.name, ob.parent_bone)
    return 1, ""


def _sb_drop_loc_helpers(pb, arm):
    """Retire the empty pair and COPY_LOCATION a location spring used to need.

    Pre-8.0 every location spring created <bone>_spring and <bone>_spring_tail
    plus a constraint -- three datablocks per bone. The compiled solver writes
    pose_bone.location directly, so they are removed the first time it takes
    over a bone. Nothing else references them.
    """
    head, tail = _sb_loc_helpers(pb, arm)
    cns = pb.constraints.get('spring')
    if cns is not None and cns.type == 'COPY_LOCATION':
        pb.constraints.remove(cns)
    for emp in (head, tail):
        if emp is not None and emp.type == 'EMPTY':
            try:
                bpy.data.objects.remove(emp, do_unlink=True)
            except Exception:
                pass
    pb.sb_loc_helper = None
    pb.sb_loc_target = None


def _sb_loc_native_ok(st, order, driven_rot):
    """Empty string if this location spring can run in the compiled core,
    otherwise the reason it cannot.

    Anything the C path does not model sends that bone back to the legacy
    empty + COPY_LOCATION route, which still works exactly as before.
    """
    p = st.params
    pb = st.pb
    if st.rot_on:
        return "bone also has a rotation spring"
    if p[14] > 0.0:
        return "Lag is not supported by the compiled location solver"
    if p[13] > 0.0:
        return "Smooth (HF damping) is not supported by the compiled solver"
    if st.noise[0] and (st.noise[1] > 0.0 or st.noise[2] > 0.0):
        return "Noise is not supported by the compiled location solver"
    if p[22] and getattr(bpy.context.scene, 'sb_self_collision_enable', False):
        return "self-collision is not supported by the compiled solver"
    ax = p[17]
    if (abs(ax[0] - 1.0) > 1e-4 or abs(ax[1] - 1.0) > 1e-4
            or abs(ax[2] - 1.0) > 1e-4):
        return "per-axis stiffness is not supported by the compiled solver"
    if pb.name not in order:
        return "bone is not in the armature buffer"
    if pb.parent is not None and pb.parent.name in driven_rot:
        return "parent '%s' is itself a spring bone" % pb.parent.name
    for c in pb.constraints:
        if c.name != 'spring':
            return "bone has a '%s' constraint" % c.type
    return ""


def _sb_native_capture_offs(rig):
    """Capture the constant rest offset of every bone: the part of

        pose_mat = pose_mat[parent] . offs_bone . matrix_basis

    that does not depend on the pose. It is pure rest geometry, so one
    capture holds for the life of the layout. The identity is exact for ANY
    pose as long as pose_mat and matrix_basis are consistent with each other,
    which they are whenever this runs (inside the post handler, after the
    depsgraph has evaluated the frame).
    """
    if not _sb_rig_alive(rig):          # deadrig2
        return False
    pbs = rig.arm.pose.bones
    for i, pb in enumerate(pbs):
        par = pb.parent
        Pm = par.matrix if par is not None else Matrix.Identity(4)
        try:
            M = Pm.inverted() @ pb.matrix @ pb.matrix_basis.inverted()
        except Exception:
            return False                  # degenerate basis (zero scale)
        o = i * 16
        for r_ in range(4):
            row = M[r_]
            rig.offs[o + r_*4 + 0] = row[0]
            rig.offs[o + r_*4 + 1] = row[1]
            rig.offs[o + r_*4 + 2] = row[2]
            rig.offs[o + r_*4 + 3] = row[3]
    rig.offs_ready = True
    return True


def _sb_native_skip_restore():
    """True when no rig needs the pre-handler to restore the base pose."""
    rigs = _sb_nat
    if not rigs or _sb_nat_dirty or not _sb_native_ok or not _SB_NATIVE_FRAME_ACTIVE:
        return False
    for r in rigs:
        if r.mode != 1 or not r.offs_ready or not r.loc_all_native:
            return False
    return True


def _sb_rig_alive(r):
    """deadrig: False once this rig's armature datablock has been removed.

    Deleting an armature does NOT invalidate the cached native layout, so
    `r.arm` is left dangling. Touching it raises ReferenceError from inside
    frame_change_post, which killed spring_bone_frame_mode for the rest of
    the session: the handler reports once and then fails silently every
    frame, so the simulation freezes and every slider looks dead.
    """
    try:
        r.arm.name
        return True
    except ReferenceError:
        return False


def _sb_native_unapply():
    """Take our own swing back out of the pose channel.

    Needed on reset: in mode 1 nothing restores the base pose each frame, so
    the channel is left holding clean . swing. Clearing the solver state
    without undoing that would make the next frame read the sprung pose as
    if it were the rest pose and bake the offset in permanently.

    Only bones whose channel still holds EXACTLY what we wrote are touched.
    """
    global _sb_nat_dirty
    rigs = _sb_nat
    if not rigs:
        return False
    any_changed = False
    for r in rigs:
        if not _sb_rig_alive(r):
            _sb_nat_dirty = True        # deadrig: force a rebuild, skip it
            continue
        # LOCATION channel first: the compiled solver writes pose_bone.location
        # directly, so a reset that only cleared the solver state would leave
        # the bone parked on its last sprung offset -- and the next run would
        # read that as the rest pose and bias the target permanently
        # (measured: a constant 0.052 m offset on the bench rig).
        if r.n_loc and r.linited.any():
            lpbs = r.arm.pose.bones
            if len(lpbs) == r.nb:
                lpbs.foreach_get("location", r.locbuf)
                touched = False
                for i in range(r.n_loc):
                    if not r.linited[i]:
                        continue
                    b = int(r.loc_bidx[i]) * 3
                    o = i * 3
                    if (r.locbuf[b] != r.loc_lastw[o]
                            or r.locbuf[b+1] != r.loc_lastw[o+1]
                            or r.locbuf[b+2] != r.loc_lastw[o+2]):
                        continue
                    r.locbuf[b] = r.lclean[o]
                    r.locbuf[b+1] = r.lclean[o+1]
                    r.locbuf[b+2] = r.lclean[o+2]
                    touched = True
                if touched:
                    lpbs.foreach_set("location", r.locbuf)
                    r.arm.update_tag(refresh={'DATA'})
                    any_changed = True
            r.linited[:] = 0
        if r.mode != 1 or not r.haveprev.any():
            r.haveprev[:] = 0
            continue
        pbs = r.arm.pose.bones
        if len(pbs) != r.nb:
            r.haveprev[:] = 0
            continue
        pbs.foreach_get("rotation_quaternion", r.qbuf)
        changed = False
        for i in range(r.n_states):
            if not r.haveprev[i]:
                continue
            j = int(r.bidx[i]) * 4
            o = i * 4
            if (r.qbuf[j] != r.lastw[o] or r.qbuf[j+1] != r.lastw[o+1]
                    or r.qbuf[j+2] != r.lastw[o+2] or r.qbuf[j+3] != r.lastw[o+3]):
                continue                  # someone else owns it now
            sw = Quaternion((r.prevsw[o], r.prevsw[o+1],
                             r.prevsw[o+2], r.prevsw[o+3]))
            sw.invert()
            cq = Quaternion((float(r.qbuf[j]), float(r.qbuf[j+1]),
                             float(r.qbuf[j+2]), float(r.qbuf[j+3]))) @ sw
            r.qbuf[j] = cq.w; r.qbuf[j+1] = cq.x
            r.qbuf[j+2] = cq.y; r.qbuf[j+3] = cq.z
            changed = True
        if changed:
            pbs.foreach_set("rotation_quaternion", r.qbuf)
            r.arm.update_tag(refresh={'DATA'})
            any_changed = True
        r.haveprev[:] = 0
    return any_changed


def _sb_native_rigs():
    global _sb_nat, _sb_nat_dirty
    if _sb_nat_dirty:
        if _sb_native_unapply():
            bpy.context.view_layer.update()
        _sb_nat = _sb_build_native_layout()
        _sb_nat_dirty = False
    return _sb_nat


def _sb_native_reset():
    global _sb_nat_dirty
    rigs = _sb_nat
    if rigs:
        _sb_native_unapply()
        for r in rigs:
            if not _sb_rig_alive(r):     # deadrig
                _sb_nat_dirty = True
                continue
            r.reset()


def _sb_native_snapshot():
    rigs = _sb_nat
    if not rigs or not _SB_NATIVE_FRAME_ACTIVE:
        return None
    return [r.snapshot() for r in rigs]


def _sb_native_restore(snaps):
    rigs = _sb_nat
    if not rigs or not snaps or len(snaps) != len(rigs):
        return
    for r, s in zip(rigs, snaps):
        r.restore(s)


_SB_SPH_SRC = None      # cached names of the all-sphere collider set
_sb_has_loc = True      # any LOCATION spring active? (recomputed on rebuild)
_SB_LOC_NATIVE = set()  # state keys whose location spring runs in C
_sb_loc_all_native = True
_sb_loc_friction = 0.5  # scene collision knobs, published once per frame for
_sb_loc_citers = 2      # the compiled location solver
_sb_loc_ss_base = 4
_sb_loc_ss_target = 0.30
_sb_loc_ss_cap = 96


def _fast_spheres_ok(scene):
    """The compiled core owns every spring and nothing needs the full gather."""
    return (_sb_native_ok and _sb_use_xpbd
            and (not _sb_has_loc or _sb_loc_all_native)
            and bool(_sb_nat) and not _sb_nat_dirty and not _sb_solver_dirty
            and getattr(scene, 'sb_collision_enable', True))


def _sb_sphere_sources(scene):
    """Names of the collider objects, if EVERY collider in the scene is a
    sphere; None otherwise.

    Rebuilt only when the solver state is marked dirty. Every property that
    can change the answer (sb_object_collider, sb_bone_collider,
    sb_collider_shape, sb_collide_use_physics_objects) routes through
    _sb_param_changed / update_bone, both of which call mark_solver_dirty().

    Scanning scene.sb_spring_bones and scene.objects to answer this cost
    0.046 ms/frame -- more than the entire physics solve.
    """
    global _SB_SPH_SRC
    if _SB_SPH_SRC is None:
        for it in scene.sb_spring_bones:
            if it.sb_bone_collider:
                _SB_SPH_SRC = ()          # bone capsules: generic path
                return None
        names = []
        use_phys = getattr(scene, 'sb_collide_use_physics_objects', True)
        for ob in scene.objects:
            if getattr(ob, 'sb_object_collider', False):
                if getattr(ob, 'sb_collider_shape', 'MESH') != 'SPHERE':
                    _SB_SPH_SRC = ()
                    return None
                names.append(ob.name)
            elif (use_phys and ob.type == 'MESH'
                  and _sb_obj_has_physics_collision(ob)):
                _SB_SPH_SRC = ()          # auto mesh collider: generic path
                return None
        _SB_SPH_SRC = tuple(names)
    return _SB_SPH_SRC if _SB_SPH_SRC != () else None


def _sb_fill_spheres_direct(scene, buf):
    """Write (cx, cy, cz, r) per collider straight into `buf`.

    Returns the count, or -1 when the scene has a collider this shortcut does
    not cover, in which case the caller falls back to the full gather.
    """
    names = _sb_sphere_sources(scene)
    if names is None:
        return -1
    objs = bpy.data.objects
    n = 0
    for nm in names:
        ob = objs.get(nm)
        if ob is None:
            _sb_collider_sources_dirty()
            return -1
        if n >= _SB_MAX_SPHERES:
            return -1
        c = ob.matrix_world.translation
        j = n * 4
        buf[j] = c[0]; buf[j+1] = c[1]; buf[j+2] = c[2]
        buf[j+3] = max(ob.sb_collider_dist, 0.0)
        n += 1
    return n


def _sb_collider_sources_dirty():
    global _SB_SPH_SRC
    _SB_SPH_SRC = None


def _sb_native_fill_spheres(colliders, buf):
    """Fill `buf` in place with (cx, cy, cz, r) per collider.

    Returns the sphere count, or -1 if the set is not all spheres. A
    degenerate capsule (head == tail) IS a sphere: that is how the gather
    step represents an explicit SPHERE collider.
    """
    n = 0
    for kind, col in colliders:
        if kind != "caps":
            return -1
        p0 = col[0]
        if (col[1] - p0).length_squared > 1e-12:
            return -1                       # a real capsule: Python path
        if n >= _SB_MAX_SPHERES:
            return -1
        j = n * 4
        buf[j] = p0[0]; buf[j+1] = p0[1]; buf[j+2] = p0[2]; buf[j+3] = col[2]
        n += 1
    return n


def _sb_native_pass(scene, colliders, cbounce, dt, wind, sim_steps, iters):
    """Run one frame of the compiled core. False = not applicable."""
    global _SB_NATIVE_FRAME_ACTIVE
    _SB_NATIVE_FRAME_ACTIVE = False
    _SB_LOC_NATIVE.clear()
    rigs = _sb_native_rigs()
    if not rigs:
        return False
    lib = _sb_native.lib()
    if lib is None:
        return False

    grav = scene.gravity
    step = lib.sfx_step
    # Validate the entire frame before any rig is written. Otherwise an
    # unsupported collider can leave a partially simulated mixed frame.
    sphere_counts = []
    for r in rigs:
        if not _sb_rig_alive(r):        # deadrig2
            _sb_native_invalidate()
            return False
        arm = r.arm
        pbs = arm.pose.bones
        if len(pbs) != r.nb:
            _sb_native_invalidate()
            return False
        count = (_sb_fill_spheres_direct(scene, r.spheres) if colliders is None
                 else _sb_native_fill_spheres(colliders, r.spheres))
        if count < 0:
            return False
        sphere_counts.append(count)
    for r, n_sph in zip(rigs, sphere_counts):
        arm = r.arm
        pbs = arm.pose.bones
        for bi in r.loc_bidx[:r.n_loc]:
            pb = pbs[int(bi)]
            if pb.sb_loc_helper or pb.constraints.get('spring'):
                _sb_drop_loc_helpers(pb, arm)
        (p_mw, p_bmat, p_brest, p_bidx, p_coff, p_root, p_prm,
         p_P, p_V, p_prevT, p_smq, p_init, p_grav, p_wind,
         p_sph, p_cdamp, p_cstiff, p_qbuf, p_outq, p_scr,
         p_offs, p_bloc, p_bscl, p_bpar, p_lastw, p_prevsw,
         p_haveprev, p_wpose, p_cleanq) = r.ptr
        if (r.mode == 1 or r.n_loc) and not r.offs_ready and not _sb_native_capture_offs(r):
            r.mode = 0
            r.why = "bone basis is not invertible (zero scale?)"

        # foreach_get writes COLUMN-major 4x4s and the C side indexes them
        # that way, so the buffer goes over untouched -- no transposed copy
        # of every bone, every frame.
        if r.mode == 1:
            for bi, apb in r.anchors:
                M = apb.matrix
                o = bi * 16
                for c_ in range(4):
                    col = M.col[c_]
                    r.bmat[o + c_*4 + 0] = col[0]
                    r.bmat[o + c_*4 + 1] = col[1]
                    r.bmat[o + c_*4 + 2] = col[2]
                    r.bmat[o + c_*4 + 3] = col[3]
            pbs.foreach_get("location", r.bloc)
            pbs.foreach_get("scale", r.bscl)
        else:
            pbs.foreach_get("matrix", r.bmat)
        pbs.foreach_get("rotation_quaternion", r.qbuf)
        r.mw_view[:] = arm.matrix_world
        r.gravity[0], r.gravity[1], r.gravity[2] = grav[0], grav[1], grav[2]
        if wind is not None:
            r.wind[0], r.wind[1], r.wind[2] = wind[0], wind[1], wind[2]
            windp = p_wind
        else:
            windp = None

        if r.n_chains:
          step(p_mw, p_bmat, p_brest, p_bidx, p_coff, p_root,
             r.n_chains, r.n_states, p_prm,
             p_P, p_V, p_prevT, p_smq, p_init,
             p_grav, windp,
             dt, sim_steps, iters,
             p_sph if n_sph else None, n_sph,
             cbounce, p_cdamp, p_cstiff,
             p_qbuf, p_outq, p_scr,
             r.mode, r.nb, p_offs, p_bloc, p_bscl, p_bpar,
             p_lastw, p_prevsw, p_haveprev, p_wpose, p_cleanq,
             _sb_opt_ptr())

        if r.n_loc:
            for i, ppb in enumerate(r.loc_parents):
                o = i * 16
                if ppb is None:
                    for k in range(16):
                        r.loc_ppose[o + k] = 1.0 if k % 5 == 0 else 0.0
                else:
                    M = ppb.matrix
                    for rr in range(4):
                        row = M[rr]
                        r.loc_ppose[o + rr*4 + 0] = row[0]
                        r.loc_ppose[o + rr*4 + 1] = row[1]
                        r.loc_ppose[o + rr*4 + 2] = row[2]
                        r.loc_ppose[o + rr*4 + 3] = row[3]
            (l_ppose, l_bidx, l_prm, l_clean, l_lastw, l_init,
             l_P, l_V, l_prevT, l_buf) = r.lptr
            pbs.foreach_get("location", r.locbuf)
            lib.sfx_loc(p_mw, l_ppose, p_offs, l_bidx, r.n_loc, l_prm,
                        l_clean, l_lastw, l_init, l_P, l_V, l_prevT,
                        p_grav, windp, dt, sim_steps,
                        p_sph if n_sph else None, n_sph,
                        cbounce, _sb_loc_friction, _sb_loc_citers,
                        _sb_loc_ss_base, _sb_loc_ss_target, _sb_loc_ss_cap,
                        l_buf, _sb_opt_ptr())
            pbs.foreach_set("location", r.locbuf)
        pbs.foreach_set("rotation_quaternion", r.qbuf)
        # foreach_set writes raw property data and skips the RNA update
        # callback, so unlike `pb.matrix = ...` nothing tags the object and
        # the depsgraph never recomputes the pose. Without this the stored
        # quaternions are correct and the rig still does not move.
        # refresh={'DATA'} is the same tag `pb.matrix = ...` raises
        # internally (ID_RECALC_GEOMETRY) and is measurably cheaper than the
        # default object-level tag: 0.656 vs 0.668 ms/frame on the bench.
        arm.update_tag(refresh={'DATA'})

    # NOTE: _sb_last_swing is deliberately NOT filled here. Materialising 24
    # tuples into a dict every frame cost 0.02 ms to serve two rare callers
    # (the no-step replay and the frame cache), both of which now read
    # r.outq directly. r.outq travels in the cache snapshot, so a restored
    # frame replays its own swing rather than the last simulated one.
    _SB_NATIVE_FRAME_ACTIVE = True
    for r in rigs:
        _SB_LOC_NATIVE.update(r.loc_keys)
    return True


def _sb_native_reapply():
    """Re-write the last computed swing WITHOUT integrating.

    The pre handler has already put every bone back on its clean pose, so
    this is the same compose-and-write as a simulated frame minus the
    physics. Returns False if the compiled path does not own this rig.
    """
    rigs = _sb_nat
    if not rigs or not _SB_NATIVE_FRAME_ACTIVE or _sb_nat_dirty:
        return False
    for r in rigs:
        if not _sb_rig_alive(r):        # deadrig2
            _sb_native_invalidate()
            return False
        pbs = r.arm.pose.bones
        if len(pbs) != r.nb:
            return False
        pbs.foreach_get("rotation_quaternion", r.qbuf)
        q = r.outq
        for i in range(r.n_states):
            j = int(r.bidx[i]) * 4
            o = i * 4
            base = Quaternion((float(r.qbuf[j]), float(r.qbuf[j + 1]),
                               float(r.qbuf[j + 2]), float(r.qbuf[j + 3])))
            nq = base @ Quaternion((q[o], q[o + 1], q[o + 2], q[o + 3]))
            r.qbuf[j] = nq.w; r.qbuf[j + 1] = nq.x
            r.qbuf[j + 2] = nq.y; r.qbuf[j + 3] = nq.z
        pbs.foreach_set("rotation_quaternion", r.qbuf)
        if r.n_loc:
            pbs.foreach_get('location', r.locbuf)
            for i in range(r.n_loc):
                if r.linited[i]:
                    j = int(r.loc_bidx[i]) * 3
                    r.locbuf[j:j + 3] = r.loc_lastw[i * 3:i * 3 + 3]
            pbs.foreach_set('location', r.locbuf)
        r.arm.update_tag(refresh={'DATA'})
    return True


def _sb_xpbd_rot_pass(scene, colliders, cbounce, cfriction, citers, dt,
                      wind, sim_steps, quality):
    """Solve every rotation-spring chain and write the result in one batch."""
    from . import xpbd
    iters = xpbd.SOLVER_ITERS.get(quality, 4)
    n_sim = 0

    # Compiled core first. It owns the entire frame when it applies, and
    # returns False (having touched nothing) when the rig uses something it
    # does not support, in which case the Python solver below runs instead.
    if _sb_native_ok and _sb_native_pass(scene, colliders, cbounce, dt,
                                        wind, sim_steps, iters):
        if colliders and scene.frame_current == scene.frame_start:
            for chain in _sb_chains:
                inside = xpbd.root_inside(
                    chain.arm.matrix_world @ chain.root_pb.head,
                    max(chain.states[0].coll_dist, 0.0), colliders)
                if inside is not None:
                    _sb_root_warnings[chain.key] = inside
        return sum(ch.n for ch in _sb_chains)

    if not _SB_NATIVE_FRAME_ACTIVE:
        _SB_LOC_NATIVE.clear()
        if _sb_native_unapply():
            bpy.context.view_layer.update()

    # v8.0 BATCHED WRITE.
    # The old loop did `pb.matrix = pb.matrix @ Q` once per bone. That setter
    # re-derives matrix_basis from the parent chain on every call and tags the
    # armature each time; measured on this rig it cost 0.044 ms of Python per
    # frame against 0.005 ms for one foreach_set, plus the depsgraph churn of
    # 24 separate tags.
    # The swap is exact, not an approximation: matrix_basis @ Q leaves the
    # translation column untouched, so the whole operation is equivalent to
    # rotation_quaternion = base_quat @ q. Verified numerically to 9e-8.
    # The fallback below still uses pb.matrix whenever the base pose is not
    # frozen yet (first frame after a reset) or a bone has no buffer index.
    _wbufs = {}
    _slow_arms = set()          # armatures written through the per-bone path
    if colliders is None:
        colliders = ()          # compiled path declined; nothing to collide
    for chain in _sb_chains:
        arm = chain.arm
        states = chain.states
        n = chain.n
        mw = arm.matrix_world
        m3 = mw.to_3x3()
        wbuf = wbase = None
        _w = _wbufs.get(arm)
        if _w is None:
            _b = _SB_QBUF.get(arm)
            _nq = len(arm.pose.bones) * 4
            if (_b is not None and arm.name in _SB_BASE_READY
                    and len(_b) == _nq):
                # Seed from the LIVE channel, not from the frozen base: this
                # buffer covers every bone on the armature, and the ones we do
                # not drive are mid-animation right now. Writing the frozen
                # copy back would pin the whole rig to whatever frame the base
                # was captured on -- measured as 0.33 m of error on frame 2
                # while the spring quaternions themselves were bit-identical.
                _o = _SB_OUTBUF.get(arm)
                if _o is None or len(_o) != _nq:
                    _o = _SB_OUTBUF[arm] = np.empty(_nq, dtype=np.float32)
                arm.pose.bones.foreach_get("rotation_quaternion", _o)
                _w = _wbufs[arm] = (_o, _b)
        if _w is not None:
            wbuf, wbase = _w

        # --- rigid geometry for this frame (bones are still at base pose) ---
        P0 = mw @ chain.root_pb.head
        rest_dirs = []
        rest_frames = []
        lengths = []
        radii = []
        for st in states:
            pb = st.pb
            v = mw @ pb.tail - mw @ pb.head
            L = v.length
            lengths.append(L)
            rest_dirs.append(v / L if L > 1e-9 else Vector((0.0, 0.0, 1.0)))
            radii.append(max(st.coll_dist, 0.0))
            # Local->world rotation at the CLEAN pose. Captured now, before a
            # single write, because writing pose_bone.matrix does NOT update a
            # child's matrix until the next depsgraph evaluation -- verified:
            # the child head did not move at all until view_layer.update().
            # Reading it per bone during the write loop gave up to 70 degrees
            # of accumulated error at the chain tip.
            Rr = (mw @ pb.matrix).to_3x3()
            Rr.normalize()
            rest_frames.append(Rr)

        key = chain.key
        P = _sb_xpbd_P.get(key)
        V = _sb_xpbd_V.get(key)
        if P is None or len(P) != n + 1:
            P = [P0.copy()]
            for i in range(n):
                P.append(P[i] + rest_dirs[i] * lengths[i])
            V = [Vector((0.0, 0.0, 0.0)) for _ in range(n + 1)]
            _sb_xpbd_P[key] = P
            _sb_xpbd_V[key] = V
        P[0] = P0                              # root is kinematic

        # --- predict: spring each joint toward its rigid target -----------
        for i, st in enumerate(states):
            (p_stiff, p_damp, p_loc_speed, p_grav, p_loc_infl,
             p_maxd, p_loc_range, p_rot_stiff, p_rot_damp,
             p_rot_infl, p_rot_range, p_drag, p_wind, p_smooth,
             p_lag, p_falloff, p_autolen, p_axis,
             p_cm, p_cs, p_cd, p_cf, p_self, p_rot_speed) = st.params
            eff = min(max(p_rot_stiff * st.chain_mult
                          * _sb_length_mult(lengths[i], p_autolen), 0.0), 1.0)
            eff = _sb_rot_speed_stiffness(eff, p_rot_speed, dt)   # rotspeed
            target = P[i] + rest_dirs[i] * lengths[i]
            # lagfix: follow-through delay. Lag was only ever implemented in
            # the legacy per-bone branch, which is gated on `not _sb_use_xpbd`
            # and so has not run since chains became the default -- the slider
            # measured EXACTLY zero effect at 0.0 / 0.5 / 1.0. Same formula as
            # the legacy path: chase a target that trails the rigid one.
            if p_lag > 0.0:
                prev_l = _sb_lag_rot.get(st.key)
                if prev_l is None:
                    prev_l = target.copy()
                target = prev_l.lerp(target, max(1.0 - 0.92 * p_lag, 0.05))
                _sb_lag_rot[st.key] = target.copy()
            k_rot = 40.0 + eff * 500.0
            grav = (scene.gravity * (p_grav * 0.1)
                    + Vector((0.0, 0.0, -1.0)) * (k_rot * lengths[i] * 0.02))
            if wind is not None and p_wind > 0.0:
                grav = grav + wind * p_wind * 0.35
            prev = _sb_prev_rot_target.get(st.key)
            if prev is None:
                prev = target.copy()
            pos, vel = P[i + 1], V[i + 1]
            for j in range(sim_steps):
                tp = prev.lerp(target, j / sim_steps)
                tc = prev.lerp(target, (j + 1) / sim_steps)
                pos, vel = simulate_spring_point(
                    pos, vel, tc, eff, p_rot_damp, grav, dt,
                    target_prev=tp, drag=p_drag,
                    substep_base=1, substep_target=0.30, substep_cap=8)
            _sb_prev_rot_target[st.key] = target.copy()
            P[i + 1], V[i + 1] = pos, vel
            n_sim += 1

        # --- root sanity: a chain rooted inside a collider is unsolvable ---
        if colliders:
            inside = xpbd.root_inside(P0, radii[0], colliders)
            if inside is not None:
                _sb_root_warnings[key] = inside

        # --- constraint solve ----------------------------------------------
        # cdelta accumulates ONLY what collision moved. The distance
        # constraints and the final length projection also move particles,
        # and feeding those into the velocity response was injecting energy
        # from a non-contact source: measured, a 1e-7 float32 seed at frame 1
        # amplified to 0.237 m of divergence by frame 120.
        cdelta = [Vector((0.0, 0.0, 0.0)) for _ in range(n + 1)]
        if colliders:
            st0 = states[0]
            xpbd.solve_chain(P, lengths, radii, colliders, iters,
                             st0.params[19], cdelta=cdelta)
        else:
            xpbd.solve_chain(P, lengths, radii, (), iters, 1.0)

        # Velocity response to the constraint solve.
        #
        # NOT "V += correction/dt": that ADDS the constraint correction as
        # extra velocity on top of the spring's own, which is positive
        # feedback. Measured while developing this: chain segments blew up to
        # 3.6x their rest length within a few frames.
        #
        # A contact removes the velocity going INTO the surface (optionally
        # returning some as restitution) and bleeds the rest. It never adds.
        cdamp = states[0].params[20]
        for i in range(1, n + 1):
            dv = cdelta[i]
            if dv.length_squared < 1e-12:
                continue
            nrm = dv.normalized()
            vn = V[i].dot(nrm)
            if vn < 0.0:
                V[i] = V[i] - nrm * (vn * (1.0 + cbounce))
            V[i] = V[i] * (1.0 - cdamp)

        # --- convert to swing quaternions and WRITE, root -> tip ------------
        # The quaternion has to be expressed in the bone's LOCAL space, and a
        # bone's local space depends on its parent's freshly written pose, so
        # this is compute-and-write in order rather than a batched write.
        # (Computing all quaternions against the pre-write matrices and then
        # batching produced garbage: the local frames had already moved.)
        # The bone frame is propagated ANALYTICALLY down the chain instead of
        # re-read from RNA: F is bone i's live world frame, built from the
        # clean frames plus the swings already applied above it.
        _Y = Vector((0.0, 1.0, 0.0))
        F = rest_frames[0]
        for i, st in enumerate(states):
            pb = st.pb
            wdir = P[i + 1] - P[i]
            if wdir.length_squared < 1e-18:
                continue
            wdir.normalize()
            q = _Y.rotation_difference((F.transposed() @ wdir).normalized())
            p_rot_infl = st.params[9]
            p_rot_range = st.params[10]
            p_smooth = st.params[13]
            if abs(p_rot_range - 1.0) > 1e-4:
                ax, an = q.to_axis_angle()
                q = Quaternion(ax, an * p_rot_range)
            if p_rot_infl < 1.0:
                q = Quaternion((1.0, 0.0, 0.0, 0.0)).slerp(q, p_rot_infl)
            if p_smooth > 0.0:
                prev_q = _sb_smooth_rot.get(st.key)
                if prev_q is not None and isinstance(prev_q, Quaternion):
                    q = prev_q.slerp(q, max(1.0 - 0.85 * p_smooth, 0.1))
                _sb_smooth_rot[st.key] = q.copy()
            _sb_last_swing[st.key] = tuple(q)
            if wbuf is not None and st.bidx >= 0 and st.quat_mode:
                # Compose against the LIVE channel, which is what pb.matrix
                # would have been read from. A spring bone may carry its own
                # animation -- on the bench rig every one of them does -- so
                # the clean pose is per-frame, not the once-captured base.
                # Caching the base here pinned the swing to frame 1 and cost
                # 0.71 m of error while the swing quaternions stayed correct.
                _j = st.bidx * 4
                _nq = Quaternion((float(wbuf[_j]), float(wbuf[_j + 1]),
                                  float(wbuf[_j + 2]),
                                  float(wbuf[_j + 3]))) @ q
                wbuf[_j] = _nq.w; wbuf[_j + 1] = _nq.x
                wbuf[_j + 2] = _nq.y; wbuf[_j + 3] = _nq.z
            elif st.quat_mode:
                pb.matrix = pb.matrix @ q.to_matrix().to_4x4()
            else:
                # Euler / axis-angle bone: compose the swing straight into
                # the channel Blender evaluates for it. This is THE fix for
                # "Rotation Only does nothing until I bake" -- the batched
                # write above targets rotation_quaternion, which such a bone
                # never reads.
                _sb_apply_local_swing(pb, q)
                _slow_arms.add(arm)
            # advance the frame: apply this swing, then the constant rest
            # offset from this bone to the next one down the chain
            F_after = F @ q.to_matrix()
            if i + 1 < n:
                F = F_after @ (rest_frames[i].transposed() @ rest_frames[i + 1])

    # One RNA write per armature for the whole rig.
    #
    # update_tag() is NOT optional here. foreach_set writes the raw property
    # data and skips the per-property RNA update callback, so unlike
    # `pb.matrix = ...` it never tags the object and the depsgraph has no
    # reason to recompute pose_mat/pose_head/pose_tail. Symptom when it is
    # missing: every stored quaternion is bit-identical to the per-bone path
    # (verified) while the rig on screen moves as if the solver never ran --
    # 0.7 m of divergence from a write that "succeeded".
    for _arm, (_buf, _base) in _wbufs.items():
        _arm.pose.bones.foreach_set("rotation_quaternion", _buf)
        _arm.update_tag()

    # Per-bone RNA writes tag their own object, but an armature touched ONLY
    # through that path is tagged explicitly anyway: it costs nothing and
    # guarantees the viewport refreshes while scrubbing.
    for _arm in _slow_arms:
        if _arm not in _wbufs:
            _arm.update_tag()

    return n_sim


def spring_bone(context):
    scene = context.scene if hasattr(context, "scene") else bpy.context.scene

    # Frame-rate-independent stepping, decided FIRST (v7.4): it may
    # short-circuit the whole evaluation, so it must run before the
    # expensive collider gather / depsgraph fetch below.
    sim_steps = _sb_catchup_steps(scene)

    # VIEWPORT PRE-ROLL (v7.4). On the first simulated frame after a reset,
    # integrate extra steps against the CURRENT (static) target so gravity has
    # settled the springs before playback starts. The 7.3.3 audit measured the
    # hair tip 9 cm off its rest pose on frame 1 while BoneDynamics Pro sat
    # exactly at rest, because the spring had had no time to hang.
    # Extra steps are safe here: the target has not moved, so the per-step
    # lerp is a no-op and this is pure settling -- no frame_set re-entrancy.
    global _sb_preroll_pending
    if _sb_preroll_pending:
        _sb_preroll_pending = False
        if (sim_steps > 0 and not _sb_bake_mode
                and getattr(scene, "sb_preroll_viewport", False)):
            sim_steps += max(int(getattr(scene, "sb_preroll_viewport_frames", 20)), 0)

    if sim_steps == 0:
        # No integration this evaluation (same frame re-evaluated, or
        # state restored from cache on a backward scrub). spring_bone_pre
        # already reset the bones to their base pose, so the last pose
        # MUST be written back or the rig pops to its springless pose.
        _sb_reapply_last_pose(scene)
        return None
    # The evaluated depsgraph is only needed for mesh-collider tests. Fetching
    # it every frame is wasteful (and triggers other addons' depsgraph
    # handlers), so only grab it when at least one collider is present.
    deps = None
    # v8.0: the old "is there any collider?" pre-scan walked every spring bone
    # AND every object just to decide whether to fetch the depsgraph. The
    # depsgraph fetch costs 0.0011 ms; the scan cost 0.015. _sb_gather_colliders
    # already returns None when it finds nothing, so ask it directly.
    _sb_colliders = None
    _fast_spheres = False
    _cbounce = _cfriction = 0.0
    _citers = 1
    if getattr(scene, 'sb_collision_enable', True):
        _cbounce = getattr(scene, 'sb_collide_bounce', 0.0)
        _cfriction = getattr(scene, 'sb_collide_friction', 0.5)
        _citers = getattr(scene, 'sb_collide_iterations', 2)
    if (_fast_spheres_ok(scene)
            and _sb_sphere_sources(scene) is not None):
        # Every collider is a sphere and the compiled core owns every spring:
        # the centres and radii go straight into the solver's flat buffer and
        # the whole generic gather (0.046 ms/frame of RNA scanning and tuple
        # building) is skipped.
        _fast_spheres = True
    elif getattr(scene, 'sb_collision_enable', True):
        # Fetch the evaluated depsgraph ONCE, before the loop (needed for mesh
        # colliders' BVH). Never fetch it mid-loop: doing so forces a full rig
        # re-evaluation that bakes whatever spring writes happened so far into
        # every bone-parented target read afterwards -> left/right asymmetry.
        deps = bpy.context.evaluated_depsgraph_get()
        _sb_colliders = _sb_gather_colliders(scene, deps)

    # quality → physics accuracy vs speed (v7.3)
    _q = _sb_quality(scene)
    _ss_base   = _q['substep_base']
    _ss_target = _q['substep_target']
    _ss_cap    = _q['substep_cap']
    _citers = max(1, int(round(_citers * _q['citer_mult'])))
    global _sb_loc_friction, _sb_loc_citers
    global _sb_loc_ss_base, _sb_loc_ss_target, _sb_loc_ss_cap
    _sb_loc_friction = _cfriction
    _sb_loc_citers = _citers
    _sb_loc_ss_base = _ss_base
    _sb_loc_ss_target = _ss_target
    _sb_loc_ss_cap = _ss_cap

    # v7.4 (P1.1): the per-frame group/param caches are gone. Every parameter
    # is resolved once into _sb_solver_state and only re-resolved when marked
    # dirty, so the loop below reads plain Python attributes, not RNA.
    if _sb_solver_dirty or not _sb_solver_state_live():
        _sb_rebuild_solver_state(scene)
        _sb_capture_unset_bases()
    _n_sim = 0
    _n_skip = 0

    # Hoisted out of the bone loop: these were read once PER BONE per frame
    # even though every bone gets the same value.
    fps = max(scene.render.fps / max(scene.render.fps_base, 1e-6), 1.0)
    dt = 1.0 / fps
    noise_frame = scene.frame_current
    _arm3x3 = {}        # armature -> matrix_world.to_3x3(), once per frame

    # (sim_steps was computed at the top of this function -- see v7.4 note)

    # Wind is global: compute the base force once per frame, scale per bone.
    _wind = _sb_wind_force(scene, scene.frame_current)

    # Self-collision: spring points processed earlier this frame, as
    # (bone_name, armature_name, world_pos, radius, parent_name).
    _self_enable = getattr(scene, 'sb_self_collision_enable', False)
    _self_pts = []

    # v7.5: rotation springs are solved as chains (see _sb_xpbd_rot_pass).
    # The per-bone loop below then only handles LOCATION springs.
    if _sb_use_xpbd and _sb_chains:
        _cols_flat = None if _fast_spheres else []
        if _sb_colliders is not None:
            for _kind in ("caps", "planes", "boxes", "meshes"):
                for _c in _sb_colliders.get(_kind, ()):
                    _cols_flat.append((_kind, _c))
        _n_sim += _sb_xpbd_rot_pass(
            scene, _cols_flat, _cbounce, _cfriction, _citers, dt,
            _wind, sim_steps,
            getattr(scene, "sb_render_quality" if _sb_bake_mode else "sb_quality", "HIGH"))

    # v8.0: when XPBD owns the rotation springs, a bone with no LOCATION
    # spring has nothing left for this loop to do -- every block below the
    # location section is already gated on `not _sb_use_xpbd`. Measured on the
    # 24-bone bench, walking all 24 anyway (skip predicate + two tuple
    # unpacks + world bone length + stiffness blend + wind) cost 0.44 ms per
    # frame to produce exactly nothing.
    _xpbd_owns_rot = _sb_use_xpbd and bool(_sb_chains)
    for _st in _sb_solver_state:
        if _xpbd_owns_rot and (not _st.loc_on or _st.key in _SB_LOC_NATIVE):
            continue
        # Everything below used to be ~28 RNA reads per bone per frame.
        # Now they are slotted attribute reads off the pre-resolved state.
        bone = _st.item
        armature = _st.arm
        pose_bone = _st.pb
        _bkey = _st.key
        loc_enabled = _st.loc_on
        rot_enabled = _st.rot_on

        if _sb_bone_skipped(scene, bone, armature, pose_bone):
            _n_skip += 1
            continue
        _n_sim += 1

        (p_stiffness, p_damp, p_loc_speed, p_gravity, p_loc_influence,
         p_max_distance, p_loc_range, p_rot_stiffness, p_rot_damp,
         p_rot_influence, p_rot_range, p_air_drag, p_wind_infl, p_smooth,
         p_lag, p_chain_falloff, p_auto_length, p_stiff_axis,
         p_c_margin, p_c_stiff, p_c_damp, p_c_fricmult, p_self,
         p_rot_speed) = _st.params
        (p_noise_enable, p_noise_loc, p_noise_rot,
         p_noise_speed, p_noise_seed) = _st.noise
        p_c_excl = _st.c_excl

        # bone length in world units, shared by auto-length + rotation spring.
        # The armature's world matrix CAN be animated, so this stays per-frame
        # -- but the 3x3 is now shared by every bone on that armature.
        _m3 = _arm3x3.get(armature)
        if _m3 is None:
            _m3 = armature.matrix_world.to_3x3()
            _arm3x3[armature] = _m3
        bone_len_world = (_m3 @ Vector((0, _st.rest_len, 0))).length

        # effective stiffness multipliers: chain falloff + auto bone-size
        _eff_mult = _st.chain_mult * _sb_length_mult(bone_len_world, p_auto_length)
        eff_stiffness     = min(max(p_stiffness * _eff_mult, 0.0), 1.0)
        eff_rot_stiffness = min(max(p_rot_stiffness * _eff_mult, 0.0), 1.0)
        eff_rot_stiffness = _sb_rot_speed_stiffness(
            eff_rot_stiffness, p_rot_speed, dt)          # rotspeed

        # per-bone wind force (world space)
        wind_force = None
        if _wind is not None and p_wind_infl > 0.0:
            wind_force = _wind * p_wind_infl

        # anisotropic stiffness: only pay the matrix cost when actually used
        axis_basis = None
        axis_mult = None
        if (abs(p_stiff_axis[0] - 1.0) > 1e-4
                or abs(p_stiff_axis[1] - 1.0) > 1e-4
                or abs(p_stiff_axis[2] - 1.0) > 1e-4):
            R = (armature.matrix_world @ pose_bone.matrix).to_3x3().normalized()
            axis_basis = (R, R.transposed())     # orthonormal: inverse == transpose
            axis_mult = p_stiff_axis

        # ------------------------------------------------------------------ #
        #  LOCATION SPRING (empty + COPY_LOCATION) — spring-damper physics
        # ------------------------------------------------------------------ #
        if loc_enabled and p_loc_influence > 0.0:
            emp_head, emp_tail = _sb_ensure_loc_helpers(pose_bone, armature, scene)

            if emp_tail is not None and emp_head is not None:
                emp_tail_loc, _r, _s = emp_tail.matrix_world.decompose()
                axis_locked = _st.lock_axis

                # Lag: the spring chases a low-pass-filtered (delayed) copy of
                # the target instead of the target itself, which reads as the
                # follow-through delay of hair/cloth trailing behind the body.
                if p_lag > 0.0:
                    prev_s = _sb_lag_loc.get(_bkey)
                    if prev_s is None:
                        prev_s = emp_tail_loc.copy()
                    alpha = max(1.0 - 0.92 * p_lag, 0.05)
                    emp_tail_loc = prev_s.lerp(emp_tail_loc, alpha)
                    _sb_lag_loc[_bkey] = emp_tail_loc.copy()

                # Read the RAW spring position from our own state (not the
                # empty's location, which holds the scaled/noised visual
                # output). This keeps the simulation clean so Move Range /
                # noise can't feed back and diverge.
                if bone.loc_raw_set:
                    pos = Vector(bone.loc_raw)
                else:
                    pos = emp_head.location.copy()
                vel = Vector(bone.speed)

                # gravity + wind as external forces. Collision is resolved
                # after integration as a hard constraint on the visible flesh
                # position (higher quality, no penetration).
                ext_force = Vector((0, 0, -p_gravity))
                if wind_force is not None:
                    ext_force = ext_force + wind_force

                # Amplification for the VISUAL output (Move Range only).
                _amp = p_loc_range if abs(p_loc_range - 1.0) > 1e-4 else 1.0
                _inv_amp = 1.0 / max(_amp, 1e-6)

                # Collision setup — gathered once per bone per frame.
                _do_collide = _sb_colliders is not None and _st.collide
                _bone_r = max(_st.coll_dist, 0.0)
                _incl   = _st.incl

                # Integrate toward the moving target. sim_steps is 1 for
                # normal playback/bake; on dropped frames it catches up one
                # step per skipped frame with the target lerped across them.
                _prev_t = _sb_prev_target.get(_bkey)
                if _prev_t is None:
                    _prev_t = emp_tail_loc.copy()
                for _i in range(sim_steps):
                    _tgt_prev = _prev_t.lerp(emp_tail_loc, _i / sim_steps)
                    _tgt      = _prev_t.lerp(emp_tail_loc, (_i + 1) / sim_steps)
                    pos, vel = simulate_spring_point(
                        pos, vel, _tgt,
                        eff_stiffness, p_damp, ext_force, dt,
                        speed=p_loc_speed, target_prev=_tgt_prev,
                        drag=p_air_drag, axis_basis=axis_basis,
                        axis_mult=axis_mult,
                        substep_base=_ss_base, substep_target=_ss_target,
                        substep_cap=_ss_cap)

                    if _do_collide:
                        # Amplify to visual space, resolve, map back to raw.
                        _step_out = emp_tail_loc + (pos - emp_tail_loc) * _amp
                        _step_out, _vw = _sb_collide_point(
                            _step_out, vel * _amp, _bone_r, _incl,
                            _cbounce, _cfriction, _citers, _sb_colliders,
                            margin=p_c_margin, stiffness=p_c_stiff,
                            hit_damping=p_c_damp, friction_mult=p_c_fricmult,
                            excl=p_c_excl)
                        pos = emp_tail_loc + (_step_out - emp_tail_loc) * _inv_amp
                        vel = _vw * _inv_amp

                _sb_prev_target[_bkey] = emp_tail_loc.copy()

                # influence blends back toward rest
                pos = lerp_vec(pos, emp_tail_loc, p_loc_influence)

                # `pos` is the RAW spring result; `out_pos` is the VISUAL
                # output (amplitude-scaled). Separated so noise / Move Range
                # never compound into the physics state and diverge.
                out_pos = emp_tail_loc + (pos - emp_tail_loc) * _amp

                bone.speed = vel

                # Noise: add smooth random jitter on top of the spring result.
                if p_noise_enable and p_noise_loc > 0.0:
                    nvec = _noise_vector(noise_frame, p_noise_speed,
                                         p_noise_seed, channel=0)
                    out_pos = out_pos + nvec * p_noise_loc

                # Smoothing ("HF damping"): low-pass the VISUAL output so any
                # residual high-frequency zigzag (fast targets, collisions,
                # noise) is filtered out without touching the physics state.
                if p_smooth > 0.0:
                    # Filter the DEVIATION from the target, not the absolute
                    # world position -- see the rotation branch for why.
                    _off_s = out_pos - emp_tail_loc
                    prev_o = _sb_smooth_loc.get(_bkey)
                    if prev_o is not None:
                        _off_s = prev_o.lerp(_off_s,
                                             max(1.0 - 0.85 * p_smooth, 0.1))
                    _sb_smooth_loc[_bkey] = _off_s.copy()
                    out_pos = emp_tail_loc + _off_s

                # clamp max distance (on the visual output)
                if p_max_distance != 0.0:
                    if (out_pos - emp_tail_loc).magnitude > p_max_distance:
                        out_pos = emp_tail_loc + (out_pos - emp_tail_loc).normalized() * p_max_distance

                # optional self-collision against already-processed springs
                if _self_enable and p_self:
                    _my_r = max(_st.coll_dist, 0.01)
                    out_pos = _sb_self_collide(
                        out_pos, _my_r, bone.armature, bone.name,
                        pose_bone.parent.name if pose_bone.parent else "",
                        _self_pts)
                    _self_pts.append((bone.name, bone.armature, out_pos.copy(),
                                      _my_r,
                                      pose_bone.parent.name if pose_bone.parent else ""))

                emp_head.location = out_pos
                _sb_last_out_pos[_bkey] = tuple(out_pos)
                # remember the raw spring position for the next frame's state
                bone.loc_raw = pos
                bone.loc_raw_set = True

        # ------------------------------------------------------------------ #
        #  ROTATION SPRING
        #  The pre-frame handler already reset this bone's rotation, so the
        #  pose read here is the CLEAN animated/parent pose. We simulate a
        #  lagging tail point in world space, re-anchored to the clean head
        #  each frame, so moving the hip never snaps the rotation.
        # ------------------------------------------------------------------ #
        if rot_enabled and p_rot_influence > 0.0 and not _sb_use_xpbd:
            mat_world = _bone_rest_matrix_world(pose_bone)
            head_world = mat_world.translation
            target = _rot_tail_world(mat_world, pose_bone.bone.length)

            # Lag on the rotation target: delayed follow-through for chains.
            if p_lag > 0.0:
                prev_s = _sb_lag_rot.get(_bkey)
                if prev_s is None:
                    prev_s = target.copy()
                alpha = max(1.0 - 0.92 * p_lag, 0.05)
                target = prev_s.lerp(target, alpha)
                _sb_lag_rot[_bkey] = target.copy()

            if not bone.rot_initialized:
                bone.rot_position = target
                bone.rot_velocity = (0.0, 0.0, 0.0)
                bone.rot_head_last = head_world
                bone.rot_initialized = True

            sim_pos = Vector(bone.rot_position)
            sim_vel = Vector(bone.rot_velocity)

            # NOTE: we do NOT carry sim_pos by the head delta here. Doing so
            # cancels the natural spring lag. The spring chases the moving
            # target, and the lag it can't close is the swing. The clamp
            # below keeps that lag bounded.

            # Gravity sag. Two components:
            #  1. User gravity (slider) — visible droop, off by default.
            #  2. A small ALWAYS-ON stabilizing sag: real flesh hangs slightly
            #     BELOW the axis, so axial acceleration produces a consistent
            #     PITCH instead of random axis wander. Sized to ~1° of droop.
            #  Wind joins in as a lateral push on the simulated tail point.
            k_rot = 40.0 + eff_rot_stiffness * 500.0
            grav = (scene.gravity * (p_gravity * 0.1)
                    + Vector((0.0, 0.0, -1.0)) * (k_rot * bone_len_world * 0.02))
            if wind_force is not None:
                grav = grav + wind_force * 0.35

            # Integrate as a SPHERICAL PENDULUM: relative damping + moving
            # target, and after every step the point is projected back onto
            # the bone-length sphere with only its TANGENTIAL velocity kept.
            # NEW in v7.1: the simulated tail point ALSO collides — this is
            # what keeps hair out of the head/shoulders and cloth out of the
            # legs. The pushout happens first, then the pendulum constraint
            # re-fixes the radius along the (now rotated) direction, so the
            # collision effectively ROTATES the swing away from the surface.
            # NOTE (v7.4, measured): SpringFX collides the tail POINT of each
            # bone, not the bone's segment. Over a 24-bone rig against two
            # spheres, 250 of 5760 samples ended up inside a collider -- and
            # 151 of those (60%) had the bone's HEAD already inside, which a
            # rotation-only spring cannot undo: the head is owned by the
            # parent. The chain cuts the corner at the root and the rest
            # follows it in. A segment (capsule) test per bone would fix the
            # remaining 40%; the head-inside cases need the parent chain to
            # collide first, i.e. a proper multi-pass chain solve.
            _do_collide_rot = _sb_colliders is not None and _st.collide
            _bone_r_rot = max(_st.coll_dist, 0.0)
            _incl_rot   = _st.incl
            _prev_rt = _sb_prev_rot_target.get(_bkey)
            if _prev_rt is None:
                _prev_rt = target.copy()
            for _i in range(sim_steps):
                _rtgt_prev = _prev_rt.lerp(target, _i / sim_steps)
                _rtgt      = _prev_rt.lerp(target, (_i + 1) / sim_steps)
                sim_pos, sim_vel = simulate_spring_point(
                    sim_pos, sim_vel, _rtgt,
                    eff_rot_stiffness, p_rot_damp, grav, dt,
                    target_prev=_rtgt_prev, drag=p_air_drag,
                    substep_base=_ss_base, substep_target=_ss_target,
                    substep_cap=_ss_cap)
                # Collision + pendulum constraint. The two constraints fight
                # when a collider blocks the swing RADIALLY (pushout moves the
                # point off the sphere, re-projection puts it back inside the
                # collider), so they are alternated twice — each pass converts
                # part of the radial pushout into a tangential rotation, which
                # converges onto the sphere/collider intersection circle.
                _cp_passes = 2 if _do_collide_rot else 1
                for _cp in range(_cp_passes):
                    if _do_collide_rot:
                        sim_pos, sim_vel = _sb_collide_point(
                            sim_pos, sim_vel, _bone_r_rot, _incl_rot,
                            _cbounce, _cfriction, _citers, _sb_colliders,
                            margin=p_c_margin, stiffness=p_c_stiff,
                            hit_damping=p_c_damp, friction_mult=p_c_fricmult,
                            excl=p_c_excl,
                            max_push=_sb_max_push(bone_len_world, _bone_r_rot))
                    # pendulum constraint: back onto the sphere, tangential vel
                    if bone_len_world > 1e-9:
                        _off = sim_pos - head_world
                        _L = _off.length
                        if _L > 1e-9:
                            _dirn = _off / _L
                            sim_pos = head_world + _dirn * bone_len_world
                            sim_vel = sim_vel - _dirn * sim_vel.dot(_dirn)
            _sb_prev_rot_target[_bkey] = target.copy()

            # soft safety limit on the swing lag (smooth, not a hard wall):
            # the lag compresses progressively past 60% of the limit and can
            # never exceed it, so violent parent moves ease into the bound.
            max_lag = bone_len_world * 1.6
            soft = max_lag * 0.6
            _lagv = sim_pos - target
            _Lg = _lagv.length
            if _Lg > soft and _Lg > 1e-9:
                _newL = soft + (max_lag - soft) * (1.0 - math.exp(-(_Lg - soft) / max(max_lag - soft, 1e-9)))
                sim_pos = target + _lagv * (_newL / _Lg)
                _ho = sim_pos - head_world
                if _ho.length > 1e-9:
                    _dirn = _ho.normalized()
                    sim_pos = head_world + _dirn * bone_len_world
                    sim_vel = sim_vel - _dirn * sim_vel.dot(_dirn)
                sim_vel = sim_vel * 0.9

            # optional self-collision: the tail point keeps a sphere of
            # personal space against every spring bone processed before it
            if _self_enable and p_self:
                _my_r = max(_st.coll_dist, 0.01)
                _parent_n = pose_bone.parent.name if pose_bone.parent else ""
                sim_pos = _sb_self_collide(sim_pos, _my_r, bone.armature,
                                           bone.name, _parent_n, _self_pts)
                if bone_len_world > 1e-9:
                    _off = sim_pos - head_world
                    if _off.length > 1e-9:
                        _dirn = _off.normalized()
                        sim_pos = head_world + _dirn * bone_len_world
                        sim_vel = sim_vel - _dirn * sim_vel.dot(_dirn)
                _self_pts.append((bone.name, bone.armature, sim_pos.copy(),
                                  _my_r, _parent_n))

            bone.rot_position = sim_pos
            bone.rot_velocity = sim_vel
            bone.rot_head_last = head_world

            applied_tail = target.lerp(sim_pos, p_rot_influence)

            # Smoothing (rotation HF damping) -- v7.4 fix.
            # This used to low-pass the applied tail point in WORLD space.
            # That point is anchored to a head that moves with the body, so
            # blending toward it from last frame's world position injected an
            # error proportional to body velocity: measured on the strong-
            # motion clip, smooth=0.5 RAISED RMS jerk from 0.637 to 0.762 --
            # the slider made the exact artifact it advertises fixing worse.
            # Filtering the offset in the bone's own frame filters the SWING,
            # which is what the property actually promises.
            if p_smooth > 0.0:
                _sm_R = mat_world.to_3x3().normalized()
                _off_l = _sm_R.transposed() @ (applied_tail - head_world)
                prev_o = _sb_smooth_rot.get(_bkey)
                if prev_o is not None:
                    _off_l = prev_o.lerp(_off_l,
                                         max(1.0 - 0.85 * p_smooth, 0.1))
                _sb_smooth_rot[_bkey] = _off_l.copy()
                applied_tail = head_world + (_sm_R @ _off_l)

            # Build the swing as the MINIMAL arc rotating the local +Y axis
            # onto the lagging-tail direction (rotation_difference = shortest
            # arc, zero twist). Then scale the ANGLE by sb_rot_range.
            vec_local = relative_matrix(mat_world, Matrix.Translation(applied_tail)).translation
            if vec_local.length > 1e-9:
                swing_quat = Vector((0.0, 1.0, 0.0)).rotation_difference(vec_local.normalized())
            else:
                swing_quat = Quaternion((1.0, 0.0, 0.0, 0.0))
            if abs(p_rot_range - 1.0) > 1e-4:
                axis, angle = swing_quat.to_axis_angle()
                swing_quat = Quaternion(axis, angle * p_rot_range)

            # Noise: small smooth random rotation on top of the swing.
            if p_noise_enable and p_noise_rot > 0.0:
                nvec = _noise_vector(noise_frame, p_noise_speed,
                                     p_noise_seed, channel=1)
                noise_quat = Euler((nvec.x * p_noise_rot,
                                    nvec.y * p_noise_rot,
                                    nvec.z * p_noise_rot), 'XYZ').to_quaternion()
                swing_quat = swing_quat @ noise_quat

            # Remember the exact swing we are about to write so a no-step
            # evaluation can reproduce this pose bit-for-bit.
            _sb_last_swing[_bkey] = tuple(swing_quat)
            rot = swing_quat.to_matrix().to_4x4()
            pose_bone.matrix = pose_bone.matrix @ rot

    _sb_cache_store_frame(scene, scene.frame_current)

    global _sb_perf_bones, _sb_perf_skipped
    _sb_perf_bones = _n_sim
    _sb_perf_skipped = _n_skip
    return None


# ================================================================== #
#  COLLIDERS
# ================================================================== #

# LOCAL-SPACE BVH cache for mesh colliders. Building a BVH from a mesh every
# frame is the single most expensive thing the old collision code did. The
# trick: build the BVH ONCE in the object's LOCAL space and transform the
# query point world->local instead of transforming the mesh local->world.
# A rigid mesh that moves/rotates/scales then never needs a rebuild — only
# genuinely DEFORMING meshes (armature/cloth/shape keys/GN...) do.
_sb_bvh_cache = {}

# Modifier types that change vertex positions — a mesh with any of these
# visible cannot use the cached BVH and is rebuilt per frame.
_SB_DEFORM_MODIFIERS = {
    'ARMATURE', 'CAST', 'CLOTH', 'CURVE', 'DISPLACE', 'HOOK',
    'LAPLACIANDEFORM', 'LATTICE', 'MESH_DEFORM', 'SHRINKWRAP',
    'SIMPLE_DEFORM', 'SMOOTH', 'CORRECTIVE_SMOOTH', 'LAPLACIANSMOOTH',
    'SURFACE_DEFORM', 'WARP', 'WAVE', 'SOFT_BODY', 'OCEAN', 'NODES',
}


def _sb_mesh_is_deforming(obj):
    """True when the evaluated mesh can change shape between frames."""
    try:
        if obj.data.shape_keys is not None:
            return True
        return any(m.type in _SB_DEFORM_MODIFIERS and m.show_viewport
                   for m in obj.modifiers)
    except Exception:
        return True     # unsure -> safe (rebuild every frame)


def _sb_get_mesh_bvh(obj, deps):
    """LOCAL-space BVHTree for a mesh collider, cached for rigid meshes."""
    dynamic = _sb_mesh_is_deforming(obj)
    if not dynamic:
        cached = _sb_bvh_cache.get(obj.name)
        if cached is not None:
            return cached
    try:
        obj_eval = obj.evaluated_get(deps)
        me = obj_eval.to_mesh()
        verts = [v.co.copy() for v in me.vertices]          # LOCAL space
        polys = [tuple(p.vertices) for p in me.polygons]
        bvh = BVHTree.FromPolygons(verts, polys, all_triangles=False)
        obj_eval.to_mesh_clear()
    except Exception:
        return None
    if not dynamic:
        _sb_bvh_cache[obj.name] = bvh
    return bvh


def _sb_obj_has_physics_collision(obj):
    """Objects the user marked with Blender's own Collision physics."""
    try:
        return any(m.type == 'COLLISION' and m.show_viewport
                   for m in obj.modifiers)
    except Exception:
        return False


def _sb_owner_ok(owner, incl, excl):
    """Include/exclude filtering shared by every collider test.
    `incl` keeps the historic semantics of sb_include_only: '*' = everything,
    otherwise substring match. `excl` is the same but inverted (empty = none)."""
    if incl != "*" and owner not in incl:
        return False
    if excl and owner in excl:
        return False
    return True


def _sb_gather_colliders(scene, deps):
    """Collect every active collider once per frame as simple analytic shapes
    so the per-bone test is a handful of cheap vector ops.

      - Bone colliders   -> capsules (world head->tail segment + radius).
      - Object colliders -> Sphere / Capsule / Plane / Box / Mesh.
      - Objects with Blender's own Collision physics -> auto Mesh colliders
        (their thickness_outer becomes the surface margin) when
        scene.sb_collide_use_physics_objects is on.

    Tuple layout:
      caps   -> (p0, p1, radius, force, bounce|None, friction|None, owner)
      planes -> (point, normal, radius, force, bounce|None, friction|None, owner)
      boxes  -> (mw, mw_inv, m3_invT, radius, force, bounce|None, friction|None, owner)
      meshes -> (bvh_LOCAL, mw, mw_inv, m3_invT, radius, force, bounce|None, friction|None, owner)
    """
    caps = []
    planes = []
    boxes = []
    meshes = []

    def _own_response(pb_or_obj):
        """(bounce, friction) override for this collider, or (None, None)."""
        if getattr(pb_or_obj, 'sb_collider_use_own_response', False):
            return (getattr(pb_or_obj, 'sb_collider_bounce', None),
                    getattr(pb_or_obj, 'sb_collider_friction', None))
        return (None, None)

    def _add_mesh(obj, r, f, bv, fv):
        bvh = _sb_get_mesh_bvh(obj, deps)
        if bvh is None:
            return
        mw = obj.matrix_world.copy()
        try:
            mw_inv = mw.inverted()
        except Exception:
            return                      # degenerate matrix (zero scale)
        m3_invT = mw_inv.to_3x3().transposed()   # normal transform
        meshes.append((bvh, mw, mw_inv, m3_invT, r, f, bv, fv, obj.name))

    # --- bone colliders: capsule from world head to world tail ---
    for b in scene.sb_spring_bones:
        if not b.sb_bone_collider:
            continue
        arm = _sb_armature_of(b)
        if arm is None:
            continue
        pbc = arm.pose.bones.get(b.name)
        if pbc is None:
            continue
        mw = arm.matrix_world
        p0 = mw @ pbc.head
        p1 = mw @ pbc.tail
        r = max(pbc.sb_collider_dist, 0.0)
        f = min(max(pbc.sb_collider_force, 0.0), 1.0)
        bv, fv = _own_response(pbc)
        caps.append((p0, p1, r, f, bv, fv, b.name))

    use_physics = getattr(scene, 'sb_collide_use_physics_objects', True)

    # --- object colliders: shape decides interpretation ---
    for obj in scene.objects:
        explicit = getattr(obj, 'sb_object_collider', False)
        if not explicit:
            # auto-pickup: any mesh with Blender Collision physics enabled
            if (use_physics and obj.type == 'MESH'
                    and _sb_obj_has_physics_collision(obj)):
                margin = 0.0
                try:
                    margin = max(obj.collision.thickness_outer, 0.0)
                except Exception:
                    pass
                _add_mesh(obj, margin, 1.0, None, None)
            continue
        shape = getattr(obj, 'sb_collider_shape', 'MESH')
        r = max(obj.sb_collider_dist, 0.0)
        f = min(max(obj.sb_collider_force, 0.0), 1.0)
        bv, fv = _own_response(obj)
        mw = obj.matrix_world
        if shape == 'SPHERE':
            c = mw.translation.copy()
            caps.append((c, c.copy(), r, f, bv, fv, obj.name))
        elif shape == 'CAPSULE':
            p0 = mw @ Vector((0.0, -1.0, 0.0))
            p1 = mw @ Vector((0.0,  1.0, 0.0))
            caps.append((p0, p1, r, f, bv, fv, obj.name))
        elif shape == 'PLANE':
            pt = mw.translation.copy()
            n = (mw.to_3x3() @ Vector((0.0, 0.0, 1.0))).normalized()
            planes.append((pt, n, r, f, bv, fv, obj.name))
        elif shape == 'BOX':
            try:
                mw_inv = mw.inverted()
            except Exception:
                continue
            m3_invT = mw_inv.to_3x3().transposed()
            boxes.append((mw.copy(), mw_inv, m3_invT, r, f, bv, fv, obj.name))
        else:  # MESH — local-space BVH (cached when the mesh is rigid)
            if obj.type != 'MESH':
                continue
            _add_mesh(obj, r, f, bv, fv)

    if not caps and not planes and not boxes and not meshes:
        return None
    return {'caps': caps, 'planes': planes, 'boxes': boxes, 'meshes': meshes}


def _sb_collide_point(pos, vel, bone_r, incl, bounce, friction, iters, colliders,
                      margin=0.0, stiffness=1.0, hit_damping=0.0,
                      friction_mult=1.0, excl="", max_push=0.0):
    """Resolve collision of a single world-space point against all colliders
    with HARD projection + velocity response, and return corrected (pos, vel).

      - Position: pushed onto the collider surface offset by
        (collider_radius + bone_r + margin), scaled by the collider's
        `force` AND the bone's Collision Stiffness.
      - Velocity: incoming component is removed; `bounce` reflects it back,
        `friction` (× the bone's friction multiplier) damps tangential
        slide, and Damping on Collision bleeds extra energy per impact so
        repeated contacts settle instead of buzzing.
      - Per-collider bounce/friction values override the scene globals.
    `iters` passes let the point settle when several colliders overlap."""
    caps   = colliders['caps']
    planes = colliders['planes']
    boxes  = colliders.get('boxes', ())
    meshes = colliders['meshes']

    stiffness = min(max(stiffness, 0.0), 1.0)
    rad_extra = bone_r + max(margin, 0.0)
    # max_push > 0 caps the TOTAL positional correction this call may apply.
    # Deep penetrations (a capsule sweeping through hair, a scrubbed timeline
    # jump) then resolve smoothly over a few frames instead of teleporting
    # the point across the collider in one — the "bones shooting off" look.
    pos0 = pos.copy() if max_push > 0.0 else None

    def _respond(n, penetration, force, c_bounce, c_friction):
        nonlocal pos, vel
        eff_bounce   = c_bounce   if c_bounce   is not None else bounce
        eff_friction = c_friction if c_friction is not None else friction
        eff_friction = min(max(eff_friction * friction_mult, 0.0), 1.0)
        pos = pos + n * (penetration * force * stiffness)
        vn = vel.dot(n)
        if vn < 0.0:
            vt = vel - n * vn
            vel = vt * (1.0 - eff_friction) + n * (-vn * eff_bounce)
        if hit_damping > 0.0:
            vel = vel * (1.0 - 0.5 * hit_damping)

    for _ in range(max(1, iters)):
        hit = False
        for (p0, p1, cr, f, cb, cfr, owner) in caps:
            if not _sb_owner_ok(owner, incl, excl):
                continue
            near = project_point_onto_line(p0, p1, pos)
            d = pos - near
            dist = d.length
            rad = cr + rad_extra
            if dist < rad:
                hit = True
                n = (d / dist) if dist > 1e-6 else Vector((0.0, 0.0, 1.0))
                _respond(n, rad - dist, f, cb, cfr)
        for (pt, nrm, cr, f, cb, cfr, owner) in planes:
            if not _sb_owner_ok(owner, incl, excl):
                continue
            signed = (pos - pt).dot(nrm)
            rad = cr + rad_extra
            if signed < rad:
                hit = True
                _respond(nrm, rad - signed, f, cb, cfr)
        # boxes: unit cube [-1,1]^3 in the object's local space (scale the
        # empty/object to size it). Closest-point test done in local space.
        for (mw, mw_inv, m3_invT, cr, f, cb, cfr, owner) in boxes:
            if not _sb_owner_ok(owner, incl, excl):
                continue
            p = mw_inv @ pos
            q = Vector((min(max(p.x, -1.0), 1.0),
                        min(max(p.y, -1.0), 1.0),
                        min(max(p.z, -1.0), 1.0)))
            inside = (p - q).length < 1e-9
            if inside:
                # push out through the NEAREST face
                dists = (1.0 - abs(p.x), 1.0 - abs(p.y), 1.0 - abs(p.z))
                axis = dists.index(min(dists))
                q = p.copy()
                q[axis] = 1.0 if p[axis] >= 0.0 else -1.0
                n_local = Vector((0.0, 0.0, 0.0))
                n_local[axis] = 1.0 if p[axis] >= 0.0 else -1.0
            else:
                n_local = (p - q)
            q_w = mw @ q
            n_w = m3_invT @ n_local
            if n_w.length < 1e-9:
                continue
            n_w.normalize()
            d = pos - q_w
            signed = -d.length if inside else d.dot(n_w)
            rad = cr + rad_extra
            if signed < rad:
                hit = True
                _respond(n_w, rad - signed, f, cb, cfr)
        # meshes: BVH lives in LOCAL space — transform the query point in,
        # bring the hit back out (normals via inverse-transpose).
        for (bvh, mw, mw_inv, m3_invT, cr, f, cb, cfr, owner) in meshes:
            if not _sb_owner_ok(owner, incl, excl):
                continue
            loc, nor, idx, dd = bvh.find_nearest(mw_inv @ pos)
            if loc is None:
                continue
            loc_w = mw @ loc
            n_w = m3_invT @ nor
            d = pos - loc_w
            if n_w.length > 1e-6:
                n_w.normalize()
            elif d.length > 1e-6:
                n_w = d.normalized()
            else:
                n_w = Vector((0.0, 0.0, 1.0))
            signed = d.dot(n_w)
            rad = cr + rad_extra
            if signed < rad:
                hit = True
                _respond(n_w, rad - signed, f, cb, cfr)
        if not hit:
            break
    if pos0 is not None:
        dp = pos - pos0
        L = dp.length
        if L > max_push:
            pos = pos0 + dp * (max_push / L)
    return pos, vel


# ================================================================== #
#  GEOMETRY HELPERS
# ================================================================== #

def _apply_axis_lock(push_vec, axis_locked, pose_bone):
    if axis_locked in (None, "NONE"):
        return push_vec
    pairs = {
        "+Y": (pose_bone.y_axis, pose_bone.z_axis, pose_bone.y_axis, True),
        "-Y": (pose_bone.y_axis, pose_bone.z_axis, pose_bone.y_axis, False),
        "+X": (pose_bone.x_axis, pose_bone.y_axis, pose_bone.x_axis, True),
        "-X": (pose_bone.x_axis, pose_bone.y_axis, pose_bone.x_axis, False),
        "+Z": (pose_bone.z_axis, pose_bone.z_axis, pose_bone.x_axis, True),
        "-Z": (pose_bone.z_axis, pose_bone.z_axis, pose_bone.x_axis, False),
    }
    if axis_locked not in pairs:
        return push_vec
    check_axis, plane_n, plane_p, positive = pairs[axis_locked]
    direction_check = check_axis.normalized().dot(push_vec)
    if (positive and direction_check > 0) or (not positive and direction_check < 0):
        locked_vec = project_point_onto_plane(push_vec, plane_p, plane_n)
        push_vec = lerp_vec(push_vec, locked_vec, 0.3)
    return push_vec


def project_point_onto_plane(q, p, n):
    n = n.normalized()
    return q - ((q - p).dot(n)) * n


def project_point_onto_line(a, b, p):
    ap = p - a
    ab = b - a
    denom = ab.dot(ab)
    if denom < 1e-12:
        # degenerate segment (a == b): sphere colliders are zero-length
        # capsules, so this is the HOT path for them, not an edge case
        return a.copy()
    fac_a = (p - a).dot(b - a)
    fac_b = (p - b).dot(b - a)
    result = a + ap.dot(ab) / denom * ab
    if fac_a < 0:
        result = a
    if fac_b > 0:
        result = b
    return result


def project_point_onto_tri(TRI, P):
    """Closest point on a triangle (numpy version, kept for API compat)."""
    B = TRI[0, :]
    E0 = TRI[1, :] - B
    E1 = TRI[2, :] - B
    D = B - P
    a = dot(E0, E0); b = dot(E0, E1); c = dot(E1, E1)
    d = dot(E0, D);  e = dot(E1, D);  f = dot(D, D)
    det = a * c - b * b
    s = b * e - c * d
    t = b * d - a * e
    if (s + t) <= det:
        if s < 0.0:
            if t < 0.0:
                if d < 0:
                    t = 0.0
                    if -d >= a: s = 1.0; sqrdistance = a + 2.0*d + f
                    else:       s = -d/a; sqrdistance = d*s + f
                else:
                    s = 0.0
                    if e >= 0.0:   t = 0.0; sqrdistance = f
                    elif -e >= c:  t = 1.0; sqrdistance = c + 2.0*e + f
                    else:          t = -e/c; sqrdistance = e*t + f
            else:
                s = 0
                if e >= 0:    t = 0; sqrdistance = f
                elif -e >= c: t = 1; sqrdistance = c + 2.0*e + f
                else:         t = -e/c; sqrdistance = e*t + f
        else:
            if t < 0:
                t = 0
                if d >= 0:    s = 0; sqrdistance = f
                elif -d >= a: s = 1; sqrdistance = a + 2.0*d + f
                else:         s = -d/a; sqrdistance = d*s + f
            else:
                invDet = 1.0/det; s *= invDet; t *= invDet
                sqrdistance = s*(a*s + b*t + 2.0*d) + t*(b*s + c*t + 2.0*e) + f
    else:
        if s < 0.0:
            tmp0 = b+d; tmp1 = c+e
            if tmp1 > tmp0:
                numer = tmp1-tmp0; denom = a-2.0*b+c
                if numer >= denom: s=1.0; t=0.0; sqrdistance = a+2.0*d+f
                else:
                    s = numer/denom; t = 1-s
                    sqrdistance = s*(a*s+b*t+2*d) + t*(b*s+c*t+2*e) + f
            else:
                s = 0.0
                if tmp1 <= 0.0:  t=1; sqrdistance = c+2.0*e+f
                elif e >= 0.0:   t=0.0; sqrdistance = f
                else:            t=-e/c; sqrdistance = e*t+f
        else:
            if t < 0.0:
                tmp0 = b+e; tmp1 = a+d
                if tmp1 > tmp0:
                    numer = tmp1-tmp0; denom = a-2.0*b+c
                    if numer >= denom: t=1.0; s=0; sqrdistance = c+2.0*e+f
                    else:
                        t = numer/denom; s = 1-t
                        sqrdistance = s*(a*s+b*t+2.0*d) + t*(b*s+c*t+2.0*e) + f
                else:
                    t = 0.0
                    if tmp1 <= 0.0:  s=1; sqrdistance = a+2.0*d+f
                    elif d >= 0.0:   s=0.0; sqrdistance = f
                    else:            s=-d/a; sqrdistance = d*s+f
            else:
                numer = c+e-b-d
                if numer <= 0: s=0.0; t=1.0; sqrdistance = c+2.0*e+f
                else:
                    denom = a-2.0*b+c
                    if numer >= denom: s=1.0; t=0.0; sqrdistance = a+2.0*d+f
                    else:
                        s = numer/denom; t = 1-s
                        sqrdistance = s*(a*s+b*t+2.0*d) + t*(b*s+c*t+2.0*e) + f
    if sqrdistance < 0: sqrdistance = 0
    dist = sqrt(sqrdistance)
    PP0 = B + s*E0 + t*E1
    return dist, PP0


# ================================================================== #
#  SETUP / TEARDOWN
# ================================================================== #

def _make_empty(name, scene, location, radius=1.0, display='PLAIN_AXES'):
    o = bpy.data.objects.get(name)
    if o is None:
        o = bpy.data.objects.new(name, None)
        scene.collection.objects.link(o)
        o.empty_display_size = radius
        o.empty_display_type = display
        o.hide_set(True)
        o.hide_select = True
    o.location = location
    return o


def _sb_loc_helpers(pb, arm):
    """Resolve owned helpers; migrate the legacy name-based pair safely."""
    head, tail = pb.sb_loc_helper, pb.sb_loc_target
    owner_name = head.get('springfx_owner_bone', '') if head else ''
    owner_pb = arm.pose.bones.get(owner_name) if owner_name else None
    foreign_bone = (owner_pb is not None and owner_pb != pb
                    and owner_pb.sb_loc_helper == head)
    if foreign_bone or (tail is not None and tail.parent != arm):
        # Duplicating an armature copies PointerProperties, but it must not
        # give the duplicate ownership of the source rig's helpers.
        pb.sb_loc_helper = None
        pb.sb_loc_target = None
        head = tail = None
    if head is None:
        cns = pb.constraints.get('spring')
        candidate = cns.target if cns and cns.type == 'COPY_LOCATION' else None
        legacy_tail = bpy.data.objects.get(pb.name + '_spring_tail')
        if (candidate is not None and candidate.type == 'EMPTY'
                and legacy_tail is not None and legacy_tail.parent == arm):
            head, tail = candidate, legacy_tail
            pb.sb_loc_helper, pb.sb_loc_target = head, tail
    if head is not None and head.get('springfx_owner_bone') != pb.name:
        head['springfx_owner_bone'] = pb.name
    return head, tail


def _sb_ensure_loc_helpers(pb, arm, scene):
    """Create the Python location path when a native feature is unavailable."""
    head, tail = _sb_loc_helpers(pb, arm)
    if head is not None and tail is not None:
        cns = pb.constraints.get('spring')
        if cns is not None and cns.type == 'COPY_LOCATION' and cns.target == head:
            return head, tail
    cns = pb.constraints.get('spring')
    if cns is not None and cns.type == 'COPY_LOCATION' and cns.target != head:
        # A copied/legacy constraint can still pin this rig to another
        # owner's output. Evaluate without it before capturing a rest target.
        pb.constraints.remove(cns)
        bpy.context.view_layer.update()
    position = arm.matrix_world @ pb.head
    for suffix, obj in (('spring', head), ('spring_tail', tail)):
        if obj is None:
            obj = bpy.data.objects.new('%s:%s_%s' % (arm.name, pb.name, suffix), None)
            scene.collection.objects.link(obj)
            obj.empty_display_type = 'PLAIN_AXES'
            obj.hide_set(True)
            obj.hide_select = True
            obj.matrix_world = Matrix.Translation(position)
        if suffix == 'spring':
            head = obj
            head['springfx_owner_bone'] = pb.name
            pb.sb_loc_helper = head
        else:
            tail = obj
            pb.sb_loc_target = tail
            if tail.parent != arm or tail.parent_bone != (pb.parent.name if pb.parent else ''):
                mat = tail.matrix_world.copy()
                tail.parent = arm
                tail.parent_type = 'BONE' if pb.parent else 'OBJECT'
                tail.parent_bone = pb.parent.name if pb.parent else ''
                tail.matrix_world = mat
    cns = pb.constraints.get('spring')
    if cns is not None and cns.type != 'COPY_LOCATION':
        pb.constraints.remove(cns)
        cns = None
    if cns is None:
        cns = pb.constraints.new('COPY_LOCATION')
        cns.name = 'spring'
    cns.target = head
    return head, tail


def _spring_enabled(pb):
    return pb.sb_bone_spring_loc or pb.sb_bone_spring_rot


def _chain_tip_depth(pb):
    """Longest run of spring-enabled bones below (and including) this one."""
    best = 0
    for c in pb.children:
        if _spring_enabled(c):
            d = _chain_tip_depth(c)
            if d > best:
                best = d
    return 1 + best


def _sb_snapshot_entries(scene):
    """Capture per-bone solver state so a list rebuild does not destroy it.

    update_bone() clears and re-adds every entry, which zeroed rot_position /
    rot_velocity / rot_initialized AND re-captured rot_base_quat from the
    LIVE channel. Mid-playback that channel holds the spring-DEFORMED pose,
    so the deformation was latched as the new rest pose. Since every property
    write triggers a rebuild, dragging a single slider both reset the
    simulation and permanently baked in the current offset (measured: 0.75 m
    of divergence from one rebuild at frame 30).

    Keyed on (armature, bone) so it survives reordering and multi-rig scenes.
    """
    snap = {}
    for it in scene.sb_spring_bones:
        if it.sb_bone_collider:
            continue
        snap[_sb_state_key(it)] = (
            tuple(it.rot_position), tuple(it.rot_velocity),
            tuple(it.rot_head_last), it.rot_initialized,
            tuple(it.rot_base_quat), tuple(it.loc_base), it.rot_base_set,
            tuple(it.speed), tuple(it.loc_raw), it.loc_raw_set)
    return snap


def _sb_restore_entries(scene, snap):
    """Put the snapshot back onto the rebuilt entries. Bones that are new to
    the list keep the fresh values the rebuild gave them."""
    for it in scene.sb_spring_bones:
        if it.sb_bone_collider:
            continue
        s = snap.get(_sb_state_key(it))
        if s is None:
            continue
        (it.rot_position, it.rot_velocity, it.rot_head_last,
         it.rot_initialized, base_quat, loc_base, base_set,
         it.speed, it.loc_raw, it.loc_raw_set) = s
        # basefix5: an entry whose rotation spring was OFF at snapshot time
        # carries rot_base_set == False. When the rebuild just enabled the
        # rotation spring, update_bone() captured the base from a channel
        # nothing has written to yet -- that capture is the clean one.
        # Overwriting it with the unset snapshot left the base to be
        # captured by the NEXT frame's pre handler, i.e. after the first
        # spring write, which latched one frame of simulated swing as the
        # rest pose. This is how Add Physics (location first, then rotation)
        # ended up with bones that carried no valid base at all.
        if base_set or not it.rot_base_set:
            it.rot_base_quat = base_quat
            it.loc_base = loc_base
            it.rot_base_set = base_set


def update_bone(self, context):
    """Rebuild the runtime spring-bone list from EVERY armature in the scene.
    (The old version only scanned the active object, which silently dropped
    the runtime entries of any other armature with springs.)"""
    global _sb_bulk_dirty
    if _sb_update_suspended or _sb_bulk_depth:
        _sb_bulk_dirty = True          # coalesce into one rebuild on exit
        return
    _sb_bulk_dirty = False         # this call satisfies any pending request
    if _sb_native_unapply():
        bpy.context.view_layer.update()
    global _sb_solver_dirty
    _sb_solver_dirty = True
    _sb_base_pose_dirty()
    time_start = time.time()
    scene = bpy.context.scene
    _verbose = getattr(scene, "sb_show_perf", False)
    if _verbose:
        print("[SpringFX] rebuilding spring-bone list...")
    _sb_bvh_cache.clear()      # collider meshes may have changed
    invalidate_cache()         # chain structure changed -> cache is stale
    _sb_sync_armature_names(scene)   # migrate legacy refs / follow renames
    _sb_purge_orphans(scene)         # rigs deleted since the last rebuild
    # Solver state must outlive the rebuild below -- see _sb_snapshot_entries.
    _sb_entry_snapshot = _sb_snapshot_entries(scene)

    armatures = [ob for ob in scene.objects if ob.type == 'ARMATURE']
    # keep the active armature first so behavior matches the old single-
    # armature version when only one rig is in play
    active = bpy.context.active_object
    if active is not None and active.type == 'ARMATURE' and active in armatures:
        armatures.remove(active)
        armatures.insert(0, active)

    for col_name in ('sb_spring_bones', 'sb_mesh_colliders'):
        coll = getattr(scene, col_name)
        i = len(coll)
        while i >= 0:
            coll.remove(i)
            i -= 1

    for armature in armatures:
        for pbone in armature.pose.bones:
            loc_on = pbone.sb_bone_spring_loc
            rot_on = pbone.sb_bone_spring_rot
            col_on = pbone.sb_bone_collider
            if not loc_on and not rot_on and not col_on:
                # always-on: a bone that was just disabled must lose its
                # helpers (empties + constraint) right here, since there is
                # no longer a "stop mode" step to clean them up.
                if (pbone.constraints.get('spring') or pbone.sb_loc_helper
                        or pbone.sb_loc_target):
                    _cleanup_bone_helpers(pbone.name, armature)
                continue

            if not loc_on:
                _sb_drop_loc_helpers(pbone, armature)

            item = scene.sb_spring_bones.add()
            item.name = pbone.name
            bone_head = armature.matrix_world @ pbone.head
            item.last_loc = bone_head
            item.armature = armature.name
            item.armature_obj = armature
            item.sb_bone_collider = col_on
            item.sb_bone_colliding = pbone.sb_collide
            # rotation sim state reset
            item.rot_initialized = False
            item.rot_position = (0.0, 0.0, 0.0)
            item.rot_velocity = (0.0, 0.0, 0.0)
            item.rot_head_last = (0.0, 0.0, 0.0)
            item.loc_raw_set = False
            # chain topology (for Chain Falloff): how many spring-enabled
            # ancestors are above this bone, and the total chain length from
            # the chain root through the deepest spring-enabled descendant.
            depth = 0
            p = pbone.parent
            while p is not None and _spring_enabled(p):
                depth += 1
                p = p.parent
            item.chain_depth = depth
            item.chain_len = depth + _chain_tip_depth(pbone) if _spring_enabled(pbone) else 1
            # capture the bone's CURRENT pose rotation as the base, so the
            # spring runs on top of the custom pose instead of snapping to rest
            if pbone.sb_bone_spring_rot:
                # basefix: capture the base pose ONCE, never re-capture.
                # A solver rebuild runs on ANY parameter change (slider drag,
                # preset apply, group edit). If that happens while the
                # playhead is off the rest frame, the rotation channel holds
                # the spring's OWN output for the current frame -- capturing
                # it froze a simulated pose as the new rest pose. The chain
                # then sprang around a bent rest, which read as a permanent
                # lean plus 2-3x exaggerated swing, and compounded with every
                # further slider move.
                # Paths that legitimately need a fresh base
                # (_sb_reset_sim_state, remove_physics, disabling the spring)
                # clear rot_base_set AFTER restoring the clean pose, so a
                # genuine re-capture still happens through them.
                if not item.rot_base_set:
                    if pbone.rotation_mode == 'QUATERNION':
                        item.rot_base_quat = pbone.rotation_quaternion[:]
                    else:
                        item.rot_base_quat = pbone.rotation_euler.to_quaternion()[:]
                    item.loc_base = pbone.location[:]
                    item.rot_base_set = True
            else:
                item.rot_base_set = False
                # basefix6: the rotation spring was just switched off on a
                # bone that keeps another effect (location / collider), so
                # the always-on cleanup above did not run. Without this the
                # channel kept the LAST simulated swing forever -- toggling
                # a group's Rotation off left its bones frozen bent instead
                # of returning to the pose the user actually authored.
                prev = _sb_entry_snapshot.get((armature.session_uid, pbone.name))
                if prev is not None and prev[6]:
                    _sb_write_local_rot(pbone, Quaternion(prev[4]))
                    pbone.location = Vector(prev[5])

            parent_name = pbone.parent.name if pbone.parent else ''
            empty_radius = 1

            # LOCATION spring empties + COPY_LOCATION
            if loc_on:
                _sb_ensure_loc_helpers(pbone, armature, scene)

            # ROTATION spring needs NO empties/constraints (written to b.matrix)

    # mesh colliders
    for obj in bpy.data.objects:
        if obj.type == "MESH" and obj.sb_object_collider:
            obj.data.calc_loop_triangles()
            item = scene.sb_mesh_colliders.add()
            item.name = obj.name
            break

    _sb_restore_entries(scene, _sb_entry_snapshot)

    if _verbose:
        print("[SpringFX] rebuilt %d entr(ies) in %.3f s"
              % (len(scene.sb_spring_bones), time.time() - time_start))


def _cleanup_bone_helpers(item_name, armature_obj):
    if armature_obj:
        pbone = armature_obj.pose.bones.get(item_name)
        if pbone:
            _sb_drop_loc_helpers(pbone, armature_obj)
            # restore the bone's base pose rotation (the user's custom pose),
            # not identity, so stopping the sim leaves the pose intact
            if pbone.sb_bone_spring_rot:
                base = None
                lbase = None
                scn = bpy.context.scene
                for it in scn.sb_spring_bones:
                    if (it.name == item_name and it.rot_base_set
                            and _sb_armature_of(it) == armature_obj):
                        base = it.rot_base_quat
                        lbase = it.loc_base
                        break
                if base is not None:
                    if pbone.rotation_mode == 'QUATERNION':
                        pbone.rotation_quaternion = Quaternion(base)
                    else:
                        pbone.rotation_euler = Quaternion(base).to_euler(pbone.rotation_mode)
                if lbase is not None:
                    # the matrix write also touched the location channel;
                    # put it back so the bone is left EXACTLY as it was
                    pbone.location = Vector(lbase)


# ================================================================== #
#  ANIMATION DATA HELPERS (Blender 5.x layered actions compatible)
# ================================================================== #

def _get_action_fcurves(action, anim_data, ensure=False):
    """Return the fcurve container for an action across Blender versions.
    Blender 5.x removed action.fcurves; use the slot's channelbag instead.
    When ensure=True, create the channelbag if missing (for writing)."""
    try:
        from bpy_extras import anim_utils
        slot = None
        if anim_data is not None and getattr(anim_data, "action_slot", None) is not None:
            slot = anim_data.action_slot
        if slot is None and hasattr(action, "slots") and len(action.slots) > 0:
            slot = action.slots[0]
        if slot is not None:
            if ensure and hasattr(anim_utils, "action_ensure_channelbag_for_slot"):
                cb = anim_utils.action_ensure_channelbag_for_slot(action, slot)
            else:
                cb = anim_utils.action_get_channelbag_for_slot(action, slot)
            if cb is not None:
                return cb.fcurves
    except Exception:
        pass
    # legacy fallback (Blender 4.4 and earlier)
    return getattr(action, "fcurves", None)


def _bone_from_datapath(dp):
    """Extract the bone name from a pose.bones["Name"].xxx data path."""
    if dp.startswith('pose.bones["'):
        try:
            return dp.split('"')[1]
        except Exception:
            return None
    return None


def _fcurves_new_grouped(fcurves, data_path, index, group):
    """Create an F-Curve inside `group` on any supported Blender version."""
    # NOTE: the signature of fcurves.new() differs per collection and version:
    # 5.x channelbags accept group_name, legacy Action.fcurves (<= 4.3) accept
    # action_group, and 4.4/4.5 channelbags accept neither -- there the group
    # has to be created on the channelbag and assigned afterwards.
    for kw in ("group_name", "action_group"):
        try:
            return fcurves.new(data_path, index=index, **{kw: group})
        except TypeError:
            continue
    new_fc = fcurves.new(data_path, index=index)
    if not group:
        return new_fc
    # NOTE: the F-Curve's id_data is the Action; find the channelbag that owns
    # it so the curve lands in the bone's group, as the Dope Sheet expects.
    action = getattr(new_fc, "id_data", None)
    for layer in getattr(action, "layers", ()):
        for strip in layer.strips:
            for bag in getattr(strip, "channelbags", ()):
                if bag.fcurves.find(data_path, index=index) is None:
                    continue
                try:
                    grp = bag.groups.get(group) or bag.groups.new(group)
                    new_fc.group = grp
                except Exception:
                    pass    # grouping is cosmetic; the curve is what matters
                return new_fc
    return new_fc


def _copy_bone_fcurves(src_action, dst_action, dst_anim_data, bone_names,
                       do_loc=True, do_rot=True):
    """Copy fcurves belonging to `bone_names` from src_action into dst_action,
    replacing any existing channels for those bones. Leaves all other channels
    in dst_action untouched, so only the spring bones get overwritten."""
    src_fcurves = _get_action_fcurves(src_action, None)
    dst_fcurves = _get_action_fcurves(dst_action, dst_anim_data, ensure=True)
    if src_fcurves is None or dst_fcurves is None:
        return 0

    def _wanted(dp):
        is_loc = dp.endswith('.location')
        is_rot = ('.rotation_quaternion' in dp or '.rotation_euler' in dp)
        if is_loc and not do_loc:
            return False
        if is_rot and not do_rot:
            return False
        return is_loc or is_rot

    # remove existing dst channels for the target bones (only wanted types)
    for fc in list(dst_fcurves):
        bn = _bone_from_datapath(fc.data_path)
        if bn in bone_names and _wanted(fc.data_path):
            dst_fcurves.remove(fc)

    copied = 0
    for fc in list(src_fcurves):
        bn = _bone_from_datapath(fc.data_path)
        if bn not in bone_names or not _wanted(fc.data_path):
            continue

        new_fc = None
        # Preferred (Blender 5.x): channelbag fcurves.copy() duplicates the
        # whole curve including keyframes in one call.
        if hasattr(dst_fcurves, "copy"):
            try:
                new_fc = dst_fcurves.copy(fc)
            except Exception:
                new_fc = None

        if new_fc is None:
            new_fc = _fcurves_new_grouped(dst_fcurves, fc.data_path,
                                          fc.array_index, bn)
            new_fc.keyframe_points.add(count=len(fc.keyframe_points))
            for i, kp in enumerate(fc.keyframe_points):
                nkp = new_fc.keyframe_points[i]
                nkp.co = kp.co
                nkp.interpolation = kp.interpolation
                nkp.handle_left = kp.handle_left
                nkp.handle_right = kp.handle_right
                nkp.handle_left_type = kp.handle_left_type
                nkp.handle_right_type = kp.handle_right_type
            new_fc.update()
        copied += 1
    return copied


# ================================================================== #
#  VIEWPORT DRAW HANDLER — collider shape visualization
# ================================================================== #

_sb_draw_handle = None   # set by register(); cleared by unregister()


def _sb_make_capsule_lines(p0, p1, radius, n_sides=12):
    """Return a flat list of Vector pairs (line segments) for a capsule."""
    segs = p1 - p0
    length = segs.length
    axis = segs.normalized() if length > 1e-6 else Vector((0.0, 1.0, 0.0))
    ref = Vector((0.0, 0.0, 1.0)) if abs(axis.dot(Vector((0.0, 0.0, 1.0)))) < 0.9 \
        else Vector((1.0, 0.0, 0.0))
    t1 = axis.cross(ref).normalized()
    t2 = axis.cross(t1).normalized()

    def ring(center):
        pts = []
        for i in range(n_sides):
            a0 = 2.0 * math.pi * i       / n_sides
            a1 = 2.0 * math.pi * (i + 1) / n_sides
            pts.append(center + t1 * (math.cos(a0) * radius) + t2 * (math.sin(a0) * radius))
            pts.append(center + t1 * (math.cos(a1) * radius) + t2 * (math.sin(a1) * radius))
        return pts

    lines = ring(p0) + ring(p1)
    # 4 connecting lines at cardinal points
    for i in range(4):
        a = math.pi * 0.5 * i
        side = t1 * (math.cos(a) * radius) + t2 * (math.sin(a) * radius)
        lines += [p0 + side, p1 + side]
    return lines


def _sb_collider_draw():
    """GPU draw callback: overlay all collider shapes in the 3D viewport."""
    try:
        context = bpy.context
        if not getattr(context.scene, 'sb_draw_colliders', False):
            return
        import gpu
        from gpu_extras.batch import batch_for_shader

        lines = []

        # bone capsule colliders
        for b in context.scene.sb_spring_bones:
            if not b.sb_bone_collider:
                continue
            arm = _sb_armature_of(b)
            if arm is None:
                continue
            pbc = arm.pose.bones.get(b.name)
            if pbc is None:
                continue
            mw = arm.matrix_world
            p0 = mw @ pbc.head
            p1 = mw @ pbc.tail
            r  = max(pbc.sb_collider_dist, 0.0)
            lines.extend(_sb_make_capsule_lines(p0, p1, r))

        # object colliders
        for obj in context.scene.objects:
            if not getattr(obj, 'sb_object_collider', False):
                continue
            shape = getattr(obj, 'sb_collider_shape', 'SPHERE')
            r  = max(obj.sb_collider_dist, 0.0)
            mw = obj.matrix_world
            if shape == 'SPHERE':
                c = mw.translation.copy()
                lines.extend(_sb_make_capsule_lines(c, c.copy(), r))
            elif shape == 'CAPSULE':
                p0 = mw @ Vector((0.0, -1.0, 0.0))
                p1 = mw @ Vector((0.0,  1.0, 0.0))
                lines.extend(_sb_make_capsule_lines(p0, p1, r))
            elif shape == 'PLANE':
                pt = mw.translation.copy()
                n  = (mw.to_3x3() @ Vector((0.0, 0.0, 1.0))).normalized()
                ref2 = Vector((1.0, 0.0, 0.0)) if abs(n.dot(Vector((1.0, 0.0, 0.0)))) < 0.9 \
                    else Vector((0.0, 1.0, 0.0))
                t1 = n.cross(ref2).normalized()
                t2 = n.cross(t1).normalized()
                sz = max(r if r > 0.01 else 0.5, 0.1)
                c0 = pt + t1*sz + t2*sz; c1 = pt - t1*sz + t2*sz
                c2 = pt - t1*sz - t2*sz; c3 = pt + t1*sz - t2*sz
                lines += [c0, c1, c1, c2, c2, c3, c3, c0]
                lines += [pt, pt + n * sz * 0.5]   # normal arrow
            elif shape == 'BOX':
                # unit cube corners in local space, index = x*4 + y*2 + z
                cs = [mw @ Vector((x, y, z))
                      for x in (-1.0, 1.0) for y in (-1.0, 1.0) for z in (-1.0, 1.0)]
                for a, b in ((0,1),(2,3),(4,5),(6,7),(0,2),(1,3),(4,6),(5,7),
                             (0,4),(1,5),(2,6),(3,7)):
                    lines += [cs[a], cs[b]]

        if not lines:
            return

        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        gpu.state.depth_test_set('LESS_EQUAL')
        gpu.state.blend_set('ALPHA')
        gpu.state.line_width_set(1.5)

        batch = batch_for_shader(shader, 'LINES',
                                  {"pos": [(v.x, v.y, v.z) for v in lines]})
        shader.bind()
        shader.uniform_float("color", (1.0, 0.55, 0.0, 0.9))
        batch.draw(shader)

        # restore
        gpu.state.depth_test_set('NONE')
        gpu.state.blend_set('NONE')
        gpu.state.line_width_set(1.0)
    except Exception:
        pass


# ================================================================== #
#  REGISTER / UNREGISTER (handlers + draw only; classes live elsewhere)
# ================================================================== #

def register():
    bpy.app.handlers.frame_change_pre.append(spring_bone_pre)
    bpy.app.handlers.frame_change_post.append(spring_bone_frame_mode)
    bpy.app.handlers.load_post.append(_sb_migrate_on_load)

    global _sb_draw_handle
    try:
        _sb_draw_handle = bpy.types.SpaceView3D.draw_handler_add(
            _sb_collider_draw, (), 'WINDOW', 'POST_VIEW')
    except Exception:
        _sb_draw_handle = None


def unregister():
    try:
        bpy.app.handlers.frame_change_pre.remove(spring_bone_pre)
    except ValueError:
        pass
    try:
        bpy.app.handlers.frame_change_post.remove(spring_bone_frame_mode)
    except ValueError:
        pass
    try:
        bpy.app.handlers.load_post.remove(_sb_migrate_on_load)
    except ValueError:
        pass

    global _sb_draw_handle
    if _sb_draw_handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_sb_draw_handle, 'WINDOW')
        except Exception:
            pass
        _sb_draw_handle = None
