# SpringFX — spring / jiggle bone dynamics for animation.
# Package layout:
#   core.py       — physics engine, frame handlers, colliders, helpers setup
#   presets.py    — built-in Hair/Clothing/Body library + user preset ops
#   properties.py — PropertyGroups and all sb_* property registration
#   operators.py  — bake, groups, bulk apply, smart convert, noise, NLA
#   ui.py         — N-panel layout (View3D > Sidebar > SpringFX); 8.2: Add/Clean
#                   Physics + lista de grupos renombrables, Bake al final
#   export_engines.py — VRChat PhysBones export (game-engine bridge)

bl_info = {
    "name": "SpringFX",
    "author": "Auron3d",
    "version": (8, 2, 3),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > SpringFX",
    "description": "Spring dynamics for bones: location + inertia rotation "
                   "springs, hair/clothing presets, wind, full collision "
                   "system (body capsules, meshes, self-collision), chains, "
                   "groups, bake",
    "category": "Animation",
}

# Support live reloading during development: if the package was already
# imported, `import ...` alone would reuse the stale modules.
if "core" in locals():
    import importlib
    core       = importlib.reload(core)        # noqa: F821
    presets    = importlib.reload(presets)     # noqa: F821
    operators  = importlib.reload(operators)   # noqa: F821
    properties = importlib.reload(properties)  # noqa: F821
    ui         = importlib.reload(ui)          # noqa: F821
    export_engines = importlib.reload(export_engines)  # noqa: F821
    xpbd       = importlib.reload(xpbd)        # noqa: F821
    native     = importlib.reload(native)      # noqa: F821
else:
    from . import core, presets, operators, properties, ui, export_engines, xpbd, native

import bpy  # noqa: F401  (kept for scripts that poke springfx.bpy)


# Registration order matters:
#   properties first (PropertyGroups + sb_* props the rest depend on),
#   then operator/preset/ui classes, then the frame handlers last so the
#   simulation never runs against a half-registered addon.
_register_order = (properties, presets, operators, export_engines, ui, core)


def register():
    for mod in _register_order:
        mod.register()


def unregister():
    for mod in reversed(_register_order):
        mod.unregister()


if __name__ == "__main__":
    register()
