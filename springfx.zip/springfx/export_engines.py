# SpringFX - export_engines.py
# Export SpringFX chains to real-time engine dynamic-bone components.
#
# WHY THIS EXISTS
# ---------------
# The largest paying segment for this addon (VTuber / VRChat / game avatars)
# sets dynamic bones up twice: once in Blender to see it, then again by hand
# in Unity because nothing carries the settings across. No competitor in the
# category -- BoneDynamics Pro, Wiggle 2, Jiggle Physics -- exports to a
# runtime format. This module is the bridge.
#
# SCOPE AND HONESTY
# -----------------
# The force parameters below are a BEHAVIOURAL mapping, not a physical one.
# SpringFX integrates a spring-damper on a lagging tail point; VRChat's
# PhysBones runs its own solver. Identical numbers would not produce identical
# motion even if the units matched. What the mapping guarantees is that the
# RELATIVE feel carries over -- a loose bouncy ponytail stays loose and bouncy
# -- and that every value lands inside its documented range.
#
# Reference: https://creators.vrchat.com/common-components/physbones/

import bpy
from mathutils import Vector
import json
import os

from . import core


# ------------------------------------------------------------------ #
#  CHAIN TOPOLOGY
# ------------------------------------------------------------------ #

def _spring_on(pb):
    """True when this pose bone is simulated (not just a collider)."""
    return bool(pb and (pb.sb_bone_spring_rot or pb.sb_bone_spring_loc))


def _chain_root(pb):
    """Walk up while the parent is also a spring bone.

    A PhysBone component attaches to ONE transform and owns everything below
    it, so the unit of export is the chain root, not the bone.
    """
    cur = pb
    while cur.parent is not None and _spring_on(cur.parent):
        cur = cur.parent
    return cur


def _chain_members(root):
    """Every spring-enabled bone at or below `root`, breadth-first.

    Breadth-first so depth matches SpringFX's own chain_depth, which is what
    the falloff curve is keyed on.
    """
    out = []
    frontier = [(root, 0)]
    while frontier:
        pb, depth = frontier.pop(0)
        out.append((pb, depth))
        for child in pb.children:
            if _spring_on(child):
                frontier.append((child, depth + 1))
    return out


def collect_chains(context, selected_only=False):
    """Group every simulated bone in the scene into chains."""
    scene = context.scene
    seen = set()
    chains = []
    sel = set()
    if selected_only:
        sel = {pb.name for pb in (context.selected_pose_bones or [])}

    for item in scene.sb_spring_bones:
        if item.sb_bone_collider:
            continue
        arm = core._sb_armature_of(item)
        if arm is None:
            continue
        pb = arm.pose.bones.get(item.name)
        if pb is None or not _spring_on(pb):
            continue
        if selected_only and pb.name not in sel:
            continue
        root = _chain_root(pb)
        key = (arm.name, root.name)
        if key in seen:
            continue
        seen.add(key)
        members = _chain_members(root)
        chains.append({
            "armature": arm,
            "root": root,
            "members": members,
            "max_depth": max((d for _pb, d in members), default=0),
        })
    return chains


# ------------------------------------------------------------------ #
#  PARAMETER MAPPING  (SpringFX -> VRChat PhysBones)
# ------------------------------------------------------------------ #
#   SpringFX                  PhysBone         Reasoning
#   sb_rot_stiffness  0..1    pull     0..1    Both are "force back to rest".
#   sb_rot_damp       0..1    spring   0..1    INVERTED: PhysBones' Spring is
#                                              the WOBBLE before settling, so
#                                              more damping is less spring.
#   sb_gravity     -100..100  gravity -1..1    SpringFX multiplies scene
#                                              gravity by (g * 0.1).
#   sb_air_drag       0..1    immobile 0..1    APPROXIMATE. Drag resists
#                                              absolute motion; Immobile
#                                              resists following the parent.
#   sb_colliding_dist   m     radius     m     Same unit, same meaning.
#   sb_chain_falloff  0..1    pullCurve        Mirrors core._sb_chain_mult().
#   sb_collide        bool    allowCollision
#
#   No PhysBone equivalent: sb_lag, sb_smooth, sb_stiff_axis (anisotropy),
#   sb_rot_range, sb_noise_*, wind. Reported as `_unmapped` so the user learns
#   what will not survive the trip here, not in VR.

_UNMAPPED = (
    ("sb_lag", "Lag / Delay"),
    ("sb_smooth", "Smooth (HF Damping)"),
    ("sb_rot_range", "Swing Range"),
    ("sb_air_drag", "Air Drag (approximated as Immobile)"),
    ("sb_noise_enable", "Noise"),
)


def _clamp(v, lo, hi):
    return lo if v < lo else (hi if v > hi else v)


def _resolve(scene, pb, attr):
    """Group-aware parameter read, identical to what the solver does."""
    return core.resolve_param(scene, pb, attr)


def _falloff_curve(falloff):
    """PhysBone curve keys mirroring core._sb_chain_mult().

    Time is normalised 0 (root) -> 1 (tip). The solver clamps the multiplier
    at 0.15, so the curve does too; otherwise a long chain would go limp in
    Blender and stay stiff in Unity.
    """
    if falloff <= 0.0:
        return None
    tip = max(1.0 - falloff * 0.85, 0.15)
    return [(0.0, 1.0), (1.0, round(tip, 4))]


def map_chain(scene, chain):
    """Build the PhysBone payload for one chain."""
    root = chain["root"]
    arm = chain["armature"]

    stiffness = _resolve(scene, root, "sb_rot_stiffness")
    damp = _resolve(scene, root, "sb_rot_damp")
    gravity = _resolve(scene, root, "sb_gravity")
    drag = _resolve(scene, root, "sb_air_drag")
    falloff = _resolve(scene, root, "sb_chain_falloff")

    out = {
        "rootTransform": root.name,
        "armature": arm.name,
        "bones": [pb.name for pb, _d in chain["members"]],
        "integrationType": "Simplified",
        "pull": round(_clamp(stiffness, 0.0, 1.0), 4),
        "spring": round(_clamp(1.0 - damp, 0.0, 1.0), 4),
        "gravity": round(_clamp(gravity * 0.1, -1.0, 1.0), 4),
        "gravityFalloff": 0.0,
        "immobile": round(_clamp(drag, 0.0, 1.0), 4),
        "immobileType": "AllMotion",
        "limitType": "None",
        "allowCollision": "True" if root.sb_collide else "False",
        "radius": round(max(root.sb_colliding_dist, 0.0), 5),
        # SpringFX has no stretching yet, so keep the bone rigid rather than
        # let PhysBones invent a length change Blender never showed.
        "stretchMotion": 0.0,
        "maxStretch": 1.0,
        "maxSquish": 0.0,
    }

    members = [pb for pb, _d in chain["members"]]

    # ENDPOINT. A PhysBone chain moves the transforms BELOW the root, so the
    # last bone in the chain only swings if something hangs off it. When the
    # chain ends at a leaf -- which is the normal case for hair and cloth --
    # the tip bone stays frozen in Unity while it swings perfectly well in
    # Blender. endpointPosition adds the virtual child that fixes it. The
    # value is the last bone's tail in ITS OWN local space, which is the
    # bone's length along +Y regardless of the axis convention the FBX used.
    tip = members[-1]
    if not any(_spring_on(c) for c in tip.children):
        out["endpointPosition"] = [0.0, round(tip.bone.length, 5), 0.0]
    else:
        out["endpointPosition"] = [0.0, 0.0, 0.0]

    # Multi-child: PhysBones has to be told what to do where a bone forks.
    out["multiChildType"] = "Ignore"

    curve = _falloff_curve(falloff)
    if curve:
        out["pullCurve"] = [{"time": t, "value": v} for t, v in curve]

    # RADIUS CURVE. SpringFX stores a collision radius per bone; PhysBones
    # takes one radius plus a curve along the chain. Exporting only the root
    # radius silently thinned or fattened every other bone.
    radii = [max(pb.sb_colliding_dist, 0.0) for pb in members]
    rmax = max(radii) if radii else 0.0
    if rmax > 1e-6 and len(radii) > 1 and (max(radii) - min(radii)) > 1e-6:
        out["radius"] = round(rmax, 5)
        n_r = len(radii) - 1
        out["radiusCurve"] = [
            {"time": round(i / n_r, 4), "value": round(r / rmax, 4)}
            for i, r in enumerate(radii)]

    # ANGLE LIMIT. Swing Range below 1 means the bone is not allowed to reach
    # the full lag angle. PhysBones expresses that as an angle cone rather
    # than a scale factor, so this is a behavioural approximation, flagged as
    # such in _notes rather than presented as an exact translation.
    rot_range = _resolve(scene, root, "sb_rot_range")
    if rot_range < 0.999:
        out["limitType"] = "Angle"
        out["maxAngleX"] = round(_clamp(rot_range * 90.0, 0.0, 180.0), 2)
        out.setdefault("_notes", []).append(
            "Swing Range %.2f approximated as a %.0f degree angle limit"
            % (rot_range, out["maxAngleX"]))

    unmapped = []
    for attr, label in _UNMAPPED:
        try:
            val = _resolve(scene, root, attr)
        except Exception:
            continue
        if isinstance(val, bool):
            if val:
                unmapped.append(label)
        else:
            neutral = 1.0 if attr == "sb_rot_range" else 0.0
            if abs(float(val) - neutral) > 1e-6:
                unmapped.append(label)
    if unmapped:
        out["_unmapped"] = unmapped
    return out


# ------------------------------------------------------------------ #
#  COLLIDERS
# ------------------------------------------------------------------ #
# PhysBone colliders are Sphere / Capsule / Plane only. SpringFX also offers
# Box and Mesh, which have no runtime equivalent and are reported as skipped.
#
# Positions are emitted as an offset in the PARENT BONE's local space, not
# world space. Blender is Z-up and Unity is Y-up, and the exact axis swap
# depends on the FBX export settings the user picked, so a world-space
# position would silently land in the wrong place. A bone-local offset at
# least travels with whatever convention the rig itself was exported under.

_SHAPE_MAP = {"SPHERE": "Sphere", "CAPSULE": "Capsule", "PLANE": "Plane"}


def collect_colliders(context):
    """(colliders, skipped) -- runtime-representable colliders and the rest."""
    scene = context.scene
    out = []
    skipped = []
    for obj in scene.objects:
        if not getattr(obj, "sb_object_collider", False):
            continue
        shape = _SHAPE_MAP.get(obj.sb_collider_shape)
        if shape is None:
            skipped.append((obj.name, obj.sb_collider_shape))
            continue
        entry = {
            "name": obj.name,
            "shape": shape,
            "radius": round(max(obj.sb_collider_dist, 0.0), 5),
        }
        if obj.parent is not None and obj.parent_type == "BONE" and obj.parent_bone:
            entry["parentArmature"] = obj.parent.name
            entry["parentBone"] = obj.parent_bone
            pb = obj.parent.pose.bones.get(obj.parent_bone)
            if pb is not None:
                bone_mat = obj.parent.matrix_world @ pb.matrix
                local = bone_mat.inverted() @ obj.matrix_world.translation
                entry["localOffset"] = [round(c, 5) for c in local]
        else:
            entry["parentBone"] = None
            entry["worldPosition"] = [round(c, 5)
                                      for c in obj.matrix_world.translation]
        if shape == "Capsule":
            # A SpringFX capsule is the segment from local (0,-1,0) to
            # (0,+1,0) transformed by the object, with sb_collider_dist as
            # its radius -- so the segment length is 2 * |world Y axis|, and
            # PhysBone height is that segment plus the two hemisphere caps.
            y_axis = obj.matrix_world.to_3x3() @ Vector((0.0, 1.0, 0.0))
            seg = y_axis.length * 2.0
            entry["height"] = round(seg + 2.0 * max(obj.sb_collider_dist, 0.0), 5)
        sx, sy, sz = (abs(v) for v in obj.matrix_world.to_scale())
        if max(sx, sy, sz) - min(sx, sy, sz) > 1e-4 and shape == "Sphere":
            entry["_warning"] = ("non-uniform scale %.3f/%.3f/%.3f; PhysBone "
                                 "spheres are uniform" % (sx, sy, sz))
        out.append(entry)
    return out, skipped


# ------------------------------------------------------------------ #
#  OPERATOR
# ------------------------------------------------------------------ #

# ------------------------------------------------------------------ #
#  PRE-FLIGHT VALIDATION
# ------------------------------------------------------------------ #
# Everything below answers one question: will this rig behave the same way
# once it is a PhysBone? The export itself cannot fail on most of these, and
# that is exactly the problem -- they surface in VR, hours later, as "the
# hair does not move" or "the collider is in her chin". Reporting them in
# Blender is the whole point.

def validate(context, selected_only=False):
    """Return (errors, warnings, info) as lists of plain strings."""
    scene = context.scene
    errors, warnings, info = [], [], []

    chains = collect_chains(context, selected_only)
    if not chains:
        errors.append("No spring chains found to export.")
        return errors, warnings, info

    # Unity matches bones by NAME. Duplicates anywhere under the avatar root
    # make the import ambiguous, and the importer picks the first match.
    seen = {}
    for chain in chains:
        arm = chain["armature"]
        for pb, _d in chain["members"]:
            seen.setdefault(pb.name, []).append(arm.name)
    for name, arms in seen.items():
        if len(arms) > 1:
            errors.append("Bone name '%s' appears on %d armatures (%s); "
                          "Unity resolves PhysBones by name."
                          % (name, len(arms), ", ".join(sorted(set(arms)))))
    for name in seen:
        if any(ord(c) > 127 for c in name):
            warnings.append("Bone '%s' has non-ASCII characters; some FBX "
                            "exporters rename these." % name)
        if name != name.strip():
            warnings.append("Bone '%s' has leading/trailing whitespace." % name)

    for chain in chains:
        root = chain["root"]
        members = [pb for pb, _d in chain["members"]]
        if len(members) < 2 and not any(root.children):
            warnings.append("Chain '%s' is a single leaf bone; a PhysBone "
                            "needs a child transform (or endpointPosition) "
                            "to have anything to move." % root.name)
        for pb in members:
            s = pb.scale
            if (abs(s[0]-1.0) > 1e-3 or abs(s[1]-1.0) > 1e-3
                    or abs(s[2]-1.0) > 1e-3):
                warnings.append("Bone '%s' is posed with a non-unit scale "
                                "(%.3f, %.3f, %.3f); PhysBones ignore bone "
                                "scale." % (pb.name, s[0], s[1], s[2]))
                break
        for pb in members:
            forks = [c for c in pb.children if _spring_on(c)]
            if len(forks) > 1:
                warnings.append("Bone '%s' forks into %d spring children; "
                                "PhysBones handles that with multiChildType, "
                                "exported as Ignore." % (pb.name, len(forks)))
                break
        data = map_chain(scene, chain)
        for label in data.get("_unmapped", ()):
            info.append("Chain '%s': %s has no PhysBone equivalent."
                        % (root.name, label))
        for note in data.get("_notes", ()):
            info.append("Chain '%s': %s" % (root.name, note))

    # LOCATION springs have no PhysBone equivalent at all: PhysBones rotate
    # bones, they never translate them.
    loc_bones = []
    for arm in {c["armature"] for c in chains}:
        for pb in arm.pose.bones:
            if getattr(pb, "sb_bone_spring_loc", False):
                loc_bones.append(pb.name)
    if loc_bones:
        warnings.append("%d bone(s) use LOCATION springs (%s%s), which "
                        "PhysBones cannot reproduce -- it only rotates."
                        % (len(loc_bones), ", ".join(loc_bones[:4]),
                           " ..." if len(loc_bones) > 4 else ""))

    cols, skipped = collect_colliders(context)
    for name, shape in skipped:
        warnings.append("Collider '%s' is a %s; PhysBones has no such shape, "
                        "it will be skipped." % (name, shape))
    for c in cols:
        if "_warning" in c:
            warnings.append("Collider '%s': %s" % (c["name"], c["_warning"]))
        if c.get("radius", 0.0) <= 0.0:
            warnings.append("Collider '%s' has radius 0 and will do nothing."
                            % c["name"])
        if c.get("parentBone") is None:
            warnings.append("Collider '%s' is not parented to a bone; its "
                            "world position is exported, which only lines up "
                            "if the avatar is at the origin." % c["name"])
    if cols and not any(ch.get("allowCollision") == "True"
                        for ch in (map_chain(scene, c) for c in chains)):
        info.append("%d collider(s) exported but no chain has collision "
                    "enabled." % len(cols))

    unit = scene.unit_settings.scale_length
    if abs(unit - 1.0) > 1e-6:
        warnings.append("Scene unit scale is %.4f; PhysBone radii and offsets "
                        "are exported in Blender units and will need scaling "
                        "in Unity." % unit)
    return errors, warnings, info


class SB_OT_validate_physbones(bpy.types.Operator):
    """Check this rig against VRChat PhysBones without writing anything.

    Reports what will not survive the conversion: duplicate bone names,
    unmapped features, collider shapes with no equivalent, location springs,
    and unit-scale mismatches
    """
    bl_idname = "sb.validate_physbones"
    bl_label = "Validate for PhysBones"
    bl_options = {"REGISTER"}

    selected_only: bpy.props.BoolProperty(name="Selected Bones Only",
                                          default=False)

    @classmethod
    def poll(cls, context):
        return bool(context.scene.sb_spring_bones)

    def execute(self, context):
        errors, warnings, info = validate(context, self.selected_only)
        for e in errors:
            print("[SpringFX] ERROR   " + e)
        for w in warnings:
            print("[SpringFX] WARNING " + w)
        for i in info:
            print("[SpringFX] note    " + i)
        if errors:
            self.report({"ERROR"}, "%d error(s), %d warning(s) -- see the "
                        "System Console" % (len(errors), len(warnings)))
            return {"CANCELLED"}
        if warnings:
            self.report({"WARNING"}, "%d warning(s), %d note(s) -- see the "
                        "System Console" % (len(warnings), len(info)))
        else:
            self.report({"INFO"}, "PhysBones export looks clean (%d note(s))."
                        % len(info))
        return {"FINISHED"}

class SB_OT_export_physbones(bpy.types.Operator):
    """Write this rig's SpringFX setup as a VRChat PhysBones JSON file.

    Pair it with the SpringFXPhysBoneImporter.cs editor script on the Unity
    side, which rebuilds the components on the imported avatar
    """
    bl_idname = "sb.export_physbones"
    bl_label = "Export to VRChat PhysBones"
    bl_options = {"REGISTER"}

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})

    selected_only: bpy.props.BoolProperty(
        name="Selected Bones Only", default=False,
        description="Export only chains that contain a selected bone")
    include_colliders: bpy.props.BoolProperty(
        name="Include Colliders", default=True,
        description="Export sphere/capsule/plane colliders. Box and Mesh "
                    "colliders have no PhysBone equivalent and are skipped")
    ignore_errors: bpy.props.BoolProperty(
        name="Ignore Errors", default=False,
        description="Export even when validation found blocking problems "
                    "(duplicate bone names and the like). The problems are "
                    "still written into the file's validation block")

    @classmethod
    def poll(cls, context):
        return bool(context.scene.sb_spring_bones)

    def execute(self, context):
        scene = context.scene
        chains = collect_chains(context, self.selected_only)
        if not chains:
            self.report({"WARNING"}, "No spring chains to export.")
            return {"CANCELLED"}

        errors, warnings, info = validate(context, self.selected_only)
        if errors and not self.ignore_errors:
            for e in errors:
                print("[SpringFX] ERROR   " + e)
            self.report({"ERROR"},
                        "%d blocking problem(s); see the System Console. "
                        "Re-run with Ignore Errors to export anyway."
                        % len(errors))
            return {"CANCELLED"}

        from . import __init__ as _pkg
        ver = ".".join(str(v) for v in getattr(_pkg, "bl_info", {})
                       .get("version", (8, 0, 0)))
        payload = {
            "format": "springfx-physbones",
            "formatVersion": 2,
            "generator": "SpringFX %s" % ver,
            "blender": bpy.app.version_string,
            "sourceFile": os.path.basename(bpy.data.filepath) or "(unsaved)",
            "unitScale": "meters",
            "sceneUnitScale": round(scene.unit_settings.scale_length, 6),
            "axisNote": ("Blender is Z-up, Unity is Y-up. Collider offsets are "
                         "emitted in the PARENT BONE's local space so they "
                         "travel with whatever convention the FBX used; world "
                         "positions are a fallback and assume the avatar sits "
                         "at the origin."),
            "note": ("Force values are a behavioural mapping, not a physical "
                     "one. See the addon docs for the parameter table."),
            "chains": [map_chain(scene, c) for c in chains],
            "validation": {
                "errors": errors, "warnings": warnings, "notes": info,
            },
        }

        skipped = []
        if self.include_colliders:
            cols, skipped = collect_colliders(context)
            payload["colliders"] = cols

        path = self.filepath
        if not path.lower().endswith(".json"):
            path += ".json"
        try:
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2)
        except OSError as exc:
            self.report({"ERROR"}, "Could not write %s: %s" % (path, exc))
            return {"CANCELLED"}

        msg = "Exported %d chain(s), %d bone(s)" % (
            len(chains), sum(len(c["members"]) for c in chains))
        if self.include_colliders:
            msg += ", %d collider(s)" % len(payload.get("colliders", []))
        if skipped:
            msg += " -- skipped %s (no PhysBone equivalent)" % ", ".join(
                "%s (%s)" % (n, s) for n, s in skipped)
        unmapped = sorted({u for c in payload["chains"]
                           for u in c.get("_unmapped", ())})
        if unmapped:
            msg += " -- not carried over: %s" % ", ".join(unmapped)
        for w in warnings:
            print("[SpringFX] WARNING " + w)
        for i in info:
            print("[SpringFX] note    " + i)
        if warnings:
            msg += " -- %d warning(s), see the System Console" % len(warnings)
            self.report({"WARNING"}, msg)
        else:
            self.report({"INFO"}, msg)
        return {"FINISHED"}

    def invoke(self, context, event):
        if not self.filepath:
            blend = bpy.data.filepath
            base = (os.path.splitext(os.path.basename(blend))[0]
                    if blend else "springfx")
            self.filepath = base + "_physbones.json"
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


classes = (SB_OT_validate_physbones, SB_OT_export_physbones)


def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)


def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
