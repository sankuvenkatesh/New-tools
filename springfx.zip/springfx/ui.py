# SpringFX — ui.py
# NOTE: 8.2 N-panel redesign. The flow is linear: Add Physics -> Clean
# Physics -> group list (renamable) -> active group settings, and Bake last.
# The Active Bone panel, "Add Noise" and the per-group foldout boxes are gone:
# all detail lives in the group selected in the list, which is where the user
# is looking.

import bpy
from . import core as _sb_core

from . import core, operators, presets
from .core import get_bone_group
from .operators import (
    SB_OT_select_bone, SB_OT_bake, SB_OT_add_physics,
    SB_OT_group_assign, SB_OT_group_select,
    SB_OT_noise_mod_apply, SB_OT_noise_mod_remove,
    SB_OT_setup_bone_colliders, SB_OT_remove_bone_colliders,
    SB_OT_action_to_nla, SB_OT_auto_setup_collisions, SB_OT_remove_physics,
)
from .presets import (
    SB_OT_preset_save, SB_OT_preset_delete,
    SB_OT_preset_rename, SB_OT_preset_favorite, _is_favorite,
)


# ================================================================== #
#  HELPERS
# ================================================================== #

def _active_group(scene):
    """(index, group) of the item selected in the list, or (-1, None)."""
    idx = scene.sb_active_group_index
    if 0 <= idx < len(scene.sb_bone_groups):
        return idx, scene.sb_bone_groups[idx]
    return -1, None


def _group_members(scene, group_name):
    """Bone names of the group across ALL armatures in the scene -- a group
    can span several rigs."""
    names = []
    for ob in scene.objects:
        if ob.type != 'ARMATURE':
            continue
        for pb in ob.pose.bones:
            if pb.sb_group == group_name:
                names.append(pb.name)
    return names


# ================================================================== #
#  UI LIST — la "ventana" de grupos (el asa inferior la expande/retrae)
# ================================================================== #

class SB_UL_groups(bpy.types.UIList):
    """One row per group. Double-click (or Ctrl+click) the name to rename it;
    the two icons toggle the location / rotation spring for every member"""

    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "name", text="", emboss=False, icon='GROUP_BONE')
            sub = row.row(align=True)
            sub.prop(item, "enable_loc", text="", icon='CON_LOCLIMIT', toggle=True)
            sub.prop(item, "enable_rot", text="", icon='CON_ROTLIMIT', toggle=True)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='GROUP_BONE')


# ================================================================== #
#  PANEL RAÍZ
# ================================================================== #

class SB_PT_ui(bpy.types.Panel):
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = 'SpringFX'
    bl_label       = "SpringFX"

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and context.active_object is not None

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        n = sum(1 for b in scene.sb_spring_bones if not b.sb_bone_collider)
        if n:
            layout.label(text=f"{n} spring bone(s) — simulating on playback",
                         icon='PLAY')
        else:
            layout.label(text="Select bones and press Add Physics",
                         icon='INFO')

        # NOTE: both buttons together and large: they are 90% of daily use.
        col = layout.column(align=True)
        col.scale_y = 1.35
        col.operator(SB_OT_add_physics.bl_idname,
                     text="Add Physics", icon='PHYSICS')
        col.operator(SB_OT_remove_physics.bl_idname,
                     text="Clean Physics", icon='TRASH')
        # NOTE: Bake here too, next to Clean: the three everyday actions stay
        # together; its options (Pre-Roll, constraints, export) live under Bake.
        col.operator(SB_OT_bake.bl_idname,
                     text="Bake Spring to Keyframes", icon='KEYFRAME_HLT')

        # NOTE: template_list instead of per-group boxes: it has a grip to
        # expand/collapse up or down, and double-click renaming.
        layout.template_list("SB_UL_groups", "", scene, "sb_bone_groups",
                             scene, "sb_active_group_index",
                             rows=3, maxrows=6)

        idx, grp = _active_group(scene)
        if grp is None:
            if scene.sb_bone_groups:
                layout.label(text="Select a group in the list", icon='INFO')
            return

        members = _group_members(scene, grp.name)
        row = layout.row(align=True)
        row.label(text=f"{len(members)} bone(s)", icon='BONE_DATA')
        op = row.operator(SB_OT_group_select.bl_idname, text="Select",
                          icon='RESTRICT_SELECT_OFF')
        op.group_index = idx
        op = row.operator(SB_OT_group_assign.bl_idname, text="Assign",
                          icon='ADD')
        op.group_index = idx
        if not members:
            layout.label(text="Empty — select bones and press Assign",
                         icon='INFO')


# ================================================================== #
#  ACTIVE GROUP SETTINGS
# ================================================================== #

class SB_PT_settings(bpy.types.Panel):
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = 'SpringFX'
    bl_label       = "Settings"
    bl_parent_id   = "SB_PT_ui"
    bl_order       = 1

    @classmethod
    def poll(cls, context):
        if context.mode != 'POSE':
            return False
        _idx, grp = _active_group(context.scene)
        return grp is not None

    def draw_header(self, context):
        # NOTE: the group name in the header makes clear WHAT is being edited
        _idx, grp = _active_group(context.scene)
        if grp is not None:
            self.layout.label(text=grp.name, icon='GROUP_BONE')

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        idx, grp = _active_group(scene)
        if grp is None:
            return

        # --- name (also editable by double-clicking in the list) ---
        layout.prop(grp, "name", text="Name")

        # --- efectos ---
        row = layout.row(align=True)
        row.prop(grp, "enable_loc", text="Location", icon='CON_LOCLIMIT',
                 toggle=True)
        row.prop(grp, "enable_rot", text="Rotation", icon='CON_ROTLIMIT',
                 toggle=True)

        # --- preset ---
        prow = layout.row(align=True)
        prow.prop(grp, "preset", text="", icon='PRESET')
        is_fav = grp.preset != "NONE" and _is_favorite(scene, grp.preset)
        op = prow.operator(SB_OT_preset_favorite.bl_idname, text="",
                           icon='SOLO_ON' if is_fav else 'SOLO_OFF',
                           depress=is_fav)
        op.group_index = idx
        prow2 = layout.row(align=True)
        op = prow2.operator(SB_OT_preset_save.bl_idname, text="Save",
                            icon='ADD')
        op.group_index = idx
        prow2.operator(SB_OT_preset_rename.bl_idname, text="Rename",
                       icon='GREASEPENCIL')
        prow2.operator(SB_OT_preset_delete.bl_idname, text="Delete",
                       icon='REMOVE')

        if not grp.drive_params:
            # NOTE: without the Active Bone panel there is nowhere to edit
            # per-bone parameters, so a group that doesn't drive them is inert: warn.
            box = layout.box()
            box.label(text="Group is not driving its bones", icon='ERROR')
            box.prop(grp, "drive_params", text="Drive Parameters",
                     icon='LINKED')
            return

        # --- parameters ---
        if grp.enable_loc:
            box = layout.box()
            box.label(text="Location Spring", icon='CON_LOCLIMIT')
            col = box.column(align=True)
            col.prop(grp, "sb_stiffness",     text="Stiffness")
            col.prop(grp, "sb_damp",          text="Damping")
            col.prop(grp, "sb_loc_speed",     text="Speed")
            col.prop(grp, "sb_gravity",       text="Gravity")
            col.prop(grp, "sb_loc_influence", text="Influence")
            col.prop(grp, "sb_loc_range",     text="Move Range")
            col.prop(grp, "sb_max_distance",  text="Max Distance")

        if grp.enable_rot:
            box = layout.box()
            box.label(text="Rotation Spring", icon='CON_ROTLIMIT')
            col = box.column(align=True)
            col.prop(grp, "sb_rot_stiffness", text="Stiffness")
            col.prop(grp, "sb_rot_damp",      text="Damping")
            col.prop(grp, "sb_rot_speed",     text="Speed")
            col.prop(grp, "sb_rot_range",     text="Swing Range")
            col.prop(grp, "sb_rot_influence", text="Influence")

        if not grp.enable_loc and not grp.enable_rot:
            layout.label(text="Enable Location and/or Rotation above",
                         icon='INFO')

        # --- group collision (formerly in Active Bone) ---
        cbox = layout.box()
        crow = cbox.row()
        crow.prop(grp, "collide", text="")
        crow.label(text="Reacts to Colliders", icon='PHYSICS')
        if grp.collide:
            ccol = cbox.column(align=True)
            ccol.prop(grp, "collide_radius",     text="Collide Radius")
            ccol.prop(grp, "sb_collide_margin",  text="Margin")
            ccol.prop(grp, "sb_collide_stiffness", text="Stiffness")
            ccol.prop(grp, "sb_collide_damping", text="Damping on Impact")
            ccol.prop(grp, "sb_collide_friction_mult", text="Friction Mult")
            ccol.prop(grp, "sb_self_collision",  text="Self Collision")
            if grp.sb_self_collision and not scene.sb_self_collision_enable:
                ccol.label(text="Enable Self Collision in Collisions",
                           icon='ERROR')

        # --- advanced dynamics (collapsible) ---
        abox = layout.box()
        abox.prop(scene, "sb_ui_show_advanced",
                  icon='TRIA_DOWN' if scene.sb_ui_show_advanced else 'TRIA_RIGHT',
                  emboss=False)
        if scene.sb_ui_show_advanced:
            col = abox.column(align=True)
            col.prop(grp, "sb_chain_falloff",  text="Chain Falloff")
            col.prop(grp, "sb_lag",            text="Lag / Delay")
            col.prop(grp, "sb_smooth",         text="Smooth (HF Damping)")
            col.prop(grp, "sb_air_drag",       text="Air Drag")
            col.prop(grp, "sb_wind_influence", text="Wind Influence")
            col.prop(grp, "sb_auto_length",    text="Auto Bone-Size Tuning")
            col.separator()
            col.label(text="Stiffness per Local Axis:")
            col.row(align=True).prop(grp, "sb_stiff_axis", text="")


# ================================================================== #
#  COLLISIONS
# ================================================================== #

class SB_PT_collisions(bpy.types.Panel):
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = 'SpringFX'
    bl_label       = "Collisions"
    bl_parent_id   = "SB_PT_ui"
    bl_order       = 2
    bl_options     = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE'

    def draw_header(self, context):
        self.layout.prop(context.scene, "sb_collision_enable", text="")

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.enabled = scene.sb_collision_enable

        layout.operator(SB_OT_auto_setup_collisions.bl_idname,
                        text="Auto Setup Collisions", icon='AUTO')

        gbox = layout.box()
        grow = gbox.row()
        grow.label(text="Global Response", icon='PHYSICS')
        grow.prop(scene, "sb_draw_colliders", text="",
                  icon='HIDE_OFF' if scene.sb_draw_colliders else 'HIDE_ON')
        gcol = gbox.column(align=True)
        gcol.prop(scene, "sb_collide_bounce",     text="Bounce")
        gcol.prop(scene, "sb_collide_friction",   text="Friction")
        gcol.prop(scene, "sb_collide_iterations", text="Iterations")
        gcol.separator()
        gcol.prop(scene, "sb_collide_use_physics_objects",
                  text="Use Blender Collision Objects")
        gcol.prop(scene, "sb_self_collision_enable",
                  text="Self Collision (Master)")

        sbox = layout.box()
        sbox.label(text="Colliders (Selected Bones)", icon='MESH_CAPSULE')
        row = sbox.row(align=True)
        row.operator(SB_OT_setup_bone_colliders.bl_idname,
                     text="Mark as Colliders", icon='MESH_CAPSULE')
        row.operator(SB_OT_remove_bone_colliders.bl_idname,
                     text="Remove", icon='X')

        # NOTE: per-collider radius/stiffness used to live in Active Bone; it is
        # now edited here for the active bone when it is a collider.
        pb = context.active_pose_bone
        if pb is not None and pb.sb_bone_collider:
            abox = layout.box()
            abox.label(text=f"Collider: {pb.name}", icon='BONE_DATA')
            col = abox.column(align=True)
            col.prop(pb, 'sb_collider_dist',  text="Radius")
            col.prop(pb, 'sb_collider_force', text="Hardness")
            col.separator()
            col.prop(pb, 'sb_collider_use_own_response',
                     text="Per-Collider Response")
            if pb.sb_collider_use_own_response:
                col.prop(pb, 'sb_collider_bounce',   text="Bounce")
                col.prop(pb, 'sb_collider_friction', text="Friction")

        layout.prop(scene, "sb_show_colliders")
        if scene.sb_show_colliders and context.active_object:
            col = layout.column(align=True)
            for pbone in context.active_object.pose.bones:
                if pbone.sb_bone_collider:
                    row = col.row()
                    row.label(text=pbone.name)
                    r = row.operator(SB_OT_select_bone.bl_idname, text="Select")
                    r.bone_name = pbone.name


# ================================================================== #
#  WIND
# ================================================================== #

class SB_PT_wind(bpy.types.Panel):
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = 'SpringFX'
    bl_label       = "Wind"
    bl_parent_id   = "SB_PT_ui"
    bl_order       = 3
    bl_options     = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE'

    def draw_header(self, context):
        self.layout.prop(context.scene, "sb_wind_enable", text="")

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        col = layout.column(align=True)
        col.enabled = scene.sb_wind_enable
        col.prop(scene, "sb_wind_vector",     text="Direction")
        col.prop(scene, "sb_wind_strength",   text="Strength")
        col.prop(scene, "sb_wind_turbulence", text="Turbulence")
        col.prop(scene, "sb_wind_speed",      text="Gust Speed")
        layout.label(text="Per-group response: Wind Influence (Advanced)",
                     icon='INFO')


# ================================================================== #
#  PERFORMANCE
# ================================================================== #

class SB_PT_performance(bpy.types.Panel):
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = 'SpringFX'
    bl_label       = "Performance"
    bl_parent_id   = "SB_PT_ui"
    bl_order       = 4
    bl_options     = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        sbox = layout.box()
        sbox.prop(scene, "sb_preroll_viewport", icon='RECOVER_LAST')
        if scene.sb_preroll_viewport:
            sbox.prop(scene, "sb_preroll_viewport_frames")

        cbox = layout.box()
        cbox.prop(scene, "sb_cache_enable", icon='FILE_CACHE')
        if scene.sb_cache_enable:
            n, first, last, entries = _sb_core.get_cache_info()
            row = cbox.row(align=True)
            row.operator("sb.cache_bake", icon='PHYSICS')
            row.operator("sb.cache_clear", text="", icon='TRASH')
            if n:
                cbox.label(text=f"Cached: {first}–{last}  ({n} frames)",
                           icon='CHECKMARK')
            else:
                cbox.label(text="Not cached — scrubbing re-simulates",
                           icon='INFO')

        col = layout.column(align=True)
        col.prop(scene, "sb_quality",        text="Viewport")
        col.prop(scene, "sb_render_quality", text="Render / Bake")

        box = layout.box()
        bcol = box.column(align=True)
        bcol.prop(scene, "sb_substeps_override", text="Substeps (0 = auto)")
        bcol.prop(scene, "sb_update_rate",       text="Update Every N Frames")
        bcol.separator()
        bcol.prop(scene, "sb_skip_hidden", text="Skip Hidden Armatures")
        row = bcol.row(align=True)
        row.prop(scene, "sb_skip_far", text="Skip Far Bones")
        sub = row.row()
        sub.enabled = scene.sb_skip_far
        sub.prop(scene, "sb_far_distance", text="")

        layout.prop(scene, "sb_show_perf", text="Show Performance Stats")
        if scene.sb_show_perf:
            ms, simulated, skipped = core.get_perf_stats()
            pbox = layout.box()
            if ms > 0.05:
                pbox.label(text=f"{ms:.1f} ms/frame (~{(1000.0 / ms):.0f} fps cap)",
                           icon='TIME')
                pbox.label(text=f"{simulated} simulated / {skipped} skipped")
            else:
                pbox.label(text="Play the animation to measure", icon='TIME')
            # NOTE: say which solver is running, and why when it isn't the
            # compiled one; otherwise a slowdown looks like a mystery.
            compiled, why = core.get_solver_status()
            pbox.label(text="Compiled solver" if compiled else "Python solver",
                       icon='CHECKMARK' if compiled else 'INFO')
            if why:
                pbox.label(text=why, icon='ERROR')


# ================================================================== #
#  BAKE -- always last
# ================================================================== #

class SB_PT_bake(bpy.types.Panel):
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = 'SpringFX'
    bl_label       = "Bake"
    bl_parent_id   = "SB_PT_ui"
    bl_order       = 5
    bl_options     = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE'

    def draw(self, context):
        layout = self.layout
        scene  = context.scene
        layout.label(text=f"Range: {scene.frame_start} – {scene.frame_end}",
                     icon='RENDER_ANIMATION')

        prebox = layout.box()
        prebox.prop(scene, "sb_preroll_enable",
                    text="Pre-Roll Warm-Up", icon='RECOVER_LAST')
        if scene.sb_preroll_enable:
            prebox.prop(scene, "sb_preroll_frames", text="Warm-Up Frames")
            prebox.label(text="Extra frames before baking so springs settle",
                         icon='INFO')

        # NOTE: the Bake button sits above, under Clean Physics; only what
        # changes its result goes here.
        layout.prop(scene, "sb_bake_mute_constraints",
                    text="Apply Other Constraints", icon='CONSTRAINT_BONE')
        layout.label(text="Baked groups are removed after baking", icon='INFO')

        ebox = layout.box()
        ebox.label(text="Export to Game Engine", icon='EXPORT')
        row = ebox.row(align=True)
        row.operator("sb.validate_physbones", icon='CHECKMARK')
        row.operator("sb.export_physbones", icon='ARMATURE_DATA')
        ebox.label(text="No bake needed: settings travel, not keys.",
                   icon='INFO')

        nbox = layout.box()
        nbox.label(text="NLA", icon='NLA')
        nbox.operator(SB_OT_action_to_nla.bl_idname,
                      text="Push Action to NLA Strip", icon='NLA_PUSHDOWN')


class SB_PT_noise_mod(bpy.types.Panel):
    """Noise modifier on the already baked curves"""
    # NOTE: it hangs off Bake rather than the root panel because it only acts
    # on curves that already exist.
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = 'SpringFX'
    bl_label       = "Noise Modifier (Post-Bake)"
    bl_parent_id   = "SB_PT_bake"
    bl_options     = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE'

    def _draw_section(self, layout, s, kind):
        header = layout.row(align=True)
        header.prop(s, "enable",
                    text=("Location Noise" if kind == 'LOC' else "Rotation Noise"),
                    icon='MOD_NOISE')
        if not s.enable:
            return
        box = layout.box()
        row = box.row(align=True)
        row.label(text="Axes:")
        if kind == 'ROT':
            row.prop(s, "use_w", toggle=True)
        row.prop(s, "use_x", toggle=True)
        row.prop(s, "use_y", toggle=True)
        row.prop(s, "use_z", toggle=True)
        col = box.column(align=True)
        col.prop(s, "blend_type")
        col.prop(s, "scale")
        col.prop(s, "strength")
        col.prop(s, "phase")
        col.prop(s, "offset")
        col.prop(s, "depth")
        col.prop(s, "variation")
        adv = box.box()
        adv.prop(s, "show_advanced",
                 icon='TRIA_DOWN' if s.show_advanced else 'TRIA_RIGHT',
                 emboss=False)
        if s.show_advanced:
            c = adv.column(align=True)
            c.prop(s, "use_legacy_noise")
            sub = c.column(align=True)
            sub.enabled = not s.use_legacy_noise
            sub.prop(s, "lacunarity")
            sub.prop(s, "roughness")
            c.separator()
            c.prop(s, "use_restricted_range")
            if s.use_restricted_range:
                rr = c.column(align=True)
                rr.prop(s, "frame_start")
                rr.prop(s, "frame_end")
                rr.prop(s, "blend_in")
                rr.prop(s, "blend_out")
            c.separator()
            c.prop(s, "use_influence")
            if s.use_influence:
                c.prop(s, "influence")

    def draw(self, context):
        layout = self.layout
        scn = context.scene
        layout.label(text="Applies to the SELECTED bones' baked curves",
                     icon='INFO')
        layout.prop(scn, "sb_nmod_live", text="Live tweak (selected bones)")
        self._draw_section(layout, scn.sb_nmod_loc, 'LOC')
        self._draw_section(layout, scn.sb_nmod_rot, 'ROT')
        layout.separator()
        row = layout.row(align=True)
        row.operator(SB_OT_noise_mod_apply.bl_idname, icon='CHECKMARK')
        row.operator(SB_OT_noise_mod_remove.bl_idname, text="Remove", icon='X')


# ================================================================== #
#  OBJECT MODE — collider de objeto (sin cambios funcionales)
# ================================================================== #

class SB_PT_object_ui(bpy.types.Panel):
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = 'SpringFX'
    bl_label       = "SpringFX — Object Collider"

    @classmethod
    def poll(cls, context):
        return (context.mode == 'OBJECT'
                and context.active_object is not None)

    def draw(self, context):
        layout = self.layout
        scene  = context.scene
        obj    = context.active_object
        col    = layout.column(align=True)
        col.prop(obj, 'sb_object_collider', text="Use as Collider")
        if obj.sb_object_collider:
            col.prop(obj, 'sb_collider_shape', text="Shape")
            if obj.sb_collider_shape == 'MESH' and obj.type != 'MESH':
                col.label(text="Mesh shape needs a mesh object", icon='ERROR')
            col.prop(obj, 'sb_collider_dist',  text="Radius / Margin")
            col.prop(obj, 'sb_collider_force', text="Hardness")
            if obj.sb_collider_shape == 'CAPSULE':
                col.label(text="Capsule runs along local Y (scale Y = length)",
                          icon='INFO')
            elif obj.sb_collider_shape == 'PLANE':
                col.label(text="Plane faces local +Z", icon='INFO')

            col.separator()
            col.prop(obj, 'sb_collider_use_own_response',
                     text="Per-Collider Response")
            if obj.sb_collider_use_own_response:
                col.prop(obj, 'sb_collider_bounce',   text="Bounce")
                col.prop(obj, 'sb_collider_friction', text="Friction")

        layout.separator()
        gbox = layout.box()
        grow = gbox.row()
        grow.prop(scene, "sb_collision_enable", text="Collision Active",
                  icon='PHYSICS')
        grow.prop(scene, "sb_draw_colliders",
                  text="", icon='HIDE_OFF' if scene.sb_draw_colliders else 'HIDE_ON')
        if scene.sb_collision_enable:
            gcol = gbox.column(align=True)
            gcol.prop(scene, "sb_collide_bounce",     text="Bounce (global)")
            gcol.prop(scene, "sb_collide_friction",   text="Friction (global)")
            gcol.prop(scene, "sb_collide_iterations", text="Iterations")


# NOTE: registration order sets the sub-panel order: Bake is the last child
# of SB_PT_ui (and Noise Modifier hangs off Bake).
classes = (
    SB_UL_groups,
    SB_PT_ui,
    SB_PT_settings,
    SB_PT_collisions,
    SB_PT_wind,
    SB_PT_performance,
    SB_PT_bake,
    SB_PT_noise_mod,
    SB_PT_object_ui,
)


def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)


def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
