# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

__author__ = "Sanku Venkatesh"
__copyright__ = "Copyright 2021-2026, CaptainHansode, sakaiden.com; 2026 Sanku Venkatesh"
__credits__ = ["Sanku Venkatesh", "CaptainHansode (original author)"]
__license__ = "GPL"
__maintainer__ = "Sanku Venkatesh"
__status__ = "Production"


import bpy
import mathutils
import copy
import numpy as np


# Bones with these name prefixes are rig plumbing, not animator-facing
# controls. Advanced rigs (Rigify and friends) sit them between the controls,
# so hierarchy detection walks through them instead of stopping at them.
NON_CONTROL_PREFIXES = (
    "def-", "def_", "def.",
    "org-", "org_", "org.",
    "mch-", "mch_", "mch.",
    "wgt-", "wgt_", "wgt.",
    "vis-", "vis_",
)

EPS = 1.0e-6


class SJPhaserModule(object):
    r"""Perfect-overlap phase calculation core."""

    def __init__(self, *args, **kwargs):
        self.delay = 5.0
        self.recursion = 5.0
        self.strength = 1.0
        self.threshold = 0.001
        self.sf = 0
        self.ef = 10
        self.debug = False

        # --- options -----------------------------------------------------
        # Detect the control hierarchy under the selected controller and
        # include every child control automatically.
        self.hierarchy = False
        # Add overlapping motion to translation as well as rotation.
        self.animate_translate = False

    # ------------------------------------------------------------------
    # rig inspection
    # ------------------------------------------------------------------
    def _bone_visible(self, pbn):
        bone = pbn.bone
        if bone.hide:
            return False
        colls = getattr(bone, "collections", None)
        if colls:
            visible = False
            for c in colls:
                if getattr(c, "is_visible_effectively",
                           getattr(c, "is_visible", True)):
                    visible = True
                    break
            if not visible:
                return False
        return True

    def is_control_bone(self, pbn):
        r"""True for animator-facing controls. Mechanism, deform, org and
        widget bones - and anything hidden - are treated as plumbing."""
        if pbn.name.lower().startswith(NON_CONTROL_PREFIXES):
            return False
        return self._bone_visible(pbn)

    def control_children(self, pbn, _depth=0):
        r"""Direct control children of `pbn`.

        On an advanced rig a control is often parented to its logical parent
        through one or more mechanism bones, so those are walked through
        rather than treated as the end of the chain."""
        out = []
        for child in pbn.children:
            if self.is_control_bone(child):
                out.append(child)
            elif _depth < 8:
                out.extend(self.control_children(child, _depth + 1))
        return out

    def next_in_chain(self, pbn, candidates):
        r"""Which child actually continues this bone's chain.

        Simple FK rigs use connected children, so those win outright. When
        nothing is connected (common on control rigs) the child whose head
        sits closest to this bone's tail and points the same way is the real
        continuation - taking `children[0]` blindly picks whatever bone
        happened to be added to the rig first."""
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]

        for c in candidates:
            if c.bone.use_connect:
                return c

        tail = pbn.tail
        dir_v = pbn.tail - pbn.head
        dir_v = (dir_v.normalized() if dir_v.length > EPS
                 else mathutils.Vector((0.0, 1.0, 0.0)))
        scale = max(pbn.length, EPS)

        best = None
        best_score = None
        for c in candidates:
            dist = (c.head - tail).length / scale
            c_dir = c.tail - c.head
            align = c_dir.normalized().dot(dir_v) if c_dir.length > EPS else -1.0
            score = dist - align          # near the tail + same direction wins
            if best_score is None or score < best_score:
                best_score = score
                best = c
        return best

    def can_translate(self, pbn):
        r"""Whether translation overlap can be written to this control at all.
        Connected bones and fully locked controls cannot move, so they fall
        back to rigid follow instead of producing a broken bake."""
        if not self.animate_translate:
            return False
        if pbn.bone.use_connect:
            return False
        if all(pbn.lock_location):
            return False
        return True

    # ------------------------------------------------------------------
    # selection
    # ------------------------------------------------------------------
    def get_selection(self):
        r"""Pose bones to operate on.

        With `hierarchy` on, the control hierarchy below every selected bone
        is detected and added, so the user only selects the top controller."""
        selected = list(bpy.context.selected_pose_bones or [])
        if not self.hierarchy:
            return selected

        out = []
        seen = set()

        def walk(pbn):
            if pbn.name in seen:
                return
            seen.add(pbn.name)
            out.append(pbn)
            for child in self.control_children(pbn):
                walk(child)

        # An explicitly selected bone is always honoured, even if its name
        # would otherwise mark it as plumbing.
        for pbn in selected:
            walk(pbn)
        return out

    def get_hierarchy_count(self, obj):
        r"""Depth of the bone in the hierarchy."""
        obj = obj.parent
        cnt = 0
        while obj is not None:
            obj = obj.parent
            cnt += 1
        return cnt

    def get_default_data_table(self):
        return {
            "obj_list": [],
            "pre_mt": [],
            "obj_length": [],
            "old_vec": [],
            "old_pos": [],
            "old_pvec": []
        }

    def get_tree_list(self):
        r"""Build the bone chains to simulate.

        Bones are consumed shallowest-first, so a chain always starts at its
        own highest bone; branches that were not picked as the continuation
        become chains of their own."""
        sel_bones = self.get_selection()
        sel_names = {pbn.name for pbn in sel_bones}
        ordered = sorted(sel_bones, key=self.get_hierarchy_count)

        obj_trees = {}
        used = set()
        t_cnt = 0

        for pbn in ordered:
            if pbn.name in used:
                continue
            # A chain needs a parent to hang from - the parent supplies the
            # driving motion. A parentless controller drives, it is not baked.
            if pbn.parent is None:
                continue

            chain = [pbn]
            used.add(pbn.name)

            cur = pbn
            while True:
                candidates = [c for c in self.control_children(cur)
                              if c.name in sel_names and c.name not in used]
                nxt = self.next_in_chain(cur, candidates)
                if nxt is None:
                    break
                chain.append(nxt)
                used.add(nxt.name)
                cur = nxt

            depth_cnt = self.get_hierarchy_count(pbn)
            if depth_cnt not in obj_trees:
                obj_trees[depth_cnt] = {}

            t_name = "tree{}".format(t_cnt)
            obj_trees[depth_cnt][t_name] = self.get_default_data_table()
            obj_trees[depth_cnt][t_name]["obj_list"] = chain
            t_cnt += 1

        return obj_trees

    def iter_bones(self, obj_trees):
        r"""Every pose bone in every chain, shallowest chain first."""
        for k in sorted(obj_trees.keys()):
            for t in obj_trees[k]:
                for pbn in obj_trees[k][t]["obj_list"]:
                    yield pbn

    # ------------------------------------------------------------------
    # matrices
    # ------------------------------------------------------------------
    def get_bone_length_matrix(self, pbn, ref_pbn):
        r"""World-space matrix of this bone relative to `ref_pbn`.

        `ref_pbn` is the previous bone in the chain, which is not always the
        bone's literal parent on an advanced rig - mechanism bones can sit in
        between. Measuring against the chain predecessor is what keeps the
        simulation correct in that case."""
        amt = bpy.context.active_object
        wmt = amt.matrix_world @ pbn.matrix

        p_wmt = amt.matrix_world @ ref_pbn.matrix
        len_mt = wmt.transposed() @ p_wmt.transposed().inverted()
        return len_mt.transposed()

    def get_bone_pre_matrix(self, pbn):
        r"""Bone's initial world matrix."""
        amt = bpy.context.active_object
        return amt.matrix_world @ pbn.matrix

    def get_end_pos_from_bonelength(self, pbn):
        r"""World matrix at the bone's tip."""
        amt = bpy.context.active_object
        wmt = amt.matrix_world @ pbn.matrix

        x = mathutils.Vector((1.0, 0.0, 0.0, 0.0))
        y = mathutils.Vector((0.0, 1.0, 0.0, pbn.length))
        z = mathutils.Vector((0.0, 0.0, 1.0, 0.0))
        w = mathutils.Vector((0.0, 0.0, 0.0, 1.0))
        len_mt = mathutils.Matrix([x, y, z, w])
        len_mt = len_mt.transposed() @ wmt.transposed()
        return len_mt.transposed()

    def normalize(self, vec):
        r"""Normalize a numpy vector."""
        return vec / np.linalg.norm(vec)

    def set_pre_data(self, obj_trees):
        dct_k = sorted(obj_trees.keys())  # process shallowest chains first
        for k in dct_k:
            for t in obj_trees[k]:
                obj_list = obj_trees[k][t]["obj_list"]
                obj_count = len(obj_list)
                for idx, pbn in enumerate(obj_list):
                    pre_mt = self.get_bone_pre_matrix(pbn)
                    obj_trees[k][t]["pre_mt"].append(pre_mt)

                    # Measure against the chain predecessor, falling back to
                    # the literal parent for the first bone.
                    ref_pbn = obj_list[idx - 1] if idx > 0 else pbn.parent
                    obj_trees[k][t]["obj_length"].append(
                        self.get_bone_length_matrix(pbn, ref_pbn))

                    obj_trees[k][t]["old_vec"].append(
                        mathutils.Vector((0.0, 0.0, 0.0)))
                    obj_trees[k][t]["old_pvec"].append(
                        mathutils.Vector((0.0, 0.0, 0.0)))
                    obj_trees[k][t]["old_pos"].append(
                        pre_mt.translation.copy())

                    # The last bone in the chain also needs its tip position tracked.
                    if idx == obj_count - 1:
                        amt = bpy.context.active_object
                        wmt = amt.matrix_world @ pbn.matrix

                        end_mt = self.get_end_pos_from_bonelength(pbn)
                        obj_trees[k][t]["pre_mt"].append(end_mt)

                        len_mt = end_mt.transposed() @ wmt.transposed().inverted()
                        obj_trees[k][t]["obj_length"].append(len_mt.transposed())
        return obj_trees

    # ------------------------------------------------------------------
    # keyframes
    # ------------------------------------------------------------------
    def rotation_data_path(self, pbn):
        if pbn.rotation_mode == 'QUATERNION':
            return 'rotation_quaternion'
        if pbn.rotation_mode == 'AXIS_ANGLE':
            return 'rotation_axis_angle'
        return 'rotation_euler'

    def _key_delete_safe(self, pbn, data_path, frame):
        r"""keyframe_delete raises when there is no key on that frame - that is
        not an error, and it must NOT abort the rest of the cleanup."""
        try:
            pbn.keyframe_delete(data_path=data_path, frame=frame)
        except (RuntimeError, TypeError):
            pass

    def del_animkey(self, obj_trees):
        r"""Remove existing keys in [sf, ef] and (re)key the start frame."""
        for pbn in self.iter_bones(obj_trees):
            paths = ['rotation_euler', 'rotation_quaternion',
                     'rotation_axis_angle', 'scale']
            if self.can_translate(pbn):
                paths.append('location')
            for f in range(self.sf, self.ef + 1):
                for dp in paths:
                    # Each channel is deleted independently: a missing key on
                    # one channel used to abort the whole cleanup loop, which
                    # left stale keys behind.
                    self._key_delete_safe(pbn, dp, f)

        # Needed so the bones' evaluated state reflects the deleted keys.
        bpy.context.view_layer.update()

        for pbn in self.iter_bones(obj_trees):
            if self.can_translate(pbn):
                pbn.keyframe_insert(data_path='location', frame=self.sf)
            pbn.keyframe_insert(
                data_path=self.rotation_data_path(pbn), frame=self.sf)

        self.remove_cyclic_modifiers(obj_trees)
        return None

    def set_animkey(self, obj):
        f = bpy.context.scene.frame_current
        if self.can_translate(obj):
            obj.keyframe_insert(data_path='location', frame=f)
        obj.keyframe_insert(data_path=self.rotation_data_path(obj), frame=f)
        # Scale is never keyed - baking scale here is what made armatures
        # grow/shrink during the simulation.
        return None

    # ------------------------------------------------------------------
    # f-curves
    # ------------------------------------------------------------------
    def _get_fcurves(self, id_data):
        r"""Return the id_data's F-Curves, compatible with both the legacy
        Action API (Blender <= 4.3) and the slotted Action API (4.4+, where
        Action.fcurves was removed entirely in 5.0)."""
        adt = id_data.animation_data
        if adt is None or adt.action is None:
            return []
        action = adt.action
        try:
            from bpy_extras import anim_utils
            channelbag = anim_utils.action_get_channelbag_for_slot(action, adt.action_slot)
            return list(channelbag.fcurves) if channelbag else []
        except (ImportError, AttributeError):
            # Blender 4.3 and earlier still expose fcurves directly.
            return list(action.fcurves)

    def _chain_data_paths(self, obj_trees):
        r"""data_path prefixes ("pose.bones[\"Bone\"]") for every bone we keyed."""
        return [pbn.path_from_id() for pbn in self.iter_bones(obj_trees)]

    def _chain_fcurves(self, obj_trees):
        amt = bpy.context.active_object
        prefixes = self._chain_data_paths(obj_trees)
        return [fc for fc in self._get_fcurves(amt)
                if any(fc.data_path.startswith(p) for p in prefixes)]

    def add_cyclic_modifiers(self, obj_trees):
        r"""Add a Cycles F-Curve modifier to every channel we keyed, so the
        action keeps repeating past the end frame."""
        for fcurve in self._chain_fcurves(obj_trees):
            if not any(m.type == 'CYCLES' for m in fcurve.modifiers):
                fcurve.modifiers.new('CYCLES')

    def remove_cyclic_modifiers(self, obj_trees):
        r"""Remove Cycles F-Curve modifiers previously added by Cycle."""
        for fcurve in self._chain_fcurves(obj_trees):
            for m in list(fcurve.modifiers):
                if m.type == 'CYCLES':
                    fcurve.modifiers.remove(m)

    def smooth_cycle_seam(self, obj_trees):
        r"""Give the first and last key of the range auto handles, so the curve
        does not kick as it wraps around the seam."""
        for fcurve in self._chain_fcurves(obj_trees):
            for kp in fcurve.keyframe_points:
                if int(round(kp.co[0])) in (self.sf, self.ef):
                    kp.interpolation = 'BEZIER'
                    kp.handle_left_type = 'AUTO_CLAMPED'
                    kp.handle_right_type = 'AUTO_CLAMPED'
            fcurve.update()

    # ------------------------------------------------------------------
    # cycle
    # ------------------------------------------------------------------
    def _pose_snapshot(self, obj_trees):
        pose = {}
        for pbn in self.iter_bones(obj_trees):
            pose[pbn.name] = {
                'location': pbn.location.copy(),
                'rotation_quaternion': pbn.rotation_quaternion.copy(),
                'rotation_euler': pbn.rotation_euler.copy(),
                'rotation_axis_angle': [v for v in pbn.rotation_axis_angle],
                'scale': pbn.scale.copy(),
            }
        return pose

    def cycle_blend_tail(self, obj_trees, blend_frames):
        r"""Blend the tail of the range back into the start pose.

        The final frame is written as an exact copy of the start-frame pose,
        so frame `ef` and frame `sf` match and the action cycles without a pop
        at the seam."""
        scene = bpy.context.scene
        blend_frames = max(1, min(int(blend_frames), self.ef - self.sf))

        # Collect the start-frame pose - this is the cycle target.
        scene.frame_set(self.sf)
        bpy.context.view_layer.update()
        start_pose = self._pose_snapshot(obj_trees)

        for i in range(blend_frames):
            f = self.ef - blend_frames + 1 + i
            factor = (i + 1) / float(blend_frames)
            exact = (f == self.ef)

            scene.frame_set(f)
            bpy.context.view_layer.update()

            for pbn in self.iter_bones(obj_trees):
                target = start_pose[pbn.name]
                mode = pbn.rotation_mode
                translate = self.can_translate(pbn)

                if translate:
                    if exact:
                        pbn.location = target['location'].copy()
                    else:
                        pbn.location = pbn.location.lerp(
                            target['location'], factor)

                if mode == 'QUATERNION':
                    if exact:
                        pbn.rotation_quaternion = target['rotation_quaternion'].copy()
                    else:
                        cur = pbn.rotation_quaternion.normalized()
                        tgt = target['rotation_quaternion'].normalized()
                        # Take the short way round the hypersphere.
                        if cur.dot(tgt) < 0.0:
                            tgt = mathutils.Quaternion(
                                (-tgt.w, -tgt.x, -tgt.y, -tgt.z))
                        pbn.rotation_quaternion = cur.slerp(tgt, factor)
                elif mode == 'AXIS_ANGLE':
                    tgt = target['rotation_axis_angle']
                    if exact:
                        pbn.rotation_axis_angle = tgt
                    else:
                        pbn.rotation_axis_angle = [
                            pbn.rotation_axis_angle[a] +
                            (tgt[a] - pbn.rotation_axis_angle[a]) * factor
                            for a in range(4)]
                else:
                    tgt = target['rotation_euler']
                    if exact:
                        pbn.rotation_euler = mathutils.Euler(
                            (tgt[0], tgt[1], tgt[2]), tgt.order)
                    else:
                        pbn.rotation_euler = mathutils.Euler(
                            [pbn.rotation_euler[a] +
                             (tgt[a] - pbn.rotation_euler[a]) * factor
                             for a in range(3)],
                            pbn.rotation_euler.order)

                # Scale is never animated by this add-on.
                pbn.scale = target['scale'].copy()

                if translate:
                    pbn.keyframe_insert(data_path='location', frame=f)
                pbn.keyframe_insert(
                    data_path=self.rotation_data_path(pbn), frame=f)

        self.smooth_cycle_seam(obj_trees)
        scene.frame_set(self.sf)
        return None

    def check_cycle_match(self, obj_trees):
        r"""Largest channel difference between frame sf and frame ef.
        Returns (bone_name, difference)."""
        scene = bpy.context.scene
        cur = scene.frame_current

        scene.frame_set(self.sf)
        bpy.context.view_layer.update()
        pose_a = self._pose_snapshot(obj_trees)

        scene.frame_set(self.ef)
        bpy.context.view_layer.update()
        pose_b = self._pose_snapshot(obj_trees)

        scene.frame_set(cur)

        translate_names = {pbn.name for pbn in self.iter_bones(obj_trees)
                           if self.can_translate(pbn)}

        worst_name = ""
        worst = 0.0
        for name, a in pose_a.items():
            b = pose_b[name]
            keys = ['rotation_quaternion', 'rotation_euler',
                    'rotation_axis_angle']
            if name in translate_names:
                keys.append('location')
            for key in keys:
                for va, vb in zip(a[key], b[key]):
                    d = abs(va - vb)
                    if d > worst:
                        worst = d
                        worst_name = name
        return worst_name, worst

    # ------------------------------------------------------------------
    # simulation
    # ------------------------------------------------------------------
    def clamp(self, n, minn=0.0, maxn=1.0):
        return max(min(maxn, n), minn)

    def rotate_matrix(self, mtx, rot_mt):
        r"""Rotate matrix `mtx` by rotation matrix `rot_mt`, keeping its scale/location parts."""
        loc, r_mt, s_mt = mtx.decompose()

        pos = mathutils.Matrix.Translation(loc)
        rot = r_mt.to_matrix().to_4x4()
        scl = (mathutils.Matrix.Scale(s_mt[0], 4, (1, 0, 0)) @
               mathutils.Matrix.Scale(s_mt[1], 4, (0, 1, 0)) @
               mathutils.Matrix.Scale(s_mt[2], 4, (0, 0, 1))
               )
        return pos @ rot_mt @ rot @ scl

    def create_test_empty(self, e_name, mtx):
        r"""Debug helper: drop an empty at a given matrix, only when `debug` is on."""
        if self.debug is False:
            return None
        emp = bpy.data.objects.new(e_name, None)
        bpy.context.selected_objects[0].users_collection[0].objects.link(emp)
        emp.empty_display_size = 0.2
        emp.empty_display_type = 'ARROWS'
        emp.matrix_world = copy.copy(mtx)
        return None

    def translation_overlap(self, obj_data, i, tag_pos):
        r"""Lag the bone's position behind where the rig puts it, then let it
        settle back - the positional equivalent of the rotational phase.

        The target is always the rig's own position, so the original movement
        is preserved; only the timing of it is offset."""
        old_pos = obj_data["old_pos"][i]

        lag_vec = (tag_pos - old_pos) / self.delay
        pos_vec = lag_vec + (obj_data["old_pvec"][i] * self.recursion)

        if pos_vec.length < self.threshold:
            pos_vec = mathutils.Vector((0.0, 0.0, 0.0))

        new_pos = old_pos + pos_vec
        obj_data["old_pvec"][i] = pos_vec
        obj_data["old_pos"][i] = new_pos.copy()
        return new_pos

    def calculate(self, obj_data):
        r"""Advance one chain's phase simulation by one frame."""
        amt = bpy.context.active_object

        cur_p_mt = amt.matrix_world @ obj_data["obj_list"][0].parent.matrix
        strgh = self.strength     # overlap amplitude - larger = stronger wobble
        trshd = self.threshold    # noise floor for the phase vector

        for i in range(len(obj_data["obj_list"])):
            # Order per bone: 1) current axis, 2) roll, 3) phase (overlap).

            obj = obj_data["obj_list"][i]
            translate = self.can_translate(obj)

            # Values the bone already has on this frame. The simulation builds
            # an orthonormal world matrix, so assigning it would otherwise bake
            # 1/armature-scale into the bone's local scale - that is what made
            # armatures scale. These are put back afterwards.
            orig_loc = obj.location.copy()
            orig_scale = obj.scale.copy()

            # 1) current axis
            tag_mt = obj_data["obj_length"][i].transposed() @ cur_p_mt.transposed()
            tag_mt = tag_mt.transposed()
            pre_mt = copy.copy(obj_data["pre_mt"][i])
            new_mt = copy.copy(obj_data["pre_mt"][i])
            tag_pos = tag_mt.translation

            # Where the bone actually sits this frame: rigid follow, or lagged
            # behind that when translation overlap is on.
            if translate:
                bone_pos = self.translation_overlap(obj_data, i, tag_pos)
            else:
                bone_pos = tag_pos.copy()
                obj_data["old_pos"][i] = tag_pos.copy()
                obj_data["old_pvec"][i] = mathutils.Vector((0.0, 0.0, 0.0))

            pre_y_vec = pre_mt.transposed().to_3x3()[1].normalized()
            tag_y_vec = tag_mt.transposed().to_3x3()[1].normalized()
            y_diff = np.arccos(self.clamp(np.dot(pre_y_vec, tag_y_vec)))
            axis_vec = mathutils.Vector(np.cross(pre_y_vec, tag_y_vec))
            new_mt = self.rotate_matrix(
                new_mt,
                (mathutils.Matrix.Rotation(y_diff, 4, axis_vec.normalized())))
            new_mt.translation = copy.copy(bone_pos)

            # 2) roll
            new_x_vec = new_mt.transposed().to_3x3()[0].normalized()
            tag_x_vec = tag_mt.transposed().to_3x3()[0].normalized()
            dot_val = np.dot(new_x_vec, tag_x_vec)

            if dot_val > 1.0:
                roll = 0.0
            else:
                roll = np.arccos(dot_val)
            roll = roll / self.delay

            check_vec = np.cross(new_x_vec, tag_x_vec)
            if np.dot(check_vec, tag_y_vec) < 0.0:
                roll = -roll

            axis_vec = new_mt.transposed().to_3x3()[1].normalized()
            new_mt = self.rotate_matrix(
                new_mt,
                (mathutils.Matrix.Rotation(roll, 4, axis_vec)))
            new_mt.translation = copy.copy(bone_pos)

            # 3) phase (overlap) vector
            c_pos = obj_data["pre_mt"][i + 1].translation
            new_y_vec = new_mt.transposed().to_3x3()[1].normalized()
            aim_vec = c_pos - bone_pos
            if aim_vec.length < EPS:
                # Degenerate: bone and child sit on top of each other.
                y_vec = np.array(new_y_vec)
            else:
                y_vec = self.normalize(aim_vec)

            rcs_vec = (obj_data["old_vec"][i] * self.recursion)
            phase_vec = ((new_y_vec - (y_vec * strgh)) / self.delay) + rcs_vec

            if phase_vec.length < trshd:
                phase_vec = mathutils.Vector((0.0, 0.0, 0.0))

            y_vec = y_vec + phase_vec
            obj_data["old_vec"][i] = phase_vec

            new_z_vec = new_mt.transposed().to_3x3()[2].normalized()
            y_vec = mathutils.Vector(self.normalize(y_vec))
            x_vec = mathutils.Vector(self.normalize(np.cross(y_vec, new_z_vec)))
            z_vec = mathutils.Vector(self.normalize(np.cross(x_vec, y_vec)))

            new_mt = mathutils.Matrix([x_vec, y_vec, z_vec])
            new_mt = new_mt.transposed().to_4x4()
            new_mt.translation = copy.copy(bone_pos)

            # Keying: view_layer.update() is required so pose_bone.matrix reflects
            # the change before the next bone in the chain reads it.
            # https://blender.stackexchange.com/questions/132403/
            obj.matrix = amt.matrix_world.inverted() @ new_mt
            bpy.context.view_layer.update()

            # Put back what the simulation must not touch.
            obj.scale = orig_scale
            if not translate:
                obj.location = orig_loc
            else:
                for a in range(3):
                    if obj.lock_location[a]:
                        obj.location[a] = orig_loc[a]
            bpy.context.view_layer.update()

            # Re-read the corrected world matrix so the rest of the chain is
            # built from what the bone actually is, not what we asked for.
            new_mt = amt.matrix_world @ obj.matrix
            obj_data["old_pos"][i] = new_mt.translation.copy()

            self.set_animkey(obj)

            obj_data["pre_mt"][i] = copy.copy(new_mt)
            cur_p_mt = copy.copy(new_mt)
            len_mt = obj_data["obj_length"][i + 1].transposed() @ new_mt.transposed()
            obj_data["pre_mt"][i + 1].translation = len_mt.transposed().translation

    def message_box(self, message="", title="Message", icon='INFO'):
        def draw(self, context):
            self.layout.label(text=message)
        bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)

    def excute(self, obj_trees):
        r"""Run the simulation for every frame in [sf+1, ef]."""
        dct_k = sorted(obj_trees.keys())
        for f in range(self.sf + 1, self.ef + 1):
            bpy.context.scene.frame_set(f)
            for k in dct_k:
                for t in obj_trees[k]:
                    self.calculate(obj_trees[k][t])
        return True
