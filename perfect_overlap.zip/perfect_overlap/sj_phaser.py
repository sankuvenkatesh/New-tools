# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

__author__ = "CaptainHansode"
__copyright__ = "Copyright 2021-2026, CaptainHansode, sakaiden.com"
__credits__ = ["CaptainHansode"]
__license__ = "GPL"
__maintainer__ = "CaptainHansode"
__email__ = "sakaiden@live.jp"
__status__ = "Production"
# web:  https://sakaiden.com
# twitter: https://twitter.com/CaptainHansode


import bpy
import mathutils
import copy
import numpy as np


class SJPhaserModule(object):
    r"""Perfect-overlap phase calculation core."""

    def __init__(self, *args, **kwargs):
        self.delay = 5.0
        self.recursion = 5.0
        self.strength = 1.0
        self.threshold = 0.001
        self.sf = 0
        self.ef = 10
        self.debug = False

    def get_hierarchy_count(self, obj):
        r"""Depth of the bone in the hierarchy."""
        obj = obj.parent
        cnt = 0
        while obj is not None:
            obj = obj.parent
            cnt += 1
        return cnt

    def get_default_data_table(self):
        return {
            "obj_list": [],
            "pre_mt": [],
            "obj_length": [],
            "old_vec": []
        }

    def get_tree_list(self):
        r"""Collect selected, connected bone chains."""
        tree_roots = []
        obj_trees = {}

        for pbn in bpy.context.selected_pose_bones:
            # No parent: skip, nothing to chain from.
            if pbn.parent is None:
                continue

            # If the parent is also selected, this bone is only a chain root
            # when it is the parent's first child (i.e. not a branch).
            if pbn.parent in bpy.context.selected_pose_bones:
                if pbn.parent.children[0] == pbn:
                    continue
            tree_roots.append(pbn)

        t_cnt = 0
        for root_obj in tree_roots:
            depth_cnt = self.get_hierarchy_count(root_obj)
            tree = []
            t_name = "tree{}".format(t_cnt)

            if depth_cnt not in obj_trees:
                obj_trees[depth_cnt] = {}

            # No children: this is a one-bone chain.
            if len(root_obj.children) == 0:
                tree.append(root_obj)
                obj_trees[depth_cnt][t_name] = self.get_default_data_table()
                obj_trees[depth_cnt][t_name]["obj_list"] = tree
                t_cnt += 1
                continue

            # A chain always follows the first ("0 index") child.
            tree.append(root_obj)
            c_obj = root_obj.children[0]

            while c_obj in bpy.context.selected_pose_bones:
                tree.append(c_obj)
                if len(c_obj.children) == 0:
                    break
                c_obj = c_obj.children[0]

            obj_trees[depth_cnt][t_name] = self.get_default_data_table()
            obj_trees[depth_cnt][t_name]["obj_list"] = tree
            t_cnt += 1

        return obj_trees

    def get_bone_length_matrix(self, pbn):
        r"""World-space matrix representing this bone's length/direction relative to its parent."""
        amt = bpy.context.active_object
        wmt = amt.matrix_world @ pbn.matrix

        p_wmt = amt.matrix_world @ pbn.parent.matrix
        len_mt = wmt.transposed() @ p_wmt.transposed().inverted()
        return len_mt.transposed()

    def get_bone_pre_matrix(self, pbn):
        r"""Bone's initial world matrix."""
        amt = bpy.context.active_object
        return amt.matrix_world @ pbn.matrix

    def get_end_pos_from_bonelength(self, pbn):
        r"""World matrix at the bone's tip."""
        amt = bpy.context.active_object
        wmt = amt.matrix_world @ pbn.matrix

        x = mathutils.Vector((1.0, 0.0, 0.0, 0.0))
        y = mathutils.Vector((0.0, 1.0, 0.0, pbn.length))
        z = mathutils.Vector((0.0, 0.0, 1.0, 0.0))
        w = mathutils.Vector((0.0, 0.0, 0.0, 1.0))
        len_mt = mathutils.Matrix([x, y, z, w])
        len_mt = len_mt.transposed() @ wmt.transposed()
        return len_mt.transposed()

    def normalize(self, vec):
        r"""Normalize a numpy vector."""
        return vec / np.linalg.norm(vec)

    def set_pre_data(self, obj_trees):
        dct_k = sorted(obj_trees.keys())  # process shallowest chains first
        for k in dct_k:
            for t in obj_trees[k]:
                obj_count = len(obj_trees[k][t]["obj_list"])
                cnt = 1
                for pbn in obj_trees[k][t]["obj_list"]:
                    obj_trees[k][t]["pre_mt"].append(
                        self.get_bone_pre_matrix(pbn))

                    obj_trees[k][t]["obj_length"].append(
                        self.get_bone_length_matrix(pbn))

                    obj_trees[k][t]["old_vec"].append(
                        mathutils.Vector((0.0, 0.0, 0.0)))

                    # The last bone in the chain also needs its tip position tracked.
                    if cnt == obj_count:
                        amt = bpy.context.active_object
                        wmt = amt.matrix_world @ pbn.matrix

                        end_mt = self.get_end_pos_from_bonelength(pbn)
                        obj_trees[k][t]["pre_mt"].append(end_mt)

                        len_mt = end_mt.transposed() @ wmt.transposed().inverted()
                        obj_trees[k][t]["obj_length"].append(len_mt.transposed())
                    cnt += 1
        return obj_trees

    def del_animkey(self, obj_trees):
        r"""Remove existing keys in [sf, ef] and (re)key the start frame."""
        dct_k = sorted(obj_trees.keys())
        for k in dct_k:
            for t in obj_trees[k]:
                for pbn in obj_trees[k][t]["obj_list"]:
                    for f in range(self.sf - 1, self.ef + 1):
                        try:
                            pbn.keyframe_delete(data_path="location", frame=f)
                            pbn.keyframe_delete(
                                data_path="rotation_euler", frame=f)
                            pbn.keyframe_delete(
                                data_path="rotation_quaternion", frame=f)
                            pbn.keyframe_delete(data_path="scale", frame=f)
                        except RuntimeError:
                            break
        # Needed so the bones' evaluated state reflects the deleted keys.
        bpy.context.view_layer.update()

        for k in dct_k:
            for t in obj_trees[k]:
                for pbn in obj_trees[k][t]["obj_list"]:
                    pbn.keyframe_insert(data_path='location', frame=self.sf)
                    pbn.keyframe_insert(
                        data_path='rotation_euler', frame=self.sf)
                    pbn.keyframe_insert(
                        data_path='rotation_quaternion', frame=self.sf)
                    pbn.keyframe_insert(data_path='scale', frame=self.sf)

        self.remove_cyclic_modifiers(obj_trees)
        return None

    def _get_fcurves(self, id_data):
        r"""Return the id_data's F-Curves, compatible with both the legacy
        Action API (Blender <= 4.3) and the slotted Action API (4.4+, where
        Action.fcurves was removed entirely in 5.0)."""
        adt = id_data.animation_data
        if adt is None or adt.action is None:
            return []
        action = adt.action
        try:
            from bpy_extras import anim_utils
            channelbag = anim_utils.action_get_channelbag_for_slot(action, adt.action_slot)
            return list(channelbag.fcurves) if channelbag else []
        except (ImportError, AttributeError):
            # Blender 4.3 and earlier still expose fcurves directly.
            return list(action.fcurves)

    def _chain_data_paths(self, obj_trees):
        r"""data_path prefixes ("pose.bones[\"Bone\"]") for every bone we keyed."""
        dct_k = sorted(obj_trees.keys())
        paths = []
        for k in dct_k:
            for t in obj_trees[k]:
                for pbn in obj_trees[k][t]["obj_list"]:
                    paths.append(pbn.path_from_id())
        return paths

    def add_cyclic_modifiers(self, obj_trees):
        r"""Add a Cycles F-Curve modifier to every channel we keyed, so the
        action repeats automatically past the end frame (used by Loop)."""
        amt = bpy.context.active_object
        prefixes = self._chain_data_paths(obj_trees)
        for fcurve in self._get_fcurves(amt):
            if any(fcurve.data_path.startswith(p) for p in prefixes):
                if not any(m.type == 'CYCLES' for m in fcurve.modifiers):
                    fcurve.modifiers.new('CYCLES')

    def remove_cyclic_modifiers(self, obj_trees):
        r"""Remove Cycles F-Curve modifiers previously added by Loop."""
        amt = bpy.context.active_object
        prefixes = self._chain_data_paths(obj_trees)
        for fcurve in self._get_fcurves(amt):
            if any(fcurve.data_path.startswith(p) for p in prefixes):
                for m in list(fcurve.modifiers):
                    if m.type == 'CYCLES':
                        fcurve.modifiers.remove(m)

    def loop_blend_tail(self, obj_trees, loop_frames):
        r"""Ease the last `loop_frames` frames of the range back toward the
        start-frame pose, so frame `ef` matches frame `sf` exactly and the
        action can be played on a loop without a pop at the seam."""
        dct_k = sorted(obj_trees.keys())
        scene = bpy.context.scene
        loop_frames = max(1, min(loop_frames, self.ef - self.sf))

        # Collect the start-frame pose - this is the loop target.
        scene.frame_set(self.sf)
        bpy.context.view_layer.update()
        start_pose = {}
        for k in dct_k:
            for t in obj_trees[k]:
                for pbn in obj_trees[k][t]["obj_list"]:
                    start_pose[pbn.name] = (
                        pbn.location.copy(),
                        pbn.rotation_quaternion.copy(),
                        pbn.rotation_euler.copy(),
                        pbn.scale.copy(),
                    )

        # Ease each tail frame toward that pose; the last one (f == ef)
        # lands on factor == 1.0, i.e. an exact match with the start frame.
        for i in range(loop_frames):
            f = self.ef - loop_frames + 1 + i
            factor = (i + 1) / loop_frames
            scene.frame_set(f)
            bpy.context.view_layer.update()
            for k in dct_k:
                for t in obj_trees[k]:
                    for pbn in obj_trees[k][t]["obj_list"]:
                        s_loc, s_quat, s_eul, s_scale = start_pose[pbn.name]

                        pbn.location = pbn.location.lerp(s_loc, factor)
                        pbn.rotation_quaternion = pbn.rotation_quaternion.slerp(s_quat, factor)
                        pbn.rotation_euler = mathutils.Euler(
                            [pbn.rotation_euler[a] + (s_eul[a] - pbn.rotation_euler[a]) * factor
                             for a in range(3)],
                            pbn.rotation_euler.order)
                        pbn.scale = pbn.scale.lerp(s_scale, factor)

                        pbn.keyframe_insert(data_path='location', frame=f)
                        pbn.keyframe_insert(data_path='rotation_euler', frame=f)
                        pbn.keyframe_insert(data_path='rotation_quaternion', frame=f)
                        pbn.keyframe_insert(data_path='scale', frame=f)

        scene.frame_set(self.sf)
        return None

    def set_animkey(self, obj):
        f = bpy.context.scene.frame_current
        obj.keyframe_insert(data_path='location', frame=f)
        obj.keyframe_insert(data_path='rotation_euler', frame=f)
        obj.keyframe_insert(data_path='rotation_quaternion', frame=f)
        obj.keyframe_insert(data_path='scale', frame=f)
        return None

    def clamp(self, n, minn=0.0, maxn=1.0):
        return max(min(maxn, n), minn)

    def rotate_matrix(self, mtx, rot_mt):
        r"""Rotate matrix `mtx` by rotation matrix `rot_mt`, keeping its scale/location parts."""
        loc, r_mt, s_mt = mtx.decompose()

        pos = mathutils.Matrix.Translation(loc)
        rot = r_mt.to_matrix().to_4x4()
        scl = (mathutils.Matrix.Scale(s_mt[0], 4, (1, 0, 0)) @
               mathutils.Matrix.Scale(s_mt[1], 4, (0, 1, 0)) @
               mathutils.Matrix.Scale(s_mt[2], 4, (0, 0, 1))
               )
        return pos @ rot_mt @ rot @ scl

    def create_test_empty(self, e_name, mtx):
        r"""Debug helper: drop an empty at a given matrix, only when `debug` is on."""
        if self.debug is False:
            return None
        emp = bpy.data.objects.new(e_name, None)
        bpy.context.selected_objects[0].users_collection[0].objects.link(emp)
        emp.empty_display_size = 0.2
        emp.empty_display_type = 'ARROWS'
        emp.matrix_world = copy.copy(mtx)
        return None

    def calculate(self, obj_data):
        r"""Advance one chain's phase simulation by one frame."""
        amt = bpy.context.active_object

        cur_p_mt = amt.matrix_world @ obj_data["obj_list"][0].parent.matrix
        strgh = self.strength     # overlap amplitude - larger = stronger wobble
        trshd = self.threshold    # noise floor for the phase vector

        for i in range(len(obj_data["obj_list"])):
            # Order per bone: 1) current axis, 2) roll, 3) phase (overlap).

            # 1) current axis
            obj = obj_data["obj_list"][i]
            tag_mt = obj_data["obj_length"][i].transposed() @ cur_p_mt.transposed()
            tag_mt = tag_mt.transposed()
            pre_mt = copy.copy(obj_data["pre_mt"][i])
            new_mt = copy.copy(obj_data["pre_mt"][i])
            tag_pos = tag_mt.translation

            pre_y_vec = pre_mt.transposed().to_3x3()[1].normalized()
            tag_y_vec = tag_mt.transposed().to_3x3()[1].normalized()
            y_diff = np.arccos(self.clamp(np.dot(pre_y_vec, tag_y_vec)))
            axis_vec = mathutils.Vector(np.cross(pre_y_vec, tag_y_vec))
            new_mt = self.rotate_matrix(
                new_mt,
                (mathutils.Matrix.Rotation(y_diff, 4, axis_vec.normalized())))
            new_mt.translation = copy.copy(tag_pos)  # re-apply position just in case

            # 2) roll
            new_x_vec = new_mt.transposed().to_3x3()[0].normalized()
            tag_x_vec = tag_mt.transposed().to_3x3()[0].normalized()
            dot_val = np.dot(new_x_vec, tag_x_vec)

            if dot_val > 1.0:
                roll = 0.0
            else:
                roll = np.arccos(dot_val)
            roll = roll / self.delay

            check_vec = np.cross(new_x_vec, tag_x_vec)
            if np.dot(check_vec, tag_y_vec) < 0.0:
                roll = -roll

            axis_vec = new_mt.transposed().to_3x3()[1].normalized()
            new_mt = self.rotate_matrix(
                new_mt,
                (mathutils.Matrix.Rotation(roll, 4, axis_vec)))
            new_mt.translation = tag_pos

            # 3) phase (overlap) vector
            c_pos = obj_data["pre_mt"][i + 1].translation
            y_vec = self.normalize(c_pos - tag_pos)
            new_y_vec = new_mt.transposed().to_3x3()[1].normalized()
            rcs_vec = (obj_data["old_vec"][i] * self.recursion)
            phase_vec = ((new_y_vec - (y_vec * strgh)) / self.delay) + rcs_vec

            if phase_vec.length < trshd:
                phase_vec = mathutils.Vector((0.0, 0.0, 0.0))

            y_vec = y_vec + phase_vec
            obj_data["old_vec"][i] = phase_vec

            new_z_vec = new_mt.transposed().to_3x3()[2].normalized()
            y_vec = mathutils.Vector(self.normalize(y_vec))
            x_vec = mathutils.Vector(self.normalize(np.cross(y_vec, new_z_vec)))
            z_vec = mathutils.Vector(self.normalize(np.cross(x_vec, y_vec)))

            new_mt = mathutils.Matrix([x_vec, y_vec, z_vec])
            new_mt = new_mt.transposed().to_4x4()
            new_mt.translation = copy.copy(tag_pos)

            # Keying: view_layer.update() is required so pose_bone.matrix reflects
            # the change before the next bone in the chain reads it.
            # https://blender.stackexchange.com/questions/132403/
            obj.matrix = amt.matrix_world.inverted() @ new_mt
            bpy.context.view_layer.update()
            self.set_animkey(obj)

            obj_data["pre_mt"][i] = copy.copy(new_mt)
            cur_p_mt = copy.copy(new_mt)
            len_mt = obj_data["obj_length"][i + 1].transposed() @ new_mt.transposed()
            obj_data["pre_mt"][i + 1].translation = len_mt.transposed().translation

    def message_box(self, message="", title="Message", icon='INFO'):
        def draw(self, context):
            self.layout.label(text=message)
        bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)

    def excute(self, obj_trees):
        r"""Run the simulation for every frame in [sf+1, ef]."""
        dct_k = sorted(obj_trees.keys())
        for f in range(self.sf + 1, self.ef + 1):
            bpy.context.scene.frame_set(f)
            for k in dct_k:
                for t in obj_trees[k]:
                    self.calculate(obj_trees[k][t])
        return True
