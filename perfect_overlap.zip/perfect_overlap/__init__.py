# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# "Perfect Overlap" (formerly "SJ Phaser")
# Calculates perfect-overlap / follow-through phase animation on bone chains.
#
# Packaged as a Blender Extension (blender_manifest.toml holds the metadata
# that used to live in bl_info - bl_info is no longer read once an add-on is
# converted into an extension, see:
# https://docs.blender.org/manual/en/latest/advanced/extensions/addons.html
#
# author: CaptainHansode
# web:    https://sakaiden.com
# twitter: https://twitter.com/CaptainHansode

# Reload modules on "Reload Scripts"
if "bpy" in locals():
    import importlib
    if "sj_phaser" in locals():
        importlib.reload(sj_phaser)

import bpy
from . import sj_phaser


class PERFECTOVERLAP_PG_props(bpy.types.PropertyGroup):
    r"""Add-on settings, stored on the Scene."""
    # frame range
    start_frame: bpy.props.IntProperty(name="Start Frame", default=0, min=0)
    end_frame: bpy.props.IntProperty(name="End Frame", default=100, min=1)
    # delay before the tip catches up to the root
    delay: bpy.props.FloatProperty(name="Delay", default=3, min=1.0, max=10.0)
    # how much of the previous frame's phase vector carries forward
    recursion: bpy.props.FloatProperty(
        name="Recursion", default=5.0, min=0.0, max=10.0)
    # amplitude of the overlap wobble
    strength: bpy.props.FloatProperty(
        name="Strength", default=1.0, min=1.0, max=10.0)
    # cleans up floating point noise from cross/dot products
    threshold: bpy.props.FloatProperty(
        name="Threshold",
        default=0.001, min=0.00001, max=0.1, step=0.01, precision=4)
    debug: bpy.props.BoolProperty(name="Debug", default=False)

    # loop
    loop: bpy.props.BoolProperty(
        name="Loop",
        default=False,
        description="Ease the tail of the range back to match the start pose, "
                    "so the overlap action repeats seamlessly")
    loop_blend: bpy.props.IntProperty(
        name="Blend Frames", default=5, min=1, max=200,
        description="Number of frames at the end of the range that are eased "
                    "back toward the start pose")
    loop_cycle_curves: bpy.props.BoolProperty(
        name="Cyclic F-Curves", default=True,
        description="Add a Cycles F-Curve modifier so playback keeps repeating "
                    "past the end frame")


class PERFECTOVERLAP_OT_calculate(bpy.types.Operator):
    r"""Generate the perfect-overlap phase animation on the selected bone chain"""
    bl_idname = "perfect_overlap.calculate"
    bl_label = "Calculate"
    bl_description = "Calculate a perfect-overlap phase animation."
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'ARMATURE'

    def execute(self, context):
        props = context.scene.perfect_overlap_props
        module = sj_phaser.SJPhaserModule()

        module.sf = props.start_frame
        module.ef = props.end_frame
        module.debug = props.debug

        # delay: default 1 to -inf, always >= 1
        module.delay = props.delay
        # recursion amount: default 0 to max 1.0
        module.recursion = props.recursion / 10.0
        # overlap strength: default 1.0 to max 2.0 (vector multiplier, 2x is plenty)
        module.strength = 1.0 + ((props.strength - 1.0) / 10.0)
        module.threshold = props.threshold

        if props.start_frame >= props.end_frame:
            msg = "Make the start frame smaller than the end frame."

            def draw(self, context):
                self.layout.label(text=msg)

            bpy.context.window_manager.popup_menu(draw, title="Info", icon="INFO")
            self.report({'INFO'}, msg)
            return {'CANCELLED'}

        bpy.context.scene.frame_set(props.start_frame)
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        obj_trees = module.get_tree_list()          # collect selected bone chains
        module.del_animkey(obj_trees)                # clear existing keys, reset to start frame

        obj_trees = module.set_pre_data(obj_trees)    # collect starting matrices/lengths
        module.excute(obj_trees)                      # run the simulation

        if props.loop:
            module.loop_blend_tail(obj_trees, props.loop_blend)
            if props.loop_cycle_curves:
                module.add_cyclic_modifiers(obj_trees)
            else:
                module.remove_cyclic_modifiers(obj_trees)
        else:
            module.remove_cyclic_modifiers(obj_trees)

        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        return {'FINISHED'}


class PERFECTOVERLAP_OT_del_anim(bpy.types.Operator):
    r"""Delete the keyframes created by Calculate"""
    bl_idname = "perfect_overlap.del_anim"
    bl_label = "Delete Keyframe"
    bl_description = "Delete the perfect-overlap animation keys."
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'ARMATURE'

    def execute(self, context):
        props = context.scene.perfect_overlap_props
        module = sj_phaser.SJPhaserModule()

        module.sf = props.start_frame
        module.ef = props.end_frame
        module.debug = props.debug

        if props.start_frame >= props.end_frame:
            msg = "Make the start frame smaller than the end frame."

            def draw(self, context):
                self.layout.label(text=msg)

            bpy.context.window_manager.popup_menu(draw, title="Info", icon="INFO")
            self.report({'INFO'}, msg)
            return {'CANCELLED'}

        bpy.context.scene.frame_set(props.start_frame)
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        obj_trees = module.get_tree_list()
        module.del_animkey(obj_trees)

        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        return {'FINISHED'}


class PERFECTOVERLAP_PT_panel(bpy.types.Panel):
    r"""Sidebar UI, Pose Mode only."""
    bl_label = "Perfect Overlap"
    bl_idname = "PERFECTOVERLAP_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = "posemode"
    bl_category = "SJT"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.perfect_overlap_props

        layout.label(text="Frame")
        row = layout.row()
        row.prop(props, "start_frame")
        row.prop(props, "end_frame")

        layout.label(text="Properties")
        row = layout.row(align=True)
        row.prop(props, "delay")
        row.prop(props, "recursion")
        row.prop(props, "strength")

        row = layout.row()
        row.prop(props, "threshold")

        box = layout.box()
        box.prop(props, "loop")
        if props.loop:
            col = box.column(align=True)
            col.prop(props, "loop_blend")
            col.prop(props, "loop_cycle_curves")

        layout.label(text="Main")
        row = layout.row()
        row.scale_y = 1.8
        row.operator("perfect_overlap.calculate", icon="KEYTYPE_KEYFRAME_VEC")
        row = layout.row()
        row.operator("perfect_overlap.del_anim", icon="KEYFRAME")


classes = (
    PERFECTOVERLAP_PG_props,
    PERFECTOVERLAP_OT_calculate,
    PERFECTOVERLAP_OT_del_anim,
    PERFECTOVERLAP_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.perfect_overlap_props = bpy.props.PointerProperty(type=PERFECTOVERLAP_PG_props)


def unregister():
    del bpy.types.Scene.perfect_overlap_props
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
