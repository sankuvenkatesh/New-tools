# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# "Perfect Overlap" (formerly "SJ Phaser")
# Generates overlap / follow-through animation on bone chains.
#
# Packaged as a Blender Extension (blender_manifest.toml holds the metadata
# that used to live in bl_info - bl_info is no longer read once an add-on is
# converted into an extension, see:
# https://docs.blender.org/manual/en/latest/advanced/extensions/addons.html
#
# author:          Sanku Venkatesh
# original author: CaptainHansode - https://sakaiden.com

# Reload modules on "Reload Scripts"
if "bpy" in locals():
    import importlib
    if "sj_phaser" in locals():
        importlib.reload(sj_phaser)

import bpy
from . import sj_phaser


class PERFECTOVERLAP_PG_props(bpy.types.PropertyGroup):
    r"""Add-on settings, stored on the Scene."""
    # frame range
    start_frame: bpy.props.IntProperty(name="Start Frame", default=0, min=0)
    end_frame: bpy.props.IntProperty(name="End Frame", default=100, min=1)

    # how long the chain takes to catch up with the control driving it
    delay: bpy.props.FloatProperty(
        name="Delay", default=3, min=1.0, max=10.0,
        description="How far the chain lags behind the control driving it. "
                    "Higher is slower and looser")
    # how much momentum carries through, i.e. how much it keeps swinging
    recursion: bpy.props.FloatProperty(
        name="Recursion", default=5.0, min=0.0, max=10.0,
        description="How much momentum carries through. 0 settles without "
                    "overshoot, 10 keeps swinging past the target")
    # exaggerates the offset from the rig pose
    strength: bpy.props.FloatProperty(
        name="Strength", default=1.0, min=1.0, max=10.0,
        description="Exaggerates the overlap offset. 1 is the natural "
                    "simulated result")
    # noise floor: kills sub-threshold motion and redundant keys
    threshold: bpy.props.FloatProperty(
        name="Threshold",
        default=0.001, min=0.00001, max=0.1, step=0.01, precision=4,
        description="Motion smaller than this is ignored, and keys that add "
                    "nothing beyond it are removed after baking")
    debug: bpy.props.BoolProperty(name="Debug", default=False)

    # options
    hierarchy: bpy.props.BoolProperty(
        name="Hierarchy",
        default=False,
        description="Detect the control hierarchy automatically. Select only "
                    "the parent controller and every child control below it "
                    "is included, walking through mechanism bones on "
                    "advanced rigs")
    animate_translate: bpy.props.BoolProperty(
        name="Translation",
        default=False,
        description="Also lag the control's position, on every axis it leaves "
                    "unlocked. Connected bones cannot move at all in Blender, "
                    "so they are skipped - they still swing, because the "
                    "solver reacts to the driver's translation either way")

    # cycle
    cycle: bpy.props.BoolProperty(
        name="Cycle",
        default=False,
        description="Solve the range as a continuous loop. The overlap "
                    "carried at the end frame is the same overlap the start "
                    "frame begins with, so the animation cycles with no pop")
    cycle_preroll: bpy.props.IntProperty(
        name="Pre-roll Passes", default=2, min=1, max=6,
        description="How many times the range is solved before baking, to "
                    "settle the motion into its looping steady state. Raise "
                    "this for long chains or a high Delay")


def _configure(module, props):
    r"""Copy panel settings onto the calculation module."""
    module.sf = props.start_frame
    module.ef = props.end_frame
    module.debug = props.debug

    # Raw slider values - the module converts them into stable spring
    # coefficients in solver_params().
    module.delay = props.delay
    module.recursion = props.recursion
    module.strength = props.strength
    module.threshold = props.threshold

    module.hierarchy = props.hierarchy
    module.animate_translate = props.animate_translate
    return module


def _frame_range_ok(operator, props):
    if props.start_frame < props.end_frame:
        return True

    msg = "Make the start frame smaller than the end frame."

    def draw(self, context):
        self.layout.label(text=msg)

    bpy.context.window_manager.popup_menu(draw, title="Info", icon="INFO")
    operator.report({'INFO'}, msg)
    return False


class PERFECTOVERLAP_OT_calculate(bpy.types.Operator):
    r"""Generate overlapping motion on the selected control chain"""
    bl_idname = "perfect_overlap.calculate"
    bl_label = "Calculate"
    bl_description = "Calculate overlapping (follow-through) animation."
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'ARMATURE'

    def execute(self, context):
        props = context.scene.perfect_overlap_props
        module = _configure(sj_phaser.SJPhaserModule(), props)

        if not _frame_range_ok(self, props):
            return {'CANCELLED'}

        bpy.context.scene.frame_set(props.start_frame)
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        obj_trees = module.get_tree_list()          # detect the control chains
        if not obj_trees:
            msg = ("No usable control chain. Select controls that have a "
                   "parent, or enable Hierarchy and select the parent "
                   "controller.")
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}

        module.del_animkey(obj_trees)               # clear our channels in range
        bpy.context.scene.frame_set(props.start_frame)
        module.set_pre_data(obj_trees)              # rest offsets + solver seed

        if props.cycle:
            passes = module.solve_cycle(obj_trees, props.cycle_preroll)
            name, diff = module.cycle_residual(obj_trees)
            module.cleanup_keys(obj_trees)
            module.enforce_cycle_seam(obj_trees)
            module.set_cycle_seam_tangents(obj_trees)
            module.add_cyclic_modifiers(obj_trees)

            if diff > 0.01:
                self.report(
                    {'WARNING'},
                    "Cycle: {} pre-roll passes + bake, drift {:.4f} on '{}' - "
                    "raise Pre-roll Passes or check that the source animation "
                    "loops".format(passes, diff, name))
            else:
                self.report(
                    {'INFO'},
                    "Cycle solved over {} pre-roll passes + bake, "
                    "loop closed (drift {:.5f})".format(passes, diff))
        else:
            module.excute(obj_trees, write=True, include_start=False)
            module.cleanup_keys(obj_trees)
            module.remove_cyclic_modifiers(obj_trees)

        if props.animate_translate and module.translate_skipped:
            self.report(
                {'WARNING'},
                "Translation skipped on {} control(s) that are connected to "
                "their parent or have location locked - they still swing from "
                "rotation".format(len(module.translate_skipped)))

        bpy.context.scene.frame_set(props.start_frame)
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        return {'FINISHED'}


class PERFECTOVERLAP_OT_del_anim(bpy.types.Operator):
    r"""Delete the keyframes created by Calculate"""
    bl_idname = "perfect_overlap.del_anim"
    bl_label = "Delete Keyframe"
    bl_description = "Delete the overlap animation keys."
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'ARMATURE'

    def execute(self, context):
        props = context.scene.perfect_overlap_props
        module = _configure(sj_phaser.SJPhaserModule(), props)

        if not _frame_range_ok(self, props):
            return {'CANCELLED'}

        bpy.context.scene.frame_set(props.start_frame)
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        obj_trees = module.get_tree_list()
        module.del_animkey(obj_trees)

        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        return {'FINISHED'}


class PERFECTOVERLAP_OT_reset_settings(bpy.types.Operator):
    r"""Reset every Perfect Overlap setting back to its default value"""
    bl_idname = "perfect_overlap.reset_settings"
    bl_label = "Reset Settings"
    bl_description = "Reset all Perfect Overlap values to their defaults."
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.perfect_overlap_props
        for key in props.bl_rna.properties.keys():
            if key in {"rna_type", "name"}:
                continue
            props.property_unset(key)
        self.report({'INFO'}, "Perfect Overlap settings reset to defaults")
        return {'FINISHED'}


class PERFECTOVERLAP_PT_panel(bpy.types.Panel):
    r"""Sidebar UI, Pose Mode only."""
    bl_label = "Perfect Overlap"
    bl_idname = "PERFECTOVERLAP_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = "posemode"
    bl_category = "SJT"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.perfect_overlap_props

        layout.label(text="Frame")
        row = layout.row()
        row.prop(props, "start_frame")
        row.prop(props, "end_frame")

        layout.label(text="Properties")
        row = layout.row(align=True)
        row.prop(props, "delay")
        row.prop(props, "recursion")
        row.prop(props, "strength")

        row = layout.row()
        row.prop(props, "threshold")

        layout.label(text="Options")
        box = layout.box()
        col = box.column(align=True)
        col.prop(props, "hierarchy")
        col.prop(props, "animate_translate")

        box = layout.box()
        box.prop(props, "cycle")
        if props.cycle:
            col = box.column(align=True)
            col.prop(props, "cycle_preroll")

        layout.label(text="Main")
        row = layout.row()
        row.scale_y = 1.8
        row.operator("perfect_overlap.calculate", icon="KEYTYPE_KEYFRAME_VEC")
        row = layout.row()
        row.operator("perfect_overlap.del_anim", icon="KEYFRAME")
        row = layout.row()
        row.operator("perfect_overlap.reset_settings", icon="LOOP_BACK")


classes = (
    PERFECTOVERLAP_PG_props,
    PERFECTOVERLAP_OT_calculate,
    PERFECTOVERLAP_OT_del_anim,
    PERFECTOVERLAP_OT_reset_settings,
    PERFECTOVERLAP_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.perfect_overlap_props = bpy.props.PointerProperty(type=PERFECTOVERLAP_PG_props)


def unregister():
    del bpy.types.Scene.perfect_overlap_props
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
