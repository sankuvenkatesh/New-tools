# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

__author__ = "Sanku Venkatesh"
__copyright__ = "Copyright 2021-2026, CaptainHansode, sakaiden.com; 2026 Sanku Venkatesh"
__credits__ = ["Sanku Venkatesh", "CaptainHansode (original author)"]
__license__ = "GPL"
__maintainer__ = "Sanku Venkatesh"
__status__ = "Production"


import bpy
import math
import mathutils


# Bones with these name prefixes are rig plumbing, not animator-facing
# controls. Advanced rigs (Rigify and friends) sit them between the controls,
# so hierarchy detection walks through them instead of stopping at them.
NON_CONTROL_PREFIXES = (
    "def-", "def_", "def.",
    "org-", "org_", "org.",
    "mch-", "mch_", "mch.",
    "wgt-", "wgt_", "wgt.",
    "vis-", "vis_",
)

EPS = 1.0e-6
ZERO = mathutils.Vector((0.0, 0.0, 0.0))
BONE_AXIS = mathutils.Vector((0.0, 1.0, 0.0))   # bones point down local +Y

# Anti-flip guard only. Kept wide so it never kinks normal motion.
MAX_LAG_ANGLE = math.radians(150.0)
# How far a control may drift from the rig, in bone lengths, when Translation
# is on. Stops a runaway from turning into a spike.
MAX_HEAD_DRIFT = 2.0


class SJPhaserModule(object):
    r"""Perfect-overlap solver.

    Each bone's TIP is simulated as a damped point mass chasing the tip the
    rig would give it, then the bone is re-aimed at that lagged tip. Working in
    positions rather than angles is what makes the chain swing from the
    driver's translation as well as its rotation, and it cannot wind up or
    gimbal-flip the way an angle-space solver can."""

    def __init__(self, *args, **kwargs):
        # Raw UI values - converted to solver coefficients in solver_params().
        self.delay = 3.0
        self.recursion = 5.0
        self.strength = 1.0
        self.threshold = 0.001
        self.sf = 0
        self.ef = 100
        self.debug = False

        # --- options -----------------------------------------------------
        self.hierarchy = False
        self.animate_translate = False

        # --- reporting ---------------------------------------------------
        self.passes_run = 0
        self.translate_skipped = []

    # ------------------------------------------------------------------
    # solver coefficients
    # ------------------------------------------------------------------
    def solver_params(self):
        r"""(stiffness, damping, amplitude) for a one-frame integration step.

        Discrete spring: v += k*error - c*v ; x += v. Stable while k > 0 and
        k + 2c < 4, so both are clamped into that region - the bake cannot
        oscillate frame to frame no matter how the sliders are set."""
        k = 1.0 / max(self.delay, 1.0)
        k = min(max(k, 0.05), 0.9)

        rec = min(max(self.recursion, 0.0), 10.0)
        zeta = 1.15 - (rec / 10.0) * 0.8          # damping ratio 1.15 -> 0.35
        c = 2.0 * zeta * math.sqrt(k)
        c = min(max(c, 0.0), min(1.9, (4.0 - k) * 0.5 * 0.95))

        amp = 1.0 + (min(max(self.strength, 1.0), 10.0) - 1.0) / 9.0
        return k, c, amp

    def _limit_dir(self, base, vec, max_angle):
        r"""Keep `vec` within `max_angle` of `base` (both unit vectors)."""
        dot = min(max(base.dot(vec), -1.0), 1.0)
        angle = math.acos(dot)
        if angle <= max_angle or angle < EPS:
            return vec
        return base.slerp(vec, max_angle / angle).normalized()

    # ------------------------------------------------------------------
    # rig inspection
    # ------------------------------------------------------------------
    def _bone_visible(self, pbn):
        bone = pbn.bone
        if bone.hide:
            return False
        colls = getattr(bone, "collections", None)
        if colls:
            for c in colls:
                if getattr(c, "is_visible_effectively",
                           getattr(c, "is_visible", True)):
                    return True
            return False
        return True

    def is_control_bone(self, pbn):
        r"""True for animator-facing controls. Mechanism, deform, org and
        widget bones - and anything hidden - are treated as plumbing."""
        if pbn.name.lower().startswith(NON_CONTROL_PREFIXES):
            return False
        return self._bone_visible(pbn)

    def control_children(self, pbn, _depth=0):
        r"""Direct control children, walking through mechanism bones that an
        advanced rig puts between two controls."""
        out = []
        for child in pbn.children:
            if self.is_control_bone(child):
                out.append(child)
            elif _depth < 8:
                out.extend(self.control_children(child, _depth + 1))
        return out

    def next_in_chain(self, pbn, candidates):
        r"""Which child actually continues this bone's chain.

        Connected children win outright (simple FK). Otherwise the child whose
        head sits closest to this bone's tail and points the same way is the
        real continuation - `children[0]` is just whichever bone was added to
        the rig first."""
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]

        for c in candidates:
            if c.bone.use_connect:
                return c

        tail = pbn.tail
        dir_v = pbn.tail - pbn.head
        dir_v = dir_v.normalized() if dir_v.length > EPS else BONE_AXIS.copy()
        scale = max(pbn.length, EPS)

        best = None
        best_score = None
        for c in candidates:
            dist = (c.head - tail).length / scale
            c_dir = c.tail - c.head
            align = c_dir.normalized().dot(dir_v) if c_dir.length > EPS else -1.0
            score = dist - align
            if best_score is None or score < best_score:
                best_score = score
                best = c
        return best

    def translate_axes(self, pbn):
        r"""Location axes this control may overlap on.

        Blender ignores the location channel of a connected bone entirely, and
        a locked axis belongs to the animator, so both are left alone. The
        chain still swings from the driver's translation - that comes out of
        the tip solver, not the location channel."""
        if not self.animate_translate:
            return []
        if pbn.bone.use_connect:
            return []
        return [a for a in range(3) if not pbn.lock_location[a]]

    def can_translate(self, pbn):
        return len(self.translate_axes(pbn)) > 0

    # ------------------------------------------------------------------
    # selection / chains
    # ------------------------------------------------------------------
    def get_selection(self):
        r"""Pose bones to operate on. With `hierarchy` on, the control
        hierarchy below every selected bone is detected and added."""
        selected = list(bpy.context.selected_pose_bones or [])
        if not self.hierarchy:
            return selected

        out = []
        seen = set()

        def walk(pbn):
            if pbn.name in seen:
                return
            seen.add(pbn.name)
            out.append(pbn)
            for child in self.control_children(pbn):
                walk(child)

        # An explicitly selected bone is always honoured, even if its name
        # would otherwise mark it as plumbing.
        for pbn in selected:
            walk(pbn)
        return out

    def get_hierarchy_count(self, obj):
        obj = obj.parent
        cnt = 0
        while obj is not None:
            obj = obj.parent
            cnt += 1
        return cnt

    def get_default_data_table(self):
        return {
            "obj_list": [],     # pose bones, root first
            "offset": [],       # rest offset from the chain predecessor
            "length": [],       # bone length in local units
            "state": []         # solver state per bone
        }

    def get_tree_list(self):
        r"""Build the bone chains to simulate. Bones are consumed
        shallowest-first, so a chain always starts at its own highest bone and
        unpicked branches become chains of their own."""
        sel_bones = self.get_selection()
        sel_names = {pbn.name for pbn in sel_bones}
        ordered = sorted(sel_bones, key=self.get_hierarchy_count)

        obj_trees = {}
        used = set()
        t_cnt = 0

        for pbn in ordered:
            if pbn.name in used:
                continue
            # A chain needs a parent to hang from - it supplies the driving
            # motion. A parentless controller drives, it is not baked.
            if pbn.parent is None:
                continue

            chain = [pbn]
            used.add(pbn.name)

            cur = pbn
            while True:
                candidates = [c for c in self.control_children(cur)
                              if c.name in sel_names and c.name not in used]
                nxt = self.next_in_chain(cur, candidates)
                if nxt is None:
                    break
                chain.append(nxt)
                used.add(nxt.name)
                cur = nxt

            depth_cnt = self.get_hierarchy_count(pbn)
            if depth_cnt not in obj_trees:
                obj_trees[depth_cnt] = {}

            t_name = "tree{}".format(t_cnt)
            obj_trees[depth_cnt][t_name] = self.get_default_data_table()
            obj_trees[depth_cnt][t_name]["obj_list"] = chain
            t_cnt += 1

        return obj_trees

    def iter_chains(self, obj_trees):
        r"""Every chain, shallowest first, so a parent chain is always solved
        before anything hanging off it."""
        for k in sorted(obj_trees.keys()):
            for t in sorted(obj_trees[k].keys()):
                yield obj_trees[k][t]

    def iter_bones(self, obj_trees):
        for chain in self.iter_chains(obj_trees):
            for pbn in chain["obj_list"]:
                yield pbn

    # ------------------------------------------------------------------
    # setup
    # ------------------------------------------------------------------
    def world_matrix(self, pbn):
        return bpy.context.active_object.matrix_world @ pbn.matrix

    def _tip_of(self, mtx, length):
        return mtx @ mathutils.Vector((0.0, length, 0.0))

    def set_pre_data(self, obj_trees):
        r"""Measure each bone's rest offset from its chain predecessor and
        seed the solver from the current (start frame) pose."""
        self.translate_skipped = []

        for chain in self.iter_chains(obj_trees):
            obj_list = chain["obj_list"]
            chain["offset"] = []
            chain["length"] = []
            chain["state"] = []

            for idx, pbn in enumerate(obj_list):
                # The predecessor is not always the literal parent on an
                # advanced rig - mechanism bones can sit in between - so the
                # offset is measured against whatever actually drives it.
                ref_pbn = obj_list[idx - 1] if idx > 0 else pbn.parent
                ref_mt = self.world_matrix(ref_pbn)
                bone_mt = self.world_matrix(pbn)

                chain["offset"].append(ref_mt.inverted() @ bone_mt)
                chain["length"].append(pbn.length)
                chain["state"].append({
                    "head": bone_mt.translation.copy(),
                    "head_vel": ZERO.copy(),
                    "tip": self._tip_of(bone_mt, pbn.length),
                    "tip_vel": ZERO.copy(),
                    "prev_quat": pbn.rotation_quaternion.copy(),
                    "prev_euler": pbn.rotation_euler.copy(),
                })

                if self.animate_translate and not self.can_translate(pbn):
                    self.translate_skipped.append(pbn.name)
        return obj_trees

    # ------------------------------------------------------------------
    # keyframes
    # ------------------------------------------------------------------
    def rotation_data_path(self, pbn):
        if pbn.rotation_mode == 'QUATERNION':
            return 'rotation_quaternion'
        if pbn.rotation_mode == 'AXIS_ANGLE':
            return 'rotation_axis_angle'
        return 'rotation_euler'

    def make_rotation_continuous(self, pbn, state):
        r"""Keep the rotation channel continuous with the previous frame.

        Setting pose_bone.matrix writes whichever euler or quaternion happens
        to come out of the matrix decomposition. Between two frames that can
        jump a full turn or flip sign - the pose is identical, but the F-Curve
        gets a huge spike and everything interpolated after it is wrong. This
        rewrites the same orientation in the representation nearest the
        previous frame's."""
        mode = pbn.rotation_mode

        if mode == 'QUATERNION':
            quat = pbn.rotation_quaternion.copy()
            prev = state.get("prev_quat")
            if prev is not None and quat.dot(prev) < 0.0:
                quat = mathutils.Quaternion(
                    (-quat.w, -quat.x, -quat.y, -quat.z))
                pbn.rotation_quaternion = quat
            state["prev_quat"] = quat.copy()

        elif mode == 'AXIS_ANGLE':
            state["prev_quat"] = pbn.rotation_quaternion.copy()

        else:
            eul = pbn.rotation_euler.copy()
            prev = state.get("prev_euler")
            if prev is not None:
                eul.make_compatible(prev)
                pbn.rotation_euler = eul
            state["prev_euler"] = eul.copy()

    def set_animkey(self, pbn):
        f = bpy.context.scene.frame_current
        # Locked and connected axes are never keyed, so whatever the animator
        # put there stays untouched.
        for a in self.translate_axes(pbn):
            pbn.keyframe_insert(data_path='location', index=a, frame=f)
        pbn.keyframe_insert(data_path=self.rotation_data_path(pbn), frame=f)
        # Scale is never keyed - baking scale is what made armatures grow or
        # shrink during the simulation.
        return None

    def del_animkey(self, obj_trees):
        r"""Strip our channels inside [sf, ef], then key the start frame.

        This edits the F-Curves directly instead of calling keyframe_delete()
        once per frame: far faster, and it cannot bail out half way through
        and leave stale keys behind to fight the new ones."""
        container = self._fcurve_container(bpy.context.active_object)
        emptied = []

        for fcurve, pbn, channel in self._chain_fcurve_map(obj_trees):
            if channel == 'location':
                if fcurve.array_index not in self.translate_axes(pbn):
                    continue
            elif channel not in ('scale', 'rotation_euler',
                                 'rotation_quaternion', 'rotation_axis_angle'):
                continue

            kps = fcurve.keyframe_points
            drop = [i for i, kp in enumerate(kps)
                    if self.sf <= kp.co[0] <= self.ef]
            for i in reversed(drop):
                kps.remove(kps[i], fast=True)
            fcurve.update()

            if len(fcurve.keyframe_points) == 0:
                emptied.append(fcurve)

        # An empty F-Curve evaluates to 0.0, which would collapse the bone, so
        # it is removed outright rather than left behind.
        if container is not None:
            for fcurve in emptied:
                try:
                    container.remove(fcurve)
                except (RuntimeError, ReferenceError):
                    pass

        bpy.context.view_layer.update()

        for pbn in self.iter_bones(obj_trees):
            for a in self.translate_axes(pbn):
                pbn.keyframe_insert(data_path='location', index=a, frame=self.sf)
            pbn.keyframe_insert(
                data_path=self.rotation_data_path(pbn), frame=self.sf)

        self.remove_cyclic_modifiers(obj_trees)
        return None

    # ------------------------------------------------------------------
    # f-curves
    # ------------------------------------------------------------------
    def _fcurve_container(self, id_data):
        r"""The collection holding the F-Curves, compatible with both the
        legacy Action API (Blender <= 4.3) and the slotted Action API (4.4+,
        where Action.fcurves was removed in 5.0)."""
        adt = id_data.animation_data
        if adt is None or adt.action is None:
            return None
        action = adt.action
        try:
            from bpy_extras import anim_utils
            channelbag = anim_utils.action_get_channelbag_for_slot(
                action, adt.action_slot)
            return channelbag.fcurves if channelbag else None
        except (ImportError, AttributeError):
            return action.fcurves

    def _get_fcurves(self, id_data):
        container = self._fcurve_container(id_data)
        return list(container) if container is not None else []

    def _chain_fcurve_map(self, obj_trees):
        r"""(fcurve, pose_bone, channel) for every curve belonging to a bone
        we are baking."""
        amt = bpy.context.active_object
        by_prefix = {pbn.path_from_id(): pbn
                     for pbn in self.iter_bones(obj_trees)}

        out = []
        for fc in self._get_fcurves(amt):
            for prefix, pbn in by_prefix.items():
                if fc.data_path.startswith(prefix + "."):
                    out.append((fc, pbn, fc.data_path[len(prefix) + 1:]))
                    break
        return out

    def _baked_channels(self, obj_trees):
        r"""The curves this bake writes, grouped per bone and channel.

        Grouping matters: a quaternion or a location is only meaningful as a
        set, so keys are only ever removed on a frame where every component
        agrees they are redundant."""
        groups = {}
        for fc, pbn, channel in self._chain_fcurve_map(obj_trees):
            if channel == self.rotation_data_path(pbn):
                pass
            elif channel == 'location' and fc.array_index in self.translate_axes(pbn):
                pass
            else:
                continue
            groups.setdefault((pbn.name, channel), []).append((fc, pbn))
        return groups

    def _baked_fcurves(self, obj_trees):
        out = []
        for curves in self._baked_channels(obj_trees).values():
            out.extend(curves)
        return out

    def add_cyclic_modifiers(self, obj_trees):
        r"""Add a Cycles F-Curve modifier to every channel we keyed, so the
        action keeps repeating past the end frame."""
        for fcurve, _pbn in self._baked_fcurves(obj_trees):
            if not any(m.type == 'CYCLES' for m in fcurve.modifiers):
                fcurve.modifiers.new('CYCLES')

    def remove_cyclic_modifiers(self, obj_trees):
        for fcurve, _pbn, _ch in self._chain_fcurve_map(obj_trees):
            for m in list(fcurve.modifiers):
                if m.type == 'CYCLES':
                    fcurve.modifiers.remove(m)

    def cleanup_keys(self, obj_trees):
        r"""Drop keys that carry no information and smooth what is left.

        The bake writes one key per frame; a key already sitting on the line
        between its neighbours adds nothing. A frame is only dropped when
        every component of that channel agrees, so a quaternion never ends up
        with its components keyed on different frames."""
        tol = max(self.threshold, 1.0e-6)
        removed = 0

        for curves in self._baked_channels(obj_trees).values():
            fcurves = [fc for fc, _pbn in curves]

            frames = None
            for fc in fcurves:
                fs = [kp.co[0] for kp in fc.keyframe_points
                      if self.sf <= kp.co[0] <= self.ef]
                frames = fs if frames is None else [f for f in frames if f in fs]
            if not frames or len(frames) <= 2:
                self._smooth(fcurves)
                continue

            values = []
            for fc in fcurves:
                lookup = {kp.co[0]: kp.co[1] for kp in fc.keyframe_points}
                values.append([lookup[f] for f in frames])

            drop = set()
            prev = 0
            for i in range(1, len(frames) - 1):
                t0, t1, t2 = frames[prev], frames[i], frames[i + 1]
                if abs(t2 - t0) < EPS:
                    continue
                ratio = (t1 - t0) / (t2 - t0)
                redundant = True
                for comp in values:
                    lerp = comp[prev] + (comp[i + 1] - comp[prev]) * ratio
                    if abs(comp[i] - lerp) > tol:
                        redundant = False
                        break
                if redundant:
                    drop.add(t1)
                else:
                    prev = i

            if drop:
                for fc in fcurves:
                    kps = fc.keyframe_points
                    idx = [n for n, kp in enumerate(kps) if kp.co[0] in drop]
                    for n in reversed(idx):
                        kps.remove(kps[n], fast=True)
                    removed += len(idx)

            self._smooth(fcurves)

        return removed

    def _smooth(self, fcurves):
        for fc in fcurves:
            for kp in fc.keyframe_points:
                if self.sf <= kp.co[0] <= self.ef:
                    kp.interpolation = 'BEZIER'
                    kp.handle_left_type = 'AUTO_CLAMPED'
                    kp.handle_right_type = 'AUTO_CLAMPED'
            fc.update()

    # ------------------------------------------------------------------
    # cycle
    # ------------------------------------------------------------------
    def cycle_residual(self, obj_trees):
        r"""How far the end frame sits from the start frame. Small values mean
        the cyclic solve has converged."""
        worst = 0.0
        worst_name = ""
        for fcurve, pbn in self._baked_fcurves(obj_trees):
            diff = abs(fcurve.evaluate(self.ef) - fcurve.evaluate(self.sf))
            if diff > worst:
                worst = diff
                worst_name = pbn.name
        return worst_name, worst

    def _seam_keys(self, fcurve):
        first = None
        last = None
        for kp in fcurve.keyframe_points:
            f = int(round(kp.co[0]))
            if f == self.sf:
                first = kp
            elif f == self.ef:
                last = kp
        return first, last

    def enforce_cycle_seam(self, obj_trees):
        r"""Make the end frame hold exactly the start frame's values.

        After the cyclic pre-roll the two are already within a rounding error
        of each other, so this only removes the residual - the overlap the
        chain is carrying at the seam is preserved, unlike a blend that
        flattens the tail back to the rig pose."""
        for fcurve, _pbn in self._baked_fcurves(obj_trees):
            first, last = self._seam_keys(fcurve)
            if first is None or last is None or first is last:
                continue
            last.co[1] = first.co[1]
            fcurve.update()

    def set_cycle_seam_tangents(self, obj_trees):
        r"""Match the tangents across the loop point.

        The slope at the seam is taken from the key after the start and the
        key before the end - the two frames that are actually adjacent once
        the action wraps - so the curve runs continuously through the loop."""
        for fcurve, _pbn in self._baked_fcurves(obj_trees):
            first, last = self._seam_keys(fcurve)
            if first is None or last is None or first is last:
                continue

            after = None
            before = None
            for kp in fcurve.keyframe_points:
                if first.co[0] < kp.co[0] <= last.co[0]:
                    if after is None:
                        after = kp
                    if kp.co[0] < last.co[0]:
                        before = kp
            if after is None or before is None or after is last or before is first:
                continue

            dt_a = after.co[0] - first.co[0]
            dt_b = last.co[0] - before.co[0]
            if dt_a + dt_b < EPS:
                continue
            slope = (after.co[1] - before.co[1]) / (dt_a + dt_b)

            for kp in (first, last):
                kp.interpolation = 'BEZIER'
                kp.handle_left_type = 'FREE'
                kp.handle_right_type = 'FREE'
                kp.handle_left = (kp.co[0] - dt_b / 3.0,
                                  kp.co[1] - slope * dt_b / 3.0)
                kp.handle_right = (kp.co[0] + dt_a / 3.0,
                                   kp.co[1] + slope * dt_a / 3.0)
            fcurve.update()

    # ------------------------------------------------------------------
    # simulation
    # ------------------------------------------------------------------
    def solve_bone(self, chain, idx, driver_mt, k, c, amp):
        r"""One integration step for one bone. Returns its new world matrix."""
        pbn = chain["obj_list"][idx]
        st = chain["state"][idx]
        thr = self.threshold

        # Where the rig would put this bone if it followed rigidly.
        tag_mt = driver_mt @ chain["offset"][idx]
        tag_quat = tag_mt.to_quaternion().normalized()
        tag_head = tag_mt.translation.copy()
        tag_tip = self._tip_of(tag_mt, chain["length"][idx])

        seg = tag_tip - tag_head
        seg_len = seg.length
        if seg_len < EPS:
            seg = (tag_quat @ BONE_AXIS).normalized()
            seg_len = max(chain["length"][idx], EPS)
            tag_tip = tag_head + seg * seg_len
        tag_dir = (tag_tip - tag_head).normalized()

        # --- head: only lags when Translation is on -----------------------
        if self.can_translate(pbn):
            hvel = st["head_vel"] * (1.0 - c) + (tag_head - st["head"]) * k
            if hvel.length < thr:
                hvel = ZERO.copy()
            st["head_vel"] = hvel
            st["head"] = st["head"] + hvel

            drift = st["head"] - tag_head
            if drift.length > seg_len * MAX_HEAD_DRIFT:
                st["head"] = tag_head + drift.normalized() * seg_len * MAX_HEAD_DRIFT
                st["head_vel"] = ZERO.copy()
            out_head = tag_head + (st["head"] - tag_head) * amp
        else:
            st["head"] = tag_head.copy()
            st["head_vel"] = ZERO.copy()
            out_head = tag_head.copy()

        # --- tip: this is the overlap -------------------------------------
        # A point mass chasing the rig's tip. Because it is a position, the
        # chain swings whether the driver rotates, translates, or both.
        tvel = st["tip_vel"] * (1.0 - c) + (tag_tip - st["tip"]) * k
        if tvel.length < thr:
            tvel = ZERO.copy()
        st["tip_vel"] = tvel
        st["tip"] = st["tip"] + tvel

        # Hold the bone's length: the tip may lag, it may not stretch.
        span = st["tip"] - st["head"]
        if span.length < EPS:
            span = tag_dir.copy()
        st["tip"] = st["head"] + span.normalized() * seg_len

        sim_dir = (st["tip"] - st["head"]).normalized()
        if amp > 1.0:
            out_dir = tag_dir + (sim_dir - tag_dir) * amp
            out_dir = out_dir.normalized() if out_dir.length > EPS else sim_dir
        else:
            out_dir = sim_dir
        out_dir = self._limit_dir(tag_dir, out_dir, MAX_LAG_ANGLE)

        # Re-aim the rig's own orientation at the lagged tip: the roll comes
        # straight from the rig, so it cannot drift or flip.
        out_quat = tag_dir.rotation_difference(out_dir) @ tag_quat

        return (mathutils.Matrix.Translation(out_head) @
                out_quat.to_matrix().to_4x4())

    def solve_chain(self, chain, k, c, amp, write):
        amt = bpy.context.active_object
        amt_inv = amt.matrix_world.inverted()

        driver_mt = self.world_matrix(chain["obj_list"][0].parent)

        for idx in range(len(chain["obj_list"])):
            pbn = chain["obj_list"][idx]
            st = chain["state"][idx]
            translate = self.can_translate(pbn)

            # What the bone already has this frame. The solver builds an
            # orthonormal matrix, so assigning it would otherwise bake
            # 1/armature-scale into the bone's local scale - that is what made
            # armatures scale.
            orig_loc = pbn.location.copy()
            orig_scale = pbn.scale.copy()

            pbn.matrix = amt_inv @ self.solve_bone(chain, idx, driver_mt, k, c, amp)
            pbn.scale = orig_scale
            if not translate:
                pbn.location = orig_loc
            else:
                for a in range(3):
                    if pbn.lock_location[a]:
                        pbn.location[a] = orig_loc[a]

            # Same pose, written in the representation closest to last frame's
            # - this is what stops euler wrap and quaternion sign flips from
            # spiking the curves.
            self.make_rotation_continuous(pbn, st)

            if write:
                self.set_animkey(pbn)

            # Required so pose_bone.matrix reflects the change before the next
            # bone in the chain reads it.
            # https://blender.stackexchange.com/questions/132403/
            bpy.context.view_layer.update()

            # Drive the rest of the chain from what the bone actually became
            # (constraints, locks and the restored scale all apply here), not
            # from what we asked for. The solver state is left alone: feeding
            # the amplified result back in is what would make it compound.
            driver_mt = self.world_matrix(pbn)

    def excute(self, obj_trees, write=True, include_start=False):
        r"""Solve every frame in the range.

        `write` off runs the solver without touching keyframes - that is how
        the cyclic pre-roll settles the motion before anything is baked."""
        k, c, amp = self.solver_params()
        scene = bpy.context.scene
        start = self.sf if include_start else self.sf + 1

        for f in range(start, self.ef + 1):
            scene.frame_set(f)
            for chain in self.iter_chains(obj_trees):
                self.solve_chain(chain, k, c, amp, write)
        self.passes_run += 1
        return True

    def solve_cycle(self, obj_trees, preroll):
        r"""Solve the range as a continuous circular timeline.

        Frame ef is followed by frame sf: the solver keeps its velocities and
        positions across the seam and runs the range `preroll` times without
        writing anything. By the bake pass the motion has settled into its
        periodic steady state, so the overlap the chain carries into frame sf
        is the same overlap it leaves frame ef with - the loop closes because
        the simulation is genuinely cyclic, not because the tail was blended
        shut."""
        self.passes_run = 0
        passes = max(1, int(preroll))
        for _ in range(passes):
            self.excute(obj_trees, write=False, include_start=True)
        self.excute(obj_trees, write=True, include_start=True)
        return passes

    def message_box(self, message="", title="Message", icon='INFO'):
        def draw(self, context):
            self.layout.label(text=message)
        bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)
