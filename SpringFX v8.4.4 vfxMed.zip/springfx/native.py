"""ctypes bridge to the compiled SpringFX solver core.

Blender 5.2 ships no Python.h and no python313.lib, so a CPython extension
(Cython included) cannot be linked against its interpreter. The core is
therefore a plain C shared library (.dll / .dylib / .so) called through ctypes -- same machine code, no
headers required, and the only cost is that the boundary is crossed with
raw pointers instead of PyObjects.

That cost is why the boundary is crossed exactly ONCE PER FRAME. An earlier
build called into C once per chain and came out SLOWER than pure Python
(1.497 vs 1.396 ms/frame): the solve was already fast, and marshalling four
lists of mathutils.Vector into flat arrays and back cost more than it saved.
sfx_step() takes the whole rig -- pose matrices in, quaternions out.

The module degrades to the pure-Python solver if anything here fails: a
missing DLL, an ABI mismatch, or an unsupported rig configuration. Nothing
in the addon requires the compiled path to be present.
"""

import ctypes
import os
import sys

_LIB = None
_AVAILABLE = False
_ERROR = ""
_ABI_REQUIRED = 8
# NOTE (8.3.0): mesh colliders in the compiled core are an OPTIONAL extension
# of ABI 8 (extra exported symbols, nothing changed in the existing ones). A
# library built before 8.3.0 still loads; mesh scenes then keep running on
# the pure-Python solver exactly as they did, so a platform whose binary was
# not rebuilt degrades instead of breaking.
_MESH_API = 0


def _lib_filename():
    """Name of the compiled core for the running platform."""
    # NOTE: macOS ships one universal2 dylib (arm64 + x86_64) so a single file
    # covers Apple Silicon and Intel Macs; Linux uses the usual lib*.so name.
    if sys.platform == "win32":
        return "springfx_step.dll"
    if sys.platform == "darwin":
        return "libspringfx_step.dylib"
    return "libspringfx_step.so"


_dp = ctypes.POINTER(ctypes.c_double)
_fp = ctypes.POINTER(ctypes.c_float)
_ip = ctypes.POINTER(ctypes.c_int)


def _load():
    global _LIB, _AVAILABLE, _ERROR
    if _LIB is not None or _ERROR:
        return _AVAILABLE
    path = os.path.join(os.path.dirname(__file__), "native", _lib_filename())
    if not os.path.exists(path):
        _ERROR = "%s not found" % _lib_filename()
        return False
    try:
        lib = ctypes.CDLL(path)
        lib.sfx_abi.restype = ctypes.c_int
        lib.sfx_abi.argtypes = []
        abi = lib.sfx_abi()
        if abi != _ABI_REQUIRED:
            _ERROR = "ABI %d, expected %d (stale DLL)" % (abi, _ABI_REQUIRED)
            return False
        lib.sfx_step.restype = None
        lib.sfx_step.argtypes = [
            _dp, _dp, _dp,              # mw, bmat, brest
            _ip, _ip, _ip,              # bidx, chain_off, root_bidx
            ctypes.c_int, ctypes.c_int, # n_chains, n_states
            _dp,                        # prm
            _dp, _dp, _dp, _dp,         # P, V, prevT, smoothq
            _ip,                        # inited
            _dp, _dp,                   # gravity, wind
            ctypes.c_double, ctypes.c_int, ctypes.c_int,   # dt, sim_steps, iters
            _dp, ctypes.c_int,          # spheres, n_sph
            ctypes.c_double, _dp, _dp,  # cbounce, cdamp[], cstiff[]
            _fp, _dp,                   # qbuf (float32), outq
            _dp,                        # scratch
            ctypes.c_int, ctypes.c_int, # mode, n_bones
            _dp, _dp, _dp,              # offs, bloc, bscl
            _ip,                        # bparent
            _fp, _dp, _ip,              # lastw, prevsw, haveprev
            _dp, _dp,                   # wpose, cleanq
            _dp,                        # opt
        ]
        lib.sfx_loc.restype = None
        lib.sfx_loc.argtypes = [
            _dp, _dp, _dp,              # mw, ppose, offs
            _ip, ctypes.c_int, _dp,     # lbidx, n_loc, lprm
            _dp, _fp, _ip,              # lclean, lastw, linited
            _dp, _dp, _dp,              # P, V, prevT
            _dp, _dp,                   # gravity, wind
            ctypes.c_double, ctypes.c_int,          # dt, sim_steps
            _dp, ctypes.c_int,                      # spheres, n_sph
            ctypes.c_double, ctypes.c_double, ctypes.c_int,  # bounce, friction, iters
            ctypes.c_int, ctypes.c_double, ctypes.c_int,     # ss_base/target/cap
            _fp, _dp,                   # locbuf, opt
        ]
        lib.sfx_reset.restype = None
        lib.sfx_reset.argtypes = [_ip, ctypes.c_int]
        global _MESH_API
        _MESH_API = 0
        fn = getattr(lib, "sfx_mesh_api", None)
        if fn is not None:
            fn.restype = ctypes.c_int
            fn.argtypes = []
            if fn() == 1:
                lib.sfx_set_meshes.restype = None
                lib.sfx_set_meshes.argtypes = [
                    ctypes.c_int,                    # n meshes
                    ctypes.POINTER(ctypes.c_void_p), # 8 buffer pointers each
                    _ip,                             # nv, nt each
                    _dp,                             # 51 parameters each
                ]
                _u64p = ctypes.POINTER(ctypes.c_uint64)
                lib.sfx_set_mesh_masks.restype = None
                lib.sfx_set_mesh_masks.argtypes = [_u64p, ctypes.c_int,
                                                   _u64p, ctypes.c_int]
                lib.sfx_mesh_nearest.restype = ctypes.c_int
                lib.sfx_mesh_nearest.argtypes = [
                    ctypes.POINTER(ctypes.c_void_p), # 8 buffer pointers
                    _ip,                             # nv, nt
                    _dp,                             # LOCAL query point
                    _dp,                             # out: loc, normal, dist
                ]
                _MESH_API = 1
        _LIB = lib
        _AVAILABLE = True
    except Exception as exc:                       # pragma: no cover
        _ERROR = str(exc)
        _AVAILABLE = False
    return _AVAILABLE


def available():
    return _load()


def status():
    if _load():
        return "compiled solver active"
    return "pure-Python solver (%s)" % (_ERROR or "unavailable")


def lib():
    return _LIB if _load() else None


def mesh_api():
    """1 when the loaded library collides mesh colliders itself, else 0."""
    return _MESH_API if _load() else 0


def ptr_d(a):
    return a.ctypes.data_as(_dp)


def ptr_f(a):
    return a.ctypes.data_as(_fp)


def ptr_i(a):
    return a.ctypes.data_as(_ip)


def unload():
    """Release the DLL so it can be rebuilt in place (development aid).

    Windows keeps a load count, and ctypes.CDLL bumps it on every import
    cycle, so the handle has to be freed until the module is really gone or
    the linker cannot overwrite the file.
    """
    global _LIB, _AVAILABLE, _ERROR
    if os.name != "nt":
        return False
    import ctypes.wintypes                       # noqa: F401
    k = ctypes.windll.kernel32
    k.GetModuleHandleW.restype = ctypes.c_void_p
    k.GetModuleHandleW.argtypes = [ctypes.c_wchar_p]
    k.FreeLibrary.argtypes = [ctypes.c_void_p]
    for _ in range(64):
        h = k.GetModuleHandleW(_lib_filename())
        if not h or not k.FreeLibrary(ctypes.c_void_p(h)):
            break
    global _MESH_API
    _LIB = None
    _AVAILABLE = False
    _ERROR = ""
    _MESH_API = 0
    return True
