#!/usr/bin/env bash
# Build the SpringFX compiled core for macOS or Linux.
# NOTE: no -ffast-math. MSVC's /fp:fast and clang/gcc fast-math reorder
# floating point differently; plain -O2 keeps results closest to the
# reference trajectories and still vectorises the hot loops.
set -euo pipefail
cd "$(dirname "$0")"
case "$(uname -s)" in
  Darwin)
    clang -O2 -std=c99 -Wall -dynamiclib -fPIC \
      -arch arm64 -arch x86_64 -mmacosx-version-min=11.0 \
      -Wl,-install_name,@rpath/libspringfx_step.dylib \
      springfx_step.c -o libspringfx_step.dylib -lm
    # NOTE: arm64 refuses to load unsigned code; an ad-hoc signature is enough.
    codesign --force --sign - libspringfx_step.dylib
    lipo -info libspringfx_step.dylib
    ;;
  Linux)
    gcc -O2 -std=c99 -Wall -shared -fPIC \
      springfx_step.c -o libspringfx_step.so -lm
    ;;
  *) echo "unsupported platform" >&2; exit 1 ;;
esac
