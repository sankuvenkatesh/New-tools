/* springfx_solver.c -- XPBD chain solver, compiled core.
 *
 * Built as a PLAIN C DLL and called through ctypes, NOT as a CPython
 * extension. Blender 5.2 ships no Python.h or python313.lib, so a real
 * extension module cannot be built against it; a bare DLL only needs the
 * Windows SDK, which is present. One call per frame solves every chain, so
 * the ~1 us ctypes overhead is amortised over the whole rig.
 *
 * Layout is SoA and flat: all chains share P/cdelta, indexed by offsets.
 */
#include <math.h>

#ifdef _WIN32
#define SFX_API __declspec(dllexport)
#else
#define SFX_API
#endif

static void seg_vs_sphere(const double *h, const double *t, double br,
                          const double *c, double r,
                          double *out_s, double *out_depth, double *out_n)
{
    double dx = t[0]-h[0], dy = t[1]-h[1], dz = t[2]-h[2];
    double dd = dx*dx + dy*dy + dz*dz;
    double s = 0.0, px, py, pz, ox, oy, oz, dist, total;
    if (dd > 1e-12) {
        s = ((c[0]-h[0])*dx + (c[1]-h[1])*dy + (c[2]-h[2])*dz) / dd;
        if (s < 0.0) s = 0.0; else if (s > 1.0) s = 1.0;
    }
    px = h[0]+dx*s; py = h[1]+dy*s; pz = h[2]+dz*s;
    ox = px-c[0];  oy = py-c[1];  oz = pz-c[2];
    dist = sqrt(ox*ox + oy*oy + oz*oz);
    total = r + br;
    *out_s = s;
    if (dist >= total) { *out_depth = -1.0; return; }
    *out_depth = total - dist;
    if (dist > 1e-9) { out_n[0]=ox/dist; out_n[1]=oy/dist; out_n[2]=oz/dist; }
    else             { out_n[0]=0.0; out_n[1]=0.0; out_n[2]=1.0; }
}

static void solve_link(double *P, double *cdelta, int p0, int i,
                       const double *lengths, const double *radii, int l0,
                       const double *spheres, int n_sph, double stiffness)
{
    double *h = P + (p0+i)*3;
    double *t = P + (p0+i+1)*3;
    double s, depth, n[3], w_h, w_t, tot, ln, corr, dv;
    int k, d;
    for (k = 0; k < n_sph; ++k) {
        seg_vs_sphere(h, t, radii[l0+i], spheres+k*4, spheres[k*4+3],
                      &s, &depth, n);
        if (depth <= 0.0) continue;
        w_t = s;
        w_h = (i > 0) ? (1.0 - s) : 0.0;
        tot = w_h + w_t;
        if (tot < 1e-9) continue;
        for (d = 0; d < 3; ++d) {
            if (w_h > 0.0) {
                dv = n[d]*depth*stiffness*(w_h/tot);
                h[d] += dv; cdelta[(p0+i)*3+d] += dv;
            }
            dv = n[d]*depth*stiffness*(w_t/tot);
            t[d] += dv; cdelta[(p0+i+1)*3+d] += dv;
        }
    }
    ln = sqrt((t[0]-h[0])*(t[0]-h[0]) + (t[1]-h[1])*(t[1]-h[1]) + (t[2]-h[2])*(t[2]-h[2]));
    if (ln < 1e-9) return;
    corr = (ln - lengths[l0+i]) / ln;
    for (d = 0; d < 3; ++d) {
        dv = (t[d]-h[d]) * corr;
        if (i > 0) { h[d] += dv*0.5; t[d] -= dv*0.5; }
        else       { t[d] -= dv; }
    }
}

/* Bounding-sphere prefilter: which spheres can this chain possibly touch. */
static int prefilter(const double *P, int p0, int np, const double *radii,
                     int l0, int nl, const double *spheres, int n_sph,
                     double *out, int max_out)
{
    double lo[3], hi[3], c[3], r = 0.0, maxr = 0.0, dx, dy, dz;
    int i, d, k, n = 0;
    for (d = 0; d < 3; ++d) { lo[d] = hi[d] = P[p0*3+d]; }
    for (i = 1; i < np; ++i)
        for (d = 0; d < 3; ++d) {
            double v = P[(p0+i)*3+d];
            if (v < lo[d]) lo[d] = v;
            if (v > hi[d]) hi[d] = v;
        }
    for (i = 0; i < nl; ++i) if (radii[l0+i] > maxr) maxr = radii[l0+i];
    for (d = 0; d < 3; ++d) { c[d] = (lo[d]+hi[d])*0.5; }
    dx = hi[0]-lo[0]; dy = hi[1]-lo[1]; dz = hi[2]-lo[2];
    r = sqrt(dx*dx+dy*dy+dz*dz)*0.5 + maxr;
    for (k = 0; k < n_sph && n < max_out; ++k) {
        dx = spheres[k*4+0]-c[0]; dy = spheres[k*4+1]-c[1]; dz = spheres[k*4+2]-c[2];
        if (sqrt(dx*dx+dy*dy+dz*dz) <= r + spheres[k*4+3]) {
            out[n*4+0]=spheres[k*4+0]; out[n*4+1]=spheres[k*4+1];
            out[n*4+2]=spheres[k*4+2]; out[n*4+3]=spheres[k*4+3];
            ++n;
        }
    }
    return n;
}

SFX_API void sfx_solve(double *P, double *cdelta,
                       const int *chain_off, const int *link_off, int n_chains,
                       const double *lengths, const double *radii,
                       const double *spheres, int n_sph,
                       int iters, double stiffness)
{
    double local[64*4];
    int ci, it, i, d, p0, np, l0, nl, ns;
    for (ci = 0; ci < n_chains; ++ci) {
        p0 = chain_off[ci];  np = chain_off[ci+1] - p0;
        l0 = link_off[ci];   nl = link_off[ci+1] - l0;
        if (nl < 1) continue;
        ns = (n_sph > 0) ? prefilter(P, p0, np, radii, l0, nl,
                                     spheres, n_sph, local, 64) : 0;
        if (ns > 0) {
            for (it = 0; it < iters; ++it) {
                for (i = 0; i < nl; ++i)
                    solve_link(P, cdelta, p0, i, lengths, radii, l0, local, ns, stiffness);
                for (i = nl-1; i >= 0; --i)
                    solve_link(P, cdelta, p0, i, lengths, radii, l0, local, ns, stiffness);
            }
        }
        /* hard root->tip projection: exact rest lengths from a fixed root */
        for (i = 0; i < nl; ++i) {
            double *h = P + (p0+i)*3, *t = P + (p0+i+1)*3, ln;
            ln = sqrt((t[0]-h[0])*(t[0]-h[0]) + (t[1]-h[1])*(t[1]-h[1]) + (t[2]-h[2])*(t[2]-h[2]));
            if (ln > 1e-9)
                for (d = 0; d < 3; ++d) t[d] = h[d] + (t[d]-h[d])*(lengths[l0+i]/ln);
        }
    }
}
