@echo off
rem NOTE: flags must match the shipped DLLs, otherwise results stop being
rem bit-exact with previous releases.
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
cd /d "%~dp0"
cl /LD /O2 /Oi /fp:fast /GS- /W3 /nologo springfx_step.c /Fe:springfx_step.dll
cl /LD /O2 /Oi /fp:fast /GS- /nologo springfx_solver.c /Fe:springfx_solver.dll
del /q *.obj *.lib *.exp 2>nul
