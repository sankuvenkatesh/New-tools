/* springfx_step.c -- SpringFX 8.0 compiled solver core.
 *
 * Built as a PLAIN C DLL and called through ctypes, NOT as a CPython
 * extension. Blender 5.2 ships no Python.h and no python313.lib, so a real
 * extension module cannot be linked against its interpreter; a bare DLL only
 * needs the Windows SDK, which is present. The trade is that the boundary is
 * ctypes rather than the C-API -- which is why the boundary is crossed ONCE
 * PER FRAME for the whole rig instead of once per chain or once per bone.
 *
 * sfx_step() owns the entire per-frame pipeline for rotation springs:
 *   1. rebuild world-space chain geometry from the pose matrices
 *   2. predict   -- spring-damper integration of each joint toward its target
 *   3. solve     -- XPBD distance + segment/sphere collision, Gauss-Seidel
 *   4. respond   -- contact velocity response
 *   5. convert   -- swing quaternions in bone-local space, composed onto the
 *                   clean pose and written straight into the float32 buffer
 *                   Python hands to foreach_set
 *
 * Everything is flat and contiguous: doubles for state, one float32 array
 * shared with Blender's RNA. Nothing is allocated per frame.
 *
 * The Python implementation in core.py / xpbd.py remains the documented
 * semantics; this file must match it, and the bench compares both
 * trajectories bone-for-bone.
 */

#include <math.h>
#include <string.h>

#ifdef _WIN32
#define SFX_API __declspec(dllexport)
#else
#define SFX_API
#endif

#define MAX_SPH_LOCAL 64

enum {
    PRM_STIFF = 0,   /* rot stiffness x chain falloff, pre-multiplied */
    PRM_DAMP,        /* rot damping 0..1                              */
    PRM_GRAV,        /* gravity slider                                */
    PRM_DRAG,        /* air drag 0..1                                 */
    PRM_WIND,        /* wind influence 0..1                           */
    PRM_INFL,        /* rot influence 0..1                            */
    PRM_RANGE,       /* swing range multiplier                        */
    PRM_SMOOTH,      /* HF damping 0..1                               */
    PRM_AUTOLEN,     /* auto length compensation flag                 */
    PRM_RADIUS,      /* collision radius                              */
    PRM_N
};

static double v_len(const double *v)
{
    return sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
}

static void v_norm(double *v)
{
    double l = v_len(v);
    if (l > 1e-12) { v[0] /= l; v[1] /= l; v[2] /= l; }
}

static void mat4_point(const double *M, const double *p, double *out)
{
    out[0] = M[0]*p[0] + M[1]*p[1] + M[2]*p[2]  + M[3];
    out[1] = M[4]*p[0] + M[5]*p[1] + M[6]*p[2]  + M[7];
    out[2] = M[8]*p[0] + M[9]*p[1] + M[10]*p[2] + M[11];
}

static void m3_mul(const double *A, const double *B, double *C)
{
    int r, c;
    for (r = 0; r < 3; ++r)
        for (c = 0; c < 3; ++c)
            C[r*3+c] = A[r*3+0]*B[0*3+c] + A[r*3+1]*B[1*3+c] + A[r*3+2]*B[2*3+c];
}

static void m3_Tmul_vec(const double *A, const double *v, double *out)
{
    out[0] = A[0]*v[0] + A[3]*v[1] + A[6]*v[2];
    out[1] = A[1]*v[0] + A[4]*v[1] + A[7]*v[2];
    out[2] = A[2]*v[0] + A[5]*v[1] + A[8]*v[2];
}

static void m3_Tmul(const double *A, const double *B, double *C)
{
    int r, c;
    for (r = 0; r < 3; ++r)
        for (c = 0; c < 3; ++c)
            C[r*3+c] = A[0*3+r]*B[0*3+c] + A[1*3+r]*B[1*3+c] + A[2*3+r]*B[2*3+c];
}

static void m3_normalize_cols(double *M)
{
    int c, r;
    for (c = 0; c < 3; ++c) {
        double l = sqrt(M[0*3+c]*M[0*3+c] + M[1*3+c]*M[1*3+c] + M[2*3+c]*M[2*3+c]);
        if (l > 1e-12)
            for (r = 0; r < 3; ++r) M[r*3+c] /= l;
    }
}

static void q_to_m3(const double *q, double *M)
{
    double w = q[0], x = q[1], y = q[2], z = q[3];
    double xx = x*x, yy = y*y, zz = z*z;
    double xy = x*y, xz = x*z, yz = y*z;
    double wx = w*x, wy = w*y, wz = w*z;
    M[0] = 1.0 - 2.0*(yy+zz); M[1] = 2.0*(xy-wz);       M[2] = 2.0*(xz+wy);
    M[3] = 2.0*(xy+wz);       M[4] = 1.0 - 2.0*(xx+zz); M[5] = 2.0*(yz-wx);
    M[6] = 2.0*(xz-wy);       M[7] = 2.0*(yz+wx);       M[8] = 1.0 - 2.0*(xx+yy);
}

/* C = A * B, both 4x4 ROW major */
static void m4_mul(const double *A, const double *B, double *C)
{
    int r, c;
    for (r = 0; r < 4; ++r)
        for (c = 0; c < 4; ++c)
            C[r*4+c] = A[r*4+0]*B[0*4+c] + A[r*4+1]*B[1*4+c]
                     + A[r*4+2]*B[2*4+c] + A[r*4+3]*B[3*4+c];
}

static void q_conj(const double *q, double *out)
{
    out[0] = q[0]; out[1] = -q[1]; out[2] = -q[2]; out[3] = -q[3];
}

/* matrix_basis = T(loc) . R(quat) . S(scale), ROW major */
static void basis_from_trs(const double *loc, const double *q,
                           const double *scl, double *M)
{
    double R[9];
    int r, c;
    q_to_m3(q, R);
    for (r = 0; r < 3; ++r) {
        for (c = 0; c < 3; ++c) M[r*4+c] = R[r*3+c] * scl[c];
        M[r*4+3] = loc[r];
    }
    M[12] = M[13] = M[14] = 0.0; M[15] = 1.0;
}

static void q_mul(const double *a, const double *b, double *out)
{
    double w = a[0]*b[0] - a[1]*b[1] - a[2]*b[2] - a[3]*b[3];
    double x = a[0]*b[1] + a[1]*b[0] + a[2]*b[3] - a[3]*b[2];
    double y = a[0]*b[2] + a[2]*b[0] + a[3]*b[1] - a[1]*b[3];
    double z = a[0]*b[3] + a[3]*b[0] + a[1]*b[2] - a[2]*b[1];
    out[0] = w; out[1] = x; out[2] = y; out[3] = z;
}

static void q_norm(double *q)
{
    double l = sqrt(q[0]*q[0] + q[1]*q[1] + q[2]*q[2] + q[3]*q[3]);
    if (l > 1e-12) { q[0]/=l; q[1]/=l; q[2]/=l; q[3]/=l; }
    else { q[0]=1.0; q[1]=q[2]=q[3]=0.0; }
}

/* Shortest-arc rotation taking +Y onto `v` (unit). Mirrors mathutils
 * Vector.rotation_difference, antipodal fallback included: an exactly
 * opposite vector has no unique arc, so a stable axis is chosen rather than
 * letting the quaternion blow up. */
static void q_from_y_to(const double *v, double *q)
{
    double c = v[1];                    /* dot((0,1,0), v) */
    if (c < -1.0 + 1e-10) {
        q[0] = 0.0; q[1] = 0.0; q[2] = 0.0; q[3] = 1.0;
        return;
    }
    q[0] = 1.0 + c;
    q[1] = v[2]; q[2] = 0.0; q[3] = -v[0];   /* cross((0,1,0), v) */
    q_norm(q);
}

static void q_scale_angle(double *q, double t)
{
    double w, s, ang, na, sn;
    if (q[0] < 0.0) { q[0]=-q[0]; q[1]=-q[1]; q[2]=-q[2]; q[3]=-q[3]; }
    w = q[0];
    if (w > 1.0) w = 1.0; else if (w < -1.0) w = -1.0;
    ang = 2.0 * acos(w);
    s = sqrt(1.0 - w*w);
    if (ang < 1e-9 || s < 1e-9) { q[0]=1.0; q[1]=q[2]=q[3]=0.0; return; }
    na = ang * t * 0.5;
    sn = sin(na);
    q[0] = cos(na);
    q[1] = q[1]/s*sn; q[2] = q[2]/s*sn; q[3] = q[3]/s*sn;
}

static void q_slerp(const double *a, const double *b, double t, double *out)
{
    double d = a[0]*b[0] + a[1]*b[1] + a[2]*b[2] + a[3]*b[3];
    double bb[4], th, st, wa, wb;
    int i;
    for (i = 0; i < 4; ++i) bb[i] = b[i];
    if (d < 0.0) { for (i = 0; i < 4; ++i) bb[i] = -bb[i]; d = -d; }
    if (d > 0.9995) {
        for (i = 0; i < 4; ++i) out[i] = a[i] + (bb[i]-a[i])*t;
        q_norm(out);
        return;
    }
    if (d > 1.0) d = 1.0;
    th = acos(d); st = sin(th);
    wa = sin((1.0-t)*th)/st; wb = sin(t*th)/st;
    for (i = 0; i < 4; ++i) out[i] = a[i]*wa + bb[i]*wb;
    q_norm(out);
}

/* ------------------------------------------------------------------ */
/*  collision                                                          */
/* ------------------------------------------------------------------ */

static void seg_vs_sphere(const double *h, const double *t, double br,
                          const double *c, double r,
                          double *out_s, double *out_depth, double *out_n)
{
    double dx = t[0]-h[0], dy = t[1]-h[1], dz = t[2]-h[2];
    double dd = dx*dx + dy*dy + dz*dz;
    double s = 0.0, px, py, pz, ox, oy, oz, dist, total;
    if (dd > 1e-12) {
        s = ((c[0]-h[0])*dx + (c[1]-h[1])*dy + (c[2]-h[2])*dz) / dd;
        if (s < 0.0) s = 0.0; else if (s > 1.0) s = 1.0;
    }
    px = h[0]+dx*s; py = h[1]+dy*s; pz = h[2]+dz*s;
    ox = px-c[0];  oy = py-c[1];  oz = pz-c[2];
    dist = sqrt(ox*ox + oy*oy + oz*oz);
    total = r + br;
    *out_s = s;
    if (dist >= total) { *out_depth = -1.0; return; }
    *out_depth = total - dist;
    if (dist > 1e-9) { out_n[0]=ox/dist; out_n[1]=oy/dist; out_n[2]=oz/dist; }
    else             { out_n[0]=0.0; out_n[1]=0.0; out_n[2]=1.0; }
}


/* ------------------------------------------------------------------ */
/*  mesh colliders (8.3.0)                                             */
/* ------------------------------------------------------------------ */
/*
 * Until 8.2 a single mesh collider sent the whole frame -- every chain of
 * every rig -- back to the pure-Python solver, because this core only knew
 * spheres. On a dense character (a body with Blender's Collision modifier)
 * that was ~70 ms of Python per frame for 394 bones. Mesh colliders now run
 * here with the semantics of xpbd.seg_vs_mesh and the mesh branch of
 * core._sb_collide_point:
 *
 *   - the mesh lives in its LOCAL space; query points go in through the
 *     inverse world matrix and hits come back out, normals through the
 *     inverse transpose, exactly as the Python BVH path does;
 *   - a segment is sampled at u = 0, 0.5, 1 and the deepest contact wins;
 *   - a sample farther than the contact radius outside the collider's world
 *     bounds is skipped, and so is building the tree when nothing ever gets
 *     that close (lazy build, same as core._SBMeshBVH).
 *
 * The BVH is built here, lazily, into buffers Python owns and keeps across
 * frames; Python clears state[0] whenever the evaluated vertices change.
 * Nothing is allocated in C. Results are not bit-identical to the Python
 * BVH (a different tree, Blender's loop-triangle split of quads), only
 * equivalent: the nearest point is exact, ties at shared edges can resolve
 * to the other face.
 */
#define MAX_MESH 64
#define MESH_PRM 51
#define BVH_LEAF 4
#define BVH_STACK 256

typedef struct {
    const double *V;    /* nv*3 LOCAL vertex positions                    */
    const int *T;       /* nt*3 triangle vertex indices                   */
    double *tn;         /* nt*3 LOCAL unit triangle normals (built here)  */
    double *box;        /* (2*nt)*6 node bounds: lo xyz, hi xyz           */
    int *node;          /* (2*nt)*2: children, or (first, -count) leaf    */
    int *perm;          /* nt triangle order                              */
    double *cen;        /* nt*3 centroid scratch                          */
    int *state;         /* [0] 0 build, 1 ready, 2 refit; [1] node count;
                         * [2] refits since the last full build             */
    int nv, nt;
    double mw[16], mwi[16], m3it[9], lo[3], hi[3];
    double margin, force, bounce, friction;  /* bounce/friction < 0: scene */
} SfxMesh;

static SfxMesh g_mesh[MAX_MESH];
static int g_n_mesh = 0;

/* Per-chain / per-location-spring masks of mesh colliders to IGNORE (bit m =
 * table entry m): the meshes that chain's own bones deform ("Ignore Own
 * Mesh"). Set by Python around each rig's step, NULL otherwise. */
static const unsigned long long *g_chain_skip = NULL;
static int g_chain_skip_n = 0;
static const unsigned long long *g_loc_skip = NULL;
static int g_loc_skip_n = 0;

SFX_API void sfx_set_mesh_masks(const unsigned long long *chain_skip, int n_chain,
                                const unsigned long long *loc_skip, int n_loc)
{
    g_chain_skip = chain_skip; g_chain_skip_n = chain_skip ? n_chain : 0;
    g_loc_skip = loc_skip;     g_loc_skip_n = loc_skip ? n_loc : 0;
}

SFX_API int sfx_mesh_api(void) { return 1; }

/* ptrs   n*8   V, T, tn, box, node, perm, cen, state
 * counts n*2   nv, nt
 * prm    n*51  mw[16] mwi[16] (row major), m3it[9], lo[3], hi[3],
 *              margin, force, bounce, friction
 * n = 0 clears the table; Python does so after every frame so no stale
 * pointer can outlive the buffers it points into. */
SFX_API void sfx_set_meshes(int n, void **ptrs, const int *counts, const double *prm)
{
    int m, k;
    if (n < 0) n = 0;
    if (n > MAX_MESH) n = MAX_MESH;
    for (m = 0; m < n; ++m) {
        SfxMesh *M = &g_mesh[m];
        void **p = ptrs + (size_t)m*8;
        const double *q = prm + (size_t)m*MESH_PRM;
        M->V = (const double *)p[0]; M->T = (const int *)p[1];
        M->tn = (double *)p[2];      M->box = (double *)p[3];
        M->node = (int *)p[4];       M->perm = (int *)p[5];
        M->cen = (double *)p[6];     M->state = (int *)p[7];
        M->nv = counts[m*2]; M->nt = counts[m*2+1];
        for (k = 0; k < 16; ++k) M->mw[k]  = q[k];
        for (k = 0; k < 16; ++k) M->mwi[k] = q[16+k];
        for (k = 0; k < 9;  ++k) M->m3it[k] = q[32+k];
        for (k = 0; k < 3;  ++k) { M->lo[k] = q[41+k]; M->hi[k] = q[44+k]; }
        M->margin = q[47]; M->force = q[48]; M->bounce = q[49]; M->friction = q[50];
    }
    g_n_mesh = n;
}

static void m3_vec(const double *A, const double *v, double *out)
{
    out[0] = A[0]*v[0] + A[1]*v[1] + A[2]*v[2];
    out[1] = A[3]*v[0] + A[4]*v[1] + A[5]*v[2];
    out[2] = A[6]*v[0] + A[7]*v[1] + A[8]*v[2];
}

/* quickselect: perm[lo..hi) partially ordered so perm[nth] holds the
 * element that would sit there sorted by centroid[axis]. */
static void bvh_select(int *perm, const double *cen, int axis, int lo, int hi, int nth)
{
    int l = lo, r = hi - 1;
    while (r > l) {
        double pv = cen[perm[(l + r) / 2]*3 + axis];
        int i = l, j = r, tmp;
        while (i <= j) {
            while (cen[perm[i]*3 + axis] < pv) ++i;
            while (cen[perm[j]*3 + axis] > pv) --j;
            if (i <= j) { tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp; ++i; --j; }
        }
        if (nth <= j) r = j;
        else if (nth >= i) l = i;
        else break;
    }
}

static void tri_normal(SfxMesh *M, int i)
{
    const double *a = M->V + (size_t)M->T[i*3+0]*3;
    const double *b = M->V + (size_t)M->T[i*3+1]*3;
    const double *c = M->V + (size_t)M->T[i*3+2]*3;
    double u[3], w[3], *n = M->tn + (size_t)i*3, l;
    int d;
    for (d = 0; d < 3; ++d) { u[d] = b[d]-a[d]; w[d] = c[d]-a[d]; }
    n[0] = u[1]*w[2] - u[2]*w[1];
    n[1] = u[2]*w[0] - u[0]*w[2];
    n[2] = u[0]*w[1] - u[1]*w[0];
    l = v_len(n);
    if (l > 1e-30) { n[0] /= l; n[1] /= l; n[2] /= l; }
    else           { n[0] = n[1] = n[2] = 0.0; }
}

/* Refit: same tree, new vertex positions. Children are always allocated
 * after their parent, so one reverse sweep recomputes every box bottom-up.
 * A deforming collider with unchanged topology (an armature-skinned body)
 * pays O(n) per frame instead of a full O(n log n) rebuild; the boxes stay
 * exact bounds, so queries stay exact -- only the tree gets less tight as
 * the pose drifts, which the periodic rebuild below resets. */
static void bvh_refit(SfxMesh *M)
{
    int nn = M->state[1], k, i, d, v;
    for (i = 0; i < M->nt; ++i) tri_normal(M, i);
    for (k = nn - 1; k >= 0; --k) {
        double *bx = M->box + (size_t)k*6;
        int a = M->node[k*2], b = M->node[k*2+1];
        if (b < 0) {
            for (d = 0; d < 3; ++d) { bx[d] = 1e300; bx[3+d] = -1e300; }
            for (i = a; i < a - b; ++i) {
                int t = M->perm[i];
                for (v = 0; v < 3; ++v) {
                    const double *p = M->V + (size_t)M->T[t*3+v]*3;
                    for (d = 0; d < 3; ++d) {
                        if (p[d] < bx[d]) bx[d] = p[d];
                        if (p[d] > bx[3+d]) bx[3+d] = p[d];
                    }
                }
            }
        } else {
            const double *L = M->box + (size_t)a*6, *R = M->box + (size_t)b*6;
            for (d = 0; d < 3; ++d) {
                bx[d]   = (L[d]   < R[d])   ? L[d]   : R[d];
                bx[3+d] = (L[3+d] > R[3+d]) ? L[3+d] : R[3+d];
            }
        }
    }
    M->state[0] = 1;
}

#define BVH_REFITS_PER_BUILD 30

static void bvh_build(SfxMesh *M)
{
    int nt = M->nt, i, d, nn = 1, sp = 0;
    int st_k[BVH_STACK], st_a[BVH_STACK], st_b[BVH_STACK];
    for (i = 0; i < nt; ++i) {
        const double *a = M->V + (size_t)M->T[i*3+0]*3;
        const double *b = M->V + (size_t)M->T[i*3+1]*3;
        const double *c = M->V + (size_t)M->T[i*3+2]*3;
        tri_normal(M, i);
        for (d = 0; d < 3; ++d) M->cen[(size_t)i*3+d] = (a[d] + b[d] + c[d]) / 3.0;
        M->perm[i] = i;
    }
    M->state[1] = 0;
    if (nt <= 0) { M->state[0] = 1; return; }
    st_k[0] = 0; st_a[0] = 0; st_b[0] = nt; sp = 1;
    while (sp > 0) {
        int k, a, b, cnt, axis, mid, L, R;
        double *bx, clo[3], chi[3], ext[3];
        --sp; k = st_k[sp]; a = st_a[sp]; b = st_b[sp];
        cnt = b - a;
        bx = M->box + (size_t)k*6;
        for (d = 0; d < 3; ++d) { bx[d] = 1e300; bx[3+d] = -1e300; clo[d] = 1e300; chi[d] = -1e300; }
        for (i = a; i < b; ++i) {
            int t = M->perm[i], v;
            for (v = 0; v < 3; ++v) {
                const double *p = M->V + (size_t)M->T[t*3+v]*3;
                for (d = 0; d < 3; ++d) {
                    if (p[d] < bx[d]) bx[d] = p[d];
                    if (p[d] > bx[3+d]) bx[3+d] = p[d];
                }
            }
            for (d = 0; d < 3; ++d) {
                double cc = M->cen[(size_t)t*3+d];
                if (cc < clo[d]) clo[d] = cc;
                if (cc > chi[d]) chi[d] = cc;
            }
        }
        for (d = 0; d < 3; ++d) ext[d] = chi[d] - clo[d];
        axis = (ext[0] >= ext[1] && ext[0] >= ext[2]) ? 0 : (ext[1] >= ext[2] ? 1 : 2);
        /* NOTE: a leaf when small, when every centroid coincides (no split
         * can separate them), or when the stack would overflow. */
        if (cnt <= BVH_LEAF || ext[axis] <= 0.0 || sp + 2 > BVH_STACK) {
            M->node[k*2] = a; M->node[k*2+1] = -cnt;
            continue;
        }
        mid = a + cnt / 2;
        bvh_select(M->perm, M->cen, axis, a, b, mid);
        L = nn++; R = nn++;
        M->node[k*2] = L; M->node[k*2+1] = R;
        st_k[sp] = R; st_a[sp] = mid; st_b[sp] = b; ++sp;
        st_k[sp] = L; st_a[sp] = a;   st_b[sp] = mid; ++sp;
    }
    M->state[1] = nn;
    M->state[2] = 0;
    M->state[0] = 1;
}

static void bvh_ensure(SfxMesh *M)
{
    if (M->state[0] == 1) return;
    if (M->state[0] == 2 && M->state[1] > 0 && M->state[2] < BVH_REFITS_PER_BUILD) {
        ++M->state[2];
        bvh_refit(M);
        return;
    }
    bvh_build(M);
}

static double box_d2(const double *bx, const double *p)
{
    double s = 0.0, e;
    int d;
    for (d = 0; d < 3; ++d) {
        if (p[d] < bx[d])        { e = bx[d] - p[d];   s += e*e; }
        else if (p[d] > bx[3+d]) { e = p[d] - bx[3+d]; s += e*e; }
    }
    return s;
}

/* Closest point on triangle abc to p (Ericson, Real-Time Collision
 * Detection 5.1.5), with the degenerate divisions guarded. */
static void closest_pt_tri(const double *p, const double *a, const double *b,
                           const double *c, double *out)
{
    double ab[3], ac[3], ap[3], bp[3], cp[3], d1, d2, d3, d4, d5, d6, va, vb, vc, v, w, den;
    int d;
    for (d = 0; d < 3; ++d) { ab[d] = b[d]-a[d]; ac[d] = c[d]-a[d]; ap[d] = p[d]-a[d]; }
    d1 = ab[0]*ap[0] + ab[1]*ap[1] + ab[2]*ap[2];
    d2 = ac[0]*ap[0] + ac[1]*ap[1] + ac[2]*ap[2];
    if (d1 <= 0.0 && d2 <= 0.0) { for (d = 0; d < 3; ++d) out[d] = a[d]; return; }
    for (d = 0; d < 3; ++d) bp[d] = p[d]-b[d];
    d3 = ab[0]*bp[0] + ab[1]*bp[1] + ab[2]*bp[2];
    d4 = ac[0]*bp[0] + ac[1]*bp[1] + ac[2]*bp[2];
    if (d3 >= 0.0 && d4 <= d3) { for (d = 0; d < 3; ++d) out[d] = b[d]; return; }
    vc = d1*d4 - d3*d2;
    if (vc <= 0.0 && d1 >= 0.0 && d3 <= 0.0) {
        den = d1 - d3;
        v = (den != 0.0) ? d1 / den : 0.0;
        for (d = 0; d < 3; ++d) out[d] = a[d] + ab[d]*v;
        return;
    }
    for (d = 0; d < 3; ++d) cp[d] = p[d]-c[d];
    d5 = ab[0]*cp[0] + ab[1]*cp[1] + ab[2]*cp[2];
    d6 = ac[0]*cp[0] + ac[1]*cp[1] + ac[2]*cp[2];
    if (d6 >= 0.0 && d5 <= d6) { for (d = 0; d < 3; ++d) out[d] = c[d]; return; }
    vb = d5*d2 - d1*d6;
    if (vb <= 0.0 && d2 >= 0.0 && d6 <= 0.0) {
        den = d2 - d6;
        w = (den != 0.0) ? d2 / den : 0.0;
        for (d = 0; d < 3; ++d) out[d] = a[d] + ac[d]*w;
        return;
    }
    va = d3*d6 - d5*d4;
    if (va <= 0.0 && (d4 - d3) >= 0.0 && (d5 - d6) >= 0.0) {
        den = (d4 - d3) + (d5 - d6);
        w = (den != 0.0) ? (d4 - d3) / den : 0.0;
        for (d = 0; d < 3; ++d) out[d] = b[d] + (c[d]-b[d])*w;
        return;
    }
    den = va + vb + vc;
    if (den == 0.0) { for (d = 0; d < 3; ++d) out[d] = a[d]; return; }
    den = 1.0 / den;
    v = vb*den; w = vc*den;
    for (d = 0; d < 3; ++d) out[d] = a[d] + ab[d]*v + ac[d]*w;
}

/* Nearest surface point to LOCAL p. Returns the triangle, or -1. */
static int bvh_nearest(SfxMesh *M, const double *p, double *out)
{
    int stack[BVH_STACK], sp = 0, bt = -1, i;
    double best = 1e300, q[3];
    if (M->nt <= 0) return -1;
    bvh_ensure(M);
    if (M->state[1] <= 0) return -1;
    stack[sp++] = 0;
    while (sp > 0) {
        int k = stack[--sp], a, b;
        if (box_d2(M->box + (size_t)k*6, p) >= best) continue;
        a = M->node[k*2]; b = M->node[k*2+1];
        if (b < 0) {
            for (i = a; i < a - b; ++i) {
                int t = M->perm[i];
                double dx, dy, dz, d2;
                closest_pt_tri(p, M->V + (size_t)M->T[t*3+0]*3,
                               M->V + (size_t)M->T[t*3+1]*3,
                               M->V + (size_t)M->T[t*3+2]*3, q);
                dx = q[0]-p[0]; dy = q[1]-p[1]; dz = q[2]-p[2];
                d2 = dx*dx + dy*dy + dz*dz;
                if (d2 < best) { best = d2; bt = t; out[0] = q[0]; out[1] = q[1]; out[2] = q[2]; }
            }
        } else {
            double dl = box_d2(M->box + (size_t)a*6, p);
            double dr = box_d2(M->box + (size_t)b*6, p);
            if (sp + 2 > BVH_STACK) continue;
            /* farther child first, so the nearer one is popped next */
            if (dl <= dr) {
                if (dr < best) stack[sp++] = b;
                if (dl < best) stack[sp++] = a;
            } else {
                if (dl < best) stack[sp++] = a;
                if (dr < best) stack[sp++] = b;
            }
        }
    }
    return bt;
}

static int outside_bounds(const double *p, const SfxMesh *M, double rad)
{
    return (p[0] < M->lo[0] - rad || p[0] > M->hi[0] + rad
            || p[1] < M->lo[1] - rad || p[1] > M->hi[1] + rad
            || p[2] < M->lo[2] - rad || p[2] > M->hi[2] + rad);
}

/* One LOCAL-space nearest query for the Python side (Euler chains and
 * Python-owned location springs), on the same buffers and the same lazily
 * built tree the compiled solve uses -- one tree per mesh per frame instead
 * of a second mathutils BVH. out = loc[3], local normal[3], distance.
 * Returns the triangle index, or -1. */
SFX_API int sfx_mesh_nearest(void **ptrs, const int *counts, const double *p,
                             double *out)
{
    SfxMesh M;
    int tri, d;
    double loc[3], dd = 0.0;
    memset(&M, 0, sizeof(M));
    M.V = (const double *)ptrs[0]; M.T = (const int *)ptrs[1];
    M.tn = (double *)ptrs[2];      M.box = (double *)ptrs[3];
    M.node = (int *)ptrs[4];       M.perm = (int *)ptrs[5];
    M.cen = (double *)ptrs[6];     M.state = (int *)ptrs[7];
    M.nv = counts[0]; M.nt = counts[1];
    tri = bvh_nearest(&M, p, loc);
    if (tri < 0) return -1;
    for (d = 0; d < 3; ++d) {
        out[d] = loc[d];
        out[3+d] = M.tn[(size_t)tri*3+d];
        dd += (loc[d]-p[d])*(loc[d]-p[d]);
    }
    out[6] = sqrt(dd);
    return tri;
}

/* xpbd.seg_vs_mesh: deepest of three samples along the segment. */
static void seg_vs_mesh(const double *h, const double *t, double br, SfxMesh *M,
                        double *out_s, double *out_depth, double *out_n)
{
    double rad = M->margin + br, best = -1.0;
    int k, d;
    *out_s = 0.0; *out_depth = -1.0;
    for (k = 0; k < 3; ++k) {
        double u = 0.5 * (double)k, wp[3], lp[3], loc[3], wl[3], wn[3], sg, depth;
        int tri;
        for (d = 0; d < 3; ++d) wp[d] = h[d]*(1.0 - u) + t[d]*u;
        if (outside_bounds(wp, M, rad)) continue;
        mat4_point(M->mwi, wp, lp);
        tri = bvh_nearest(M, lp, loc);
        if (tri < 0) continue;
        mat4_point(M->mw, loc, wl);
        m3_vec(M->m3it, M->tn + (size_t)tri*3, wn);
        v_norm(wn);
        sg = (wp[0]-wl[0])*wn[0] + (wp[1]-wl[1])*wn[1] + (wp[2]-wl[2])*wn[2];
        depth = rad - sg;
        if (depth <= 0.0) continue;
        if (best < 0.0 || depth > best) {
            best = depth; *out_s = u;
            out_n[0] = wn[0]; out_n[1] = wn[1]; out_n[2] = wn[2];
        }
    }
    *out_depth = best;
}

/* xpbd.prefilter for meshes: chain bounding sphere vs world AABB + margin. */
static int prefilter_meshes(const double *P, int p0, int np, const double *radii,
                            int l0, int nl, unsigned long long skip, int *out)
{
    double lo[3], hi[3], c[3], r, maxr = 0.0, dx, dy, dz;
    int i, d, m, n = 0;
    for (d = 0; d < 3; ++d) { lo[d] = hi[d] = P[p0*3+d]; }
    for (i = 1; i < np; ++i)
        for (d = 0; d < 3; ++d) {
            double v = P[(p0+i)*3+d];
            if (v < lo[d]) lo[d] = v;
            if (v > hi[d]) hi[d] = v;
        }
    for (i = 0; i < nl; ++i) if (radii[l0+i] > maxr) maxr = radii[l0+i];
    for (d = 0; d < 3; ++d) c[d] = (lo[d]+hi[d])*0.5;
    dx = hi[0]-lo[0]; dy = hi[1]-lo[1]; dz = hi[2]-lo[2];
    r = sqrt(dx*dx+dy*dy+dz*dz)*0.5 + maxr;
    for (m = 0; m < g_n_mesh; ++m) {
        const SfxMesh *M = &g_mesh[m];
        double ex, ey, ez, reach;
        if (M->nt <= 0 || ((skip >> m) & 1ULL)) continue;
        ex = (M->lo[0] - c[0] > 0.0) ? M->lo[0] - c[0] : ((c[0] - M->hi[0] > 0.0) ? c[0] - M->hi[0] : 0.0);
        ey = (M->lo[1] - c[1] > 0.0) ? M->lo[1] - c[1] : ((c[1] - M->hi[1] > 0.0) ? c[1] - M->hi[1] : 0.0);
        ez = (M->lo[2] - c[2] > 0.0) ? M->lo[2] - c[2] : ((c[2] - M->hi[2] > 0.0) ? c[2] - M->hi[2] : 0.0);
        reach = r + (M->margin > 0.0 ? M->margin : 0.0);
        if (ex*ex + ey*ey + ez*ez > reach*reach) continue;
        out[n++] = m;
    }
    return n;
}

static void solve_link(double *P, double *cdelta, int p0, int i,
                       const double *lengths, const double *radii, int l0,
                       const double *spheres, int n_sph,
                       const int *mids, int n_m, double stiffness)
{
    double *h = P + (p0+i)*3;
    double *t = P + (p0+i+1)*3;
    double s, depth, n[3], w_h, w_t, tot, ln, corr, dv;
    int k, d;
    for (k = 0; k < n_sph; ++k) {
        seg_vs_sphere(h, t, radii[l0+i], spheres+k*4, spheres[k*4+3],
                      &s, &depth, n);
        if (depth <= 0.0) continue;
        w_t = s;
        w_h = (i > 0) ? (1.0 - s) : 0.0;
        tot = w_h + w_t;
        if (tot < 1e-9) continue;
        for (d = 0; d < 3; ++d) {
            if (w_h > 0.0) {
                dv = n[d]*depth*stiffness*(w_h/tot);
                h[d] += dv; cdelta[(p0+i)*3+d] += dv;
            }
            dv = n[d]*depth*stiffness*(w_t/tot);
            t[d] += dv; cdelta[(p0+i+1)*3+d] += dv;
        }
    }
    for (k = 0; k < n_m; ++k) {
        seg_vs_mesh(h, t, radii[l0+i], &g_mesh[mids[k]], &s, &depth, n);
        if (depth <= 0.0) continue;
        w_t = s;
        w_h = (i > 0) ? (1.0 - s) : 0.0;
        tot = w_h + w_t;
        if (tot < 1e-9) continue;
        for (d = 0; d < 3; ++d) {
            if (w_h > 0.0) {
                dv = n[d]*depth*stiffness*(w_h/tot);
                h[d] += dv; cdelta[(p0+i)*3+d] += dv;
            }
            dv = n[d]*depth*stiffness*(w_t/tot);
            t[d] += dv; cdelta[(p0+i+1)*3+d] += dv;
        }
    }
    ln = sqrt((t[0]-h[0])*(t[0]-h[0]) + (t[1]-h[1])*(t[1]-h[1]) + (t[2]-h[2])*(t[2]-h[2]));
    if (ln < 1e-9) return;
    corr = (ln - lengths[l0+i]) / ln;
    for (d = 0; d < 3; ++d) {
        dv = (t[d]-h[d]) * corr;
        if (i > 0) { h[d] += dv*0.5; t[d] -= dv*0.5; }
        else       { t[d] -= dv; }
    }
}

/* Bounding-sphere prefilter: which spheres this chain can possibly touch. */
static int prefilter(const double *P, int p0, int np, const double *radii,
                     int l0, int nl, const double *spheres, int n_sph,
                     double *out, int max_out)
{
    double lo[3], hi[3], c[3], r, maxr = 0.0, dx, dy, dz;
    int i, d, k, n = 0;
    for (d = 0; d < 3; ++d) { lo[d] = hi[d] = P[p0*3+d]; }
    for (i = 1; i < np; ++i)
        for (d = 0; d < 3; ++d) {
            double v = P[(p0+i)*3+d];
            if (v < lo[d]) lo[d] = v;
            if (v > hi[d]) hi[d] = v;
        }
    for (i = 0; i < nl; ++i) if (radii[l0+i] > maxr) maxr = radii[l0+i];
    for (d = 0; d < 3; ++d) { c[d] = (lo[d]+hi[d])*0.5; }
    dx = hi[0]-lo[0]; dy = hi[1]-lo[1]; dz = hi[2]-lo[2];
    r = sqrt(dx*dx+dy*dy+dz*dz)*0.5 + maxr;
    for (k = 0; k < n_sph && n < max_out; ++k) {
        dx = spheres[k*4+0]-c[0]; dy = spheres[k*4+1]-c[1]; dz = spheres[k*4+2]-c[2];
        if (sqrt(dx*dx+dy*dy+dz*dz) <= r + spheres[k*4+3]) {
            out[n*4+0]=spheres[k*4+0]; out[n*4+1]=spheres[k*4+1];
            out[n*4+2]=spheres[k*4+2]; out[n*4+3]=spheres[k*4+3];
            ++n;
        }
    }
    return n;
}

/* Final contact pass, root -> tip, that a rotation-only chain can actually
 * reproduce.
 *
 * The plain length projection has to run last -- a chain of fixed-length
 * bones cannot represent anything else -- but it re-anchors each head to its
 * parent's tip and can push a segment back through a surface the collision
 * pass had just cleared. Residual on the bench: 0.70 mm.
 *
 * This pass fixes the head (already final, because we walk root -> tip) and
 * moves only the TIP, re-imposing the exact bone length about the head after
 * every push. The segment therefore ROTATES instead of stretching, which is
 * exactly the motion the bone will be given, so nothing downstream can undo
 * it. A contact at parameter s along the segment needs the tip to travel
 * depth/s to clear it, hence the scale.
 *
 * It cannot help when the HEAD itself is inside a collider: that head belongs
 * to the parent bone, and for the chain root it is kinematic. Those cases are
 * reported through _sb_root_warnings instead of being silently half-solved.
 */
static void resolve_tangential(double *P, int p0, int nl,
                               const double *lengths, const double *radii, int l0,
                               const double *spheres, int n_sph,
                               const int *mids, int n_m)
{
    int i, k, it, d;
    for (i = 0; i < nl; ++i) {
        double *h = P + (p0+i)*3, *t = P + (p0+i+1)*3;
        double L = lengths[l0+i], s, depth, n[3], ln, sc;
        for (it = 0; it < 4; ++it) {
            int hit = 0;
            for (k = 0; k < n_sph; ++k) {
                seg_vs_sphere(h, t, radii[l0+i], spheres+k*4, spheres[k*4+3],
                              &s, &depth, n);
                if (depth <= 1e-12) continue;
                hit = 1;
                sc = (s > 0.10) ? (depth / s) : (depth * 10.0);
                for (d = 0; d < 3; ++d) t[d] += n[d] * sc;
                ln = sqrt((t[0]-h[0])*(t[0]-h[0]) + (t[1]-h[1])*(t[1]-h[1])
                        + (t[2]-h[2])*(t[2]-h[2]));
                if (ln > 1e-9)
                    for (d = 0; d < 3; ++d) t[d] = h[d] + (t[d]-h[d])*(L/ln);
            }
            for (k = 0; k < n_m; ++k) {
                seg_vs_mesh(h, t, radii[l0+i], &g_mesh[mids[k]], &s, &depth, n);
                if (depth <= 1e-12) continue;
                hit = 1;
                sc = (s > 0.10) ? (depth / s) : (depth * 10.0);
                for (d = 0; d < 3; ++d) t[d] += n[d] * sc;
                ln = sqrt((t[0]-h[0])*(t[0]-h[0]) + (t[1]-h[1])*(t[1]-h[1])
                        + (t[2]-h[2])*(t[2]-h[2]));
                if (ln > 1e-9)
                    for (d = 0; d < 3; ++d) t[d] = h[d] + (t[d]-h[d])*(L/ln);
            }
            if (!hit) break;
        }
    }
}

SFX_API void sfx_solve(double *P, double *cdelta,
                       const int *chain_off, const int *link_off, int n_chains,
                       const double *lengths, const double *radii,
                       const double *spheres, int n_sph,
                       int iters, const double *stiffness)
{
    double local[MAX_SPH_LOCAL*4];
    int mloc[MAX_MESH];
    int ci, it, i, d, p0, np, l0, nl, ns, nm;
    for (ci = 0; ci < n_chains; ++ci) {
        p0 = chain_off[ci];  np = chain_off[ci+1] - p0;
        l0 = link_off[ci];   nl = link_off[ci+1] - l0;
        if (nl < 1) continue;
        ns = (n_sph > 0) ? prefilter(P, p0, np, radii, l0, nl,
                                     spheres, n_sph, local, MAX_SPH_LOCAL) : 0;
        nm = (g_n_mesh > 0)
             ? prefilter_meshes(P, p0, np, radii, l0, nl,
                                (ci < g_chain_skip_n) ? g_chain_skip[ci] : 0ULL, mloc)
             : 0;
        if (ns > 0 || nm > 0) {
            for (it = 0; it < iters; ++it) {
                for (i = 0; i < nl; ++i)
                    solve_link(P, cdelta, p0, i, lengths, radii, l0, local, ns,
                               mloc, nm, stiffness[ci]);
                for (i = nl-1; i >= 0; --i)
                    solve_link(P, cdelta, p0, i, lengths, radii, l0, local, ns,
                               mloc, nm, stiffness[ci]);
            }
        }
        /* Hard root->tip projection: exact rest lengths from a fixed root.
         * A chain of rotation-only bones can only represent EXACT lengths,
         * so this has to be the last word -- but on its own it also undoes
         * whatever the collision pass just did, re-anchoring every head to
         * its parent's tip. Alternating [collision, projection] converges
         * onto a pose that is both representable and outside the collider:
         * the projection only rescales a segment along its own direction,
         * so the direction collision established survives it. Measured on
         * the bench, 29 penetrating samples -> see README. */
        for (i = 0; i < nl; ++i) {
            double *h = P + (p0+i)*3, *t = P + (p0+i+1)*3, ln;
            ln = sqrt((t[0]-h[0])*(t[0]-h[0]) + (t[1]-h[1])*(t[1]-h[1]) + (t[2]-h[2])*(t[2]-h[2]));
            if (ln > 1e-9)
                for (d = 0; d < 3; ++d) t[d] = h[d] + (t[d]-h[d])*(lengths[l0+i]/ln);
        }
        if (ns > 0 || nm > 0)
            resolve_tangential(P, p0, nl, lengths, radii, l0, local, ns, mloc, nm);
    }
}

/* ------------------------------------------------------------------ */
/*  predict                                                            */
/* ------------------------------------------------------------------ */

/* Auto stiffness compensation by bone size. Mirrors _sb_length_mult. */
static double length_mult(double L, double enabled)
{
    double m;
    if (enabled < 0.5) return 1.0;
    if (L < 0.02) L = 0.02; else if (L > 4.0) L = 4.0;
    m = sqrt(0.25 / L);
    if (m < 0.6) m = 0.6; else if (m > 1.6) m = 1.6;
    return m;
}

/* ------------------------------------------------------------------ */
/*  EXACT DAMPED-SPRING INTEGRATOR                                     */
/* ------------------------------------------------------------------ */
/*
 * The spring is a LINEAR system, so it does not need to be integrated
 * numerically at all -- it can be solved.
 *
 * Working relative to the moving target, e = pos - T(t), and with T linear
 * across the step (which is exactly how the caller feeds it), the equation
 *
 *     accel = k(T - pos) - c(vel - v_T) + g - c_air * vel
 *
 * becomes a constant-coefficient ODE
 *
 *     e'' + C e' + K e = G,    C = c + c_air,  K = k,  G = g - c_air * v_T
 *
 * whose closed-form solution is evaluated below. Semi-implicit Euler was
 * being run at omega*dt ~ 0.58 with two substeps; at that ratio it both
 * lags the phase and pumps a little energy back in every step, and the
 * per-frame residual of that error is high-frequency -- which is precisely
 * what a jerk metric measures.
 *
 * The exact form has no step-size error at all, so one step per frame is
 * both smoother AND cheaper than the substepped approximation it replaces.
 * It is also unconditionally stable: no stiffness setting can blow it up.
 */
static void spring_point_exact(double *pos, double *vel,
                               const double *tgt, const double *tgt_prev,
                               double k, double c, double dt, double drag,
                               const double *grav)
{
    double C = c + drag * 12.0;
    double K = k;
    double v_T[3], e[3], ed[3], G, u0, v0, uh, vh, ss;
    double disc, alpha, w, ca, sa, ex, l1, l2, c1, c2, e1, e2;
    int d;

    if (dt <= 1e-12) return;
    for (d = 0; d < 3; ++d) v_T[d] = (tgt[d] - tgt_prev[d]) / dt;

    /* state relative to the target at the START of the step */
    for (d = 0; d < 3; ++d) {
        e[d]  = pos[d] - tgt_prev[d];
        ed[d] = vel[d] - v_T[d];
    }

    disc = C*C - 4.0*K;
    if (disc < -1e-12) {                       /* underdamped */
        alpha = 0.5*C;
        w = sqrt(K - 0.25*C*C);
        ex = exp(-alpha*dt);
        ca = cos(w*dt); sa = sin(w*dt);
        for (d = 0; d < 3; ++d) {
            G  = grav[d] - (drag * 12.0) * v_T[d];
            ss = G / K;                        /* steady-state offset */
            u0 = e[d] - ss;  v0 = ed[d];
            uh = ex*(u0*ca + ((v0 + alpha*u0)/w)*sa);
            vh = ex*((v0)*ca - (w*u0 + (alpha/w)*(v0 + alpha*u0))*sa);
            e[d]  = uh + ss;
            ed[d] = vh;
        }
    } else if (disc > 1e-12) {                 /* overdamped */
        double sq = sqrt(disc);
        l1 = 0.5*(-C + sq);
        l2 = 0.5*(-C - sq);
        e1 = exp(l1*dt); e2 = exp(l2*dt);
        for (d = 0; d < 3; ++d) {
            G  = grav[d] - (drag * 12.0) * v_T[d];
            ss = G / K;
            u0 = e[d] - ss;  v0 = ed[d];
            c1 = (v0 - l2*u0) / (l1 - l2);
            c2 = u0 - c1;
            e[d]  = c1*e1 + c2*e2 + ss;
            ed[d] = c1*l1*e1 + c2*l2*e2;
        }
    } else {                                   /* critically damped */
        alpha = 0.5*C;
        ex = exp(-alpha*dt);
        for (d = 0; d < 3; ++d) {
            G  = grav[d] - (drag * 12.0) * v_T[d];
            ss = G / K;
            u0 = e[d] - ss;  v0 = ed[d];
            e[d]  = (u0 + (v0 + alpha*u0)*dt)*ex + ss;
            ed[d] = ((v0) - alpha*(v0 + alpha*u0)*dt)*ex;
        }
    }

    for (d = 0; d < 3; ++d) {
        pos[d] = e[d] + tgt[d];                /* target at the step END */
        vel[d] = ed[d] + v_T[d];
    }
}

/* One simulate_spring_point call, XPBD flavour: no anisotropy, no speed
 * multiplier, substep_base 1 / target 0.30 / cap 8. */
static void spring_point(double *pos, double *vel,
                         const double *tgt, const double *tgt_prev,
                         double stiff, double damp, const double *grav,
                         double dt, double drag, const double *opt)
{
    double k = 40.0 + stiff * 500.0;
    double c = 2.0 * sqrt(k) * (0.15 + damp);
    if (opt && opt[0] > 0.5) {
        spring_point_exact(pos, vel, tgt, tgt_prev, k, c, dt, drag, grav);
        return;
    }
    double c_air = drag * 12.0;
    double v_t[3], sub_dt, t_frac, tp[3], accel[3];
    double omega = sqrt(k);
    int substeps, j, d;

    if (dt > 1e-9) {
        for (d = 0; d < 3; ++d) v_t[d] = (tgt[d] - tgt_prev[d]) / dt;
    } else {
        v_t[0] = v_t[1] = v_t[2] = 0.0;
    }

    substeps = (int)(omega * dt / (opt ? opt[2] : 0.30)) + 1;
    if (opt && substeps < (int)opt[1]) substeps = (int)opt[1];
    if (substeps < 1) substeps = 1;
    if (opt && substeps > (int)opt[3]) substeps = (int)opt[3];
    else if (!opt && substeps > 8) substeps = 8;
    sub_dt = dt / substeps;

    for (j = 0; j < substeps; ++j) {
        t_frac = (double)(j + 1) / (double)substeps;
        for (d = 0; d < 3; ++d) {
            tp[d] = tgt_prev[d] + (tgt[d] - tgt_prev[d]) * t_frac;
            accel[d] = (tp[d] - pos[d])*k - (vel[d] - v_t[d])*c + grav[d];
            if (c_air > 0.0) accel[d] -= vel[d]*c_air;
        }
        for (d = 0; d < 3; ++d) {
            vel[d] += accel[d]*sub_dt;
            pos[d] += vel[d]*sub_dt;
        }
    }
}

/* ------------------------------------------------------------------ */
/*  the whole frame                                                    */
/* ------------------------------------------------------------------ */

/*
 * mw          16      armature matrix_world, ROW major
 * bmat        nb*16   pose-bone matrices, COLUMN major -- exactly what
 *                     foreach_get("matrix") produces, so Python hands the
 *                     buffer straight over instead of paying for a
 *                     transposed copy of every bone every frame
 * brest       nb      rest bone lengths
 * bidx        ns      bone index per simulated bone, chain order root->tip
 * chain_off   nc+1    offsets into bidx
 * root_bidx   nc      bone index whose HEAD anchors each chain
 * prm         ns*PRM_N
 * P, V        (ns+nc)*3   persistent particle state, chain-major
 * prevT       ns*3        previous rigid target per joint
 * smoothq     ns*4        previous smoothed swing (HF damping state)
 * inited      nc          0 = seed this chain from its rest pose
 * wind        3, or NULL
 * qbuf        nb*4 float32, the RNA rotation_quaternion buffer: read AND written
 * outq        ns*4 raw local swing, for the frame cache / no-step replay
 * scratch     ns*(1+1+3+9) + (ns+nc)*3 doubles, caller-owned
 */
SFX_API void sfx_step(const double *mw, const double *bmat, const double *brest,
                      const int *bidx, const int *chain_off, const int *root_bidx,
                      int n_chains, int n_states,
                      const double *prm,
                      double *P, double *V, double *prevT, double *smoothq,
                      int *inited,
                      const double *gravity, const double *wind,
                      double dt, int sim_steps, int iters,
                      const double *spheres, int n_sph,
                      double cbounce, const double *cdamp, const double *cstiff,
                      float *qbuf, double *outq,
                      double *scratch,
                      /* --- clean-pose reconstruction (mode 1) --- */
                      int mode, int n_bones,
                      const double *offs, const double *bloc, const double *bscl,
                      const int *bparent,
                      float *lastw, double *prevsw, int *haveprev,
                      double *wpose, double *cleanq,
                      const double *opt)
{
    double *lengths = scratch;
    double *radii   = lengths + n_states;
    double *rdirs   = radii   + n_states;
    double *rframes = rdirs   + n_states*3;
    double *cdelta  = rframes + n_states*9;

    int coff[257], loff[257];
    int ci, i, d, s0, n, np = 0;
    double mw3[9];

    if (n_chains > 255 || n_chains < 1) return;

    mw3[0]=mw[0]; mw3[1]=mw[1]; mw3[2]=mw[2];
    mw3[3]=mw[4]; mw3[4]=mw[5]; mw3[5]=mw[6];
    mw3[6]=mw[8]; mw3[7]=mw[9]; mw3[8]=mw[10];

    /* ---- 0. pose matrices, row major -------------------------------- */
    /* foreach_get("matrix") hands back column-major; flip once here so the
     * rest of the function reads one layout. */
    {
        int b, r, c;
        for (b = 0; b < n_bones; ++b) {
            const double *S = bmat + (size_t)b*16;
            double *Dm = wpose + (size_t)b*16;
            for (r = 0; r < 4; ++r)
                for (c = 0; c < 4; ++c) Dm[r*4+c] = S[c*4+r];
        }
    }

    /* ---- 0b. MODE 1: rebuild the clean pose of every driven bone ------
     *
     * Without this the add-on has to restore the base pose from a
     * frame_change_pre handler so the depsgraph produces a clean pose_mat
     * to read. That restore is a foreach_set, and a foreach_set on the
     * rotation channel costs ~0.10 ms of Blender-side work per frame even
     * when it writes byte-identical values (measured). Reconstructing here
     * removes the write entirely.
     *
     * pose_mat[i] = pose_mat[parent] . offs_bone[i] . matrix_basis[i],
     * where offs_bone depends only on rest geometry and is captured once.
     * The parent of a chain root is never spring-driven, so its pose_mat
     * as read is already clean, and the chain is rebuilt from there.
     *
     * The clean rotation is recovered by dividing out the swing we applied
     * last frame -- but ONLY if the channel still holds exactly what we
     * wrote. If anything else (animation, a driver, the user) has touched
     * it, the live value IS the clean value and nothing is divided out.
     * That check is a bitwise float32 compare, so it cannot drift.
     */
    if (mode == 1) {
        for (ci = 0; ci < n_chains; ++ci) {
            const double *par;
            double acc[16], basis[16], tmp[16];
            int pb = bparent[root_bidx[ci]];
            s0 = chain_off[ci]; n = chain_off[ci+1] - s0;
            par = (pb >= 0) ? (wpose + (size_t)pb*16) : NULL;
            for (i = 0; i < n; ++i) {
                int b = bidx[s0+i], j = b*4, k;
                double lq[4], cq[4], cj[4];
                lq[0]=qbuf[j]; lq[1]=qbuf[j+1]; lq[2]=qbuf[j+2]; lq[3]=qbuf[j+3];
                if (haveprev[s0+i]
                        && lastw[(s0+i)*4+0] == qbuf[j+0]
                        && lastw[(s0+i)*4+1] == qbuf[j+1]
                        && lastw[(s0+i)*4+2] == qbuf[j+2]
                        && lastw[(s0+i)*4+3] == qbuf[j+3]) {
                    q_conj(prevsw + (size_t)(s0+i)*4, cj);
                    q_mul(lq, cj, cq);
                    q_norm(cq);
                } else {
                    for (k = 0; k < 4; ++k) cq[k] = lq[k];
                    q_norm(cq);
                }
                for (k = 0; k < 4; ++k) cleanq[(s0+i)*4+k] = cq[k];
                basis_from_trs(bloc + (size_t)b*3, cq, bscl + (size_t)b*3, basis);
                m4_mul(offs + (size_t)b*16, basis, tmp);
                if (par) m4_mul(par, tmp, acc);
                else     memcpy(acc, tmp, 16*sizeof(double));
                memcpy(wpose + (size_t)b*16, acc, 16*sizeof(double));
                par = wpose + (size_t)b*16;
            }
        }
    }

    /* ---- 1. world geometry from the clean pose ---------------------- */
    for (ci = 0; ci < n_chains; ++ci) {
        s0 = chain_off[ci]; n = chain_off[ci+1] - s0;
        coff[ci] = np; loff[ci] = s0;
        np += n + 1;
        for (i = 0; i < n; ++i) {
            const double *M = wpose + (size_t)bidx[s0+i]*16;
            double hp[3], tp[3], hw[3], tw[3], R[9], RW[9], L, ycol[3];
            hp[0]=M[3]; hp[1]=M[7]; hp[2]=M[11];       /* translation column */
            ycol[0]=M[1]; ycol[1]=M[5]; ycol[2]=M[9];  /* bone Y axis        */
            for (d = 0; d < 3; ++d) tp[d] = hp[d] + ycol[d]*brest[bidx[s0+i]];
            mat4_point(mw, hp, hw);
            mat4_point(mw, tp, tw);
            L = sqrt((tw[0]-hw[0])*(tw[0]-hw[0]) + (tw[1]-hw[1])*(tw[1]-hw[1])
                   + (tw[2]-hw[2])*(tw[2]-hw[2]));
            lengths[s0+i] = L;
            if (L > 1e-9) {
                rdirs[(s0+i)*3+0] = (tw[0]-hw[0])/L;
                rdirs[(s0+i)*3+1] = (tw[1]-hw[1])/L;
                rdirs[(s0+i)*3+2] = (tw[2]-hw[2])/L;
            } else {
                rdirs[(s0+i)*3+0] = 0.0; rdirs[(s0+i)*3+1] = 0.0;
                rdirs[(s0+i)*3+2] = 1.0;
            }
            radii[s0+i] = prm[(size_t)(s0+i)*PRM_N + PRM_RADIUS];
            R[0]=M[0]; R[1]=M[1]; R[2]=M[2];
            R[3]=M[4]; R[4]=M[5]; R[5]=M[6];
            R[6]=M[8]; R[7]=M[9]; R[8]=M[10];
            m3_mul(mw3, R, RW);
            m3_normalize_cols(RW);
            memcpy(rframes + (size_t)(s0+i)*9, RW, 9*sizeof(double));
        }
    }
    coff[n_chains] = np;
    loff[n_chains] = n_states;

    /* ---- 2. predict --------------------------------------------------- */
    for (ci = 0; ci < n_chains; ++ci) {
        const double *Mr = wpose + (size_t)root_bidx[ci]*16;
        double rh[3], P0[3];
        int p0 = coff[ci], seed;
        s0 = chain_off[ci]; n = chain_off[ci+1] - s0;
        rh[0]=Mr[3]; rh[1]=Mr[7]; rh[2]=Mr[11];
        mat4_point(mw, rh, P0);

        seed = !inited[ci];
        if (seed) {
            for (d = 0; d < 3; ++d) { P[p0*3+d] = P0[d]; V[p0*3+d] = 0.0; }
            for (i = 0; i < n; ++i)
                for (d = 0; d < 3; ++d) {
                    P[(p0+i+1)*3+d] = P[(p0+i)*3+d] + rdirs[(s0+i)*3+d]*lengths[s0+i];
                    V[(p0+i+1)*3+d] = 0.0;
                }
            inited[ci] = 1;
        }
        for (d = 0; d < 3; ++d) P[p0*3+d] = P0[d];      /* root is kinematic */

        for (i = 0; i < n; ++i) {
            const double *pr = prm + (size_t)(s0+i)*PRM_N;
            double eff, k_rot, grav[3], target[3], tp[3], tc[3];
            double *pos = P + (p0+i+1)*3;
            double *vel = V + (p0+i+1)*3;
            int j;
            eff = pr[PRM_STIFF] * length_mult(lengths[s0+i], pr[PRM_AUTOLEN]);
            if (eff < 0.0) eff = 0.0; else if (eff > 1.0) eff = 1.0;
            for (d = 0; d < 3; ++d)
                target[d] = P[(p0+i)*3+d] + rdirs[(s0+i)*3+d]*lengths[s0+i];
            /* First frame: the previous target IS this target, and it has to
             * be sampled HERE -- P[i] has already been advanced by this
             * frame's integration of the bone above, so seeding the whole
             * chain up front instead gave a 5.6 mm startup transient. */
            if (seed)
                for (d = 0; d < 3; ++d) prevT[(s0+i)*3+d] = target[d];
            k_rot = 40.0 + eff*500.0;
            grav[0] = gravity[0]*(pr[PRM_GRAV]*0.1);
            grav[1] = gravity[1]*(pr[PRM_GRAV]*0.1);
            grav[2] = gravity[2]*(pr[PRM_GRAV]*0.1) - k_rot*lengths[s0+i]*0.02;
            if (wind && pr[PRM_WIND] > 0.0)
                for (d = 0; d < 3; ++d) grav[d] += wind[d]*pr[PRM_WIND]*0.35;

            for (j = 0; j < sim_steps; ++j) {
                double fa = (double)j / (double)sim_steps;
                double fb = (double)(j+1) / (double)sim_steps;
                for (d = 0; d < 3; ++d) {
                    tp[d] = prevT[(s0+i)*3+d] + (target[d]-prevT[(s0+i)*3+d])*fa;
                    tc[d] = prevT[(s0+i)*3+d] + (target[d]-prevT[(s0+i)*3+d])*fb;
                }
                spring_point(pos, vel, tc, tp, eff, pr[PRM_DAMP], grav, dt,
                             pr[PRM_DRAG], opt);
            }
            for (d = 0; d < 3; ++d) prevT[(s0+i)*3+d] = target[d];
        }
    }

    /* ---- 3. constraint solve ------------------------------------------ */
    memset(cdelta, 0, (size_t)np*3*sizeof(double));
    sfx_solve(P, cdelta, coff, loff, n_chains, lengths, radii,
              spheres, n_sph, iters, cstiff);   /* per-chain array */

    /* ---- 4. contact velocity response ---------------------------------
     * A contact REMOVES the velocity going into the surface (optionally
     * returning some as restitution) and bleeds the rest. It never adds:
     * feeding the constraint correction back as velocity is positive
     * feedback, measured at 3.6x rest length within a few frames. Only the
     * collision delta is used, never the distance projection. */
    for (ci = 0; ci < n_chains; ++ci) {
        int p0 = coff[ci];
        n = chain_off[ci+1] - chain_off[ci];
        for (i = 1; i <= n; ++i) {
            double *dv = cdelta + (p0+i)*3;
            double *vv = V + (p0+i)*3;
            double l2 = dv[0]*dv[0] + dv[1]*dv[1] + dv[2]*dv[2], nn[3], vn;
            if (l2 < 1e-12) continue;
            l2 = sqrt(l2);
            nn[0]=dv[0]/l2; nn[1]=dv[1]/l2; nn[2]=dv[2]/l2;
            vn = vv[0]*nn[0] + vv[1]*nn[1] + vv[2]*nn[2];
            if (vn < 0.0)
                for (d = 0; d < 3; ++d) vv[d] -= nn[d]*(vn*(1.0+cbounce));
            for (d = 0; d < 3; ++d) vv[d] *= (1.0 - cdamp[ci]);
        }
    }

    /* ---- 5. swing quaternions, root -> tip ---------------------------- */
    for (ci = 0; ci < n_chains; ++ci) {
        int p0 = coff[ci];
        double F[9], Fn[9], Qm[9], Off[9], tmp[9];
        s0 = chain_off[ci]; n = chain_off[ci+1] - s0;
        memcpy(F, rframes + (size_t)s0*9, 9*sizeof(double));
        for (i = 0; i < n; ++i) {
            const double *pr = prm + (size_t)(s0+i)*PRM_N;
            double wdir[3], loc[3], q[4], bq[4], nq[4];
            int j = bidx[s0+i]*4;
            for (d = 0; d < 3; ++d)
                wdir[d] = P[(p0+i+1)*3+d] - P[(p0+i)*3+d];
            if (wdir[0]*wdir[0] + wdir[1]*wdir[1] + wdir[2]*wdir[2] < 1e-18) {
                outq[(s0+i)*4+0] = 1.0; outq[(s0+i)*4+1] = 0.0;
                outq[(s0+i)*4+2] = 0.0; outq[(s0+i)*4+3] = 0.0;
                continue;
            }
            v_norm(wdir);
            m3_Tmul_vec(F, wdir, loc);
            v_norm(loc);
            q_from_y_to(loc, q);

            if (fabs(pr[PRM_RANGE] - 1.0) > 1e-4) q_scale_angle(q, pr[PRM_RANGE]);
            if (pr[PRM_INFL] < 1.0) {
                double idq[4] = {1.0, 0.0, 0.0, 0.0}, o[4];
                q_slerp(idq, q, pr[PRM_INFL], o);
                memcpy(q, o, 4*sizeof(double));
            }
            if (pr[PRM_SMOOTH] > 0.0) {
                double *pq = smoothq + (size_t)(s0+i)*4, o[4];
                double a = 1.0 - 0.85*pr[PRM_SMOOTH];
                if (a < 0.1) a = 0.1;
                if (pq[0] != 0.0 || pq[1] != 0.0 || pq[2] != 0.0 || pq[3] != 0.0) {
                    q_slerp(pq, q, a, o);
                    memcpy(q, o, 4*sizeof(double));
                }
                memcpy(pq, q, 4*sizeof(double));
            }
            memcpy(outq + (size_t)(s0+i)*4, q, 4*sizeof(double));

            /* compose onto the clean pose, straight into the RNA buffer.
             * matrix_basis @ Q leaves the translation column untouched, so
             * this is exactly `pb.matrix = pb.matrix @ Q` without the setter
             * having to re-derive the basis from the parent chain. */
            if (mode == 1) {
                bq[0]=cleanq[(s0+i)*4+0]; bq[1]=cleanq[(s0+i)*4+1];
                bq[2]=cleanq[(s0+i)*4+2]; bq[3]=cleanq[(s0+i)*4+3];
            } else {
                bq[0]=qbuf[j]; bq[1]=qbuf[j+1]; bq[2]=qbuf[j+2]; bq[3]=qbuf[j+3];
            }
            q_mul(bq, q, nq);
            qbuf[j]   = (float)nq[0]; qbuf[j+1] = (float)nq[1];
            qbuf[j+2] = (float)nq[2]; qbuf[j+3] = (float)nq[3];
            if (mode == 1) {
                lastw[(s0+i)*4+0]=qbuf[j];   lastw[(s0+i)*4+1]=qbuf[j+1];
                lastw[(s0+i)*4+2]=qbuf[j+2]; lastw[(s0+i)*4+3]=qbuf[j+3];
                memcpy(prevsw + (size_t)(s0+i)*4, q, 4*sizeof(double));
                haveprev[s0+i] = 1;
            }

            /* Advance the bone frame ANALYTICALLY: this swing, then the
             * constant rest offset down to the next bone. Re-reading it from
             * RNA is not an option -- a pose write does not reach a child's
             * matrix until the depsgraph runs again, which cost up to 70
             * degrees of accumulated error at the chain tip. */
            q_to_m3(q, Qm);
            m3_mul(F, Qm, Fn);
            if (i + 1 < n) {
                m3_Tmul(rframes + (size_t)(s0+i)*9,
                        rframes + (size_t)(s0+i+1)*9, Off);
                m3_mul(Fn, Off, tmp);
                memcpy(F, tmp, 9*sizeof(double));
            }
        }
    }
}

/* ================================================================== */
/*  LOCATION SPRINGS                                                   */
/* ================================================================== */
/*
 * Before v8.0 a location spring needed two empties and a COPY_LOCATION
 * constraint per bone: three datablocks of scene footprint each, and a full
 * pass of Python per bone per frame. None of that is necessary. The rigid
 * target is just the bone's own clean world head, which is
 *
 *     A . clean_location      with   A = mw . parent_pose . offs_bone
 *
 * and the simulated result is written back through the same A, straight into
 * pose_bone.location. No helper objects, no constraint, nothing in the .blend.
 */

enum {
    LP_STIFF = 0, LP_DAMP, LP_SPEED, LP_GRAV, LP_INFL, LP_MAXD,
    LP_RANGE, LP_DRAG, LP_RADIUS, LP_CMARGIN, LP_CSTIFF, LP_CDAMP,
    LP_CFRIC, LP_N
};

static double speed_freq_mult(double stiff, double speed, double dt)
{
    double k_base, omega_base, desired, omega_cap, cap;
    if (speed <= 0.0) return 1.0;
    k_base = 40.0 + stiff * 500.0;
    omega_base = sqrt(k_base);
    desired = 1.0 + speed * 2.0;
    omega_cap = 1.0 / (dt > 1e-6 ? dt : 1e-6);
    cap = omega_cap / (omega_base > 1e-6 ? omega_base : 1e-6);
    if (cap < 1.0) cap = 1.0;
    return desired < cap ? desired : cap;
}

/* simulate_spring_point with the quality substep policy (the location path
 * uses the scene's Quality setting, unlike the chain solver which is fixed
 * at base 1 / target 0.30 / cap 8). */
static void spring_point_q(double *pos, double *vel,
                           const double *tgt, const double *tgt_prev,
                           double stiff, double damp, double speed,
                           const double *grav, double dt, double drag,
                           int ss_base, double ss_target, int ss_cap,
                           const double *opt)
{
    double k = 40.0 + stiff * 500.0;
    double fm = speed_freq_mult(stiff, speed, dt);
    double c, c_air, v_t[3], sub_dt, t_frac, tp[3], accel[3], omega;
    int substeps, j, d;
    k *= fm * fm;
    c = 2.0 * sqrt(k) * (0.15 + damp);
    if (opt && opt[0] > 0.5) {
        spring_point_exact(pos, vel, tgt, tgt_prev, k, c, dt, drag, grav);
        return;
    }
    c_air = drag * 12.0;
    if (dt > 1e-9) { for (d = 0; d < 3; ++d) v_t[d] = (tgt[d]-tgt_prev[d])/dt; }
    else           { v_t[0] = v_t[1] = v_t[2] = 0.0; }
    omega = sqrt(k);
    substeps = (int)(omega * dt / ss_target) + 1;
    if (substeps < ss_base) substeps = ss_base;
    if (substeps > ss_cap)  substeps = ss_cap;
    if (substeps < 1) substeps = 1;
    sub_dt = dt / substeps;
    for (j = 0; j < substeps; ++j) {
        t_frac = (double)(j + 1) / (double)substeps;
        for (d = 0; d < 3; ++d) {
            tp[d] = tgt_prev[d] + (tgt[d] - tgt_prev[d]) * t_frac;
            accel[d] = (tp[d]-pos[d])*k - (vel[d]-v_t[d])*c + grav[d];
            if (c_air > 0.0) accel[d] -= vel[d]*c_air;
        }
        for (d = 0; d < 3; ++d) { vel[d] += accel[d]*sub_dt; pos[d] += vel[d]*sub_dt; }
    }
}

/* Point vs spheres, matching the caps branch of _sb_collide_point for a
 * degenerate capsule: hard projection onto the surface scaled by the bone's
 * collision stiffness, then the velocity response (bounce on the normal,
 * friction on the tangent, hit damping on the whole vector). */
static void collide_point(double *pos, double *vel, double br, double margin,
                          double stiffness, double bounce, double friction,
                          double hit_damping, int iters,
                          const double *spheres, int n_sph, double fric_mult,
                          unsigned long long skip)
{
    double rad_extra = br + (margin > 0.0 ? margin : 0.0);
    int it, k, d;
    if (stiffness < 0.0) stiffness = 0.0; else if (stiffness > 1.0) stiffness = 1.0;
    if (friction < 0.0) friction = 0.0; else if (friction > 1.0) friction = 1.0;
    for (it = 0; it < (iters > 0 ? iters : 1); ++it) {
        int hit = 0;
        for (k = 0; k < n_sph; ++k) {
            double dx = pos[0]-spheres[k*4+0];
            double dy = pos[1]-spheres[k*4+1];
            double dz = pos[2]-spheres[k*4+2];
            double dist = sqrt(dx*dx + dy*dy + dz*dz);
            double rad = spheres[k*4+3] + rad_extra;
            double n[3], vn, vt[3];
            if (dist >= rad) continue;
            hit = 1;
            if (dist > 1e-6) { n[0]=dx/dist; n[1]=dy/dist; n[2]=dz/dist; }
            else             { n[0]=0.0; n[1]=0.0; n[2]=1.0; }
            for (d = 0; d < 3; ++d) pos[d] += n[d]*((rad-dist)*stiffness);
            vn = vel[0]*n[0] + vel[1]*n[1] + vel[2]*n[2];
            if (vn < 0.0) {
                for (d = 0; d < 3; ++d) vt[d] = vel[d] - n[d]*vn;
                for (d = 0; d < 3; ++d)
                    vel[d] = vt[d]*(1.0-friction) + n[d]*(-vn*bounce);
            }
            if (hit_damping > 0.0)
                for (d = 0; d < 3; ++d) vel[d] *= (1.0 - 0.5*hit_damping);
        }
        for (k = 0; k < g_n_mesh; ++k) {
            SfxMesh *M = &g_mesh[k];
            double rad = M->margin + rad_extra, lp[3], loc[3], wl[3], nw[3], dd[3];
            double ln, sg, pen, eb, ef, vn, vt[3];
            int tri;
            if (M->nt <= 0 || ((skip >> k) & 1ULL) || outside_bounds(pos, M, rad)) continue;
            mat4_point(M->mwi, pos, lp);
            tri = bvh_nearest(M, lp, loc);
            if (tri < 0) continue;
            mat4_point(M->mw, loc, wl);
            m3_vec(M->m3it, M->tn + (size_t)tri*3, nw);
            for (d = 0; d < 3; ++d) dd[d] = pos[d] - wl[d];
            ln = v_len(nw);
            if (ln > 1e-6) { nw[0] /= ln; nw[1] /= ln; nw[2] /= ln; }
            else {
                ln = v_len(dd);
                if (ln > 1e-6) { nw[0] = dd[0]/ln; nw[1] = dd[1]/ln; nw[2] = dd[2]/ln; }
                else           { nw[0] = 0.0; nw[1] = 0.0; nw[2] = 1.0; }
            }
            sg = dd[0]*nw[0] + dd[1]*nw[1] + dd[2]*nw[2];
            if (sg >= rad) continue;
            hit = 1;
            pen = rad - sg;
            eb = (M->bounce >= 0.0) ? M->bounce : bounce;
            if (M->friction >= 0.0) {
                ef = M->friction * fric_mult;
                if (ef < 0.0) ef = 0.0; else if (ef > 1.0) ef = 1.0;
            } else {
                ef = friction;
            }
            for (d = 0; d < 3; ++d) pos[d] += nw[d]*(pen*M->force*stiffness);
            vn = vel[0]*nw[0] + vel[1]*nw[1] + vel[2]*nw[2];
            if (vn < 0.0) {
                for (d = 0; d < 3; ++d) vt[d] = vel[d] - nw[d]*vn;
                for (d = 0; d < 3; ++d)
                    vel[d] = vt[d]*(1.0-ef) + nw[d]*(-vn*eb);
            }
            if (hit_damping > 0.0)
                for (d = 0; d < 3; ++d) vel[d] *= (1.0 - 0.5*hit_damping);
        }
        if (!hit) break;
    }
}

/* 3x3 inverse of the rotation/scale part of a row-major 4x4. */
static int m4_rot_inverse(const double *A, double *inv)
{
    double a=A[0], b=A[1], c=A[2], d=A[4], e=A[5], f=A[6], g=A[8], h=A[9], i=A[10];
    double det = a*(e*i - f*h) - b*(d*i - f*g) + c*(d*h - e*g);
    if (fabs(det) < 1e-14) return 0;
    det = 1.0/det;
    inv[0]=(e*i-f*h)*det; inv[1]=(c*h-b*i)*det; inv[2]=(b*f-c*e)*det;
    inv[3]=(f*g-d*i)*det; inv[4]=(a*i-c*g)*det; inv[5]=(c*d-a*f)*det;
    inv[6]=(d*h-e*g)*det; inv[7]=(b*g-a*h)*det; inv[8]=(a*e-b*d)*det;
    return 1;
}

/*
 * mw      16       armature world matrix, ROW major
 * ppose   n_loc*16 each bone's PARENT clean pose matrix, ROW major
 * offs    nb*16    constant rest offsets
 * lbidx   n_loc    bone index per location spring
 * lprm    n_loc*LP_N
 * lclean  n_loc*3  clean location channel (persistent)
 * lastw   n_loc*3  what we wrote last frame (float32, for the ownership test)
 * linited n_loc
 * P,V,prevT  n_loc*3 persistent simulation state
 * locbuf  nb*3 float32, the RNA location buffer: read AND written
 */
SFX_API void sfx_loc(const double *mw, const double *ppose, const double *offs,
                     const int *lbidx, int n_loc, const double *lprm,
                     double *lclean, float *lastw, int *linited,
                     double *P, double *V, double *prevT,
                     const double *gravity, const double *wind,
                     double dt, int sim_steps,
                     const double *spheres, int n_sph,
                     double cbounce, double cfriction, int citers,
                     int ss_base, double ss_target, int ss_cap,
                     float *locbuf, const double *opt)
{
    int i, d, j;
    for (i = 0; i < n_loc; ++i) {
        const double *pr = lprm + (size_t)i*LP_N;
        int b = lbidx[i];
        double A[16], MP[16], inv3[9];
        double cl[3], tgt[3], grav[3], out[3], loc[3], amp, dv[3], mag;
        double *pos = P + (size_t)i*3, *vel = V + (size_t)i*3;

        /* clean location channel: ours unless something else owns it now */
        for (d = 0; d < 3; ++d) {
            float live = locbuf[b*3+d];
            cl[d] = (linited[i] && live == lastw[i*3+d]) ? lclean[i*3+d] : (double)live;
            lclean[i*3+d] = cl[d];
        }

        /* A = mw . parent_pose . offs_bone   -- the bone's own frame */
        m4_mul(ppose + (size_t)i*16, offs + (size_t)b*16, MP);
        m4_mul(mw, MP, A);
        /* rigid world head = A . clean_location (the basis rotation does not
         * move the head, only the translation column does) */
        for (d = 0; d < 3; ++d)
            tgt[d] = A[d*4+0]*cl[0] + A[d*4+1]*cl[1] + A[d*4+2]*cl[2] + A[d*4+3];

        if (!linited[i]) {
            for (d = 0; d < 3; ++d) { pos[d]=tgt[d]; vel[d]=0.0; prevT[i*3+d]=tgt[d]; }
            linited[i] = 1;
        }

        grav[0]=gravity[0]*pr[LP_GRAV]; grav[1]=gravity[1]*pr[LP_GRAV];
        grav[2]=gravity[2]*pr[LP_GRAV];
        grav[2] -= pr[LP_GRAV];              /* slider is a downward force */
        if (wind) for (d = 0; d < 3; ++d) grav[d] += wind[d];

        amp = pr[LP_RANGE];
        if (amp < 1e-6) amp = 1e-6;
        for (j = 0; j < sim_steps; ++j) {
            double fa = (double)j/(double)sim_steps, fb = (double)(j+1)/(double)sim_steps;
            double tp[3], tc[3];
            for (d = 0; d < 3; ++d) {
                tp[d] = prevT[i*3+d] + (tgt[d]-prevT[i*3+d])*fa;
                tc[d] = prevT[i*3+d] + (tgt[d]-prevT[i*3+d])*fb;
            }
            spring_point_q(pos, vel, tc, tp, pr[LP_STIFF], pr[LP_DAMP],
                           pr[LP_SPEED], grav, dt, pr[LP_DRAG],
                           ss_base, ss_target, ss_cap, opt);
            if ((n_sph > 0 || g_n_mesh > 0) && pr[LP_RADIUS] >= 0.0) {
                /* resolve in VISUAL space, then map back, exactly as the
                 * Python path does -- Move Range must not feed the physics */
                double sp[3], sv[3];
                for (d = 0; d < 3; ++d) {
                    sp[d] = tgt[d] + (pos[d]-tgt[d])*amp;
                    sv[d] = vel[d]*amp;
                }
                collide_point(sp, sv, pr[LP_RADIUS], pr[LP_CMARGIN],
                              pr[LP_CSTIFF], cbounce, cfriction*pr[LP_CFRIC],
                              pr[LP_CDAMP], citers, spheres, n_sph, pr[LP_CFRIC],
                              (i < g_loc_skip_n) ? g_loc_skip[i] : 0ULL);
                for (d = 0; d < 3; ++d) {
                    pos[d] = tgt[d] + (sp[d]-tgt[d])/amp;
                    vel[d] = sv[d]/amp;
                }
            }
        }
        for (d = 0; d < 3; ++d) prevT[i*3+d] = tgt[d];

        /* influence blends back toward the rigid target */
        for (d = 0; d < 3; ++d)
            pos[d] = pos[d]*pr[LP_INFL] + tgt[d]*(1.0 - pr[LP_INFL]);
        /* visual output = amplitude-scaled deviation */
        for (d = 0; d < 3; ++d) out[d] = tgt[d] + (pos[d]-tgt[d])*amp;
        /* Max Distance clamp on the visual output */
        if (pr[LP_MAXD] != 0.0) {
            for (d = 0; d < 3; ++d) dv[d] = out[d]-tgt[d];
            mag = sqrt(dv[0]*dv[0]+dv[1]*dv[1]+dv[2]*dv[2]);
            if (mag > pr[LP_MAXD] && mag > 1e-12)
                for (d = 0; d < 3; ++d)
                    out[d] = tgt[d] + dv[d]*(pr[LP_MAXD]/mag);
        }

        /* world -> location channel:  loc = A3x3^-1 . (out - A.translation) */
        if (!m4_rot_inverse(A, inv3)) continue;
        for (d = 0; d < 3; ++d) dv[d] = out[d] - A[d*4+3];
        for (d = 0; d < 3; ++d)
            loc[d] = inv3[d*3+0]*dv[0] + inv3[d*3+1]*dv[1] + inv3[d*3+2]*dv[2];
        for (d = 0; d < 3; ++d) {
            locbuf[b*3+d] = (float)loc[d];
            lastw[i*3+d]  = locbuf[b*3+d];
        }
    }
}

SFX_API void sfx_reset(int *inited, int n_chains)
{
    int i;
    for (i = 0; i < n_chains; ++i) inited[i] = 0;
}

SFX_API int sfx_abi(void) { return 8; }
