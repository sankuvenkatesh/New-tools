# SpringFX — operators.py
# Every operator except the preset ones (presets.py): simulation setup,
# bake, groups, bulk apply, colliders, NLA, the post-bake noise F-modifier
# and the one-click smart converter for hair / clothing rigs.

import bpy
import os
import sys

from . import core, presets
from .core import (
    get_pose_bone, update_bone, _cleanup_bone_helpers,
    _get_action_fcurves, _bone_from_datapath, _copy_bone_fcurves,
)

# NOTE: Blender 5.0 moved pose-bone selection onto PoseBone.select; 4.x only
# exposes it on the underlying Bone. These helpers keep one code path for both.
def _pb_get_select(pb):
    if hasattr(pb, "select"):
        return pb.select
    return pb.bone.select


def _pb_set_select(pb, value):
    if hasattr(pb, "select"):
        pb.select = value
    else:
        pb.bone.select = value


# ================================================================== #
#  OPERATORS — simulation control
# ================================================================== #

class SB_OT_select_bone(bpy.types.Operator):
    """Select this bone in the viewport"""
    bl_idname = "sb.select_bone"
    bl_label = "select_bone"
    bone_name: bpy.props.StringProperty(default="")

    def execute(self, context):
        pbone = get_pose_bone(self.bone_name)
        if pbone is None:
            self.report({'WARNING'}, f"Bone '{self.bone_name}' not found.")
            return {'CANCELLED'}
        data_bone = pbone.bone
        bpy.context.active_object.data.bones.active = data_bone
        _pb_set_select(pbone, True)
        for bcoll in data_bone.collections:
            bcoll.is_visible = True
        return {'FINISHED'}


# ================================================================== #
#  F-CURVE NOISE MODIFIER  (post-bake secondary jitter)
#  Layers Blender's built-in Noise F-Modifier onto the baked location /
#  rotation channels — organic, NON-destructive jitter on top of a baked
#  spring, separately for location and rotation, with per-axis control.
#
#  Note on blend modes: the Noise modifier's 'REPLACE' blend actually adds
#  CENTERED noise (value + (noise-0.5)*strength), i.e. zero-mean jitter that
#  does NOT bias the animation — the natural choice for secondary motion.
# ================================================================== #

SB_NOISE_TAG = "SpringBonesNoise"   # FModifier.name we tag OUR modifiers with
_SB_NMOD_BUSY = False               # re-entrancy guard for live updates


def _sb_active_armature(context):
    ob = getattr(context, "active_object", None)
    if ob is not None and ob.type == 'ARMATURE':
        return ob
    return None


def _sb_selected_pose_bones(context):
    """Pose bones the user has selected on the active armature."""
    arm = _sb_active_armature(context)
    if arm is None:
        return []
    sel = getattr(context, "selected_pose_bones", None)
    if sel:
        return [pb for pb in sel if pb.id_data == arm]
    return []


def _sb_fcurve_index(context):
    """Build {(data_path, array_index): fcurve} for the active action.
    Returns (index_dict, fcurve_container) or (None, None)."""
    arm = _sb_active_armature(context)
    if arm is None:
        return None, None
    ad = arm.animation_data
    act = ad.action if ad else None
    if act is None:
        return None, None
    fcurves = _get_action_fcurves(act, ad)
    if fcurves is None:
        return None, None
    idx = {}
    for fc in fcurves:
        idx[(fc.data_path, fc.array_index)] = fc
    return idx, fcurves


def _sb_section_channels(pose_bone, kind):
    """Yield (data_path, array_index, axis_toggle_attr) for a section.

    kind 'LOC' -> location X/Y/Z.
    kind 'ROT' -> whichever rotation channel this bone actually evaluates
    (_SB_ROTMODE_PATCH_V1): quaternion W/X/Y/Z, axis-angle W/X/Y/Z, or Euler X/Y/Z.
    Hard-coding rotation_quaternion here put the noise modifiers on curves
    an Euler-mode bone never reads.
    """
    if kind == 'LOC':
        dp = pose_bone.path_from_id("location")
        yield (dp, 0, 'use_x')
        yield (dp, 1, 'use_y')
        yield (dp, 2, 'use_z')
        return
    mode = pose_bone.rotation_mode
    if mode == 'QUATERNION':
        dp = pose_bone.path_from_id("rotation_quaternion")
        yield (dp, 0, 'use_w')
        yield (dp, 1, 'use_x')
        yield (dp, 2, 'use_y')
        yield (dp, 3, 'use_z')
    elif mode == 'AXIS_ANGLE':
        dp = pose_bone.path_from_id("rotation_axis_angle")
        yield (dp, 0, 'use_w')          # angle
        yield (dp, 1, 'use_x')
        yield (dp, 2, 'use_y')
        yield (dp, 3, 'use_z')
    else:
        dp = pose_bone.path_from_id("rotation_euler")
        yield (dp, 0, 'use_x')
        yield (dp, 1, 'use_y')
        yield (dp, 2, 'use_z')


def _sb_remove_tagged(fcurve):
    """Remove all of OUR noise modifiers from a single fcurve."""
    n = 0
    for m in list(fcurve.modifiers):
        if getattr(m, "name", "") == SB_NOISE_TAG:
            fcurve.modifiers.remove(m)
            n += 1
    return n


def _sb_write_noise_params(nm, s, array_index):
    """Copy the UI settings `s` onto an FModifierNoise for one axis. The base
    phase is offset per-axis (by `variation`) so each channel gets a DIFFERENT
    noise pattern — otherwise every enabled axis moves in lockstep."""
    try:
        nm.name = SB_NOISE_TAG
    except Exception:
        pass
    nm.mute       = False
    nm.blend_type = s.blend_type
    nm.scale      = s.scale
    nm.strength   = s.strength
    nm.phase      = s.phase + array_index * s.variation
    nm.offset     = s.offset
    nm.depth      = s.depth
    # newer fractal-noise controls (harmless / ignored by the legacy generator)
    try:
        nm.use_legacy_noise = s.use_legacy_noise
        nm.lacunarity       = s.lacunarity
        nm.roughness        = s.roughness
    except Exception:
        pass
    # restricted frame range (values are stored even when the toggle is off)
    nm.use_restricted_range = s.use_restricted_range
    nm.frame_start          = s.frame_start
    nm.frame_end            = s.frame_end
    nm.blend_in             = s.blend_in
    nm.blend_out            = s.blend_out
    # influence
    nm.use_influence = s.use_influence
    nm.influence     = s.influence


def _sb_apply_section(context, kind):
    """Clear our old noise mods for one section on the SELECTED bones, then
    (re)add fresh ones per the current enable / axis / parameter settings.
    Returns (curves_added, bones_touched)."""
    idx, _ = _sb_fcurve_index(context)
    if idx is None:
        return 0, 0
    scn = context.scene
    s = scn.sb_nmod_loc if kind == 'LOC' else scn.sb_nmod_rot
    added = 0
    touched = set()
    for pb in _sb_selected_pose_bones(context):
        for dp, ai, axis_attr in _sb_section_channels(pb, kind):
            fc = idx.get((dp, ai))
            if fc is None:
                continue
            _sb_remove_tagged(fc)          # always clear our previous mod first
            if not s.enable or not getattr(s, axis_attr):
                fc.update()
                continue
            nm = fc.modifiers.new(type='NOISE')
            _sb_write_noise_params(nm, s, ai)
            fc.update()
            added += 1
            touched.add(pb.name)
    arm = _sb_active_armature(context)
    if arm is not None:
        try:
            arm.update_tag()
        except Exception:
            pass
    return added, len(touched)


def _sb_remove_section(context, kind):
    """Strip our noise mods for one section on the selected bones."""
    idx, _ = _sb_fcurve_index(context)
    if idx is None:
        return 0
    removed = 0
    for pb in _sb_selected_pose_bones(context):
        for dp, ai, _axis in _sb_section_channels(pb, kind):
            fc = idx.get((dp, ai))
            if fc is not None:
                removed += _sb_remove_tagged(fc)
                fc.update()
    arm = _sb_active_armature(context)
    if arm is not None:
        try:
            arm.update_tag()
        except Exception:
            pass
    return removed


def _nmod_update(self, context):
    """Live-update callback: when 'Live tweak' is on, editing any parameter
    immediately re-applies that section to the currently selected bones."""
    global _SB_NMOD_BUSY
    scn = getattr(context, "scene", None)
    if scn is None or not getattr(scn, "sb_nmod_live", False):
        return
    if _SB_NMOD_BUSY:
        return
    try:
        _SB_NMOD_BUSY = True
        p = self.as_pointer()
        if p == scn.sb_nmod_loc.as_pointer():
            _sb_apply_section(context, 'LOC')
        elif p == scn.sb_nmod_rot.as_pointer():
            _sb_apply_section(context, 'ROT')
    except Exception:
        pass
    finally:
        _SB_NMOD_BUSY = False


class SB_OT_noise_mod_apply(bpy.types.Operator):
    """Add (or refresh) the Noise F-Modifier on the selected bones' baked
    location / rotation curves, using the parameters below"""
    bl_idname = "sb.noise_mod_apply"
    bl_label = "Apply / Refresh Noise"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and _sb_active_armature(context) is not None

    def execute(self, context):
        scn = context.scene
        if not _sb_selected_pose_bones(context):
            self.report({'WARNING'}, "Select the baked bones first (in Pose mode).")
            return {'CANCELLED'}
        arm = _sb_active_armature(context)
        ad = arm.animation_data
        if ad is None or ad.action is None:
            self.report({'WARNING'},
                        "This armature has no baked action/keyframes yet. Bake first.")
            return {'CANCELLED'}
        a_add, _ = _sb_apply_section(context, 'LOC')
        b_add, _ = _sb_apply_section(context, 'ROT')
        total = a_add + b_add
        if total == 0:
            if not scn.sb_nmod_loc.enable and not scn.sb_nmod_rot.enable:
                self.report({'WARNING'}, "Enable Location and/or Rotation noise first.")
            else:
                self.report({'WARNING'},
                            "No matching baked curves on the selected bones "
                            "(were those channels baked?).")
            return {'CANCELLED'}
        self.report({'INFO'},
                    f"Noise applied to {total} curve(s) on "
                    f"{len(_sb_selected_pose_bones(context))} selected bone(s).")
        return {'FINISHED'}


class SB_OT_noise_mod_remove(bpy.types.Operator):
    """Remove the Spring Bones noise modifier from the selected bones'
    location / rotation curves"""
    bl_idname = "sb.noise_mod_remove"
    bl_label = "Remove Noise"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and _sb_active_armature(context) is not None

    def execute(self, context):
        removed = _sb_remove_section(context, 'LOC') + _sb_remove_section(context, 'ROT')
        self.report({'INFO'}, f"Removed {removed} noise modifier(s).")
        return {'FINISHED'}


# ================================================================== #
#  OPERATOR — bake
# ================================================================== #

class SB_OT_bake(bpy.types.Operator):
    """Bake the spring simulation into keyframes for all active spring/rotation
    bones, then remove the spring setup so only pure keyframes remain"""
    bl_idname = "sb.bake"
    bl_label = "Bake Spring to Keyframes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'POSE'
                and context.active_object is not None
                and context.active_object.type == 'ARMATURE')

    def execute(self, context):
        # Bake mode pins the sim to Render Quality and disables every
        # viewport-only shortcut (update rate, hidden/far skipping) so the
        # baked result is deterministic and full quality no matter what the
        # viewport performance settings say.
        core.set_bake_mode(True)
        try:
            return self._execute(context)
        finally:
            core.set_bake_mode(False)

    def _execute(self, context):
        scene = context.scene
        armature = context.active_object
        frame_start = scene.frame_start
        frame_end = scene.frame_end

        # collect bones that have a spring effect active
        update_bone(self, context)
        target_names = []
        any_loc = False
        any_rot = False
        for item in scene.sb_spring_bones:
            if item.sb_bone_collider:
                continue
            pb = armature.pose.bones.get(item.name)
            if pb is None:
                continue
            if pb.sb_bone_spring_loc or pb.sb_bone_spring_rot:
                # v8.0.2: the bake used to force rotation_mode = 'QUATERNION'
                # here, because the realtime solver could only write that one
                # channel. That flip silently discarded whatever pose sat in
                # the bone's Euler channel, and it was also the reason a
                # Rotation-Only setup appeared to "only work after baking".
                # The solver is rotation-mode aware now and bake_action keys
                # visual transforms into whatever channel the bone uses, so
                # the bone's mode is left exactly as the rigger set it.
                target_names.append(item.name)
                any_loc = any_loc or pb.sb_bone_spring_loc
                any_rot = any_rot or pb.sb_bone_spring_rot

        if not target_names:
            self.report({'WARNING'}, "No bones with an active spring effect to bake.")
            for item in scene.sb_spring_bones:
                _cleanup_bone_helpers(item.name, armature)
            return {'CANCELLED'}

        original_frame = scene.frame_current

        # NOTE: 8.4.3 -- the static pose of the baked channels, captured
        # before the bake runs, is what they return to outside the bake range
        # when nothing else animates them.
        rest_channels = core._sb_bake_rest_channels(scene, armature, target_names)

        # Reset sim state and snap empties to rest at the start frame.
        scene.frame_set(frame_start)
        context.view_layer.update()
        for item in scene.sb_spring_bones:
            if item.sb_bone_collider:
                continue
            owner = core._sb_armature_of(item)
            pb = owner.pose.bones.get(item.name) if owner else None
            emp_head, emp_tail = core._sb_loc_helpers(pb, owner) if pb else (None, None)
            if emp_head is not None and emp_tail is not None:
                tl, _r, _s = emp_tail.matrix_world.decompose()
                emp_head.location = tl
            # NOTE: 8.4.2 -- solver state lives in core's module dicts now.
            k = core._sb_state_key(item)
            core._sb_loc_vel.pop(k, None)
            core._sb_loc_raw.pop(k, None)
            core._sb_rot_sim.pop(k, None)
        context.view_layer.update()

        # The always-on frame handlers run the simulation as the baker steps
        # through frames. nla.bake's operator is broken in Blender 5.x (it
        # uses the removed Bone.select), so we call the underlying
        # anim_utils.bake_action directly with visual keying instead.

        # ── PRE-ROLL ────────────────────────────────────────────────────
        # Simulate the animation N extra frames BEFORE the bake starts so
        # the spring reaches a steady periodic state instead of starting
        # cold with a visible settling artifact.
        n_preroll = scene.sb_preroll_frames if scene.sb_preroll_enable else 0
        if n_preroll > 0:
            anim_len = max(frame_end - frame_start + 1, 1)
            core.reset_transient_state()
            for _pr in range(n_preroll):
                _pf = frame_start + (_pr % anim_len)
                scene.frame_set(_pf)
                context.view_layer.update()
            # after pre-roll, reset the catchup counter (but KEEP the warm
            # sim state in the bones) ready for the actual bake pass
            core._sb_sim_last_frame = None
            core._sb_prev_target.clear()
            core._sb_prev_rot_target.clear()
            scene.frame_set(frame_start)
            context.view_layer.update()
            self.report({'INFO'}, f"Pre-roll: simulated {n_preroll} warm-up frame(s).")
        # ────────────────────────────────────────────────────────────────

        # Keep a reference to the ORIGINAL action + slot so we can write the
        # baked spring motion back into it for ONLY the spring bones, leaving
        # the rest of the walk/jump animation untouched.
        ad = armature.animation_data
        orig_action = ad.action if ad else None
        # NOTE: action slots only exist from Blender 4.4.
        orig_slot = getattr(ad, "action_slot", None) if ad else None

        # CRITICAL: select ONLY the spring bones and bake with
        # only_selected=True. Baking everything evaluates and keys EVERY
        # bone, which on rigs with drivers/IK/constraints (e.g. Daz/Genesis)
        # corrupts the rest pose. PoseBone.select (NOT Bone.select, removed
        # in 5.x) is the correct selection API.
        prev_sel = {pb.name: _pb_get_select(pb) for pb in armature.pose.bones}
        prev_active_bone = armature.data.bones.active
        for pb in armature.pose.bones:
            _pb_set_select(pb, pb.name in target_names)
        first_target = armature.data.bones.get(target_names[0]) if target_names else None
        if first_target is not None:
            armature.data.bones.active = first_target

        baked_ok = False
        temp_action = None
        try:
            from bpy_extras import anim_utils

            # Bake into a NEW temporary action (action=None) so we don't
            # disturb the original.
            try:
                opts = anim_utils.BakeOptions(
                    only_selected=True,
                    do_pose=True,
                    do_object=False,
                    do_visual_keying=True,
                    do_constraint_clear=False,
                    do_parents_clear=False,
                    do_clean=False,
                    do_location=any_loc,
                    do_rotation=any_rot,
                    do_scale=False,
                    do_bbone=False,
                    do_custom_props=False,
                )
                temp_action = anim_utils.bake_action(
                    armature, action=None,
                    frames=range(frame_start, frame_end + 1),
                    bake_options=opts,
                )
            except (AttributeError, TypeError):
                temp_action = anim_utils.bake_action(
                    armature, action=None,
                    frames=range(frame_start, frame_end + 1),
                    only_selected=True, do_pose=True, do_object=False,
                    do_visual_keying=True,
                )

            # bake_action may return the action or assign it to the object.
            if temp_action is None and ad:
                temp_action = ad.action

            # NOTE: 8.4.3 -- the baked channels replace ONLY the bake range.
            # Keyframes and NLA animation outside it are left playing exactly
            # as before (see core._sb_place_baked_fcurves).
            if temp_action is not None and temp_action != orig_action:
                if orig_action is not None:
                    ad.action = orig_action
                    if orig_slot is not None:
                        try:
                            if hasattr(ad, "action_slot"):
                                ad.action_slot = orig_slot
                        except Exception:
                            pass
                core._sb_place_baked_fcurves(
                    armature, temp_action, orig_action, set(target_names),
                    any_loc, any_rot, frame_start, frame_end, rest_channels)
            baked_ok = True
        except Exception as e:
            self.report({'ERROR'}, f"Bake failed: {e}")
            if ad and orig_action is not None:
                ad.action = orig_action
                if orig_slot is not None:
                    try:
                        if hasattr(ad, "action_slot"):
                            ad.action_slot = orig_slot
                    except Exception:
                        pass
        finally:
            # restore the original bone selection + active bone
            for pb in armature.pose.bones:
                if pb.name in prev_sel:
                    _pb_set_select(pb, prev_sel[pb.name])
            armature.data.bones.active = prev_active_bone

        # Remove the spring helpers (empties + constraints).
        for item in scene.sb_spring_bones:
            _cleanup_bone_helpers(item.name, armature)

        # The baked keys were captured with VISUAL keying, so they already
        # contain the effect of every other constraint on these bones (e.g.
        # a Transformation constraint following the thigh). Those constraints
        # must stop evaluating after the bake, or they would apply AGAIN on
        # top of the baked keys and double the offset. Muting (not removing)
        # keeps them recoverable if the user wants the live setup back.
        if baked_ok and scene.sb_bake_mute_constraints:
            muted = 0
            for _bn in target_names:
                _pb = armature.pose.bones.get(_bn)
                if _pb:
                    for _c in _pb.constraints:
                        if not _c.mute:
                            _c.mute = True
                            muted += 1
            if muted:
                self.report({'INFO'},
                            f"Muted {muted} pre-existing constraint(s) on the "
                            f"baked bones (their effect is now keyframed).")

        # ALWAYS-ON simulation: the baked bones must stop simulating, or the
        # spring would immediately run on top of the baked keyframes.
        core.set_update_suspended(True)
        try:
            for _bn in target_names:
                _pb = armature.pose.bones.get(_bn)
                if _pb:
                    _pb.sb_bone_spring_loc = False
                    _pb.sb_bone_spring_rot = False
        finally:
            core.set_update_suspended(False)

        # NOTE: (v8.2) groups of baked bones are removed -- the physics now
        # lives in keyframes and the group would only clutter the list.
        if baked_ok:
            _removed = _sb_drop_groups_after_bake(scene, armature, target_names)
            if _removed:
                self.report({'INFO'},
                            "Removed baked group(s): " + ", ".join(_removed))
        update_bone(self, context)
        if baked_ok:
            core._sb_purge_orphan_helpers()

        scene.frame_set(original_frame)

        if baked_ok:
            self.report({'INFO'},
                        f"Baked {len(target_names)} bone(s) from frame "
                        f"{frame_start} to {frame_end}.")
            return {'FINISHED'}
        return {'CANCELLED'}


# ================================================================== #
#  OPERATORS — collision setup
# ================================================================== #

class SB_OT_setup_bone_colliders(bpy.types.Operator):
    """Mark all selected pose bones as Spring Bones bone-colliders (capsules).
    Radius is auto-set to half the bone length so it wraps the bone nicely;
    you can fine-tune it afterwards in the Active Bone panel."""
    bl_idname  = "sb.setup_bone_colliders"
    bl_label   = "Mark Selected as Colliders"
    bl_options = {'REGISTER', 'UNDO'}

    radius_mult: bpy.props.FloatProperty(
        name="Radius Multiplier", default=0.5, min=0.05, max=2.0,
        description="Auto-radius = bone length × this value")
    hardness: bpy.props.FloatProperty(
        name="Hardness", default=1.0, min=0.0, max=1.0,
        description="1 = solid, lower = softer contact")

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and bool(context.selected_pose_bones)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        n = 0
        for pb in context.selected_pose_bones:
            pb.sb_bone_collider = True
            pb.sb_bone_spring_loc = False
            pb.sb_bone_spring_rot = False
            pb.sb_collider_dist  = max(pb.bone.length * self.radius_mult, 0.01)
            pb.sb_collider_force = self.hardness
            n += 1
        # refresh the spring bones list so the new colliders appear
        update_bone(self, context)
        self.report({'INFO'}, f"Marked {n} bone(s) as colliders.")
        return {'FINISHED'}


class SB_OT_remove_bone_colliders(bpy.types.Operator):
    """Remove the collider flag from all selected pose bones."""
    bl_idname  = "sb.remove_bone_colliders"
    bl_label   = "Remove Collider Flag"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and bool(context.selected_pose_bones)

    def execute(self, context):
        n = 0
        for pb in context.selected_pose_bones:
            if pb.sb_bone_collider:
                pb.sb_bone_collider = False
                n += 1
        update_bone(self, context)
        self.report({'INFO'}, f"Removed collider flag from {n} bone(s).")
        return {'FINISHED'}


# ================================================================== #
#  OPERATORS — NLA
# ================================================================== #

class SB_OT_action_to_nla(bpy.types.Operator):
    """Push the active armature's current action as an NLA strip, then clear
    the active action so you can layer new animation on top."""
    bl_idname  = "sb.action_to_nla"
    bl_label   = "Push Action to NLA"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == 'ARMATURE'
                and obj.animation_data is not None
                and obj.animation_data.action is not None)

    def execute(self, context):
        obj = context.active_object
        ad  = obj.animation_data
        action = ad.action
        scene  = context.scene

        # Determine the strip start frame from the action's keyframe range.
        try:
            fc_list = _get_action_fcurves(action, ad)
            all_f = [kp.co[0] for fc in (fc_list or []) for kp in fc.keyframe_points]
            strip_start = int(min(all_f)) if all_f else scene.frame_start
        except Exception:
            strip_start = scene.frame_start

        # Create a dedicated NLA track and add the action as a strip.
        try:
            track = ad.nla_tracks.new()
            track.name = action.name
            strip = track.strips.new(action.name, strip_start, action)
            strip.action_frame_start = action.frame_range[0]
            strip.action_frame_end   = action.frame_range[1]
        except Exception as e:
            self.report({'ERROR'}, f"Could not create NLA strip: {e}")
            return {'CANCELLED'}

        # Clear the stacked action so the NLA drives the object from now on.
        ad.action = None
        try:
            ad.use_nla = True
        except Exception:
            pass

        self.report({'INFO'},
                    f"Pushed '{action.name}' to NLA track '{track.name}'. "
                    "Active action cleared — NLA is now in control.")
        return {'FINISHED'}


# ================================================================== #
#  OPERATORS — bulk enable + automatic grouping
# ================================================================== #

def _unique_group_name(scene, base="Group"):
    existing = {g.name for g in scene.sb_bone_groups}
    if base not in existing:
        return base
    idx = 1
    name = f"{base}.{idx:03d}"
    while name in existing:
        idx += 1
        name = f"{base}.{idx:03d}"
    return name


class SB_OT_add_effect_group(bpy.types.Operator):
    """Add the chosen spring effect to all selected bones, then create a
    new group containing exactly those bones"""
    bl_idname = "sb.add_effect_group"
    bl_label = "Add Effect + Create Group"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.EnumProperty(
        name="Preset",
        items=presets._preset_enum_items,
        description="Start from a preset. The preset decides which spring(s) "
                    "get enabled -- Hair and Cloth are rotation-only, the body "
                    "presets drive both")
    effect: bpy.props.EnumProperty(
        name="Effect",
        items=(('LOC',  "Location Only", "Enable the location spring"),
               ('ROT',  "Rotation Only", "Enable the rotation spring"),
               ('BOTH', "Location + Rotation", "Enable both springs")),
        default='BOTH')
    make_group: bpy.props.BoolProperty(
        name="Create Group", default=True,
        description="Create a group containing the affected bones")

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and context.selected_pose_bones

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "preset")
        eff = self._preset_effect(context)
        row = layout.row()
        # presetfx: with a preset chosen the effect is the preset's business,
        # so show what it will do rather than offering a contradictory choice.
        row.enabled = eff is None
        row.prop(self, "effect")
        if eff is not None:
            layout.label(
                text="Preset enables: "
                     + (" + ".join(eff) if eff else "nothing"),
                icon='CHECKMARK')
        layout.prop(self, "make_group")
        n = len(context.selected_pose_bones or [])
        layout.label(text=f"{n} bone(s) selected", icon='BONE_DATA')

    def _preset_effect(self, context):
        """Effects the chosen preset declares, or None if none chosen."""
        if not self.preset or self.preset == 'NONE':
            return None
        return presets.preset_effects(context.scene, self.preset)

    def execute(self, context):
        scene = context.scene
        sel = context.selected_pose_bones or []
        if not sel:
            self.report({'WARNING'}, "No bones selected.")
            return {'CANCELLED'}

        # presetfx: the preset, when one is picked, decides the effects.
        pre_eff = self._preset_effect(context)
        if pre_eff is not None:
            set_loc, set_rot = ('LOC' in pre_eff), ('ROT' in pre_eff)
        else:
            set_loc = self.effect in ('LOC', 'BOTH')
            set_rot = self.effect in ('ROT', 'BOTH')

        msg = f"Applied {'+'.join(pre_eff) if pre_eff else self.effect} to {len(sel)} bone(s)"

        if self.make_group:
            name = _unique_group_name(scene, "Group")
            grp = scene.sb_bone_groups.add()
            grp.name = name
            for pb in sel:
                pb.sb_group = name
            scene.sb_active_group_index = len(scene.sb_bone_groups) - 1
            # Setting the group toggles propagates the effect to all members
            # via their update callbacks, so we don't set the bones directly.
            grp.enable_loc = set_loc
            grp.enable_rot = set_rot
            if self.preset and self.preset != 'NONE':
                # goes through the enum's update path, exactly like picking
                # the preset by hand in the group panel
                grp.preset = self.preset
                msg += f"; preset {self.preset.split('::')[-1]}"
            msg += f"; created group '{name}'"
        else:
            values = None
            if self.preset and self.preset != 'NONE':
                values = presets.preset_values_from_id(context.scene, self.preset)
            for pb in sel:
                pb.sb_bone_spring_loc = set_loc
                pb.sb_bone_spring_rot = set_rot
                if values:
                    # no group to hold them: write the preset onto each bone
                    presets._apply_preset_values(pb, values)

        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SB_OT_enable_selected(bpy.types.Operator):
    """Enable/disable a spring effect on ALL selected bones at once"""
    bl_idname = "sb.enable_selected"
    bl_label = "Apply to Selected Bones"
    bl_options = {'REGISTER', 'UNDO'}

    effect: bpy.props.EnumProperty(
        items=(('LOC', "Location", ""), ('ROT', "Rotation", ""), ('COLLIDER', "Collider", "")),
        default='LOC')
    enable: bpy.props.BoolProperty(default=True)

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and context.selected_pose_bones

    def execute(self, context):
        attr = {'LOC': 'sb_bone_spring_loc',
                'ROT': 'sb_bone_spring_rot',
                'COLLIDER': 'sb_bone_collider'}[self.effect]
        n = 0
        for pb in context.selected_pose_bones:
            setattr(pb, attr, self.enable)
            n += 1
        self.report({'INFO'}, f"{attr} set to {self.enable} on {n} bone(s)")
        return {'FINISHED'}


# ================================================================== #
#  OPERATOR — smart one-click conversion (hair / clothing detection)
# ================================================================== #

# Keyword tables for rig-type detection. Checked lowercase, substring match.
# English + Spanish so Daz, MetaHuman, Genesis and home-grown rigs all work.
# NOTE: bone-name keywords for Smart Convert's auto-detection, in English and
# Spanish, because rigs exported from Spanish tools name their bones that
# way. They are matched against bone names only; they are not UI text.
_SB_KW_HAIR = (
    'hair', 'pelo', 'cabello', 'strand', 'mechon', 'mecho',
    'pony', 'coleta', 'braid', 'trenza', 'bang', 'fringe', 'flequillo',
    'sideburn', 'patilla', 'curl', 'rizo', 'lock',
)
_SB_KW_PONYTAIL = ('pony', 'coleta', 'braid', 'trenza')
_SB_KW_BANGS    = ('bang', 'fringe', 'flequillo')
_SB_KW_CLOTH = (
    'cloth', 'skirt', 'falda', 'cape', 'capa', 'cloak', 'manto',
    'coat', 'jacket', 'chaqueta', 'abrigo', 'dress', 'vestido',
    'pant', 'pantalon', 'sleeve', 'manga', 'ribbon', 'lazo', 'cinta',
    'scarf', 'bufanda', 'shirt', 'camisa', 'camiseta', 'tie', 'corbata',
    'belt', 'cinturon', 'strap', 'correa', 'tassel', 'fleco',
)
_SB_KW_CLOTH_MAP = (
    (('skirt', 'falda'),                    "Cloth - Skirt"),
    (('cape', 'capa', 'cloak', 'manto'),    "Cloth - Cape"),
    (('jacket', 'chaqueta', 'coat', 'abrigo'), "Cloth - Jacket"),
    (('dress', 'vestido'),                  "Cloth - Dress"),
    (('pant', 'pantalon'),                  "Cloth - Pants"),
)
_SB_KW_BREAST = ('breast', 'boob', 'pecho', 'pectoral', 'chest_l', 'chest_r')
_SB_KW_GLUTE  = ('glute', 'butt', 'gluteo', 'nalga', 'hip_jiggle')
_SB_KW_TAIL   = ('tail', 'cola')
_SB_KW_EAR    = ('ear_', 'oreja')


def _sb_classify_bone(name):
    """Return a rig-type tag for a bone name, or None if it doesn't look
    like a secondary-motion bone at all."""
    n = name.lower()
    for kw in _SB_KW_BREAST:
        if kw in n:
            return 'BREAST'
    for kw in _SB_KW_GLUTE:
        if kw in n:
            return 'GLUTE'
    for kw in _SB_KW_HAIR:
        if kw in n:
            return 'HAIR'
    for kw in _SB_KW_CLOTH:
        if kw in n:
            return 'CLOTH'
    for kw in _SB_KW_TAIL:
        if kw in n:
            return 'TAIL'
    for kw in _SB_KW_EAR:
        if kw in n:
            return 'EAR'
    return None


def _sb_pick_preset(kind, names, chain_len):
    """Choose the best built-in preset for a detected cluster."""
    joined = " ".join(n.lower() for n in names)
    if kind == 'BREAST':
        return "Breast", ('LOC', 'ROT')
    if kind == 'GLUTE':
        return "Glute", ('LOC', 'ROT')
    if kind == 'HAIR':
        # presetfx: one Hair preset now -- ponytail/bangs/length variants were
        # collapsed into it, so the chain-length branching is gone.
        return "Hair", ('ROT',)
    if kind == 'CLOTH':
        for kws, preset in _SB_KW_CLOTH_MAP:
            if any(kw in joined for kw in kws):
                return preset, ('ROT',)
        return "Cloth - Shirt", ('ROT',)
    if kind == 'TAIL':
        return "Hair", ('ROT',)
    if kind == 'EAR':
        return "Hair", ('ROT',)
    return "Hair", ('ROT',)


# NOTE: readable name per detected bone type, so each group is recognisable
# in the list without renaming it by hand.
_SB_AUTO_NAMES = {
    'BREAST': "Breast", 'GLUTE': "Glute", 'HAIR': "Hair",
    'CLOTH': "Cloth", 'TAIL': "Tail", 'EAR': "Ears",
}


def _sb_auto_group_name(scene, bones):
    """Derive a name for the new group from the selected bones (the most
    common keyword, otherwise their shared prefix)."""
    tags = {}
    for pb in bones:
        kind = _sb_classify_bone(pb.name)
        if kind:
            tags[kind] = tags.get(kind, 0) + 1
    if tags:
        base = _SB_AUTO_NAMES.get(max(tags, key=tags.get), "Physics")
    else:
        prefix = os.path.commonprefix([pb.name for pb in bones])
        prefix = prefix.strip(" _-.:0123456789")
        base = (prefix[:1].upper() + prefix[1:]) if len(prefix) >= 3 else "Physics"
    return _unique_group_name(scene, base)


class SB_OT_add_physics(bpy.types.Operator):
    """Add SpringFX physics with the default settings (location + rotation
    springs) to the selected bones and put them in a new, renameable group"""
    bl_idname = "sb.add_physics"
    bl_label = "Add Physics"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'POSE'
                and context.active_object is not None
                and context.active_object.type == 'ARMATURE'
                and bool(context.selected_pose_bones))

    def execute(self, context):
        scene = context.scene
        sel = list(context.selected_pose_bones or [])
        if not sel:
            self.report({'WARNING'}, "No bones selected.")
            return {'CANCELLED'}

        name = _sb_auto_group_name(scene, sel)
        grp = scene.sb_bone_groups.add()
        grp.name = name
        grp.drive_params = True
        # NOTE: a bone already in another group is MOVED to the new one -- the
        # enum holds a single group per bone, so it cannot stay in both.
        with core.sb_bulk():
            for pb in sel:
                pb.sb_group = name
        scene.sb_active_group_index = len(scene.sb_bone_groups) - 1

        # NOTE: the add-on's default physics is both springs; the group toggles
        # push the effect to the members through their update callbacks.
        grp.enable_loc = True
        grp.enable_rot = True
        grp.collide = True
        self.report({'INFO'},
                    f"Physics added to {len(sel)} bone(s) — group '{name}'")
        return {'FINISHED'}


class SB_OT_smart_convert(bpy.types.Operator):
    """Convert bones to spring bones in ONE click.
    With bones selected: converts the selection.
    With nothing selected: scans the whole armature and auto-detects hair,
    clothing, breast/glute and tail bones by name.
    Detected chains are clustered per root, put into a group and given the
    best-matching preset (hair length, skirt vs cape, etc.)"""
    bl_idname = "sb.smart_convert"
    bl_label = "Convert to Spring Bones"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'POSE'
                and context.active_object is not None
                and context.active_object.type == 'ARMATURE')

    def execute(self, context):
        scene = context.scene
        arm = context.active_object

        # Only the ACTIVE armature's selection counts — selected_pose_bones
        # can contain bones from other armatures sharing pose mode.
        sel = [pb for pb in (context.selected_pose_bones or [])
               if pb.id_data == arm]
        if sel:
            candidates = {pb.name: pb for pb in sel}
            selection_mode = True
        else:
            candidates = {pb.name: pb
                          for pb in arm.pose.bones
                          if _sb_classify_bone(pb.name) is not None}
            selection_mode = False

        if not candidates:
            self.report({'WARNING'},
                        "Nothing to convert: select bones, or use recognizable "
                        "names (hair, skirt, cape, breast, tail…).")
            return {'CANCELLED'}

        # ---- cluster into chains: a bone whose parent is also a candidate
        # belongs to its parent's cluster; otherwise it starts a new one.
        cluster_of = {}     # bone name -> root name
        def _root_for(pb):
            if pb.name in cluster_of:
                return cluster_of[pb.name]
            if pb.parent is not None and pb.parent.name in candidates:
                r = _root_for(pb.parent)
            else:
                r = pb.name
            cluster_of[pb.name] = r
            return r

        clusters = {}       # root name -> [pose bones]
        for pb in candidates.values():
            clusters.setdefault(_root_for(pb), []).append(pb)

        # ---- one group per cluster, classified + preset applied
        made_groups = 0
        converted = 0
        summary = {}
        core.set_update_suspended(True)
        try:
            for root, bones in clusters.items():
                names = [pb.name for pb in bones]
                # classify by the whole cluster (root name wins on conflict)
                kind = _sb_classify_bone(root)
                if kind is None:
                    kinds = [k for k in (_sb_classify_bone(n) for n in names) if k]
                    kind = kinds[0] if kinds else 'GENERIC'
                # longest parent-chain run inside the cluster
                depth = {}
                for pb in sorted(bones, key=lambda b: len(b.parent_recursive)):
                    depth[pb.name] = depth.get(pb.parent.name, 0) + 1 \
                        if pb.parent is not None and pb.parent.name in depth else 1
                chain_len = max(depth.values()) if depth else 1

                preset_name, effects = _sb_pick_preset(kind, names, chain_len)

                grp_name = _unique_group_name(scene, root)
                grp = scene.sb_bone_groups.add()
                grp.name = grp_name
                for pb in bones:
                    pb.sb_group = grp_name
                    if 'LOC' in effects:
                        pb.sb_bone_spring_loc = True
                    if 'ROT' in effects:
                        # Rotation springs run in any rotation mode now, so
                        # imported rigs keep their Euler channels (and their
                        # existing Euler keyframes) intact.
                        pb.sb_bone_spring_rot = True
                    converted += 1
                grp.enable_loc = 'LOC' in effects
                grp.enable_rot = 'ROT' in effects
                # applying the preset via the enum triggers the same update
                # path as picking it by hand in the dropdown
                grp.preset = f"BUILTIN::{preset_name}"
                made_groups += 1
                summary[grp_name] = (kind, preset_name, len(bones))
        finally:
            core.set_update_suspended(False)

        update_bone(self, context)
        scene.sb_active_group_index = max(0, len(scene.sb_bone_groups) - 1)

        mode_txt = "selected bones" if selection_mode else "auto-detected bones"
        self.report({'INFO'},
                    f"Converted {converted} {mode_txt} into {made_groups} "
                    f"spring group(s): "
                    + ", ".join(f"{g} [{k[1]}]" for g, k in summary.items()))
        return {'FINISHED'}


# ================================================================== #
#  OPERATOR — automatic collision setup
# ================================================================== #

# Body bones that should become capsule colliders, by name keyword (EN+ES).
# Order matters: first match wins, and the multiplier tunes the capsule
# radius per body part (relative to bone length).
_SB_BODY_COLLIDERS = (
    (('head', 'cabeza'),                              0.45),
    (('neck', 'cuello'),                              0.35),
    (('spine', 'chest', 'torso', 'columna', 'torax'), 0.55),
    (('clavicle', 'shoulder', 'clavicula', 'hombro'), 0.35),
    (('pelvis', 'hip', 'cadera'),                     0.55),
    (('upperarm', 'upper_arm', 'brazo'),              0.30),
    (('forearm', 'antebrazo'),                        0.25),
    (('thigh', 'upleg', 'up_leg', 'muslo'),           0.35),
    (('shin', 'calf', 'lowleg', 'low_leg', 'leg', 'pierna', 'gemelo'), 0.28),
)
# Never auto-collide these: tiny face/hand bones that would spam capsules,
# and rig-control bones (IK targets, ctrl/master/pole helpers) that happen
# to contain body keywords ('Necklace' contains 'neck', 'L_Leg_IK'...).
_SB_BODY_SKIP = ('twist', 'finger', 'thumb', 'index', 'mid', 'ring', 'pinky',
                 'carpal', 'toe', 'eye', 'jaw', 'tongue', 'teeth', 'brow',
                 'lip', 'cheek', 'nose', 'ear',
                 'ik', 'ctrl', 'control', 'master', 'pole', 'pull', 'target',
                 'orientation', 'constraint', 'squish', 'swing', 'necklace',
                 'root', '_dis', 'helper', 'mch', 'org',
                 'jiggle', 'corrective')


def _sb_fit_head_capsule(arm):
    """Auto-fit the head capsule radius to the actual skull, using the hair
    chain ROOTS as measurement points: they sit ON the scalp, so their
    distance to the head bone segment IS the skull radius at that spot. The
    capsule is set slightly below the closest root (0.85x) so resting hair
    is not pushed out, and the neck capsules are scaled to match.

    The head bone itself is usually SHORT (skull base to crown pivot), so the
    generic length-based radius lands far too small for hair collision — this
    fit is what makes hair-vs-head actually work out of the box.

    Returns (radius, n_roots) or None when there is no head collider or no
    recognizable hair bones to measure against."""
    head_pb = None
    for pb in arm.pose.bones:
        n = pb.name.lower()
        if pb.sb_bone_collider and 'head' in n and 'forehead' not in n:
            head_pb = pb
            break
    if head_pb is None:
        return None

    mw = arm.matrix_world
    p0 = mw @ head_pb.head
    p1 = mw @ head_pb.tail

    # Hair chain roots, two tiers. PHYSICS roots (spring flags on, or a
    # physics naming convention like *_Phy) are preferred: they are exactly
    # the strands that will collide, so their scalp distance is the radius
    # that matters. Falling back to every hair-NAMED root also works, but
    # nape/center bones sitting near the head axis drag the minimum down.
    #
    # CRITICAL: the usable skull radius is the scalp distance MINUS the hair
    # bone's own collide radius and margin. Ignoring those (the pre-7.3.1
    # bug) left resting hair already inside its own head capsule, so turning
    # collisions on blasted every strand outward.
    def _is_phys(pb):
        return (pb.sb_bone_spring_loc or pb.sb_bone_spring_rot
                or 'phy' in pb.name.lower())

    phys_d, named_d = [], []
    for pb in arm.pose.bones:
        if _sb_classify_bone(pb.name) != 'HAIR':
            continue
        if pb.parent is not None and _sb_classify_bone(pb.parent.name) == 'HAIR':
            continue        # not a chain root
        h = mw @ pb.head
        near = core.project_point_onto_line(p0, p1, h)
        d = (h - near).length
        d -= max(pb.sb_colliding_dist, 0.0) + max(pb.sb_collide_margin, 0.0)
        if d > 0.01:        # ignore roots ON the bone axis (no information)
            named_d.append(d)
            if _is_phys(pb):
                phys_d.append(d)
    dists = phys_d if len(phys_d) >= 3 else named_d
    n_roots = len(dists)
    if not dists:
        return None

    r = min(dists) * 0.9
    r = min(max(r, 0.05), 0.35)     # plausible skull radii (world units)
    head_pb.sb_collider_dist = r

    # necks scaled to the skull so the hair slides down them cleanly
    for pb in arm.pose.bones:
        n = pb.name.lower()
        if pb.sb_bone_collider and 'neck' in n and 'necklace' not in n:
            pb.sb_collider_dist = max(pb.sb_collider_dist, r * 0.55)
    return r, n_roots


def _sb_body_collider_mult(pb):
    """Capsule radius multiplier for a body bone, or None to skip it.
    Only DEFORM bones qualify — control/helper bones never deform the mesh,
    so they are not part of the character's physical body."""
    if not pb.bone.use_deform:
        return None
    n = pb.name.lower()
    for kw in _SB_BODY_SKIP:
        if kw in n:
            return None
    for kws, mult in _SB_BODY_COLLIDERS:
        for kw in kws:
            if kw in n:
                return mult
    return None


class SB_OT_auto_setup_collisions(bpy.types.Operator):
    """One-click collision setup:
    1. Marks the character's body bones (head, neck, torso, arms, legs...)
       as capsule colliders with auto-sized radii.
    2. Registers every scene mesh that has Blender Collision physics as a
       SpringFX mesh collider.
    3. Enables 'Reacts to Colliders' on every current spring bone, with a
       sensible collide radius and margin"""
    bl_idname = "sb.auto_setup_collisions"
    bl_label = "Auto Setup Collisions"
    bl_options = {'REGISTER', 'UNDO'}

    setup_body: bpy.props.BoolProperty(
        name="Body Capsules", default=True,
        description="Mark body bones as capsule colliders (auto radius)")
    setup_meshes: bpy.props.BoolProperty(
        name="Physics Meshes", default=True,
        description="Use meshes with Blender Collision physics as colliders")
    enable_on_springs: bpy.props.BoolProperty(
        name="Enable on Spring Bones", default=True,
        description="Turn on 'Reacts to Colliders' for every spring bone")

    @classmethod
    def poll(cls, context):
        return (context.mode == 'POSE'
                and context.active_object is not None
                and context.active_object.type == 'ARMATURE')

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        scene = context.scene
        arm = context.active_object
        n_caps = n_mesh = n_spring = 0
        head_fit = None

        core.set_update_suspended(True)
        try:
            if self.setup_body:
                for pb in arm.pose.bones:
                    # spring bones and existing colliders are left alone
                    if (pb.sb_bone_spring_loc or pb.sb_bone_spring_rot
                            or pb.sb_bone_collider):
                        continue
                    mult = _sb_body_collider_mult(pb)
                    if mult is None:
                        continue
                    pb.sb_bone_collider = True
                    pb.sb_collider_dist = max(pb.bone.length * mult, 0.02)
                    pb.sb_collider_force = 1.0
                    n_caps += 1

            if self.setup_meshes:
                scene.sb_collide_use_physics_objects = True
                for obj in scene.objects:
                    if (obj.type == 'MESH'
                            and not getattr(obj, 'sb_object_collider', False)
                            and core._sb_obj_has_physics_collision(obj)):
                        n_mesh += 1     # picked up automatically by the sim

            if self.enable_on_springs:
                for item in scene.sb_spring_bones:
                    if item.sb_bone_collider:
                        continue
                    ob = core._sb_armature_of(item)
                    pb = ob.pose.bones.get(item.name) if ob else None
                    if pb is None:
                        continue
                    pb.sb_collide = True
                    if pb.sb_colliding_dist <= 0.0:
                        # a hair/cloth strand is THIN: ~20% of the bone,
                        # hard-capped at 5 cm. The old "a third of the bone,
                        # 2 cm floor" made strands so fat they started out
                        # already colliding with the fitted skull capsule.
                        pb.sb_colliding_dist = min(
                            max(pb.bone.length * 0.2, 0.008), 0.05)
                    if pb.sb_collide_margin <= 0.0:
                        pb.sb_collide_margin = 0.005
                    n_spring += 1

            # skull-fit LAST: it must know the spring bones' collide radii
            # to leave real clearance between resting hair and the capsule
            if self.setup_body:
                head_fit = _sb_fit_head_capsule(arm)
        finally:
            core.set_update_suspended(False)

        update_bone(self, context)

        if n_caps == 0 and self.setup_body:
            self.report({'WARNING'},
                        "No body bones recognized by name — mark colliders "
                        "manually or rename bones (head, spine, thigh…). "
                        f"Enabled collision on {n_spring} spring bone(s).")
        else:
            msg = (f"Colliders: {n_caps} body capsule(s), {n_mesh} physics "
                   f"mesh(es); collision enabled on {n_spring} spring bone(s).")
            if head_fit is not None:
                msg += (f" Head capsule fitted to r={head_fit[0]:.3f} from "
                        f"{head_fit[1]} hair root(s).")
            self.report({'INFO'}, msg)
        return {'FINISHED'}


class SB_OT_auto_tune_length(bpy.types.Operator):
    """Enable automatic bone-size compensation on the selected bones (or the
    active group): long bones get softer springs, short bones stiffer ones,
    so one preset reads consistently across the whole rig"""
    bl_idname = "sb.auto_tune_length"
    bl_label = "Auto-Tune by Bone Size"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and context.selected_pose_bones

    def execute(self, context):
        n = 0
        for pb in context.selected_pose_bones:
            pb.sb_auto_length = True
            n += 1
        self.report({'INFO'}, f"Auto bone-size tuning enabled on {n} bone(s).")
        return {'FINISHED'}


# ================================================================== #
#  PHYSICS RESET — the single source of truth for "a clean bone"
# ================================================================== #

# Factory defaults for every per-bone SpringFX property. Removing a group
# (or running Clean Physics) writes these back so the bone ends up EXACTLY
# as it was before any spring/collision setup touched it.
SB_BONE_PHYSICS_DEFAULTS = dict(
    sb_bone_spring_loc=False, sb_bone_spring_rot=False, sb_bone_collider=False,
    sb_stiffness=0.35, sb_damp=0.4, sb_loc_speed=0.0, sb_gravity=0.0,
    sb_loc_influence=1.0, sb_max_distance=0.0, sb_loc_range=1.0,
    sb_rot_stiffness=0.35, sb_rot_damp=0.4, sb_rot_influence=1.0,
    sb_rot_range=1.0,
    sb_noise_enable=False, sb_noise_loc=0.0, sb_noise_rot=0.0,
    sb_noise_speed=1.0, sb_noise_seed=0,
    sb_stiff_axis=(1.0, 1.0, 1.0), sb_air_drag=0.0, sb_wind_influence=1.0,
    sb_smooth=0.0, sb_lag=0.0, sb_chain_falloff=0.0, sb_auto_length=False,
    sb_collide=True, sb_colliding_dist=0.0,
    sb_include_only='*', sb_collide_exclude='',
    sb_collide_margin=0.0, sb_collide_stiffness=1.0, sb_collide_damping=0.2,
    sb_collide_friction_mult=1.0, sb_self_collision=False,
    sb_collider_dist=0.5, sb_collider_force=1.0,
    sb_collider_use_own_response=False, sb_collider_bounce=0.0,
    sb_collider_friction=0.5,
    sb_lock_axis='NONE',
)


def _sb_reset_bone_physics(pb):
    """Restore every SpringFX property on a pose bone to factory defaults.
    Callers are expected to run _cleanup_bone_helpers FIRST (it restores the
    captured pose and removes empties/constraints while the flags are still
    on) and to suspend the update callback around bulk resets."""
    for k, v in SB_BONE_PHYSICS_DEFAULTS.items():
        try:
            setattr(pb, k, v)
        except Exception:
            pass
    try:
        pb.sb_group = 'NONE'
    except Exception:
        pass


class SB_OT_remove_physics(bpy.types.Operator):
    """Remove the group selected in the list and completely strip SpringFX
    physics from its bones: helpers removed, original pose restored, every
    property back to default. With no groups it cleans the selected bones,
    or EVERY configured bone when nothing is selected"""
    bl_idname = "sb.remove_physics"
    bl_label = "Clean Physics"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'POSE'
                and context.active_object is not None
                and context.active_object.type == 'ARMATURE')

    def execute(self, context):
        scene = context.scene
        arm = context.active_object
        # NOTE: when the list has groups, Clean Physics acts on the selected
        # group: it deletes it and fully clears its members. The classic mode
        # (selection / all) remains for ungrouped bones.
        if len(scene.sb_bone_groups):
            idx = scene.sb_active_group_index
            if not (0 <= idx < len(scene.sb_bone_groups)):
                idx = len(scene.sb_bone_groups) - 1
            grp_name, n = _sb_remove_group(context, idx)
            update_bone(self, context)
            # NOTE: also sweep helpers orphaned by pre-8.2.5 override reloads;
            # no group leads to them, so the member loop above cannot.
            core._sb_purge_orphan_helpers()
            context.view_layer.update()
            self.report({'INFO'},
                        f"Group '{grp_name}' removed — physics cleared "
                        f"from {n} bone(s).")
            return {'FINISHED'}
        sel = [pb for pb in (context.selected_pose_bones or [])
               if pb.id_data == arm]
        if not sel:
            sel = [pb for pb in arm.pose.bones
                   if (pb.sb_bone_spring_loc or pb.sb_bone_spring_rot
                       or pb.sb_bone_collider
                       or pb.sb_group not in ('NONE', ''))]
        if not sel:
            self.report({'INFO'}, "No bones with SpringFX physics found.")
            return {'CANCELLED'}

        # helpers/pose first (needs the flags still on), then full reset
        for pb in sel:
            _cleanup_bone_helpers(pb.name, arm)
        core.set_update_suspended(True)
        try:
            for pb in sel:
                _sb_reset_bone_physics(pb)
        finally:
            core.set_update_suspended(False)
        update_bone(self, context)
        core._sb_purge_orphan_helpers()
        self.report({'INFO'}, f"Physics removed from {len(sel)} bone(s).")
        return {'FINISHED'}


# ================================================================== #
#  OPERATORS — bone groups
# ================================================================== #

class SB_OT_clear_bake_group(bpy.types.Operator):
    """Delete baked keyframes for all bones in the active group"""
    bl_idname = "sb.clear_bake_group"
    bl_label = "Clear Bake (Group)"
    bl_options = {'REGISTER', 'UNDO'}

    group_index: bpy.props.IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        return (context.mode == 'POSE'
                and context.active_object is not None
                and context.active_object.type == 'ARMATURE'
                and len(context.scene.sb_bone_groups) > 0)

    def execute(self, context):
        scene = context.scene
        ob = context.active_object
        _idx, grp = _sb_group_from_index(scene, self.group_index)
        if grp is None:
            self.report({'WARNING'}, "Group not found.")
            return {'CANCELLED'}

        ad = ob.animation_data
        if not ad or not ad.action:
            self.report({'WARNING'}, "No animation/action on this armature.")
            return {'CANCELLED'}

        bone_names = {pb.name for pb in ob.pose.bones if pb.sb_group == grp.name}
        if not bone_names:
            self.report({'WARNING'}, f"Group '{grp.name}' has no bones.")
            return {'CANCELLED'}

        # Blender 5.x removed action.fcurves; access via the slot's channelbag.
        from bpy_extras import anim_utils
        action = ad.action
        try:
            channelbag = anim_utils.action_get_channelbag_for_slot(action, ad.action_slot)
        except Exception:
            channelbag = None

        fcurve_container = channelbag if channelbag is not None else getattr(action, "fcurves", None)
        if fcurve_container is None:
            self.report({'WARNING'}, "Could not access F-Curves on this action.")
            return {'CANCELLED'}

        removed = 0
        for fc in list(fcurve_container.fcurves):
            dp = fc.data_path  # e.g. pose.bones["Name"].location
            if dp.startswith('pose.bones["'):
                bname = dp.split('"')[1]
                if bname in bone_names and (
                    dp.endswith('.location') or
                    dp.endswith('.rotation_quaternion') or
                    dp.endswith('.rotation_euler') or
                    dp.endswith('.scale')):
                    fcurve_container.fcurves.remove(fc)
                    removed += 1

        # reset those bones to rest so they don't hold the last baked pose
        for bname in bone_names:
            pb = ob.pose.bones.get(bname)
            if pb:
                pb.location = (0, 0, 0)
                if pb.rotation_mode == 'QUATERNION':
                    pb.rotation_quaternion = (1, 0, 0, 0)
                elif pb.rotation_mode == 'AXIS_ANGLE':
                    pb.rotation_axis_angle = (0, 0, 1, 0)
                else:
                    pb.rotation_euler = (0, 0, 0)

        self.report({'INFO'}, f"Cleared {removed} baked channel(s) for group '{grp.name}'.")
        return {'FINISHED'}


class SB_OT_group_add(bpy.types.Operator):
    """Create a new bone group from the current selection"""
    bl_idname = "sb.group_add"
    bl_label = "New Group"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE'

    def execute(self, context):
        scene = context.scene
        name = _unique_group_name(scene, "Group")
        grp = scene.sb_bone_groups.add()
        grp.name = name
        n = 0
        for pb in (context.selected_pose_bones or []):
            pb.sb_group = name
            n += 1
        scene.sb_active_group_index = len(scene.sb_bone_groups) - 1
        self.report({'INFO'}, f"Created group '{name}' with {n} bone(s)")
        return {'FINISHED'}


def _sb_group_membership(scene):
    """Snapshot name -> [(armature, pbone)] of ALL groups before touching the
    collection: pb.sb_group is a dynamic enum and deleting a group shifts the
    indices, so membership is rewritten by name."""
    membership = {}
    for ob in scene.objects:
        if ob.type != 'ARMATURE':
            continue
        for pb in ob.pose.bones:
            g = pb.sb_group
            if g not in ('NONE', ''):
                membership.setdefault(g, []).append((ob, pb))
    return membership


def _sb_rewrite_membership(scene, membership):
    surviving = {g.name for g in scene.sb_bone_groups}
    for g_name, pairs in membership.items():
        if g_name not in surviving:
            continue
        for ob, pb in pairs:
            try:
                pb.sb_group = g_name
            except Exception:
                pass


def _sb_remove_group(context, idx):
    """Delete group `idx` and FULLY clear its members' physics; returns
    (name, bone count) or (None, 0). Shared by Remove Group and Clean Physics
    so both behave exactly the same."""
    scene = context.scene
    if not (0 <= idx < len(scene.sb_bone_groups)):
        return None, 0
    grp_name = scene.sb_bone_groups[idx].name
    membership = _sb_group_membership(scene)
    members = membership.pop(grp_name, [])

    # 1) helpers + pose FIRST, while the flags are still set
    #    (_cleanup_bone_helpers needs them to restore the base pose)
    for ob, pb in members:
        _cleanup_bone_helpers(pb.name, ob)
    # 2) full reset (not just the flags) with the update callback suspended
    core.set_update_suspended(True)
    try:
        for ob, pb in members:
            _sb_reset_bone_physics(pb)
    finally:
        core.set_update_suspended(False)
    # 3) remove the group and rewrite the remaining membership by NAME
    scene.sb_bone_groups.remove(idx)
    _sb_rewrite_membership(scene, membership)
    scene.sb_active_group_index = min(max(0, idx - 1),
                                      max(0, len(scene.sb_bone_groups) - 1))
    return grp_name, len(members)


def _sb_drop_groups_after_bake(scene, armature, baked_names):
    """After a bake the simulation lives in keyframes: baked bones are reset
    to defaults and groups left without members are deleted; the remaining
    membership is rewritten by name. The bake already removed the helpers.
    Returns the names of the deleted groups."""
    baked = set(baked_names)
    membership = _sb_group_membership(scene)

    core.set_update_suspended(True)
    try:
        for pairs in membership.values():
            for ob, pb in pairs:
                if ob == armature and pb.name in baked:
                    _sb_reset_bone_physics(pb)
    finally:
        core.set_update_suspended(False)

    remaining = {}
    for g_name, pairs in membership.items():
        rest = [(ob, pb) for ob, pb in pairs
                if not (ob == armature and pb.name in baked)]
        if rest:
            remaining[g_name] = rest
    # NOTE: delete back to front so pending indices don't shift
    removed = []
    for i in range(len(scene.sb_bone_groups) - 1, -1, -1):
        g_name = scene.sb_bone_groups[i].name
        if g_name in membership and g_name not in remaining:
            scene.sb_bone_groups.remove(i)
            removed.append(g_name)
    _sb_rewrite_membership(scene, remaining)
    scene.sb_active_group_index = min(scene.sb_active_group_index,
                                      max(0, len(scene.sb_bone_groups) - 1))
    return removed


class SB_OT_group_remove(bpy.types.Operator):
    """Delete this group and COMPLETELY remove the physics from its member
    bones: helpers deleted, original pose restored and every SpringFX
    property reset to factory defaults — the bones end up exactly as they
    were before the effect was added"""
    bl_idname = "sb.group_remove"
    bl_label = "Remove Group"
    bl_options = {'REGISTER', 'UNDO'}

    # -1 = use the active group (legacy behavior); callers may pass an index.
    group_index: bpy.props.IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        return len(context.scene.sb_bone_groups) > 0

    def execute(self, context):
        scene = context.scene
        idx = self.group_index if self.group_index >= 0 else scene.sb_active_group_index
        grp_name, n = _sb_remove_group(context, idx)
        if grp_name is None:
            self.report({'WARNING'}, "Group not found.")
            return {'CANCELLED'}
        update_bone(self, context)
        core._sb_purge_orphan_helpers()
        context.view_layer.update()
        self.report({'INFO'},
                    f"Group '{grp_name}' removed — physics fully cleared "
                    f"from {n} bone(s).")
        return {'FINISHED'}


def _sb_group_from_index(scene, group_index):
    """Group by explicit index, falling back to the active one (-1)."""
    idx = group_index if group_index >= 0 else scene.sb_active_group_index
    if 0 <= idx < len(scene.sb_bone_groups):
        return idx, scene.sb_bone_groups[idx]
    return -1, None


class SB_OT_group_assign(bpy.types.Operator):
    """Assign the selected bones to this group"""
    bl_idname = "sb.group_assign"
    bl_label = "Assign Selected"
    bl_options = {'REGISTER', 'UNDO'}

    group_index: bpy.props.IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        return (context.mode == 'POSE' and context.selected_pose_bones
                and len(context.scene.sb_bone_groups) > 0)

    def execute(self, context):
        scene = context.scene
        idx, grp = _sb_group_from_index(scene, self.group_index)
        if grp is None:
            self.report({'WARNING'}, "Group not found.")
            return {'CANCELLED'}
        scene.sb_active_group_index = idx
        n = 0
        # NOTE: a bone joining the group inherits its effects; otherwise it
        # would be listed but springless until the toggles were pressed again.
        with core.sb_bulk():
            for pb in context.selected_pose_bones:
                pb.sb_group = grp.name
                pb.sb_bone_spring_loc = grp.enable_loc
                pb.sb_bone_spring_rot = grp.enable_rot
                pb.sb_collide = grp.collide
                pb.sb_colliding_dist = grp.collide_radius
                n += 1
        self.report({'INFO'}, f"Assigned {n} bone(s) to '{grp.name}'")
        return {'FINISHED'}


class SB_OT_group_select(bpy.types.Operator):
    """Select every bone belonging to this group"""
    bl_idname = "sb.group_select"
    bl_label = "Select Group Bones"
    bl_options = {'REGISTER', 'UNDO'}

    group_index: bpy.props.IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        return (context.mode == 'POSE'
                and len(context.scene.sb_bone_groups) > 0)

    def execute(self, context):
        scene = context.scene
        idx, grp = _sb_group_from_index(scene, self.group_index)
        if grp is None:
            self.report({'WARNING'}, "Group not found.")
            return {'CANCELLED'}
        scene.sb_active_group_index = idx
        ob = context.active_object
        bpy.ops.pose.select_all(action='DESELECT')
        n = 0
        for pb in ob.pose.bones:
            if pb.sb_group == grp.name:
                _pb_set_select(pb, True)
                n += 1
        self.report({'INFO'}, f"Selected {n} bone(s) in '{grp.name}'")
        return {'FINISHED'}




class SB_OT_cache_bake(bpy.types.Operator):
    """Simulate the whole frame range once and store it, so scrubbing the
    timeline replays the exact same motion instead of re-simulating"""
    bl_idname = "sb.cache_bake"
    bl_label = "Bake to Cache"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return bool(context.scene.sb_spring_bones)

    def execute(self, context):
        scene = context.scene
        wm = context.window_manager
        original = scene.frame_current
        f0, f1 = scene.frame_start, scene.frame_end

        core.set_cache_enabled(True)
        core.invalidate_cache()
        # Clean, repeatable start: the cache is only trustworthy if frame f0
        # was reached the same way it will be during playback.
        core._sb_reset_sim_state(scene)
        scene.frame_set(f0)

        wm.progress_begin(0, max(f1 - f0, 1))
        try:
            for f in range(f0, f1 + 1):
                scene.frame_set(f)
                wm.progress_update(f - f0)
        finally:
            wm.progress_end()
            scene.frame_set(original)

        n_frames, first, last, n_entries = core.get_cache_info()
        # NOTE: 8.4.4 -- a complete baked cache is replayed exactly, forward
        # jumps included (core._sb_catchup_steps).
        core._sb_cache_baked = n_frames > 0
        self.report({'INFO'},
                    f"Cached {n_frames} frame(s) [{first}-{last}], "
                    f"{n_entries} bone states")
        return {'FINISHED'}


class SB_OT_cache_clear(bpy.types.Operator):
    """Discard the simulation cache. Do this after moving a collider or
    editing the animation, since those are not auto-detected"""
    bl_idname = "sb.cache_clear"
    bl_label = "Clear Cache"
    bl_options = {'REGISTER'}

    def execute(self, context):
        core.invalidate_cache()
        self.report({'INFO'}, "Simulation cache cleared.")
        return {'FINISHED'}


classes = (
    SB_OT_select_bone,
    SB_OT_cache_bake,
    SB_OT_cache_clear,
    SB_OT_bake,
    SB_OT_add_effect_group,
    SB_OT_add_physics,
    SB_OT_enable_selected,
    SB_OT_smart_convert,
    SB_OT_auto_setup_collisions,
    SB_OT_auto_tune_length,
    SB_OT_remove_physics,
    SB_OT_clear_bake_group,
    SB_OT_group_add,
    SB_OT_group_remove,
    SB_OT_group_assign,
    SB_OT_group_select,
    SB_OT_noise_mod_apply,
    SB_OT_noise_mod_remove,
    SB_OT_setup_bone_colliders,
    SB_OT_remove_bone_colliders,
    SB_OT_action_to_nla,
)


def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)


def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
