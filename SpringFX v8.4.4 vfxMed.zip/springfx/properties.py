# SpringFX — properties.py
# All PropertyGroups and every bpy.types.{Scene,Object,PoseBone} property.
# Property NAMES are the addon's public contract: scenes saved with any
# previous version load unchanged. New properties are append-only.

import bpy
from . import core as _sb_core
from mathutils import Matrix

from . import core, presets
from .core import update_bone
from .operators import _nmod_update
from .presets import _preset_enum_items, _on_group_preset_selected


# ================================================================== #
#  RUNTIME COLLECTIONS
# ================================================================== #

class bones_collec(bpy.types.PropertyGroup):
    # Canonical reference to the owning armature. The legacy name STRING
    # below silently breaks the moment the user renames the rig: every spring
    # on it stops resolving and the simulation dies with no error at all.
    # A PointerProperty survives renames, append/link and library overrides.
    # `armature` is kept as a mirror for backward compatibility and as a
    # cheap identity token -- always RESOLVE through core._sb_armature_of().
    armature_obj:      bpy.props.PointerProperty(
                           name="Armature", type=bpy.types.Object,
                           poll=lambda self, o: o.type == 'ARMATURE',
                           options={'LIBRARY_EDITABLE'},
                           override={'LIBRARY_OVERRIDABLE'})
    armature:          bpy.props.StringProperty(default="")
    last_loc:          bpy.props.FloatVectorProperty(name="Loc",   subtype='TRANSLATION', default=(0,0,0), size=3)
    speed:             bpy.props.FloatVectorProperty(name="Speed", subtype='VELOCITY', default=(0,0,0), size=3)
    dist:              bpy.props.FloatProperty(name="distance", default=1.0)
    target_offset:     bpy.props.FloatVectorProperty(name="TargetLoc", subtype='TRANSLATION', default=(0,0,0), size=3)
    sb_bone_collider:  bpy.props.BoolProperty(name="Bone collider",  default=False)
    sb_bone_colliding: bpy.props.BoolProperty(name="Bone colliding", default=True)
    sb_collider_dist:  bpy.props.FloatProperty(name="Bone collider distance", default=0.5)
    sb_collider_force: bpy.props.FloatProperty(name="Bone collider force",    default=1.0)
    # rotation spring runtime state (world-space simulated tail point)
    rot_initialized:   bpy.props.BoolProperty(default=False)
    rot_position:      bpy.props.FloatVectorProperty(subtype='TRANSLATION', default=(0,0,0), size=3)
    rot_velocity:      bpy.props.FloatVectorProperty(subtype='VELOCITY', default=(0,0,0), size=3)
    rot_head_last:     bpy.props.FloatVectorProperty(subtype='TRANSLATION', default=(0,0,0), size=3)
    # raw (un-scaled, un-noised) location spring position, kept separate from
    # the empty's visual output so Move Range / noise never feed back
    loc_raw:           bpy.props.FloatVectorProperty(subtype='TRANSLATION', default=(0,0,0), size=3)
    loc_raw_set:       bpy.props.BoolProperty(default=False)
    # base pose rotation (the user's custom pose), so the sim runs on top of it
    rot_base_quat:     bpy.props.FloatVectorProperty(default=(1,0,0,0), size=4)
    loc_base:          bpy.props.FloatVectorProperty(default=(0,0,0), size=3)
    rot_base_set:      bpy.props.BoolProperty(default=False)
    # chain topology for the Chain Falloff feature (computed in update_bone):
    # how deep this bone sits in its spring chain and the chain's total length
    chain_depth:       bpy.props.IntProperty(default=0)
    chain_len:         bpy.props.IntProperty(default=1)
    matrix_offset  = Matrix()
    initial_matrix = Matrix()


class mesh_collec(bpy.types.PropertyGroup):
    test: bpy.props.StringProperty(default="")


class sb_fav_preset(bpy.types.PropertyGroup):
    """One favorite-preset marker; name holds the preset identifier
    ('BUILTIN::x' or 'USER::x')."""
    name: bpy.props.StringProperty(default="")


# ================================================================== #
#  GROUP PROPAGATION CALLBACKS
# ================================================================== #

def _sb_param_changed(self, context):
    """A simulation input changed.

    Both calls are O(1) -- a flag and two dict clears. The real work
    (re-resolving every bone's parameters) happens lazily on the next
    simulated frame, so dragging a slider stays smooth even on a heavy rig.

    Before 7.4 only 4 of the 84 properties had an update= callback at all;
    the solver simply re-read RNA every frame, which is why it could get away
    without them. The flat solver state cannot, and neither can the frame
    cache -- this is what replaces the old parameter-signature hashing.
    """
    _mark = getattr(_sb_core, "mark_solver_dirty", None)
    if _mark is not None:
        _mark()
    _sb_core.invalidate_cache()


def _group_propagate_effect(group, context, attr, value):
    """Set a spring-effect bool on every pose bone that belongs to this group,
    across all armatures in the scene.

    Wrapped in sb_bulk(): each write fires update_bone() through the
    property's own update= callback, so toggling a 40-bone group used to run
    40 full list rebuilds -- O(N^2) -- and print 80 console lines.
    """
    with _sb_core.sb_bulk():
        for ob in context.scene.objects:
            if ob.type != 'ARMATURE':
                continue
            for pb in ob.pose.bones:
                if pb.sb_group == group.name:
                    if getattr(pb, attr) != value:
                        setattr(pb, attr, value)


def _update_group_loc(self, context):
    _group_propagate_effect(self, context, 'sb_bone_spring_loc', self.enable_loc)


def _update_group_rot(self, context):
    _group_propagate_effect(self, context, 'sb_bone_spring_rot', self.enable_rot)


def _update_group_collide(self, context):
    # NOTE: with no Active Bone panel, collider response is set per group and
    # pushed to the members just like the spring toggles.
    _group_propagate_effect(self, context, 'sb_collide', self.collide)


def _update_group_collide_radius(self, context):
    _group_propagate_effect(self, context, 'sb_colliding_dist', self.collide_radius)


# ================================================================== #
#  USER PRESET STORAGE
#  Must define one property per presets.SB_PARAM_KEYS entry — the save
#  operator writes every key (this fixes the v6 bug where six keys had no
#  matching property and saving raised AttributeError).
# ================================================================== #

class sb_user_preset(bpy.types.PropertyGroup):
    """A user-saved preset storing the full parameter set."""
    name:             bpy.props.StringProperty(name="Name", default="My Preset")
    sb_stiffness:     bpy.props.FloatProperty(default=0.35)
    sb_damp:          bpy.props.FloatProperty(default=0.4)
    sb_loc_speed:     bpy.props.FloatProperty(default=0.0)
    sb_gravity:       bpy.props.FloatProperty(default=0.0)
    sb_loc_influence: bpy.props.FloatProperty(default=1.0)
    sb_max_distance:  bpy.props.FloatProperty(default=0.0)
    sb_loc_range:     bpy.props.FloatProperty(default=1.0)
    sb_rot_stiffness: bpy.props.FloatProperty(default=0.35)
    sb_rot_damp:      bpy.props.FloatProperty(default=0.4)
    sb_rot_speed:     bpy.props.FloatProperty(default=0.0)   # rotspeed
    sb_effects:       bpy.props.StringProperty(default="BOTH")   # presetfx
    sb_rot_influence: bpy.props.FloatProperty(default=1.0)
    sb_rot_range:     bpy.props.FloatProperty(default=1.0)
    sb_noise_enable:  bpy.props.BoolProperty(default=False)
    sb_noise_loc:     bpy.props.FloatProperty(default=0.0)
    sb_noise_rot:     bpy.props.FloatProperty(default=0.0)
    sb_noise_speed:   bpy.props.FloatProperty(default=1.0)
    sb_noise_seed:    bpy.props.IntProperty(default=0)
    # advanced dynamics (v7)
    sb_stiff_axis:      bpy.props.FloatVectorProperty(default=(1.0, 1.0, 1.0), size=3)
    sb_air_drag:        bpy.props.FloatProperty(default=0.0)
    sb_wind_influence:  bpy.props.FloatProperty(default=1.0)
    sb_smooth:          bpy.props.FloatProperty(default=0.0)
    sb_lag:             bpy.props.FloatProperty(default=0.0)
    sb_chain_falloff:   bpy.props.FloatProperty(default=0.0)
    sb_auto_length:     bpy.props.BoolProperty(default=False)
    # collision response (v7.1)
    sb_collide_margin:        bpy.props.FloatProperty(default=0.0)
    sb_collide_stiffness:     bpy.props.FloatProperty(default=1.0)
    sb_collide_damping:       bpy.props.FloatProperty(default=0.2)
    sb_collide_friction_mult: bpy.props.FloatProperty(default=1.0)
    sb_self_collision:        bpy.props.BoolProperty(default=False)


# ================================================================== #
#  BONE GROUP
# ================================================================== #

_sb_renaming = False   # NOTE: recursion guard for the rename callback


def _on_group_renamed(self, context):
    """The group name IS the identifier of the dynamic PoseBone.sb_group enum:
    two groups with the same name (or an empty one) would make bone membership
    ambiguous, so uniqueness is enforced with Blender's usual .001 suffix. Bones
    need no update: they store the item index, which renaming doesn't change."""
    global _sb_renaming
    if _sb_renaming:
        return
    scene = context.scene if context is not None else bpy.context.scene
    name = self.name.strip() or "Group"
    me = self.as_pointer()
    others = {g.name for g in scene.sb_bone_groups if g.as_pointer() != me}
    unique, i = name, 1
    while unique in others:
        unique = f"{name}.{i:03d}"
        i += 1
    if unique != self.name:
        _sb_renaming = True
        try:
            self.name = unique
        finally:
            _sb_renaming = False
    _sb_param_changed(self, context)


class sb_group(bpy.types.PropertyGroup):
    name:          bpy.props.StringProperty(name="Name", default="Group",
                                            update=_on_group_renamed)
    # UI only: whether this group's box is expanded in the Bone Groups panel
    ui_expanded:   bpy.props.BoolProperty(
        name="Expand", default=True,
        description="Show this group's bones and settings")
    # preset dropdown — selecting applies the preset to this group
    preset:        bpy.props.EnumProperty(
        name="Preset", items=_preset_enum_items, update=_on_group_preset_selected,
        description="Apply a preset to this group's parameters")
    # per-group effect toggles — clicking propagates to all member bones
    enable_loc:    bpy.props.BoolProperty(
        name="Location Spring", default=False,
        description="Enable/disable the LOCATION spring on every bone in this group",
        update=_update_group_loc)
    enable_rot:    bpy.props.BoolProperty(
        name="Rotation Spring", default=False,
        description="Enable/disable the ROTATION spring on every bone in this group",
        update=_update_group_rot)
    drive_params:  bpy.props.BoolProperty(update=_sb_param_changed,
        name="Drive Parameters", default=True,
        description="When on, member bones use this group's parameters instead of their own")
    # NOTE: collision proxies (v8.2): the Active Bone panel is gone, so the
    # collision toggle and radius are edited per group and propagated.
    collide:        bpy.props.BoolProperty(
        name="Reacts to Colliders", default=True,
        description="Member bones are pushed out of colliders",
        update=_update_group_collide)
    collide_radius: bpy.props.FloatProperty(
        name="Collide Radius", default=0.0, min=0.0, soft_max=1.0,
        description="Thickness of the members' flesh for collision "
                    "(world units, 0 = point)",
        update=_update_group_collide_radius)
    sb_stiffness:     bpy.props.FloatProperty(update=_sb_param_changed, name="Stiffness", default=0.35, min=0.0, max=1.0)
    sb_damp:          bpy.props.FloatProperty(update=_sb_param_changed, name="Damping",   default=0.4, min=0.0, max=1.0)
    sb_loc_speed:     bpy.props.FloatProperty(update=_sb_param_changed, name="Speed", default=0.0, min=0.0, max=1.0)
    sb_gravity:       bpy.props.FloatProperty(update=_sb_param_changed, name="Gravity",   default=0.0, min=-100.0, max=100.0)
    sb_loc_influence: bpy.props.FloatProperty(update=_sb_param_changed, name="Influence", default=1.0, min=0.0, max=1.0)
    sb_max_distance:  bpy.props.FloatProperty(update=_sb_param_changed, name="Max Distance", default=0.0)
    sb_loc_range:     bpy.props.FloatProperty(update=_sb_param_changed, name="Move Range", default=1.0, min=0.0, max=4.0, soft_max=3.0)
    sb_rot_stiffness: bpy.props.FloatProperty(update=_sb_param_changed, name="Rot Stiffness", default=0.35, min=0.0, max=1.0)
    sb_rot_damp:      bpy.props.FloatProperty(update=_sb_param_changed, name="Rot Damping",   default=0.4, min=0.0, max=1.0)
    sb_rot_speed:     bpy.props.FloatProperty(update=_sb_param_changed, name="Rot Speed", default=0.0, min=0.0, max=1.0)
    sb_rot_influence: bpy.props.FloatProperty(update=_sb_param_changed, name="Rot Influence", default=1.0, min=0.0, max=1.0)
    sb_rot_range:     bpy.props.FloatProperty(update=_sb_param_changed, name="Swing Range", default=1.0, min=0.0, max=4.0, soft_max=3.0)
    # noise
    sb_noise_enable:  bpy.props.BoolProperty(update=_sb_param_changed, name="Noise", default=False,
        description="Add random procedural motion on top of the spring simulation")
    sb_noise_loc:     bpy.props.FloatProperty(update=_sb_param_changed, name="Noise Location", default=0.0, min=0.0, soft_max=0.2)
    sb_noise_rot:     bpy.props.FloatProperty(update=_sb_param_changed, name="Noise Rotation", default=0.0, min=0.0, soft_max=1.0)
    sb_noise_speed:   bpy.props.FloatProperty(update=_sb_param_changed, name="Noise Speed", default=1.0, min=0.0, soft_max=5.0)
    sb_noise_seed:    bpy.props.IntProperty(update=_sb_param_changed, name="Noise Seed", default=0, min=0)
    # advanced dynamics (v7) — same meanings as the per-bone versions below
    sb_stiff_axis:      bpy.props.FloatVectorProperty(update=_sb_param_changed, 
        name="Axis Stiffness", default=(1.0, 1.0, 1.0), size=3,
        min=0.0, soft_max=2.0,
        description="Per-axis stiffness multiplier in the bone's LOCAL axes")
    sb_air_drag:        bpy.props.FloatProperty(update=_sb_param_changed, 
        name="Air Drag", default=0.0, min=0.0, max=1.0,
        description="Air resistance on the bone's absolute motion")
    sb_wind_influence:  bpy.props.FloatProperty(update=_sb_param_changed, 
        name="Wind Influence", default=1.0, min=0.0, soft_max=2.0,
        description="How strongly the scene wind pushes this group")
    sb_smooth:          bpy.props.FloatProperty(update=_sb_param_changed, 
        name="Smooth (HF Damping)", default=0.0, min=0.0, max=1.0,
        description="Low-pass filter on the output — removes fast jitter")
    sb_lag:             bpy.props.FloatProperty(update=_sb_param_changed, 
        name="Lag / Delay", default=0.0, min=0.0, max=1.0,
        description="Delayed follow-through: the spring chases a delayed target")
    sb_chain_falloff:   bpy.props.FloatProperty(update=_sb_param_changed, 
        name="Chain Falloff", default=0.0, min=0.0, max=1.0,
        description="Stiffness falloff along bone chains: tips get looser than roots")
    sb_auto_length:     bpy.props.BoolProperty(update=_sb_param_changed, 
        name="Auto Bone-Size Tuning", default=False,
        description="Compensate stiffness by bone length so one preset reads "
                    "the same on short and long bones")
    # collision response (v7.1) — same meanings as the per-bone versions
    sb_collide_margin:        bpy.props.FloatProperty(update=_sb_param_changed, 
        name="Collision Margin", default=0.0, min=0.0, soft_max=0.2,
        description="Extra safety distance kept from every collider surface")
    sb_collide_stiffness:     bpy.props.FloatProperty(update=_sb_param_changed, 
        name="Collision Stiffness", default=1.0, min=0.0, max=1.0,
        description="How firmly the group is pushed out of colliders")
    sb_collide_damping:       bpy.props.FloatProperty(update=_sb_param_changed, 
        name="Damping on Collision", default=0.2, min=0.0, max=1.0,
        description="Extra energy loss per impact so contacts settle")
    sb_collide_friction_mult: bpy.props.FloatProperty(update=_sb_param_changed, 
        name="Friction Multiplier", default=1.0, min=0.0, soft_max=2.0,
        description="Scales the collider friction for this group")
    sb_self_collision:        bpy.props.BoolProperty(update=_sb_param_changed, 
        name="Self Collision", default=False,
        description="Members keep a sphere of personal space against every "
                    "other spring bone (needs the global switch in Collisions)")


# ================================================================== #
#  NOISE F-MODIFIER SETTINGS (one section = location or rotation)
# ================================================================== #

class sb_noise_mod(bpy.types.PropertyGroup):
    """All parameters for one Noise F-Modifier section (location or rotation)."""
    enable: bpy.props.BoolProperty(
        name="Enable", default=False, update=_nmod_update,
        description="Layer a Noise F-Modifier on this channel group")
    # per-axis toggles (W is only used for the rotation quaternion)
    use_w: bpy.props.BoolProperty(name="W", default=False, update=_nmod_update,
        description="Apply noise to the quaternion W component")
    use_x: bpy.props.BoolProperty(name="X", default=True, update=_nmod_update,
        description="Apply noise to this axis")
    use_y: bpy.props.BoolProperty(name="Y", default=True, update=_nmod_update,
        description="Apply noise to this axis")
    use_z: bpy.props.BoolProperty(name="Z", default=True, update=_nmod_update,
        description="Apply noise to this axis")
    # core Noise F-Modifier parameters
    blend_type: bpy.props.EnumProperty(
        name="Blend", default='REPLACE', update=_nmod_update,
        items=(('REPLACE',  "Replace",  "Add CENTERED noise (mean 0) on top of the "
                                        "curve — the natural choice for jitter"),
               ('ADD',      "Add",      "Add noise (0..1)*strength — biases the value up"),
               ('SUBTRACT', "Subtract", "Subtract noise from the curve"),
               ('MULTIPLY', "Multiply", "Multiply the curve by the noise")),
        description="How the generated noise is combined with the baked value")
    scale: bpy.props.FloatProperty(
        name="Scale", default=8.0, min=0.0001, soft_max=100.0, update=_nmod_update,
        description="Size of the noise in frames — larger = slower, smoother wobble")
    strength: bpy.props.FloatProperty(
        name="Strength", default=0.05, min=0.0, soft_max=1.0, update=_nmod_update,
        description="Amplitude of the noise (scene units for location, "
                    "radians for rotation)")
    phase: bpy.props.FloatProperty(
        name="Phase", default=0.0, update=_nmod_update,
        description="Shifts the noise pattern — change for a different random look")
    offset: bpy.props.FloatProperty(
        name="Offset", default=0.0, update=_nmod_update,
        description="Time offset into the noise field")
    depth: bpy.props.IntProperty(
        name="Depth", default=0, min=0, max=12, update=_nmod_update,
        description="Fractal detail — adds finer layers on top of the base noise")
    variation: bpy.props.FloatProperty(
        name="Axis Variation", default=100.0, update=_nmod_update,
        description="Phase step added per axis so the axes don't move in lockstep. "
                    "0 = identical noise on every axis")
    # advanced / fractal
    show_advanced: bpy.props.BoolProperty(name="Advanced", default=False)
    use_legacy_noise: bpy.props.BoolProperty(
        name="Legacy Noise", default=False, update=_nmod_update,
        description="Use the old noise generator (ignores Lacunarity / Roughness)")
    lacunarity: bpy.props.FloatProperty(
        name="Lacunarity", default=2.0, min=0.0, soft_max=10.0, update=_nmod_update,
        description="Frequency gap between fractal layers (needs Depth > 0)")
    roughness: bpy.props.FloatProperty(
        name="Roughness", default=0.5, min=0.0, max=1.0, update=_nmod_update,
        description="Relative strength of the finer fractal layers (needs Depth > 0)")
    # restricted frame range
    use_restricted_range: bpy.props.BoolProperty(
        name="Restrict Frame Range", default=False, update=_nmod_update,
        description="Only apply the noise inside a frame range, with fade in/out")
    frame_start: bpy.props.FloatProperty(name="Start", default=1.0, update=_nmod_update)
    frame_end:   bpy.props.FloatProperty(name="End",   default=250.0, update=_nmod_update)
    blend_in:    bpy.props.FloatProperty(name="Blend In",  default=0.0, min=0.0, update=_nmod_update)
    blend_out:   bpy.props.FloatProperty(name="Blend Out", default=0.0, min=0.0, update=_nmod_update)
    # influence
    use_influence: bpy.props.BoolProperty(
        name="Use Influence", default=False, update=_nmod_update,
        description="Blend the whole noise effect in by an influence factor")
    influence: bpy.props.FloatProperty(
        name="Influence", default=1.0, min=0.0, max=1.0, update=_nmod_update)


# Same dynamic-enum caveat as presets._preset_enum_items: keep the returned
# strings referenced or Blender may show corrupted entries.
_group_enum_cache = []


def _group_enum_items(self, context):
    items = [("NONE", "None", "No group")]
    for grp in context.scene.sb_bone_groups:
        items.append((grp.name, grp.name, ""))
    _group_enum_cache.clear()
    _group_enum_cache.extend(items)
    return _group_enum_cache


classes = (
    bones_collec, mesh_collec, sb_fav_preset,
    sb_user_preset, sb_group, sb_noise_mod,
)


# ================================================================== #
#  REGISTER
# ================================================================== #

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    OVR = {'LIBRARY_OVERRIDABLE'}

    # LIBRARY_EDITABLE is what actually lets an artist touch these on a
    # LINKED rig. Without it, override=LIBRARY_OVERRIDABLE only gets you
    # half the way: the property can be overridden but the UI stays greyed
    # out, which made SpringFX unusable in a link-based studio pipeline.
    # ANIMATABLE is the RNA default and must be restated once options= is
    # given explicitly, or the properties silently stop being keyframable.
    OPT = {'ANIMATABLE', 'LIBRARY_EDITABLE'}
    bpy.types.Scene.sb_spring_bones        = bpy.props.CollectionProperty(options=OPT, type=bones_collec)
    bpy.types.Scene.sb_mesh_colliders      = bpy.props.CollectionProperty(options=OPT, type=mesh_collec)
    bpy.types.Scene.sb_bone_groups         = bpy.props.CollectionProperty(options=OPT, type=sb_group)
    bpy.types.Scene.sb_user_presets        = bpy.props.CollectionProperty(options=OPT, type=sb_user_preset)
    bpy.types.Scene.sb_preset_favorites    = bpy.props.CollectionProperty(options=OPT, type=sb_fav_preset)
    bpy.types.Scene.sb_active_group_index  = bpy.props.IntProperty(options=OPT, default=0)
    bpy.types.Scene.sb_show_colliders      = bpy.props.BoolProperty(options=OPT, 
        name="Show Colliders", description="Show active collider bone names",
        default=False, override=OVR)

    # ---- F-Curve Noise Modifier (post-bake secondary motion) ----
    bpy.types.Scene.sb_nmod_loc  = bpy.props.PointerProperty(options=OPT, type=sb_noise_mod)
    bpy.types.Scene.sb_nmod_rot  = bpy.props.PointerProperty(options=OPT, type=sb_noise_mod)
    bpy.types.Scene.sb_nmod_live = bpy.props.BoolProperty(options=OPT, 
        name="Live tweak", default=True,
        description="Update the noise on the selected bones immediately as you "
                    "change parameters, instead of only on Apply")

    # NOTE: override=OVR is mandatory on EVERY PoseBone property. On a library
    # override rig (a linked character, the usual animation setup) Blender only
    # saves the properties flagged overridable; the rest snap back to the
    # library value on each file open. Before 8.2.5 these three lacked it, so
    # every reopen/revert dropped the group membership and the helper
    # pointers, and the frame handler then built a fresh `.001` empty pair.
    bpy.types.PoseBone.sb_group = bpy.props.EnumProperty(update=_sb_param_changed, options=OPT, 
        name="Group", items=_group_enum_items,
        description="Spring Bones group this bone belongs to", override=OVR)

    # Persistent references keep helper ownership independent of object/bone
    # names, including two rigs with identically named bones.
    bpy.types.PoseBone.sb_loc_helper = bpy.props.PointerProperty(
        type=bpy.types.Object, override=OVR)
    bpy.types.PoseBone.sb_loc_target = bpy.props.PointerProperty(
        type=bpy.types.Object, override=OVR)

    bpy.types.PoseBone.sb_bone_spring_loc = bpy.props.BoolProperty(options=OPT, 
        name="Location Spring", default=False,
        description="Enable position-based spring on this bone",
        update=update_bone, override=OVR)
    bpy.types.PoseBone.sb_stiffness = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Stiffness", default=0.35, min=0.0, max=1.0,
        description="Spring stiffness — higher returns to rest faster (firmer). "
                    "Lower = looser, heavier jiggle", override=OVR)
    bpy.types.PoseBone.sb_damp = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Damping", default=0.4, min=0.0, max=1.0,
        description="Damping — higher settles quickly with little bounce; "
                    "lower lets it wobble longer", override=OVR)
    bpy.types.PoseBone.sb_loc_speed = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Speed", default=0.0, min=0.0, max=1.0,
        description="Spring SPEED — pure frequency boost for the location "
                    "spring (up to ~3x, capped to what your frame rate can show "
                    "smoothly). Faster also means tighter/smaller motion — for a "
                    "bigger jiggle lower the Stiffness or raise Move Range",
        override=OVR)
    bpy.types.PoseBone.sb_gravity = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Gravity", default=0.0, min=-100.0, max=100.0,
        description="Vertical force added to the spring. POSITIVE pulls DOWN "
                    "(it scales Blender's scene gravity, which already points "
                    "down); negative makes the bone float upward", override=OVR)
    bpy.types.PoseBone.sb_loc_influence = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Location Influence", default=1.0, min=0.0, max=1.0,
        description="Global influence of the location spring", override=OVR)
    bpy.types.PoseBone.sb_max_distance = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Max Distance", default=0.0,
        description="Maximum displacement from rest (0 = unlimited)", override=OVR)

    bpy.types.PoseBone.sb_bone_spring_rot = bpy.props.BoolProperty(options=OPT, 
        name="Rotation Spring", default=False,
        description="Enable inertia-based rotation spring on this bone",
        update=update_bone, override=OVR)
    bpy.types.PoseBone.sb_rot_stiffness = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Rot Stiffness", default=0.35, min=0.0, max=1.0,
        description="Rotation spring stiffness — higher returns faster (firmer); "
                    "lower = looser swing", override=OVR)
    bpy.types.PoseBone.sb_rot_damp = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Rot Damping", default=0.4, min=0.0, max=1.0,
        description="Rotation damping — higher settles quickly; "
                    "lower lets it swing longer", override=OVR)
    bpy.types.PoseBone.sb_rot_speed = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT,
        name="Speed", default=0.0, min=0.0, max=1.0,
        description="Rotation spring SPEED — pure frequency boost for the "
                    "swing (up to ~3x, capped to what your frame rate can "
                    "show smoothly). Faster also means a tighter/smaller "
                    "swing — for a wider one lower the Stiffness or raise "
                    "Swing Range",
        override=OVR)
    bpy.types.PoseBone.sb_rot_influence = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Rotation Influence", default=1.0, min=0.0, max=1.0,
        description="Global influence of the rotation spring", override=OVR)
    bpy.types.PoseBone.sb_rot_range = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Swing Range", default=1.0, min=0.0, max=4.0, soft_max=3.0,
        description="Multiplies the swing rotation angle. 1.0 = natural; "
                    "below 1 = shorter/subtler swing; above 1 = wider, more "
                    "dramatic swing",
        override=OVR)

    bpy.types.PoseBone.sb_loc_range = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Move Range", default=1.0, min=0.0, max=4.0, soft_max=3.0,
        description="Multiplies the location spring's displacement. 1.0 = "
                    "natural; below 1 = smaller/subtler motion; above 1 = "
                    "wider, more exaggerated movement",
        override=OVR)

    # ---- Noise (random secondary motion) ----
    bpy.types.PoseBone.sb_noise_enable = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT, 
        name="Noise", default=False,
        description="Add random procedural motion on top of the spring "
                    "simulation, for a more organic, less mechanical look",
        override=OVR)
    bpy.types.PoseBone.sb_noise_loc = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Noise Location", default=0.0, min=0.0, soft_max=0.2,
        description="Amplitude of the random location jitter (in world units)",
        override=OVR)
    bpy.types.PoseBone.sb_noise_rot = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Noise Rotation", default=0.0, min=0.0, soft_max=1.0,
        description="Amplitude of the random rotation jitter (radians of swing)",
        override=OVR)
    bpy.types.PoseBone.sb_noise_speed = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Noise Speed", default=1.0, min=0.0, soft_max=5.0,
        description="How fast the random motion evolves over time",
        override=OVR)
    bpy.types.PoseBone.sb_noise_seed = bpy.props.IntProperty(update=_sb_param_changed, options=OPT, 
        name="Noise Seed", default=0, min=0,
        description="Random seed; bones with the same seed move together, "
                    "different seeds move independently",
        override=OVR)

    # ---- Advanced dynamics (v7): hair / cloth oriented ----
    bpy.types.PoseBone.sb_stiff_axis = bpy.props.FloatVectorProperty(update=_sb_param_changed, options=OPT, 
        name="Axis Stiffness", default=(1.0, 1.0, 1.0), size=3,
        min=0.0, soft_max=2.0,
        description="Per-axis stiffness multiplier in the bone's LOCAL axes "
                    "(X, Y, Z). E.g. (1, 1, 0.3) lets cloth swing freely on "
                    "its local Z while staying firm on X/Y",
        override=OVR)
    bpy.types.PoseBone.sb_air_drag = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Air Drag", default=0.0, min=0.0, max=1.0,
        description="Air resistance: damps the bone's ABSOLUTE motion through "
                    "the air (unlike Damping, which is relative to the body). "
                    "Gives hair/cloth a floaty, braked feel",
        override=OVR)
    bpy.types.PoseBone.sb_wind_influence = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Wind Influence", default=1.0, min=0.0, soft_max=2.0,
        description="How strongly the scene wind (SpringFX Wind panel) pushes "
                    "this bone. 0 = ignores wind",
        override=OVR)
    bpy.types.PoseBone.sb_smooth = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Smooth (HF Damping)", default=0.0, min=0.0, max=1.0,
        description="Low-pass filter on the spring output. Rarely needed "
                    "since 8.0.1: the solver now uses the closed-form "
                    "solution of the spring instead of integrating it, so "
                    "there is no step-size jitter left to filter. Measured "
                    "on the reference rig, raising this from 0 to 0.5 "
                    "INCREASES normalised jerk from 0.172 to 0.269, because "
                    "the filter adds phase lag of its own. Leave at 0 unless "
                    "you are deliberately damping a genuinely fast motion",
        override=OVR)
    bpy.types.PoseBone.sb_lag = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Lag / Delay", default=0.0, min=0.0, max=1.0,
        description="Follow-through delay: the spring chases a delayed copy of "
                    "its target, so motion trails behind the body",
        override=OVR)
    bpy.types.PoseBone.sb_chain_falloff = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Chain Falloff", default=0.0, min=0.0, max=1.0,
        description="Stiffness falloff along a chain of spring bones: the root "
                    "keeps full stiffness, tips get up to 85% looser — ponytails "
                    "whip at the end, capes flow at the hem",
        override=OVR)
    bpy.types.PoseBone.sb_auto_length = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT, 
        name="Auto Bone-Size Tuning", default=False,
        description="Automatically soften springs on long bones and stiffen "
                    "them on short ones (normalized at 25 cm), so one preset "
                    "reads the same across differently sized bones",
        override=OVR)

    bpy.types.PoseBone.sb_bone_collider  = bpy.props.BoolProperty(options=OPT, 
        name="Collider", default=False,
        description="Use this bone as a collider (a capsule from head to tail) "
                    "that other spring bones bump into",
        update=update_bone, override=OVR)
    bpy.types.PoseBone.sb_collider_dist  = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Collider Radius", default=0.5, min=0.0, soft_max=2.0,
        description="Radius of this bone's collision capsule (world units)",
        override=OVR)
    bpy.types.PoseBone.sb_collider_force = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Collider Hardness", default=1.0, min=0.0, max=1.0,
        description="How hard this collider pushes: 1.0 = solid (no penetration), "
                    "lower = softer contact that lets the flesh sink in", override=OVR)
    bpy.types.PoseBone.sb_collide        = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT, name="Colliding", default=True,
        description="This bone's flesh reacts to colliders", override=OVR)
    bpy.types.PoseBone.sb_colliding_dist = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Collide Radius", default=0.0, min=0.0, soft_max=1.0,
        description="Thickness of this bone's flesh for collision — the point is "
                    "kept this far from every collider surface (world units)",
        override=OVR)
    bpy.types.PoseBone.sb_include_only   = bpy.props.StringProperty(update=_sb_param_changed, options=OPT, 
        name="Include only", default="*",
        description="Only collide with colliders whose name appears here "
                    "(comma-separated, '*' = all)", override=OVR)
    bpy.types.PoseBone.sb_collide_exclude = bpy.props.StringProperty(update=_sb_param_changed, options=OPT, 
        name="Exclude", default="",
        description="Never collide with colliders whose name appears here "
                    "(comma-separated). Applied after 'Include only'",
        override=OVR)
    bpy.types.PoseBone.sb_collide_margin = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Collision Margin", default=0.0, min=0.0, soft_max=0.2,
        description="Extra safety distance kept from every collider surface, "
                    "on top of the Collide Radius (world units)", override=OVR)
    bpy.types.PoseBone.sb_collide_stiffness = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Collision Stiffness", default=1.0, min=0.0, max=1.0,
        description="How firmly this bone is pushed out of colliders: "
                    "1 = rigid contact, lower = the surface gives a little",
        override=OVR)
    bpy.types.PoseBone.sb_collide_damping = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Damping on Collision", default=0.2, min=0.0, max=1.0,
        description="Extra velocity loss on every impact — higher values make "
                    "contacts settle quickly instead of buzzing against the "
                    "surface", override=OVR)
    bpy.types.PoseBone.sb_collide_friction_mult = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Friction Multiplier", default=1.0, min=0.0, soft_max=2.0,
        description="Scales the collider's friction for this bone: 0 = always "
                    "slides freely, above 1 = extra grip", override=OVR)
    bpy.types.PoseBone.sb_self_collision = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT, 
        name="Self Collision", default=False,
        description="This bone keeps a sphere of personal space (Collide "
                    "Radius) against every other spring bone. Needs the "
                    "global Self Collision switch in the Collisions panel",
        override=OVR)
    bpy.types.PoseBone.sb_lock_axis      = bpy.props.EnumProperty(update=_sb_param_changed, options=OPT, 
        items=(('NONE','None',""),('+X','+X',''),('-X','-X',''),
               ('+Y','+Y',''),('-Y','-Y',''),('+Z','+Z',''),('-Z','-Z','')),
        default="NONE", override=OVR)

    # ---- per-bone collider response overrides ----
    bpy.types.PoseBone.sb_collider_use_own_response = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT, 
        name="Per-Collider Response", default=False,
        description="Override the global Bounce / Friction for this bone collider",
        override=OVR)
    bpy.types.PoseBone.sb_collider_bounce = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Bounce", default=0.0, min=0.0, max=1.0,
        description="Restitution for this bone collider (overrides global)",
        override=OVR)
    bpy.types.PoseBone.sb_collider_friction = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Friction", default=0.5, min=0.0, max=1.0,
        description="Tangential friction for this bone collider (overrides global)",
        override=OVR)

    bpy.types.Object.sb_object_collider = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT, 
        name="Collider", default=False,
        description="Make this object a collider for the spring bones", override=OVR)
    bpy.types.Object.sb_collider_shape  = bpy.props.EnumProperty(update=_sb_param_changed, options=OPT, 
        name="Shape",
        items=(('SPHERE',  'Sphere',  "Sphere at the object's origin, sized by Radius"),
               ('CAPSULE', 'Capsule', "Capsule along the object's local Y axis (scale Y for length), sized by Radius"),
               ('PLANE',   'Plane',   "Infinite plane through the origin, facing the object's local +Z (e.g. a floor)"),
               ('BOX',     'Box',     "Box spanning the object's local -1..+1 cube (scale the object to size it); Radius adds rounding"),
               ('MESH',    'Mesh',    "Collide against the actual mesh surface (BVH-accelerated, cached for rigid meshes)")),
        default='SPHERE',
        description="How this object is interpreted as a collider", override=OVR)
    bpy.types.Object.sb_collider_dist   = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Radius", default=0.5, min=0.0, soft_max=2.0,
        description="Sphere/capsule radius, or surface margin for mesh/plane colliders "
                    "(world units)", override=OVR)
    bpy.types.Object.sb_collider_force  = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Hardness", default=1.0, min=0.0, max=1.0,
        description="How hard this collider pushes: 1.0 = solid, lower = softer contact",
        override=OVR)
    bpy.types.Object.sb_collider_use_own_response = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT, 
        name="Per-Collider Response", default=False,
        description="Override the global Bounce / Friction for this collider",
        override=OVR)
    bpy.types.Object.sb_collider_bounce = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Bounce", default=0.0, min=0.0, max=1.0,
        description="Restitution for this collider (overrides global)", override=OVR)
    bpy.types.Object.sb_collider_friction = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Friction", default=0.5, min=0.0, max=1.0,
        description="Tangential friction for this collider (overrides global)",
        override=OVR)

    # ---- global collision settings ----
    bpy.types.Scene.sb_collision_enable = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT, 
        name="Enable Collision", default=True,
        description="Master switch for all spring-bone collision")
    bpy.types.Scene.sb_collide_bounce = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Bounce", default=0.0, min=0.0, max=1.0,
        description="Global restitution on impact: 0 = dead stop, 1 = elastic bounce. "
                    "Individual colliders can override this.")
    bpy.types.Scene.sb_collide_friction = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Friction", default=0.5, min=0.0, max=1.0,
        description="Global tangential damping: 0 = slides freely, 1 = grips. "
                    "Individual colliders can override this.")
    bpy.types.Scene.sb_collide_iterations = bpy.props.IntProperty(update=_sb_param_changed, options=OPT, 
        name="Iterations", default=2, min=1, max=8,
        description="Collision resolve passes per sub-step. Higher = cleaner when "
                    "several colliders overlap, at some performance cost.")
    bpy.types.Scene.sb_draw_colliders = bpy.props.BoolProperty(options=OPT, 
        name="Show Colliders (Viewport)", default=False,
        description="Draw capsule/sphere/plane outlines for all active colliders "
                    "in the 3D viewport (orange overlay)")
    bpy.types.Scene.sb_collide_use_physics_objects = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT, 
        name="Use Blender Collision Objects", default=True,
        description="Meshes with Blender's own Collision physics enabled "
                    "automatically act as SpringFX mesh colliders (their "
                    "Outer thickness becomes the surface margin)")
    bpy.types.Scene.sb_collide_ignore_own_mesh = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT,
        name="Ignore Own Mesh", default=True,
        description="A spring bone does not collide with a mesh collider that "
                    "it deforms itself (hair against its own hair cards, a "
                    "breast bone against the body it shapes). That surface "
                    "moves with the bone, so colliding with it only fights "
                    "the simulation")
    bpy.types.Scene.sb_self_collision_enable = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT, 
        name="Self Collision", default=False,
        description="Master switch: spring bones with Self Collision enabled "
                    "keep a sphere of personal space against each other")

    # ---- bake pre-roll + constraint handling ----
    bpy.types.Scene.sb_preroll_viewport = bpy.props.BoolProperty(
        options=OPT, update=_sb_param_changed,
        name="Settle on Start", default=False,
        description="Let gravity settle the springs before the first frame "
                    "plays, instead of starting them at the bone's rest pose. "
                    "Removes the small pop you see when scrubbing to the start "
                    "of a shot with heavy hair or cloth")
    bpy.types.Scene.sb_preroll_viewport_frames = bpy.props.IntProperty(
        options=OPT, update=_sb_param_changed,
        name="Settle Steps", default=20, min=1, max=200,
        description="How many extra physics steps to run against a static "
                    "pose before playback starts")
    bpy.types.Scene.sb_preroll_enable = bpy.props.BoolProperty(options=OPT, 
        name="Pre-Roll", default=False,
        description="Simulate extra frames before baking to let springs settle "
                    "into a steady periodic state — eliminates the cold-start "
                    "artifact at the beginning of looping clips")
    bpy.types.Scene.sb_preroll_frames = bpy.props.IntProperty(options=OPT, 
        name="Pre-Roll Frames", default=60, min=1, max=1000,
        description="Number of warm-up frames to simulate before the bake starts. "
                    "For a loop, one full pass (frame_end - frame_start + 1) is "
                    "usually enough; use 2-3× for aggressive springs")
    bpy.types.Scene.sb_bake_mute_constraints = bpy.props.BoolProperty(options=OPT, 
        name="Apply Other Constraints", default=True,
        description="After baking, mute the bones' remaining constraints (e.g. a "
                    "Transformation constraint that ran before the spring). Their "
                    "effect is already captured in the baked keyframes by visual "
                    "keying — leaving them enabled would apply them twice")

    # ---- wind (scene-level; per-bone influence above) ----
    bpy.types.Scene.sb_wind_enable = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT, 
        name="Wind", default=False,
        description="Enable the global SpringFX wind that pushes spring bones "
                    "(scaled per bone/group by Wind Influence)")
    bpy.types.Scene.sb_wind_vector = bpy.props.FloatVectorProperty(update=_sb_param_changed, options=OPT, 
        name="Direction", default=(1.0, 0.0, 0.0), size=3, subtype='XYZ',
        description="World-space wind direction (magnitude is ignored; use "
                    "Strength)")
    bpy.types.Scene.sb_wind_strength = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Strength", default=2.0, min=0.0, soft_max=50.0,
        description="Wind force strength")
    bpy.types.Scene.sb_wind_turbulence = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Turbulence", default=0.3, min=0.0, max=1.0,
        description="Gusting: modulates the wind strength and direction with "
                    "smooth noise so it feels alive instead of constant")
    bpy.types.Scene.sb_wind_speed = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Gust Speed", default=1.0, min=0.0, soft_max=5.0,
        description="How fast the turbulence gusts evolve over time")

    # ---- performance / quality (v7.3) ----
    _quality_items = (
        ('LOW',    "Low (Fast)",     "1+ substeps — fastest, use while animating / for interactive tweaking"),
        ('MEDIUM', "Medium",         "2+ substeps — good balance for viewport playback"),
        ('HIGH',   "High",           "4+ substeps — full accuracy (pre-7.3 behavior)"),
        ('ULTRA',  "Ultra",          "8+ substeps, double collision iterations — final-quality checks"),
    )
    bpy.types.Scene.sb_quality = bpy.props.EnumProperty(update=_sb_param_changed, options=OPT, 
        name="Viewport Precision", items=_quality_items, default='HIGH',
        description="Physics ACCURACY in the viewport: how finely each frame is sub-stepped. Measured on 120 bones, Low is only ~4% faster than High (~10% with colliders) -- integration is not the bottleneck, so treat this as a precision dial, not a speed one. For real speed use Update Rate, Skip Hidden/Far, or Bake to Cache. Bakes and renders use Render Precision instead")
    bpy.types.Scene.sb_render_quality = bpy.props.EnumProperty(options=OPT, 
        name="Render / Bake Precision", items=_quality_items, default='HIGH',
        description="Quality used by Bake Spring to Keyframes (and renders), "
                    "regardless of the viewport setting")
    bpy.types.Scene.sb_substeps_override = bpy.props.IntProperty(update=_sb_param_changed, options=OPT, 
        name="Substeps Override", default=0, min=0, max=64,
        description="0 = automatic (from Quality). Otherwise forces this "
                    "many physics substeps per frame in the viewport")
    bpy.types.Scene.sb_update_rate = bpy.props.IntProperty(update=_sb_param_changed, options=OPT, 
        name="Update Rate", default=1, min=1, max=4,
        description="Simulate every Nth frame DURING PLAYBACK only (bones "
                    "hold their pose in between; the sim catches up "
                    "deterministically). Scrubbing and baking always "
                    "simulate every frame")
    bpy.types.Scene.sb_skip_hidden = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT, 
        name="Skip Hidden Armatures", default=True,
        description="Don't simulate bones of HIDDEN armature objects — they "
                    "freeze at their last pose. Individually hidden bones "
                    "keep simulating (they still deform the visible mesh)")
    bpy.types.Scene.sb_skip_far = bpy.props.BoolProperty(update=_sb_param_changed, options=OPT, 
        name="Skip Far Bones", default=False,
        description="Don't simulate bones farther than Max Distance from "
                    "the viewport camera — they freeze at their last pose")
    bpy.types.Scene.sb_far_distance = bpy.props.FloatProperty(update=_sb_param_changed, options=OPT, 
        name="Max Distance", default=50.0, min=1.0, soft_max=500.0,
        description="Camera distance beyond which spring bones stop "
                    "simulating (when Skip Far Bones is on)")
    bpy.types.Scene.sb_cache_enable = bpy.props.BoolProperty(
        name="Simulation Cache", default=True,
        description="Store each simulated frame so scrubbing back replays the "
                    "exact same motion. Costs a little memory and ~10% per "
                    "frame; turn off for maximum playback speed",
        update=lambda self, ctx: _sb_core.set_cache_enabled(self.sb_cache_enable),
        options={'ANIMATABLE', 'LIBRARY_EDITABLE'},
        override={'LIBRARY_OVERRIDABLE'})
    bpy.types.Scene.sb_show_perf = bpy.props.BoolProperty(options=OPT, 
        name="Show Performance", default=False,
        description="Display simulation time and bone counts in the panel")

    # ---- UI-only toggles ----
    bpy.types.Scene.sb_ui_show_advanced = bpy.props.BoolProperty(options=OPT, 
        name="Advanced Dynamics", default=False,
        description="Show the advanced hair/cloth dynamics parameters")


_SCENE_PROPS = (
    'sb_spring_bones', 'sb_mesh_colliders', 'sb_bone_groups',
    'sb_user_presets', 'sb_preset_favorites', 'sb_active_group_index',
    'sb_show_colliders',
    'sb_nmod_loc', 'sb_nmod_rot', 'sb_nmod_live',
    'sb_collision_enable', 'sb_collide_bounce', 'sb_collide_friction',
    'sb_collide_iterations', 'sb_draw_colliders',
    'sb_preroll_enable', 'sb_preroll_frames', 'sb_bake_mute_constraints',
    'sb_wind_enable', 'sb_wind_vector', 'sb_wind_strength',
    'sb_wind_turbulence', 'sb_wind_speed',
    'sb_ui_show_advanced',
    'sb_collide_use_physics_objects', 'sb_collide_ignore_own_mesh',
    'sb_self_collision_enable',
    'sb_quality', 'sb_render_quality', 'sb_substeps_override',
    'sb_update_rate', 'sb_skip_hidden', 'sb_skip_far', 'sb_far_distance',
    'sb_show_perf',
)

_POSEBONE_PROPS = (
    'sb_group',
    'sb_loc_helper', 'sb_loc_target',
    'sb_bone_spring_loc', 'sb_stiffness', 'sb_damp', 'sb_loc_speed',
    'sb_gravity', 'sb_loc_influence', 'sb_max_distance', 'sb_loc_range',
    'sb_bone_spring_rot', 'sb_rot_stiffness', 'sb_rot_damp', 'sb_rot_speed',
    'sb_rot_influence', 'sb_rot_range',
    'sb_noise_enable', 'sb_noise_loc', 'sb_noise_rot',
    'sb_noise_speed', 'sb_noise_seed',
    'sb_stiff_axis', 'sb_air_drag', 'sb_wind_influence',
    'sb_smooth', 'sb_lag', 'sb_chain_falloff', 'sb_auto_length',
    'sb_bone_collider', 'sb_collider_dist', 'sb_collider_force',
    'sb_collider_use_own_response', 'sb_collider_bounce', 'sb_collider_friction',
    'sb_collide', 'sb_colliding_dist', 'sb_include_only', 'sb_lock_axis',
    'sb_collide_exclude', 'sb_collide_margin', 'sb_collide_stiffness',
    'sb_collide_damping', 'sb_collide_friction_mult', 'sb_self_collision',
)

_OBJECT_PROPS = (
    'sb_object_collider', 'sb_collider_shape', 'sb_collider_dist',
    'sb_collider_force', 'sb_collider_use_own_response',
    'sb_collider_bounce', 'sb_collider_friction',
)


def unregister():
    from bpy.utils import unregister_class

    for p in _SCENE_PROPS:
        try:
            delattr(bpy.types.Scene, p)
        except AttributeError:
            pass
    for p in _POSEBONE_PROPS:
        try:
            delattr(bpy.types.PoseBone, p)
        except AttributeError:
            pass
    for p in _OBJECT_PROPS:
        try:
            delattr(bpy.types.Object, p)
        except AttributeError:
            pass

    for cls in reversed(classes):
        unregister_class(cls)
