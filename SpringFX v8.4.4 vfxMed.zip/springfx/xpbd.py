# SpringFX - xpbd.py
# Chain solver: particles + XPBD constraints + SEGMENT collision.
#
# WHY THIS REPLACES THE PER-BONE PENDULUM
# ---------------------------------------
# Until 7.4 every bone was an independent pendulum that collided a single
# POINT (its tail) and was then re-projected onto a sphere of radius
# bone-length around its head. Two problems, both measured:
#
#   1. A point test lets the SEGMENT cut through a collider. Measured on a
#      24-bone rig against two spheres: 125 penetrating samples, up to
#      115 mm deep. BoneDynamics Pro, riding Blender's cloth solver (which
#      collides edges), reached 0 on the same rig.
#
#   2. The pushout and the pendulum re-projection fight each other, and
#      60% of penetrations had the bone HEAD already inside the collider --
#      unfixable locally, because the head belongs to the parent.
#
# Modelling the chain as particles with distance constraints fixes both at
# the root. When collision pushes a joint out, the distance constraint
# propagates the correction to its neighbours on the next iteration, so the
# head is no longer "owned" by the parent: it is just another particle.
#
# This is the same formulation cloth, PhysBones and every PBD/XPBD solver
# uses. Reference: Muller et al., "Position Based Dynamics" (2007);
# Macklin et al., "XPBD" (2016).

import math
from mathutils import Vector, Quaternion

# Constraint iterations per quality level. Unlike substeps -- which measured
# a 4-10% spread and were effectively a no-op -- these dominate XPBD cost and
# quality, so the Quality dial finally means something.
SOLVER_ITERS = {"LOW": 1, "MEDIUM": 2, "HIGH": 4, "ULTRA": 8}

# Root-inside-collider policy. Happens constantly on real rigs: hair whose
# first bone starts under the scalp, clothing rooted inside the torso. The
# root particle is kinematic (the animation owns it), so the solver cannot
# push it out and the whole chain inherits the error.
ROOT_POLICY_IGNORE = "IGNORE"    # disable collision while the root is inside
ROOT_POLICY_PROJECT = "PROJECT"  # test from a surface-projected virtual root


# ------------------------------------------------------------------ #
#  SEGMENT INTERSECTION TESTS
# ------------------------------------------------------------------ #
# Every test returns (s, depth, normal) or None:
#   s      -- parameter 0..1 of the deepest point along the segment
#   depth  -- penetration depth (> 0)
#   normal -- unit push-out direction

def seg_vs_sphere(h, t, bone_r, c, r):
    """Segment [h,t] with thickness bone_r against a sphere (c, r)."""
    d = t - h
    dd = d.dot(d)
    s = 0.0 if dd < 1e-12 else min(max((c - h).dot(d) / dd, 0.0), 1.0)
    off = (h + d * s) - c
    dist = off.length
    total = r + bone_r
    if dist >= total:
        return None
    n = off / dist if dist > 1e-9 else Vector((0.0, 0.0, 1.0))
    return s, total - dist, n


def _closest_seg_seg(p1, q1, p2, q2):
    """Closest points between two segments. Returns (s, t, c1, c2).

    Ericson, Real-Time Collision Detection, 5.1.9. Handles the degenerate
    parallel and zero-length cases, which matter here because a sphere
    collider is stored as a capsule with p0 == p1.
    """
    d1 = q1 - p1
    d2 = q2 - p2
    r = p1 - p2
    a = d1.dot(d1)
    e = d2.dot(d2)
    f = d2.dot(r)
    if a <= 1e-12 and e <= 1e-12:
        return 0.0, 0.0, p1, p2
    if a <= 1e-12:
        s = 0.0
        t = min(max(f / e, 0.0), 1.0)
    else:
        c = d1.dot(r)
        if e <= 1e-12:
            t = 0.0
            s = min(max(-c / a, 0.0), 1.0)
        else:
            b = d1.dot(d2)
            denom = a * e - b * b
            s = min(max((b * f - c * e) / denom, 0.0), 1.0) if denom > 1e-12 else 0.0
            t = (b * s + f) / e
            if t < 0.0:
                t = 0.0
                s = min(max(-c / a, 0.0), 1.0)
            elif t > 1.0:
                t = 1.0
                s = min(max((b - c) / a, 0.0), 1.0)
    return s, t, p1 + d1 * s, p2 + d2 * t


def seg_vs_capsule(h, t, bone_r, c0, c1, r):
    """Segment against a capsule. A sphere collider arrives as c0 == c1."""
    s, _t, pa, pb = _closest_seg_seg(h, t, c0, c1)
    off = pa - pb
    dist = off.length
    total = r + bone_r
    if dist >= total:
        return None
    n = off / dist if dist > 1e-9 else Vector((0.0, 0.0, 1.0))
    return s, total - dist, n


def seg_vs_plane(h, t, bone_r, point, normal):
    """Segment against a half-space. The deepest endpoint wins."""
    dh = (h - point).dot(normal) - bone_r
    dt = (t - point).dot(normal) - bone_r
    if dh >= 0.0 and dt >= 0.0:
        return None
    if dh < dt:
        return 0.0, -dh, normal.copy()
    return 1.0, -dt, normal.copy()


def seg_vs_box(h, t, bone_r, mw, mw_inv, m3_invT, margin, samples=3):
    """Segment against an oriented box, sampled along its length.

    An exact segment-vs-OBB test would be cheaper per call but far more code
    for a collider type that is rare in rigs. Sampling keeps the shared
    return contract and is accurate to segment_length / (samples - 1).
    """
    best = None
    for k in range(samples):
        u = k / (samples - 1) if samples > 1 else 0.0
        wp = h.lerp(t, u)
        lp = mw_inv @ wp
        # closest point on the unit box, in local space
        cl = Vector((min(max(lp.x, -1.0), 1.0),
                     min(max(lp.y, -1.0), 1.0),
                     min(max(lp.z, -1.0), 1.0)))
        inside = (cl - lp).length_squared < 1e-18
        if inside:
            # push out through the nearest face
            dists = (1.0 - abs(lp.x), 1.0 - abs(lp.y), 1.0 - abs(lp.z))
            ax = dists.index(min(dists))
            cl = lp.copy()
            cl[ax] = 1.0 if lp[ax] >= 0.0 else -1.0
        wc = mw @ cl
        off = wp - wc
        dist = off.length
        depth = (margin + bone_r) - dist if not inside else (margin + bone_r) + dist
        if depth <= 0.0:
            continue
        n = (off / dist) if (dist > 1e-9 and not inside) else (m3_invT @ (cl - lp)).normalized()
        if best is None or depth > best[1]:
            best = (u, depth, n)
    return best


def seg_vs_mesh(h, t, bone_r, bvh, mw, mw_inv, m3_invT, margin, samples=3):
    """Segment against a BVH, sampled along its length.

    Measured: a static mesh collider with a cached BVH costs +1.28 ms per
    frame on 120 bones, against +1.04 ms for two primitives combined. It is
    the expensive shape, which is why the Low quality level drops it.
    """
    best = None
    rad = margin + bone_r
    # NOTE (8.2.7): world bounds of the collider (core._SBMeshBVH). A sample
    # farther than `rad` outside them cannot touch the mesh, and skipping it
    # also keeps the BVH from being built when no sample ever gets close.
    lo = getattr(bvh, "wlo", None)
    hi = bvh.whi if lo is not None else None
    for k in range(samples):
        u = k / (samples - 1) if samples > 1 else 0.0
        wp = h.lerp(t, u)
        if lo is not None and (
                wp.x < lo.x - rad or wp.x > hi.x + rad
                or wp.y < lo.y - rad or wp.y > hi.y + rad
                or wp.z < lo.z - rad or wp.z > hi.z + rad):
            continue
        lp = mw_inv @ wp
        hit = bvh.find_nearest(lp)
        if hit is None or hit[0] is None:
            continue
        loc, nrm, _idx, _dist = hit
        wl = mw @ loc
        wn = (m3_invT @ nrm).normalized()
        off = wp - wl
        signed = off.dot(wn)
        depth = rad - signed
        if depth <= 0.0:
            continue
        if best is None or depth > best[1]:
            best = (u, depth, wn)
    return best


def hit_test(h, t, bone_r, col, kind):
    """Dispatch one collider entry from core._sb_gather_colliders()."""
    if kind == "caps":
        return seg_vs_capsule(h, t, bone_r, col[0], col[1], col[2])
    if kind == "planes":
        return seg_vs_plane(h, t, bone_r, col[0], col[1])
    if kind == "boxes":
        return seg_vs_box(h, t, bone_r, col[0], col[1], col[2], col[3])
    if kind == "meshes":
        return seg_vs_mesh(h, t, bone_r, col[0], col[1], col[2], col[3], col[4])
    return None


# ------------------------------------------------------------------ #
#  CHAIN SOLVE
# ------------------------------------------------------------------ #

def chain_bounds(P, radii):
    """Centre and radius of the chain's bounding sphere.

    Cheap early-out: if the bounding sphere does not touch a collider, none of
    the chain's bones can, which saves n segment tests per collider.
    """
    lo = Vector(P[0])
    hi = Vector(P[0])
    for p in P:
        for k in range(3):
            if p[k] < lo[k]:
                lo[k] = p[k]
            if p[k] > hi[k]:
                hi[k] = p[k]
    c = (lo + hi) * 0.5
    return c, (hi - lo).length * 0.5 + max(radii)


def prefilter(P, radii, colliders):
    """Drop the colliders the chain's bounding sphere cannot reach."""
    if not colliders:
        return ()
    c, r = chain_bounds(P, radii)
    out = []
    for kind, col in colliders:
        if kind == "caps":
            c0 = col[0]
            if c0 is col[1] or (col[1] - c0).length_squared < 1e-12:
                near = c0                      # sphere: skip the segment math
            else:
                near = _closest_seg_seg(c, c, c0, col[1])[3]
            if (near - c).length <= r + col[2]:
                out.append((kind, col))
        elif kind == "meshes":
            # NOTE (8.2.7): sphere vs the mesh's world AABB grown by its
            # margin (core._SBMeshBVH). 8.2.6 had no early-out for meshes, so
            # every chain tested every mesh collider in the scene.
            bvh = col[0]
            lo = getattr(bvh, "wlo", None)
            if lo is not None:
                hi = bvh.whi
                dx = max(lo.x - c.x, 0.0, c.x - hi.x)
                dy = max(lo.y - c.y, 0.0, c.y - hi.y)
                dz = max(lo.z - c.z, 0.0, c.z - hi.z)
                reach = r + max(col[4], 0.0)
                if dx * dx + dy * dy + dz * dz > reach * reach:
                    continue
            out.append((kind, col))
        else:
            out.append((kind, col))      # planes/boxes: no early-out
    return out


def solve_chain(P, lengths, radii, colliders, iters, stiffness,
                root_locked=True, max_correction=None, cdelta=None):
    """Gauss-Seidel solve of one chain, in place on P.

    P        -- [Vector] joint positions; P[0] is the chain root head
    lengths  -- rest world length of each bone
    radii    -- collision radius of each bone
    colliders-- [(kind, tuple)] from core._sb_gather_colliders()
    iters    -- constraint iterations (Quality)
    stiffness-- 0..1 collision compliance; 1.0 = rigid contact

    Both sweep directions matter. Root->tip alone drags the accumulated
    error outward -- exactly the cascade measured in 7.4, where the tip
    ended up 115 mm inside. The return sweep redistributes it.
    """
    n = len(P) - 1
    if n < 1:
        return
    colliders = prefilter(P, radii, colliders)

    # No collider within reach of the chain's bounding sphere: the only
    # constraint left is distance, and the hard root->tip projection below
    # satisfies it EXACTLY in one pass. Running Gauss-Seidel first would
    # change nothing. Most chains on most frames take this path -- measured
    # 23040 _solve_link calls over a 120-frame sweep, nearly all of them
    # doing no collision work at all.
    if not colliders:
        for i in range(n):
            d = P[i + 1] - P[i]
            ln = d.length
            if ln > 1e-9:
                P[i + 1] = P[i] + d * (lengths[i] / ln)
        return

    for _ in range(iters):
        for i in range(n):
            _solve_link(P, lengths, radii, i, colliders, stiffness,
                        root_locked, max_correction, cdelta)
        for i in range(n - 1, -1, -1):
            _solve_link(P, lengths, radii, i, colliders, stiffness,
                        root_locked, max_correction, cdelta)

    # Final hard projection, root -> tip. Gauss-Seidel leaves the distance
    # constraints only approximately satisfied, and a bone chain can ONLY
    # represent configurations where every segment is exactly its rest
    # length from a fixed root -- otherwise converting back to rotations
    # silently discards the difference. Directions are preserved, so the
    # collision result survives; only the lengths get snapped.
    for i in range(n):
        d = P[i + 1] - P[i]
        ln = d.length
        if ln > 1e-9:
            P[i + 1] = P[i] + d * (lengths[i] / ln)

    resolve_tangential(P, lengths, radii, colliders)


def resolve_tangential(P, lengths, radii, colliders, passes=4):
    """Final contact pass a rotation-only chain can actually reproduce.

    The projection above has to run last, but it re-anchors every head to its
    parent's tip and can push a segment back through a surface the collision
    sweeps had already cleared. Measured residual on the bench before this
    pass: 0.70 mm on the hair tip; after: 1.2e-5 mm, i.e. nothing.

    Walking root -> tip means each head is already final, so only the TIP
    moves, and the exact bone length is re-imposed about the head after every
    push -- the segment rotates instead of stretching, which is the only
    motion the bone can be given, so nothing downstream undoes it. A contact
    at parameter s needs the tip to travel depth/s to clear it.

    It cannot help when the HEAD is inside a collider: that head belongs to
    the parent, and the chain root's is kinematic. root_inside() reports
    those instead of half-solving them.
    """
    n = len(P) - 1
    for i in range(n):
        h = P[i]
        L = lengths[i]
        r = radii[i]
        for _ in range(passes):
            hit_any = False
            for kind, col in colliders:
                hit = hit_test(h, P[i + 1], r, col, kind)
                if hit is None:
                    continue
                s, depth, nrm = hit
                if depth <= 1e-12:
                    continue
                hit_any = True
                P[i + 1] = P[i + 1] + nrm * (depth / s if s > 0.10 else depth * 10.0)
                d = P[i + 1] - h
                ln = d.length
                if ln > 1e-9:
                    P[i + 1] = h + d * (L / ln)
            if not hit_any:
                break


def _solve_link(P, lengths, radii, i, colliders, stiffness, root_locked,
                max_correction, cdelta=None):
    h = P[i]
    t = P[i + 1]
    br = radii[i]

    # --- 1) SEGMENT collision -------------------------------------------
    for kind, col in colliders:
        hit = hit_test(h, t, br, col, kind)
        if hit is None:
            continue
        s, depth, nrm = hit
        if max_correction is not None and depth > max_correction:
            depth = max_correction
        push = nrm * (depth * stiffness)
        # Distribute by where along the segment the contact landed. The head
        # of the FIRST link is kinematic and takes none; every other head
        # takes its share, which is what finally lets a bone whose head is
        # inside a collider get out.
        w_t = s
        w_h = (1.0 - s) if (i > 0 or not root_locked) else 0.0
        tot = w_h + w_t
        if tot < 1e-9:
            continue
        if w_h > 0.0:
            dh = push * (w_h / tot)
            P[i] = h = h + dh
            if cdelta is not None:
                cdelta[i] += dh
        dt_ = push * (w_t / tot)
        P[i + 1] = t = t + dt_
        if cdelta is not None:
            cdelta[i + 1] += dt_

    # --- 2) distance constraint (after collision, which breaks it) ------
    d = t - h
    ln = d.length
    if ln < 1e-9:
        return
    corr = d * ((ln - lengths[i]) / ln)
    if i > 0 or not root_locked:
        P[i] = h + corr * 0.5
        P[i + 1] = t - corr * 0.5
    else:
        P[i + 1] = t - corr


def root_inside(P0, radius, colliders):
    """Name of the first collider containing the (kinematic) chain root.

    Reported rather than silently absorbed: a chain rooted inside a collider
    cannot be resolved by any solver, and the user needs to know it is the
    rig, not the addon. This exact condition invalidated an entire round of
    collision measurements during development.
    """
    for kind, col in colliders:
        hit = hit_test(P0, P0, radius, col, kind)
        if hit is not None:
            return col[-1]
    return None


def swing_quaternions(P, rest_dirs):
    """Convert solved joint positions back to per-bone swing quaternions.

    rest_dirs[i] is bone i's rigid world direction for this frame, so the
    quaternion is the minimal arc from where the bone WOULD point to where
    the solved chain says it points -- zero twist, same convention the
    pre-XPBD solver used, so presets keep their meaning.
    """
    out = []
    for i in range(len(P) - 1):
        v = P[i + 1] - P[i]
        if v.length_squared < 1e-18:
            out.append(Quaternion((1.0, 0.0, 0.0, 0.0)))
            continue
        out.append(rest_dirs[i].rotation_difference(v.normalized()))
    return out
