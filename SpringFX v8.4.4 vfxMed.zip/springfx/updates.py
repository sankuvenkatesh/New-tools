# Auron3D in-Blender updates -- shared module.
#
# Copy this file unchanged into any Auron3D extension and set the three
# constants below. It needs no server of our own and no network permission:
# the store (Superhive) already publishes every purchased extension through a
# Blender remote repository, and Blender keeps that repository's index on
# disk. This module only reads that index, tells the user when a newer
# version of THIS add-on is listed there, and asks Blender to install it.
#
# NOTE: why not a self-hosted updater (the SimpleBake approach, a version
# file plus a zip on the author's own website): the zip would be public, so
# anyone could download the paid add-on, and it would bypass Superhive's
# support periods. Through the repository, each buyer only ever receives the
# versions their own purchase entitles them to.

import json
import os
import time

import bpy
import addon_utils

# --- per add-on configuration ------------------------------------------------
PREFIX = "sb"                      # operator prefix of the host add-on
ADDON_NAME = "SpringFX"            # name shown in the UI
STORE_HOST = "superhivemarket.com"  # the store's remote repository host
CONNECT_HELP_URL = ("https://support.superhivemarket.com/article/"
                    "335-connecting-superhive-as-a-remote-repository-in-blender")
# -----------------------------------------------------------------------------

_PKG = __package__                  # e.g. "bl_ext.user_default.springfx"
_HERE = os.path.dirname(os.path.abspath(__file__))
_RESCAN_SECONDS = 10.0
_state = {"t": 0.0, "status": None, "busy": False, "msg": "", "replaced": [], "shadowed_by": ""}
_index_cache = {}                   # index path -> (mtime, {pkg_id: version})


def _manifest():
    path = os.path.join(_HERE, "blender_manifest.toml")
    try:
        import tomllib
        with open(path, "rb") as f:
            return tomllib.load(f)
    except Exception:
        # NOTE: minimal fallback parser; only the top-level "key = value"
        # strings are needed here.
        data = {}
        try:
            for line in open(path, encoding="utf-8"):
                if line.startswith("["):
                    break
                if "=" in line:
                    k, v = line.split("=", 1)
                    data[k.strip()] = v.strip().strip('"')
        except Exception:
            pass
        return data


def _vtuple(v):
    out = []
    for part in str(v).split("."):
        num = ""
        for ch in part:
            if not ch.isdigit():
                break
            num += ch
        out.append(int(num) if num else 0)
    while len(out) < 3:
        out.append(0)
    return tuple(out[:3])


_MAN = _manifest()
PKG_ID = _MAN.get("id", "")
INSTALLED = str(_MAN.get("version", "0.0.0"))
PRODUCT_URL = _MAN.get("website", "")


def _repos():
    try:
        return list(bpy.context.preferences.extensions.repos)
    except Exception:
        return []


def _own_repo_module():
    parts = (_PKG or "").split(".")
    return parts[1] if len(parts) >= 3 and parts[0] == "bl_ext" else ""


def _index_versions(repo):
    path = os.path.join(repo.directory, ".blender_ext", "index.json")
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return {}, 0.0
    hit = _index_cache.get(path)
    if hit is not None and hit[0] == mtime:
        return hit[1], mtime
    vers = {}
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f).get("data", [])
        for p in data:
            pid = p.get("id")
            if pid:
                v = str(p.get("version", "0"))
                if pid not in vers or _vtuple(v) > _vtuple(vers[pid]):
                    vers[pid] = v
    except Exception:
        vers = {}
    _index_cache[path] = (mtime, vers)
    return vers, mtime


def status(force=False):
    """Update status of this add-on, recomputed at most every few seconds.

    Keys: available (str or None), repo_index, repo_name, same_repo,
    store_index (the store's remote repository, or -1), listed, own_index.
    """
    now = time.monotonic()
    st = _state["status"]
    if st is not None and not force and now - _state["t"] < _RESCAN_SECONDS:
        return st
    own_mod = _own_repo_module()
    st = {"available": None, "repo_index": -1, "repo_name": "", "same_repo": False,
          "store_index": -1, "listed": False, "own_index": -1, "checked": 0.0}
    best = _vtuple(INSTALLED)
    for i, r in enumerate(_repos()):
        if r.module == own_mod:
            st["own_index"] = i
        if not (r.enabled and r.use_remote_url):
            continue
        if STORE_HOST and STORE_HOST in (r.remote_url or "") and st["store_index"] < 0:
            st["store_index"] = i
        vers, mtime = _index_versions(r)
        v = vers.get(PKG_ID)
        if v is None:
            continue
        st["listed"] = True
        st["checked"] = max(st["checked"], mtime)
        if r.module == own_mod and st["store_index"] < 0:
            st["store_index"] = i
        if _vtuple(v) > best:
            best = _vtuple(v)
            st.update(available=v, repo_index=i, repo_name=r.name, same_repo=(r.module == own_mod))
    _state["status"] = st
    _state["t"] = now
    return st


def _online_ok(op):
    if bpy.app.online_access:
        return True
    op.report({'ERROR'}, "Online access is disabled: enable it in "
                         "Preferences > System > Network")
    return False


# --- operators ---------------------------------------------------------------

class _CheckOp:
    bl_label = "Check for Updates"
    bl_description = "Ask the store for the latest version of this add-on"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        if not _online_ok(self):
            return {'CANCELLED'}
        st = status(force=True)
        idx = st["store_index"] if st["store_index"] >= 0 else st["repo_index"]
        if idx < 0:
            self.report({'WARNING'}, "The store is not connected to Blender yet")
            return {'CANCELLED'}
        try:
            bpy.ops.extensions.repo_sync(repo_index=idx)
        except Exception as exc:
            self.report({'ERROR'}, "Could not reach the store: %s" % exc)
            return {'CANCELLED'}
        st = status(force=True)
        if st["available"]:
            self.report({'INFO'}, "%s %s is available" % (ADDON_NAME, st["available"]))
        else:
            self.report({'INFO'}, "%s %s is up to date" % (ADDON_NAME, INSTALLED))
        return {'FINISHED'}


def _do_update(repo_index, own_index, same_repo):
    """Install the listed version; returns (ok, message).

    Runs from a timer, never inside one of this add-on's operators: the
    update disables this very add-on, and an operator must not unregister
    its own class while it is executing.
    """
    _state["busy"] = True
    try:
        if same_repo:
            # Blender disables, replaces and re-enables the add-on itself.
            res = bpy.ops.extensions.package_install(repo_index=repo_index, pkg_id=PKG_ID,
                                                      enable_on_install=True)
            return ('FINISHED' in res), ""
        # NOTE: installed from a file (the "User Default" repository), the
        # update comes from the store's repository, which Blender treats as
        # a different add-on with the same id. The old copy is disabled
        # first so the two never register together, and only removed once
        # the new one is installed; on failure the old copy is restored.
        addon_utils.disable(_PKG, default_set=True)
        res = bpy.ops.extensions.package_install(repo_index=repo_index, pkg_id=PKG_ID,
                                                  enable_on_install=True)
        if 'FINISHED' not in res:
            addon_utils.enable(_PKG, default_set=True)
            return False, "the store refused the download"
        if own_index >= 0:
            try:
                bpy.ops.extensions.package_uninstall(repo_index=own_index, pkg_id=PKG_ID)
            except Exception as exc:
                return True, "old copy left in place (%s)" % exc
        return True, ""
    except Exception as exc:
        try:
            if not addon_utils.check(_PKG)[1]:
                addon_utils.enable(_PKG, default_set=True)
        except Exception:
            pass
        return False, str(exc)
    finally:
        _state["busy"] = False
        _state["status"] = None


class _InstallOp:
    bl_label = "Update Now"
    bl_description = "Download and install the latest version from the store"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        if not _online_ok(self):
            return {'CANCELLED'}
        st = status(force=True)
        if not st["available"]:
            self.report({'INFO'}, "%s is already up to date" % ADDON_NAME)
            return {'CANCELLED'}
        args = (st["repo_index"], st["own_index"], st["same_repo"])
        target = st["available"]

        def _run():
            ok, msg = _do_update(*args)
            text = ("%s updated to %s" % (ADDON_NAME, target)) if ok else \
                   ("%s update failed: %s" % (ADDON_NAME, msg))
            if ok and msg:
                text += " (" + msg + ")"
            print("[%s] %s" % (ADDON_NAME, text))
            _notify(text, ok)
            return None
        bpy.app.timers.register(_run, first_interval=0.05)
        self.report({'INFO'}, "Updating %s to %s..." % (ADDON_NAME, target))
        return {'FINISHED'}


def _notify(text, ok):
    try:
        wm = bpy.context.window_manager

        def draw(self, _context):
            self.layout.label(text=text)
        wm.popup_menu(draw, title=ADDON_NAME, icon='INFO' if ok else 'ERROR')
    except Exception:
        pass


# --- one copy at a time ------------------------------------------------------
#
# NOTE: a buyer who installed the add-on from the zip and later drags it from
# the store page into Blender ends up with TWO copies: Blender installs the
# store copy into the store's repository and enables it next to the old one.
# Both register the same operators, panels and frame handlers, so they
# overwrite each other, the simulation runs twice and disabling either copy
# raises "missing bl_rna" errors. claim_single_copy() keeps exactly one copy
# active: the store copy wins (it is the one that receives updates).

def _copy_module_names():
    out = []
    try:
        names = list(bpy.context.preferences.addons.keys())
    except Exception:
        names = []
    for name in names:
        if name == _PKG:
            continue
        if _pkg_of(name) in _FAMILY:
            out.append(name)
    return out


# NOTE: the Full and Free editions share operator and panel names, so they
# are one family: never active together, and Full always wins over Free.
_BASE_ID = PKG_ID[:-5] if PKG_ID.endswith("_free") else PKG_ID
_FAMILY = (_BASE_ID, _BASE_ID + "_free")


def _pkg_of(module_name):
    return module_name.rsplit(".", 1)[-1].lower()


def _module_repo(module_name):
    parts = module_name.split(".")
    if len(parts) != 3 or parts[0] != "bl_ext":
        return None, -1
    for i, r in enumerate(_repos()):
        if r.module == parts[1]:
            return r, i
    return None, -1


def _is_store_copy(module_name):
    r, _i = _module_repo(module_name)
    return bool(r is not None and r.use_remote_url)


def claim_single_copy():
    """True if this copy should register; call first in register()."""
    _state["replaced"] = []
    _state["shadowed_by"] = ""
    others = _copy_module_names()
    if not others:
        return True
    me_store = _is_store_copy(_PKG)
    me_free = PKG_ID.endswith("_free")
    for o in others:
        o_free = _pkg_of(o).endswith("_free")
        # The store copy beats a copy installed from a file, Full beats Free.
        if (me_free and not o_free) or (o_free == me_free and _is_store_copy(o) and not me_store):
            _state["shadowed_by"] = o
            print("[%s] %s is dormant: %s is the active copy" % (ADDON_NAME, _PKG, o))
            return False
    for o in others:
        try:
            addon_utils.disable(o, default_set=True)
            _state["replaced"].append(o)
            print("[%s] disabled the older copy %s" % (ADDON_NAME, o))
        except Exception as exc:
            print("[%s] could not disable %s: %s" % (ADDON_NAME, o, exc))
    return True


class _RemoveOldOp:
    bl_label = "Remove Old Copy"
    bl_description = "Uninstall the older copy of this add-on that was installed from a file"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        done = []
        for o in list(_state["replaced"]):
            r, i = _module_repo(o)
            if i < 0:
                continue
            try:
                bpy.ops.extensions.package_uninstall(repo_index=i, pkg_id=o.rsplit(".", 1)[-1])
                done.append(o)
            except Exception as exc:
                self.report({'ERROR'}, "Could not remove %s: %s" % (o, exc))
        _state["replaced"] = [o for o in _state["replaced"] if o not in done]
        if done:
            # NOTE: an older copy that never unloaded its solver library keeps
            # the file locked on Windows; Blender then parks the folder and
            # deletes it on the next start, so the user only needs a restart.
            leftovers = False
            for o in done:
                r, _i = _module_repo(o)
                pkg = o.rsplit(".", 1)[-1]
                if r is not None and any(os.path.exists(os.path.join(r.directory, n))
                                         for n in (pkg, "." + pkg + ".~temp~")):
                    leftovers = True
            if leftovers:
                self.report({'INFO'}, "Older copy removed. Restart Blender to delete its last files")
            else:
                self.report({'INFO'}, "Removed the older copy of %s" % ADDON_NAME)
        return {'FINISHED'}


def _draw_replaced(layout):
    if not _state["replaced"]:
        return
    box = layout.box()
    col = box.column(align=True)
    col.label(text="An older copy of %s was disabled" % ADDON_NAME, icon='INFO')
    col.label(text="(installed from a file). Only this copy is active now.")
    col.operator(PREFIX + ".update_remove_old", icon='TRASH')


# --- UI ----------------------------------------------------------------------

def draw_notice(layout, context=None):
    """Compact banner for the add-on's main panel: only when an update exists."""
    _draw_replaced(layout)
    st = status()
    if not st["available"]:
        return
    box = layout.box()
    col = box.column(align=True)
    col.label(text="%s %s is available" % (ADDON_NAME, st["available"]), icon='IMPORT')
    row = col.row(align=True)
    row.enabled = not _state["busy"]
    row.operator(PREFIX + ".update_install", text="Update Now", icon='FILE_REFRESH')
    if PRODUCT_URL:
        row.operator("wm.url_open", text="What's New", icon='URL').url = PRODUCT_URL


def draw_prefs(layout, context=None):
    """Full update section for the add-on's preferences."""
    st = status()
    if not st["available"]:
        _draw_replaced(layout)
    box = layout.box()
    box.label(text="Updates", icon='FILE_REFRESH')
    col = box.column(align=True)
    col.label(text="Installed version: %s" % INSTALLED)
    if st["available"]:
        draw_notice(col, context)
    elif st["listed"]:
        col.label(text="Up to date", icon='CHECKMARK')
    repos = _repos()
    si = st["store_index"]
    if si >= 0 and si < len(repos):
        repo = repos[si]
        col.prop(repo, "use_sync_on_startup", text="Check for updates when Blender starts")
        col.operator(PREFIX + ".update_check", icon='FILE_REFRESH')
        if not st["listed"]:
            col.label(text="This add-on is not listed in your store library yet:", icon='INFO')
            col.label(text="open your order page and drag the add-on into Blender.")
    else:
        col.label(text="Get updates inside Blender:", icon='INFO')
        col.label(text="connect your store account to Blender once.")
        col.operator("wm.url_open", text="How to Connect", icon='URL').url = CONNECT_HELP_URL
    if not bpy.app.online_access:
        col.label(text="Online access is disabled (Preferences > System).", icon='ERROR')


_classes = []


def register():
    up = PREFIX.upper()
    check = type(up + "_OT_update_check", (_CheckOp, bpy.types.Operator),
                 {"bl_idname": PREFIX + ".update_check"})
    inst = type(up + "_OT_update_install", (_InstallOp, bpy.types.Operator),
                {"bl_idname": PREFIX + ".update_install"})
    rm = type(up + "_OT_update_remove_old", (_RemoveOldOp, bpy.types.Operator),
              {"bl_idname": PREFIX + ".update_remove_old"})
    _classes[:] = [check, inst, rm]
    for c in _classes:
        bpy.utils.register_class(c)
    _state["status"] = None


def unregister():
    for c in reversed(_classes):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass
    _classes.clear()
