# SpringFX — spring / jiggle bone dynamics for animation.
# Package layout:
#   core.py       — physics engine, frame handlers, colliders, helpers setup
#   presets.py    — built-in Hair/Clothing/Body library + user preset ops
#   properties.py — PropertyGroups and all sb_* property registration
#   operators.py  — bake, groups, bulk apply, smart convert, noise, NLA
#   ui.py         — N-panel layout (View3D > Sidebar > SpringFX); 8.2: Add/Clean
#                   Physics + renamable group list, Bake last
#   export_engines.py — VRChat PhysBones export (game-engine bridge)

bl_info = {
    "name": "SpringFX",
    "author": "Auron3d",
    # NOTE: 8.3.0 = mesh colliders solved in the compiled core (lazy BVH with
    # refit), rigs with Euler / Lag chains stay compiled for the rest
    # ("mixed" rigs), and the optional "Ignore Own Mesh" collision rule.
    # NOTE: 8.4.0 = update notices and one-click updates inside Blender
    # through the store's remote repository (updates.py), and the compiled
    # core is released on disable so Windows lets an update replace it.
    # NOTE: 8.4.2 = frame handlers no longer write the Scene datablock (the
    # Python solver state moved to module dicts); that per-frame Scene write
    # crashed threaded playback in BKE_object_eval_eval_base_flags.
    # NOTE: 8.4.3 = the bake replaces only the bake range; keyframes and NLA
    # animation outside it keep playing (they were deleted or masked).
    # NOTE: 8.4.4 = exhaustive-test fixes: axis-angle bones, same-frame
    # re-evaluation in the compiled core, Location Influence 0, "Reacts to
    # Colliders" on rotation springs, undo, duplicated rigs, exact baked cache.
    "version": (8, 4, 4),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > SpringFX",
    "description": "Spring dynamics for bones: location + inertia rotation "
                   "springs, hair/clothing presets, wind, full collision "
                   "system (body capsules, meshes, self-collision), chains, "
                   "groups, bake",
    "category": "Animation",
}

# Support live reloading during development: if the package was already
# imported, `import ...` alone would reuse the stale modules.
if "core" in locals():
    import importlib
    core       = importlib.reload(core)        # noqa: F821
    presets    = importlib.reload(presets)     # noqa: F821
    operators  = importlib.reload(operators)   # noqa: F821
    properties = importlib.reload(properties)  # noqa: F821
    ui         = importlib.reload(ui)          # noqa: F821
    export_engines = importlib.reload(export_engines)  # noqa: F821
    xpbd       = importlib.reload(xpbd)        # noqa: F821
    native     = importlib.reload(native)      # noqa: F821
    updates    = importlib.reload(updates)     # noqa: F821
else:
    from . import core, presets, operators, properties, ui, export_engines, xpbd, native, updates

import bpy  # noqa: F401  (kept for scripts that poke springfx.bpy)


# Registration order matters:
#   properties first (PropertyGroups + sb_* props the rest depend on),
#   then operator/preset/ui classes, then the frame handlers last so the
#   simulation never runs against a half-registered addon.
_register_order = (properties, presets, operators, export_engines, updates, ui, core)


_dormant = False


def register():
    global _dormant
    # NOTE: never run two copies at once (see updates.claim_single_copy).
    _dormant = not updates.claim_single_copy()
    if _dormant:
        return
    for mod in _register_order:
        mod.register()


def unregister():
    if _dormant:
        return
    for mod in reversed(_register_order):
        mod.unregister()


if __name__ == "__main__":
    register()
