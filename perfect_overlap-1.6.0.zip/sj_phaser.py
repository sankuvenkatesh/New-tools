# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

__author__ = "Sanku Venkatesh"
__copyright__ = "Copyright 2021-2026, CaptainHansode, sakaiden.com; 2026 Sanku Venkatesh"
__credits__ = ["Sanku Venkatesh", "CaptainHansode (original author)"]
__license__ = "GPL"
__maintainer__ = "Sanku Venkatesh"
__status__ = "Production"


import bpy
import math
import mathutils


# Bones with these name prefixes are rig plumbing, not animator-facing
# controls. Advanced rigs (Rigify and friends) sit them between the controls,
# so hierarchy detection walks through them instead of stopping at them.
NON_CONTROL_PREFIXES = (
    "def-", "def_", "def.",
    "org-", "org_", "org.",
    "mch-", "mch_", "mch.",
    "wgt-", "wgt_", "wgt.",
    "vis-", "vis_",
)

EPS = 1.0e-6
ZERO = mathutils.Vector((0.0, 0.0, 0.0))
BONE_AXIS = mathutils.Vector((0.0, 1.0, 0.0))   # bones point down local +Y

# How far the simulation is allowed to lag behind the rig before it is reined
# in. Without these the aim vector can pass the target and flip.
MAX_STATE_ANGLE = math.radians(110.0)
MAX_OUTPUT_ANGLE = math.radians(80.0)


class SJPhaserModule(object):
    r"""Perfect-overlap solver.

    Every control is driven by a critically-dampable spring that chases the
    pose the rig would give it. Because the spring is integrated once per
    frame with a stable, damped step, the result is smooth delayed motion -
    the old formulation fed its own correction back in undamped, which is what
    produced the frame-to-frame zigzag."""

    def __init__(self, *args, **kwargs):
        # Raw UI values - converted to solver coefficients in solver_params().
        self.delay = 3.0
        self.recursion = 5.0
        self.strength = 1.0
        self.threshold = 0.001
        self.sf = 0
        self.ef = 100
        self.debug = False

        # --- options -----------------------------------------------------
        # Detect the control hierarchy under the selected controller and
        # include every child control automatically.
        self.hierarchy = False
        # Add overlapping motion to translation as well as rotation.
        self.animate_translate = False

    # ------------------------------------------------------------------
    # solver coefficients
    # ------------------------------------------------------------------
    def solver_params(self):
        r"""(stiffness, damping, amplitude) for a one-frame integration step.

        Discrete spring: v += k*error - c*v ; x += v. It stays stable while
        k > 0 and k + 2c < 4, so both coefficients are clamped into that
        region - that is what guarantees the bake cannot oscillate frame to
        frame no matter how the sliders are set."""
        k = 1.0 / max(self.delay, 1.0)
        k = min(max(k, 0.05), 0.9)

        # Recursion now controls how much momentum carries through: 0 settles
        # dead, 10 keeps swinging.
        rec = min(max(self.recursion, 0.0), 10.0)
        zeta = 1.15 - (rec / 10.0) * 0.8          # damping ratio 1.15 -> 0.35
        c = 2.0 * zeta * math.sqrt(k)
        c = min(max(c, 0.0), min(1.9, (4.0 - k) * 0.5 * 0.95))

        # Strength exaggerates the offset from the rig pose.
        amp = 1.0 + (min(max(self.strength, 1.0), 10.0) - 1.0) / 9.0
        return k, c, amp

    def _limit_dir(self, base, vec, max_angle):
        r"""Keep `vec` within `max_angle` of `base` (both unit vectors)."""
        dot = min(max(base.dot(vec), -1.0), 1.0)
        angle = math.acos(dot)
        if angle <= max_angle or angle < EPS:
            return vec
        return base.slerp(vec, max_angle / angle).normalized()

    # ------------------------------------------------------------------
    # rig inspection
    # ------------------------------------------------------------------
    def _bone_visible(self, pbn):
        bone = pbn.bone
        if bone.hide:
            return False
        colls = getattr(bone, "collections", None)
        if colls:
            for c in colls:
                if getattr(c, "is_visible_effectively",
                           getattr(c, "is_visible", True)):
                    return True
            return False
        return True

    def is_control_bone(self, pbn):
        r"""True for animator-facing controls. Mechanism, deform, org and
        widget bones - and anything hidden - are treated as plumbing."""
        if pbn.name.lower().startswith(NON_CONTROL_PREFIXES):
            return False
        return self._bone_visible(pbn)

    def control_children(self, pbn, _depth=0):
        r"""Direct control children of `pbn`.

        On an advanced rig a control is often parented to its logical parent
        through one or more mechanism bones, so those are walked through
        rather than treated as the end of the chain."""
        out = []
        for child in pbn.children:
            if self.is_control_bone(child):
                out.append(child)
            elif _depth < 8:
                out.extend(self.control_children(child, _depth + 1))
        return out

    def next_in_chain(self, pbn, candidates):
        r"""Which child actually continues this bone's chain.

        Simple FK rigs use connected children, so those win outright. When
        nothing is connected (common on control rigs) the child whose head
        sits closest to this bone's tail and points the same way is the real
        continuation - taking `children[0]` blindly picks whatever bone
        happened to be added to the rig first."""
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]

        for c in candidates:
            if c.bone.use_connect:
                return c

        tail = pbn.tail
        dir_v = pbn.tail - pbn.head
        dir_v = dir_v.normalized() if dir_v.length > EPS else BONE_AXIS.copy()
        scale = max(pbn.length, EPS)

        best = None
        best_score = None
        for c in candidates:
            dist = (c.head - tail).length / scale
            c_dir = c.tail - c.head
            align = c_dir.normalized().dot(dir_v) if c_dir.length > EPS else -1.0
            score = dist - align          # near the tail + same direction wins
            if best_score is None or score < best_score:
                best_score = score
                best = c
        return best

    def can_translate(self, pbn):
        r"""Whether translation overlap can be written to this control at all.
        Connected bones and fully locked controls cannot move, so they fall
        back to rigid follow instead of producing a broken bake."""
        if not self.animate_translate:
            return False
        if pbn.bone.use_connect:
            return False
        if all(pbn.lock_location):
            return False
        return True

    # ------------------------------------------------------------------
    # selection / chains
    # ------------------------------------------------------------------
    def get_selection(self):
        r"""Pose bones to operate on.

        With `hierarchy` on, the control hierarchy below every selected bone
        is detected and added, so the user only selects the top controller."""
        selected = list(bpy.context.selected_pose_bones or [])
        if not self.hierarchy:
            return selected

        out = []
        seen = set()

        def walk(pbn):
            if pbn.name in seen:
                return
            seen.add(pbn.name)
            out.append(pbn)
            for child in self.control_children(pbn):
                walk(child)

        # An explicitly selected bone is always honoured, even if its name
        # would otherwise mark it as plumbing.
        for pbn in selected:
            walk(pbn)
        return out

    def get_hierarchy_count(self, obj):
        r"""Depth of the bone in the hierarchy."""
        obj = obj.parent
        cnt = 0
        while obj is not None:
            obj = obj.parent
            cnt += 1
        return cnt

    def get_default_data_table(self):
        return {
            "obj_list": [],     # pose bones, root first
            "offset": [],       # rest offset from the chain predecessor
            "state": []         # solver state per bone
        }

    def get_tree_list(self):
        r"""Build the bone chains to simulate.

        Bones are consumed shallowest-first, so a chain always starts at its
        own highest bone; branches that were not picked as the continuation
        become chains of their own."""
        sel_bones = self.get_selection()
        sel_names = {pbn.name for pbn in sel_bones}
        ordered = sorted(sel_bones, key=self.get_hierarchy_count)

        obj_trees = {}
        used = set()
        t_cnt = 0

        for pbn in ordered:
            if pbn.name in used:
                continue
            # A chain needs a parent to hang from - the parent supplies the
            # driving motion. A parentless controller drives, it is not baked.
            if pbn.parent is None:
                continue

            chain = [pbn]
            used.add(pbn.name)

            cur = pbn
            while True:
                candidates = [c for c in self.control_children(cur)
                              if c.name in sel_names and c.name not in used]
                nxt = self.next_in_chain(cur, candidates)
                if nxt is None:
                    break
                chain.append(nxt)
                used.add(nxt.name)
                cur = nxt

            depth_cnt = self.get_hierarchy_count(pbn)
            if depth_cnt not in obj_trees:
                obj_trees[depth_cnt] = {}

            t_name = "tree{}".format(t_cnt)
            obj_trees[depth_cnt][t_name] = self.get_default_data_table()
            obj_trees[depth_cnt][t_name]["obj_list"] = chain
            t_cnt += 1

        return obj_trees

    def iter_chains(self, obj_trees):
        r"""Every chain, shallowest first, so a parent chain is always solved
        before anything hanging off it."""
        for k in sorted(obj_trees.keys()):
            for t in sorted(obj_trees[k].keys()):
                yield obj_trees[k][t]

    def iter_bones(self, obj_trees):
        for chain in self.iter_chains(obj_trees):
            for pbn in chain["obj_list"]:
                yield pbn

    # ------------------------------------------------------------------
    # setup
    # ------------------------------------------------------------------
    def world_matrix(self, pbn):
        return bpy.context.active_object.matrix_world @ pbn.matrix

    def set_pre_data(self, obj_trees):
        r"""Measure each bone's rest offset from its chain predecessor, and
        seed the solver state from the current (start frame) pose."""
        for chain in self.iter_chains(obj_trees):
            obj_list = chain["obj_list"]
            chain["offset"] = []
            chain["state"] = []
            for idx, pbn in enumerate(obj_list):
                # The predecessor is not always the literal parent on an
                # advanced rig - mechanism bones can sit in between - so the
                # offset is measured against whatever actually drives it.
                ref_pbn = obj_list[idx - 1] if idx > 0 else pbn.parent
                ref_mt = self.world_matrix(ref_pbn)
                bone_mt = self.world_matrix(pbn)
                chain["offset"].append(ref_mt.inverted() @ bone_mt)
                chain["state"].append({
                    "dir": (bone_mt.to_quaternion() @ BONE_AXIS).normalized(),
                    "dir_vel": ZERO.copy(),
                    "pos": bone_mt.translation.copy(),
                    "pos_vel": ZERO.copy(),
                })
        return obj_trees

    def reset_state(self, obj_trees):
        r"""Re-seed the solver from the current pose (used before a fresh solve)."""
        for chain in self.iter_chains(obj_trees):
            for idx, pbn in enumerate(chain["obj_list"]):
                bone_mt = self.world_matrix(pbn)
                st = chain["state"][idx]
                st["dir"] = (bone_mt.to_quaternion() @ BONE_AXIS).normalized()
                st["dir_vel"] = ZERO.copy()
                st["pos"] = bone_mt.translation.copy()
                st["pos_vel"] = ZERO.copy()

    # ------------------------------------------------------------------
    # keyframes
    # ------------------------------------------------------------------
    def rotation_data_path(self, pbn):
        if pbn.rotation_mode == 'QUATERNION':
            return 'rotation_quaternion'
        if pbn.rotation_mode == 'AXIS_ANGLE':
            return 'rotation_axis_angle'
        return 'rotation_euler'

    def translate_axes(self, pbn):
        r"""Which location axes this control is allowed to overlap on."""
        if not self.can_translate(pbn):
            return []
        return [a for a in range(3) if not pbn.lock_location[a]]

    def set_animkey(self, pbn):
        f = bpy.context.scene.frame_current
        # Locked axes are never keyed, so whatever the animator put there
        # stays untouched.
        for a in self.translate_axes(pbn):
            pbn.keyframe_insert(data_path='location', index=a, frame=f)
        pbn.keyframe_insert(data_path=self.rotation_data_path(pbn), frame=f)
        # Scale is never keyed - baking scale is what made armatures grow or
        # shrink during the simulation.
        return None

    def del_animkey(self, obj_trees):
        r"""Strip our channels inside [sf, ef], then key the start frame.

        This works on the F-Curves directly instead of calling
        keyframe_delete() per frame: it is far faster and it cannot bail out
        half way through, which used to leave stale keys behind."""
        container = self._fcurve_container(bpy.context.active_object)

        for fcurve, pbn, channel in self._chain_fcurve_map(obj_trees):
            if channel == 'location' and fcurve.array_index not in self.translate_axes(pbn):
                continue
            if channel not in ('location', 'scale', 'rotation_euler',
                               'rotation_quaternion', 'rotation_axis_angle'):
                continue

            kps = fcurve.keyframe_points
            drop = [i for i, kp in enumerate(kps)
                    if self.sf <= kp.co[0] <= self.ef]
            for i in reversed(drop):
                kps.remove(kps[i], fast=True)
            fcurve.update()

            # An empty F-Curve evaluates to 0.0, which would collapse the
            # bone, so it is removed outright rather than left behind.
            if container is not None and len(fcurve.keyframe_points) == 0:
                try:
                    container.remove(fcurve)
                except (RuntimeError, ReferenceError):
                    pass

        bpy.context.view_layer.update()

        for pbn in self.iter_bones(obj_trees):
            for a in self.translate_axes(pbn):
                pbn.keyframe_insert(data_path='location', index=a, frame=self.sf)
            pbn.keyframe_insert(
                data_path=self.rotation_data_path(pbn), frame=self.sf)

        self.remove_cyclic_modifiers(obj_trees)
        return None

    # ------------------------------------------------------------------
    # f-curves
    # ------------------------------------------------------------------
    def _fcurve_container(self, id_data):
        r"""The collection holding the F-Curves, compatible with both the
        legacy Action API (Blender <= 4.3) and the slotted Action API (4.4+,
        where Action.fcurves was removed in 5.0)."""
        adt = id_data.animation_data
        if adt is None or adt.action is None:
            return None
        action = adt.action
        try:
            from bpy_extras import anim_utils
            channelbag = anim_utils.action_get_channelbag_for_slot(
                action, adt.action_slot)
            return channelbag.fcurves if channelbag else None
        except (ImportError, AttributeError):
            return action.fcurves

    def _get_fcurves(self, id_data):
        container = self._fcurve_container(id_data)
        return list(container) if container is not None else []

    def _chain_fcurve_map(self, obj_trees):
        r"""(fcurve, pose_bone, channel) for every curve belonging to a bone
        we are baking."""
        amt = bpy.context.active_object
        by_prefix = {pbn.path_from_id(): pbn
                     for pbn in self.iter_bones(obj_trees)}

        out = []
        for fc in self._get_fcurves(amt):
            for prefix, pbn in by_prefix.items():
                if fc.data_path == prefix or fc.data_path.startswith(prefix + "."):
                    out.append((fc, pbn, fc.data_path[len(prefix) + 1:]))
                    break
        return out

    def _chain_fcurves(self, obj_trees):
        return [fc for fc, _pbn, _ch in self._chain_fcurve_map(obj_trees)]

    def _baked_fcurves(self, obj_trees):
        r"""Only the curves this bake writes to.

        Everything else on the bone - a locked location axis, an unused
        rotation representation - belongs to the animator and must not be
        cleaned up, retangented or made cyclic."""
        out = []
        for fc, pbn, channel in self._chain_fcurve_map(obj_trees):
            if channel == self.rotation_data_path(pbn):
                out.append((fc, pbn))
            elif channel == 'location' and fc.array_index in self.translate_axes(pbn):
                out.append((fc, pbn))
        return out

    def add_cyclic_modifiers(self, obj_trees):
        r"""Add a Cycles F-Curve modifier to every channel we keyed, so the
        action keeps repeating past the end frame."""
        for fcurve, _pbn in self._baked_fcurves(obj_trees):
            if not any(m.type == 'CYCLES' for m in fcurve.modifiers):
                fcurve.modifiers.new('CYCLES')

    def remove_cyclic_modifiers(self, obj_trees):
        for fcurve in self._chain_fcurves(obj_trees):
            for m in list(fcurve.modifiers):
                if m.type == 'CYCLES':
                    fcurve.modifiers.remove(m)

    def cleanup_keys(self, obj_trees):
        r"""Drop keys that carry no information and smooth what is left.

        The bake writes one key per frame; any key that already sits on the
        straight line between its neighbours is redundant, so it goes. This is
        what keeps the curves readable instead of a wall of identical keys."""
        tol = max(self.threshold, 1.0e-6)
        removed = 0

        for fcurve, _pbn in self._baked_fcurves(obj_trees):
            kps = fcurve.keyframe_points
            idx_range = [i for i, kp in enumerate(kps)
                         if self.sf <= kp.co[0] <= self.ef]
            if len(idx_range) > 2:
                drop = []
                prev_i = idx_range[0]
                for pos in range(1, len(idx_range) - 1):
                    i = idx_range[pos]
                    nxt_i = idx_range[pos + 1]
                    t0, v0 = kps[prev_i].co
                    t1, v1 = kps[i].co
                    t2, v2 = kps[nxt_i].co
                    if abs(t2 - t0) < EPS:
                        continue
                    lerp = v0 + (v2 - v0) * ((t1 - t0) / (t2 - t0))
                    if abs(v1 - lerp) <= tol:
                        drop.append(i)          # redundant, neighbours cover it
                    else:
                        prev_i = i
                for i in reversed(drop):
                    kps.remove(kps[i], fast=True)
                removed += len(drop)

            for kp in kps:
                if self.sf <= kp.co[0] <= self.ef:
                    kp.interpolation = 'BEZIER'
                    kp.handle_left_type = 'AUTO_CLAMPED'
                    kp.handle_right_type = 'AUTO_CLAMPED'
            fcurve.update()

        return removed

    # ------------------------------------------------------------------
    # cycle
    # ------------------------------------------------------------------
    def cycle_residual(self, obj_trees):
        r"""How far the end frame is from the start frame, per channel.
        Small values mean the cyclic solve has converged."""
        worst = 0.0
        worst_name = ""
        for fcurve, pbn in self._baked_fcurves(obj_trees):
            diff = abs(fcurve.evaluate(self.ef) - fcurve.evaluate(self.sf))
            if diff > worst:
                worst = diff
                worst_name = pbn.name
        return worst_name, worst

    def _seam_keys(self, fcurve):
        first = None
        last = None
        for kp in fcurve.keyframe_points:
            f = int(round(kp.co[0]))
            if f == self.sf:
                first = kp
            elif f == self.ef:
                last = kp
        return first, last

    def enforce_cycle_seam(self, obj_trees):
        r"""Make the end frame hold exactly the start frame's values.

        After the cyclic pre-roll the two are already within a rounding error
        of each other, so this only removes the residual - the overlap offset
        the chain is carrying at the seam is preserved, unlike a blend that
        flattens the tail back to the rig pose."""
        for fcurve, _pbn in self._baked_fcurves(obj_trees):
            first, last = self._seam_keys(fcurve)
            if first is None or last is None:
                continue
            last.co[1] = first.co[1]
            fcurve.update()

    def set_cycle_seam_tangents(self, obj_trees):
        r"""Match the tangents across the loop point.

        The slope at the seam is taken from the key after the start and the
        key before the end - the two frames that are actually adjacent once
        the action wraps - so the curve is continuous through the loop and
        there is no visible pop."""
        for fcurve, _pbn in self._baked_fcurves(obj_trees):
            first, last = self._seam_keys(fcurve)
            if first is None or last is None or first is last:
                continue

            after = None
            before = None
            for kp in fcurve.keyframe_points:
                if kp.co[0] > first.co[0] and kp.co[0] <= last.co[0]:
                    if after is None:
                        after = kp
                    if kp.co[0] < last.co[0]:
                        before = kp
            if after is None or before is None or after is last or before is first:
                continue

            dt_a = after.co[0] - first.co[0]
            dt_b = last.co[0] - before.co[0]
            if dt_a + dt_b < EPS:
                continue
            slope = (after.co[1] - before.co[1]) / (dt_a + dt_b)

            for kp in (first, last):
                kp.interpolation = 'BEZIER'
                kp.handle_left_type = 'FREE'
                kp.handle_right_type = 'FREE'
                kp.handle_left = (kp.co[0] - dt_b / 3.0,
                                  kp.co[1] - slope * dt_b / 3.0)
                kp.handle_right = (kp.co[0] + dt_a / 3.0,
                                   kp.co[1] + slope * dt_a / 3.0)
            fcurve.update()

    # ------------------------------------------------------------------
    # simulation
    # ------------------------------------------------------------------
    def solve_bone(self, chain, idx, driver_mt, k, c, amp):
        r"""One spring step for one bone. Returns the bone's new world matrix."""
        pbn = chain["obj_list"][idx]
        st = chain["state"][idx]

        # Where the rig would put this bone if it followed rigidly.
        tag_mt = driver_mt @ chain["offset"][idx]
        tag_quat = tag_mt.to_quaternion()
        tag_dir = (tag_quat @ BONE_AXIS).normalized()
        tag_pos = tag_mt.translation.copy()

        # --- aim spring -------------------------------------------------
        vel = st["dir_vel"] * (1.0 - c) + (tag_dir - st["dir"]) * k
        if vel.length < self.threshold:
            vel = ZERO.copy()
        cur_dir = st["dir"] + vel
        if cur_dir.length < EPS:
            cur_dir = tag_dir.copy()
        cur_dir = self._limit_dir(tag_dir, cur_dir.normalized(), MAX_STATE_ANGLE)
        st["dir_vel"] = vel
        st["dir"] = cur_dir

        out_dir = cur_dir
        if amp > 1.0:
            out_dir = (tag_dir + (cur_dir - tag_dir) * amp)
            out_dir = out_dir.normalized() if out_dir.length > EPS else tag_dir.copy()
        out_dir = self._limit_dir(tag_dir, out_dir, MAX_OUTPUT_ANGLE)

        # Rotate the rig's own orientation onto the lagged aim direction: the
        # roll comes straight from the rig, so it cannot drift or flip.
        out_quat = tag_dir.rotation_difference(out_dir) @ tag_quat

        # --- position spring --------------------------------------------
        if self.can_translate(pbn):
            pvel = st["pos_vel"] * (1.0 - c) + (tag_pos - st["pos"]) * k
            if pvel.length < self.threshold:
                pvel = ZERO.copy()
            st["pos_vel"] = pvel
            st["pos"] = st["pos"] + pvel
            out_pos = tag_pos + (st["pos"] - tag_pos) * amp
        else:
            st["pos_vel"] = ZERO.copy()
            st["pos"] = tag_pos.copy()
            out_pos = tag_pos

        return (mathutils.Matrix.Translation(out_pos) @
                out_quat.to_matrix().to_4x4())

    def solve_chain(self, chain, k, c, amp, write):
        amt = bpy.context.active_object
        amt_inv = amt.matrix_world.inverted()

        driver_mt = self.world_matrix(chain["obj_list"][0].parent)

        for idx in range(len(chain["obj_list"])):
            pbn = chain["obj_list"][idx]
            translate = self.can_translate(pbn)

            # What the bone already has this frame. The solver builds an
            # orthonormal matrix, so assigning it would otherwise bake
            # 1/armature-scale into the bone's local scale - that is what made
            # armatures scale.
            orig_loc = pbn.location.copy()
            orig_scale = pbn.scale.copy()

            new_mt = self.solve_bone(chain, idx, driver_mt, k, c, amp)

            pbn.matrix = amt_inv @ new_mt
            pbn.scale = orig_scale
            if not translate:
                pbn.location = orig_loc
            else:
                for a in range(3):
                    if pbn.lock_location[a]:
                        pbn.location[a] = orig_loc[a]

            # Required so pose_bone.matrix reflects the change before the next
            # bone in the chain reads it.
            # https://blender.stackexchange.com/questions/132403/
            bpy.context.view_layer.update()

            # Read back what the bone actually became (constraints, locks and
            # the restored scale all apply here) and drive the rest of the
            # chain from that, not from what we asked for. The spring state
            # itself is left alone - feeding the amplified result back in is
            # what would make it compound and buzz.
            actual_mt = self.world_matrix(pbn)

            if write:
                self.set_animkey(pbn)

            driver_mt = actual_mt

    def excute(self, obj_trees, write=True, include_start=False):
        r"""Solve every frame in the range.

        `write` off runs the solver without touching keyframes - used for the
        cyclic pre-roll passes, which exist only to settle the springs into
        their steady state."""
        k, c, amp = self.solver_params()
        scene = bpy.context.scene
        start = self.sf if include_start else self.sf + 1

        for f in range(start, self.ef + 1):
            scene.frame_set(f)
            for chain in self.iter_chains(obj_trees):
                self.solve_chain(chain, k, c, amp, write)
        return True

    def solve_cycle(self, obj_trees, preroll):
        r"""Solve the range as a continuous loop.

        The springs are run over the range `preroll` times without writing
        anything, carrying their state across the loop point each time. By the
        final pass the motion has settled into its periodic steady state, so
        the overlap at the start frame is the same overlap the chain is
        carrying at the end frame - the loop closes on its own instead of
        being blended shut."""
        for _ in range(max(1, int(preroll))):
            self.excute(obj_trees, write=False, include_start=True)
        self.excute(obj_trees, write=True, include_start=True)
        return True

    def message_box(self, message="", title="Message", icon='INFO'):
        def draw(self, context):
            self.layout.label(text=message)
        bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)
