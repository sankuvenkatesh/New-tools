# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.


bl_info = {
    "name": "Graph Pilot PRO",
    "author": "Boreo",
    "version": (6, 5, 2),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Graph Pilot",
    "description": "Easing keyframes by adjusting fcurve handles",
    "doc_url": "https://blendermarket.com/products/graphpilot/docs",
    "category": "Animation",
}

import bpy,time
import os
from bpy.props import FloatProperty
from bpy.types import Panel, Operator, PropertyGroup
from bpy.props import EnumProperty
from bpy.utils import previews
import json
from .translation import translate

# region Icons
# Getting the icons (located in a folder packed with the addon called "icons")
icons = previews.new()
addon_dir = os.path.dirname(__file__)
ease_icon_path = os.path.join(addon_dir, "icons" , "ease.png")
ease_in_icon_path=os.path.join(addon_dir,"icons","ease_in.png")
ease_out_icon_path=os.path.join(addon_dir,"icons","ease_out.png")
quad_icon_path=os.path.join(addon_dir,"icons","quad.png")
quad_in_icon_path=os.path.join(addon_dir,"icons","quad_in.png")
quad_out_icon_path=os.path.join(addon_dir,"icons","quad_out.png")
cubic_icon_path=os.path.join(addon_dir,"icons","cubic.png")
cubic_in_icon_path=os.path.join(addon_dir,"icons","cubic_in.png")
cubic_out_icon_path=os.path.join(addon_dir,"icons","cubic_out.png")
quart_icon_path=os.path.join(addon_dir,"icons","quart.png")
quart_in_icon_path=os.path.join(addon_dir,"icons","quart_in.png")
quart_out_icon_path=os.path.join(addon_dir,"icons","quart_out.png")
quint_icon_path=os.path.join(addon_dir,"icons","quint.png")
quint_in_icon_path=os.path.join(addon_dir,"icons","quint_in.png")
quint_out_icon_path=os.path.join(addon_dir,"icons","quint_out.png")
expo_icon_path=os.path.join(addon_dir,"icons","expo.png")
expo_in_icon_path=os.path.join(addon_dir,"icons","expo_in.png")
expo_out_icon_path=os.path.join(addon_dir,"icons","expo_out.png")
circ_icon_path=os.path.join(addon_dir,"icons","circ.png")
circ_in_icon_path=os.path.join(addon_dir,"icons","circ_in.png")
circ_out_icon_path=os.path.join(addon_dir,"icons","circ_out.png")
back_icon_path=os.path.join(addon_dir,"icons","back.png")
back_in_icon_path=os.path.join(addon_dir,"icons","back_in.png")
back_out_icon_path=os.path.join(addon_dir,"icons","back_out.png")
mechanical_icon_path=os.path.join(addon_dir,"icons","mechanical.png")
pause_icon_path=os.path.join(addon_dir,"icons","pause.png")
blendermarket_icon_path = os.path.join(addon_dir, "icons" , "blender_market_logo.png")
flip_icon_path = os.path.join(addon_dir, "icons" , "flip.png")

icons.load(name='Ease', path=ease_icon_path, path_type='IMAGE')
icons.load(name='Ease_In', path=ease_in_icon_path, path_type='IMAGE')
icons.load(name='Ease_Out', path=ease_out_icon_path, path_type='IMAGE')
icons.load(name='Quad', path=quad_icon_path, path_type='IMAGE')
icons.load(name='Quad_In', path=quad_in_icon_path, path_type='IMAGE')
icons.load(name='Quad_Out', path=quad_out_icon_path, path_type='IMAGE')
icons.load(name='Cubic', path=cubic_icon_path, path_type='IMAGE')
icons.load(name='Cubic_In', path=cubic_in_icon_path, path_type='IMAGE')
icons.load(name='Cubic_Out', path=cubic_out_icon_path, path_type='IMAGE')
icons.load(name='Quart', path=quart_icon_path, path_type='IMAGE')
icons.load(name='Quart_In', path=quart_in_icon_path, path_type='IMAGE')
icons.load(name='Quart_Out', path=quart_out_icon_path, path_type='IMAGE')
icons.load(name='Quint', path=quint_icon_path, path_type='IMAGE')
icons.load(name='Quint_In', path=quint_in_icon_path, path_type='IMAGE')
icons.load(name='Quint_Out',path=quint_out_icon_path, path_type='IMAGE')
icons.load(name='Expo', path=expo_icon_path, path_type='IMAGE')
icons.load(name='Expo_In', path=expo_in_icon_path, path_type='IMAGE')
icons.load(name='Expo_Out', path=expo_out_icon_path, path_type='IMAGE')
icons.load(name='Circ', path=circ_icon_path, path_type='IMAGE')
icons.load(name='Circ_In', path=circ_in_icon_path, path_type='IMAGE')
icons.load(name='Circ_Out', path=circ_out_icon_path, path_type='IMAGE')
icons.load(name='Back', path=back_icon_path, path_type='IMAGE')
icons.load(name='Back_In', path=back_in_icon_path, path_type='IMAGE')
icons.load(name='Back_Out', path=back_out_icon_path, path_type='IMAGE')
icons.load(name='Mechanical', path=mechanical_icon_path, path_type='IMAGE')
icons.load(name='Pause', path=pause_icon_path, path_type='IMAGE')
icons.load(name='BlenderMarket', path=blendermarket_icon_path, path_type='IMAGE')
icons.load(name='Flip', path=flip_icon_path, path_type='IMAGE')
print("Loaded Icons")
#endregion

#region Tooltips
LinkTooltip = """Visit the addon's page on Blender Market
Dont Forget to leave a rating!"""
InterpolationTooltip = "Interpolation"
PresetsTooltip = "Easing Presets"
EaseInTooltip = "Adjust the right handle frame"
EaseOutTooltip = "Adjust the left handle frame"
VelocityInTooltip = """Adjust the right handle value.
(Control the initial velocity of the animation)"""
VelocityOutTooltip = """Adjust the left handle value.
(Control the final velocity of the animation)"""
ChangeValuesTooltip = """Apply easing to the selected keyframes as a whole,
ignoring all the keyframe values in between"""
RestrictTooltip = """Only apply easing within the bounds of the current selection,
ignoring the outer handles"""
ApplyEasingTooltip = "Apply easing to selected keyframes"
RealtimeTooltip = """Apply easing in realtime. 
Not recommended for complex animations"""
CopyEasingTooltip = "Copy the easing of the selected keyframes"
CleanTooltip = "Remove unnecessary keyframes from the selected ones"
SwapEasingTooltip = "Swap the values between ease in and ease out"
SwapVelocityTooltip = "Swap the values between initial and final velocities"
LockVelocityTooltip = """Preserves the smooth, curved trajectory instead of forcing motion to be in straight lines"""
AddPresetTooltip = "Create a custom preset with the current easing values"
RemovePresetTooltip = "Remove the currently selected custom preset"

json_file_path = os.path.join(addon_dir, "presets.json")

#endregion


easingPresets = [
    ('(37,37,0,0)', "Ease", "", icons['Ease'].icon_id, 0),
    ('(37,0,0,0)', "Ease In", "", icons['Ease_In'].icon_id, 1),
    ('(0,37,0,0)', "Ease Out", "", icons['Ease_Out'].icon_id, 2),
    ('(45,45,5,5)', "Quad", "", icons['Quad'].icon_id, 3),
    ('(25,40,0,80)', "Quad In", "", icons['Quad_In'].icon_id, 4),
    ('(40,25,80,0)', "Quad Out", "", icons['Quad_Out'].icon_id, 5),
    ('(65,65,0,0)', "Cubic", "", icons['Cubic'].icon_id, 6),
    ('(40,32,0,94)', "Cubic In", "", icons['Cubic_In'].icon_id, 7),
    ('(32,40,94,0)', "Cubic Out", "", icons['Cubic_Out'].icon_id, 8),
    ('(76,76,0,0)', "Quart", "", icons['Quart'].icon_id, 9),
    ('(53,25,0,100)', "Quart In", "", icons['Quart_In'].icon_id, 10),
    ('(25,53,100,0)', "Quart Out", "", icons['Quart_Out'].icon_id, 11),
    ('(83,83,0,0)', "Quint", "", icons['Quint'].icon_id, 12),
    ('(65,20,0,100)', "Quint In", "", icons['Quint_In'].icon_id, 13),
    ('(20,65,100,0)', "Quint Out", "", icons['Quint_Out'].icon_id, 14),
    ('(87,87,0,0)', "Expo", "", icons['Expo'].icon_id, 15),
    ('(65,15,0,100)', "Expo In", "", icons['Expo_In'].icon_id, 16),
    ('(15,65,100,0)', "Expo Out", "", icons['Expo_Out'].icon_id, 17),
    ('(90,90,15,15)', "Circ", "", icons['Circ'].icon_id, 18),
    ('(55,0,0,55)', "Circ In", "", icons['Circ_In'].icon_id, 19),
    ('(0,55,55,0)', "Circ Out", "", icons['Circ_Out'].icon_id, 20),
    ('(36,36,-50,-50)', "Back", "", icons['Back'].icon_id, 21),
    ('(36,36,-50,94)', "Anticipate", "", icons['Back_In'].icon_id, 22),
    ('(36,36,94,-50)', "Overshoot", "", icons['Back_Out'].icon_id, 23),
    ('(60,60,100,100)', "Mechanical", "", icons['Mechanical'].icon_id, 24),
    ('(0,0,100,100)', "Pause", "", icons['Pause'].icon_id, 25),
]

originalPresetsValue = [item[0] for item in easingPresets]
originalPresetsName = [item[1] for item in easingPresets]

def onPresetsComboChange(self, context):
    currentSelection = bpy.context.scene.presetsCombo
    print("change to: ", currentSelection)
    # Find the selected item
    selectedItem = next((item for item in easingPresets if item[0] == currentSelection), None)
    if selectedItem is not None:
        # Set itemName and itemValue to the name and value of the selected item
        #bpy.context.scene.itemName = selectedItem[1]
        
        tuple_obj = tuple(map(float, selectedItem[0].strip("()").split(",")))
        bpy.context.scene.easing_right = tuple_obj[0]
        bpy.context.scene.easing_left = tuple_obj[1]
        bpy.context.scene.initial_velocity = tuple_obj[2]
        bpy.context.scene.final_velocity = tuple_obj[3]

def updateEasingPresets(newItems):
    if newItems:
        # Unregister the EnumProperty if it has already been registered
        if hasattr(bpy.types.Scene, 'presetsCombo'):
            del bpy.types.Scene.presetsCombo
        
        # Register the EnumProperty
        bpy.types.Scene.presetsCombo = bpy.props.EnumProperty(
            items=newItems,
            name="Presets",
            description="Item",
            default='(37,37,0,0)',
            update=onPresetsComboChange
        )
        saveItemsToJson()
        
def initializeSceneProperties():
    bpy.types.Scene.easing_right = FloatProperty(
        name="Ease In",
        description= EaseInTooltip,
        default=0,
        min=0,
        max=100,
        soft_min=0,
        soft_max=100,
        precision = 1,
        subtype='PERCENTAGE',
        update=lambda self, context: realtimeEase(self, context, "right-ease"),
    )

    bpy.types.Scene.easing_left = FloatProperty(
        name="Ease Out",
        description= EaseOutTooltip,
        default=0,
        min=0,
        max=100,
        soft_min=0,
        soft_max=100,
        precision = 1,
        subtype='PERCENTAGE',
        update=lambda self, context: realtimeEase(self, context, "left-ease"),
    )

    bpy.types.Scene.initial_velocity = FloatProperty(
        name="Velocity In",
        description= VelocityInTooltip,
        default=0,
        min=-1000,
        max=1000,
        soft_min=0,
        soft_max=100,
        precision = 1,
        subtype='PERCENTAGE',
        update=lambda self, context: realtimeEase(self, context, "right-velocity"),
    )

    bpy.types.Scene.final_velocity = FloatProperty(
        name="Velocity Out",
        description= VelocityOutTooltip,
        default=0,
        min=-1000,
        max=1000,
        soft_min=0,
        soft_max=100,
        precision = 1,
        subtype='PERCENTAGE',
        update=lambda self, context: realtimeEase(self, context, "left-velocity"),
    )
    
    
    
    bpy.types.Scene.change_keys = bpy.props.BoolProperty(name="Change_Keyframes_Boolean", default=False, description=ChangeValuesTooltip)
    bpy.types.Scene.restrict_to_selection = bpy.props.BoolProperty(name="Restrict_To_Selection", default=False, description=RestrictTooltip)
    bpy.types.Scene.realtime = bpy.props.BoolProperty(name="Realtime", default=False, description=RealtimeTooltip)
    bpy.types.Scene.lock_velocity = bpy.props.BoolProperty(name="Protect Velocity", default=False, description=LockVelocityTooltip)
    updateEasingPresets(easingPresets)
        
def saveItemsToJson():
    global easingPresets

    customPresets = []
    for item in easingPresets:
        ItemIcon = item[3]
        if ItemIcon == "GREASEPENCIL":
            customPresets.append(item)
    
    with open(json_file_path, 'w') as f:
        json.dump(customPresets, f)

def loadItemsFromJson():
    global easingPresets  # Assuming easingPresets is defined elsewhere

    try:
        with open(json_file_path, 'r') as f:
            new_presets = json.load(f)  # Load JSON data
            new_presets = [tuple(item) for item in new_presets]  # Convert lists to tuples
            easingPresets.extend(new_presets)  # Append new presets to existing ones
            print("New presets added:", new_presets)
            updateEasingPresets(easingPresets)  # Call function to update easing presets
    except FileNotFoundError:
        print("No items found")  # Print error message if file not found
           
def get_animation(get_keyframes=False):
    selected_keys = []
    obj = bpy.context.active_object

    if not obj or not obj.animation_data:
        return selected_keys

    selected_bones = []
    if bpy.context.mode == 'POSE':
        #blender changed to selected_pose_bones instead of obj.data.bones
        selected_bones = {p_bone.name for p_bone in bpy.context.selected_pose_bones}
        
    def process_fcurves(fcurves):
        for fcurve in fcurves:
            if bpy.context.mode == 'POSE':
                if 'pose.bones' in fcurve.data_path:
                    bone_name = fcurve.data_path.split('"')[1]
                    if bone_name not in selected_bones:
                        continue

            for keyframe in fcurve.keyframe_points:
                if keyframe.select_control_point:
                    if get_keyframes:
                        selected_keys.append((fcurve, keyframe))
                    else:
                        selected_keys.append(fcurve)

    anim_data = obj.animation_data

    if anim_data.action:
        # blender 5.0 uses sloted actions, so we check if the action has a slot and get the fcurves from there.
        if hasattr(anim_data, "action_slot"):
            from bpy_extras import anim_utils
            channelbag = anim_utils.action_get_channelbag_for_slot(
                anim_data.action, 
                anim_data.action_slot
            )
            if channelbag:
                process_fcurves(channelbag.fcurves)
        
        # fallback for older versions
        elif hasattr(anim_data.action, "fcurves"):
            process_fcurves(anim_data.action.fcurves)

    if anim_data.nla_tracks:
        for track in anim_data.nla_tracks:
            for strip in track.strips:
                # safeguard here just in case NLA strips change in future updates
                if hasattr(strip, "fcurves"):
                    process_fcurves(strip.fcurves)

    if not get_keyframes:
        selected_keys = list(set(selected_keys))

    return selected_keys


def calculate_key_diff(keyframe_data):
    key_diff = []

    fcurve, keyframe = keyframe_data
    this_key_x = keyframe.co.x
    this_key_y = keyframe.co.y

    prev_key = None
    next_key = None

    # Find previous and next keyframes
    for point in fcurve.keyframe_points:
        if point.co.x < this_key_x and (prev_key is None or point.co.x > prev_key.co.x):
            prev_key = point
        if point.co.x > this_key_x and (next_key is None or point.co.x < next_key.co.x):
            next_key = point

    # Calculate frame differences
    if prev_key is not None:
        prev_diff_x = this_key_x - prev_key.co.x
        prev_diff_y = this_key_y - prev_key.co.y
    else: prev_diff_x = prev_diff_y = 0
    

    if next_key is not None:
        next_diff_x = next_key.co.x - this_key_x
        next_diff_y = this_key_y- next_key.co.y
    else: next_diff_x = next_diff_y = 0

    key_diff.append((prev_diff_x, next_diff_x, prev_diff_y, next_diff_y))

    return key_diff[0]

def move_handle_frame(keyframe, handle, amount):
    handle.x = keyframe.co.x + amount
    
def move_handle_value(keyframe, handle, amount):
    handle.y = keyframe.co.y + amount
    
def reset_velocity(keyframe, handleR, handleL=None):
    handleR.y = keyframe.co.y
    if handleL is not None: handleL.y = keyframe.co.y

def reset_easing(keyframe, handleR, handleL=None):
    handleR.x = keyframe.co.x
    if handleL is not None: handleL.x = keyframe.co.x

def update_interpolation_mode(self, context):
    scene = context.scene
    preset = scene.interpolation_presets

    selected_keyframes = get_animation(True)
    for fcurve, keyframe in selected_keyframes:
        keyframe.interpolation = preset.interpolation
        
def update_presets(self, context):   # Separating the TUPLE into 4 different values (Ease In, Ease Out, Velocity In, Velocity Out)
    scene = context.scene
    preset = scene.interpolation_presets
    
    string_tuple = scene.easing_presets.easing
    tuple_obj = tuple(map(int, string_tuple.strip("()").split(",")))
    
    bpy.context.scene.easing_right = tuple_obj[0]
    bpy.context.scene.easing_left = tuple_obj[1]
    
    bpy.context.scene.initial_velocity = tuple_obj[2]
    bpy.context.scene.final_velocity = tuple_obj[3]    
    
def apply_easing(self, context, isCropped, influence = None):

        # Set variables
        initialVelocityValue = bpy.context.scene.initial_velocity
        finalVelocityValue = bpy.context.scene.final_velocity
        leftEaseValue = bpy.context.scene.easing_left
        rightEaseValue = bpy.context.scene.easing_right
        lockVelocity = bpy.context.scene.lock_velocity

        do_ease = leftEaseValue != 0 or rightEaseValue != 0
        do_velocity = (initialVelocityValue != 0 or finalVelocityValue != 0) and not lockVelocity
        

        selected_keyframes = get_animation(True)
        in_keys = []
        out_keys = []
        
        # If isCropped Checkbox is TRUE : Apply ease in to the keyframes [ 1 => Before Last ]  
        # & Apply ease out to the keyframes  [ 2 => Last ]

        if isCropped:
            fcurve_dict = {}
            
            # Organize keyframes by F-Curve
            for fcurve, keyframe in selected_keyframes:
                if fcurve not in fcurve_dict:
                    fcurve_dict[fcurve] = []
                fcurve_dict[fcurve].append(keyframe)
            
            # Process each F-Curve
            for fcurve, keyframes in fcurve_dict.items():
                keyframes.sort(key=lambda kf: kf.co.x)  # Sort keyframes by frame number
                num_keyframes = len(keyframes)
                
                if num_keyframes == 1:
                    in_keys.extend(keyframes)
                    out_keys.extend(keyframes)
                else:
                    in_keys.extend(keyframes[:-1]) 
                    out_keys.extend(keyframes[1:])

            
        for keyframe in selected_keyframes:
            this_key = keyframe[1]
            this_key.handle_left_type = this_key.handle_right_type = 'FREE'
            key_difference = calculate_key_diff(keyframe_data=keyframe)

            is_in_key = True if (this_key in in_keys) or not (isCropped) else False
            is_out_key = True if (this_key in out_keys) or not (isCropped) else False

            if do_ease: 
                if influence in ["left-ease", None] and is_out_key:
                    this_key.handle_left.x = this_key.co.x - (leftEaseValue / 100) * key_difference[0]
                if influence in ["right-ease", None] and is_in_key:
                    this_key.handle_right.x = this_key.co.x + (rightEaseValue / 100) * key_difference[1]
        
            else: 
                if influence in ["left-ease", None] and is_out_key: reset_easing(this_key, this_key.handle_left)
                if influence in ["right-ease", None] and is_in_key: reset_easing(this_key, this_key.handle_right)


            if do_velocity:
                if influence in ["left-velocity", None] and is_out_key:
                    this_key.handle_left.y = this_key.co.y - (finalVelocityValue / 100) * key_difference[2]
                if influence in ["right-velocity", None] and is_in_key:
                    this_key.handle_right.y = this_key.co.y - (initialVelocityValue / 100) * key_difference[3]
        
            elif not lockVelocity: 
                if influence in ["left-velocity", None] and is_out_key: reset_velocity(this_key, this_key.handle_left)
                if influence in ["right-velocity", None] and is_in_key: reset_velocity(this_key, this_key.handle_right)

def change_keys(self, context):
    selected_keyframes = get_animation(False)
    removed_key_times = [] # Array to store the removed keyframes is a tuple [Fcurve , Keyframe Time]
    
    for fcurve in selected_keyframes: # Store Middle Keyframes' frame and delete them
        selected_points = [point for point in fcurve.keyframe_points if point.select_control_point] 
        
        for i in range(len(selected_points)-1, -1, -1):
            if len(selected_points) <= 2: 
                break
                
            point = selected_points[i]
            
            if point.co != selected_points[0].co and point.co != selected_points[-1].co:
                removed_keyframe_value = point.co.x
                removed_key_times.append((fcurve, removed_keyframe_value))
                fcurve.keyframe_points.remove(point)

    return removed_key_times

def realtimeEase(self, context, influence = None):
    if context.scene.realtime:
        if bpy.context.scene.change_keys:   # Remove the middle keyframes and add them again after easing the FIRST and LAST ones
            removed_key_times = change_keys(self, context)
            apply_easing(self, context, bpy.context.scene.restrict_to_selection)
            
            for removed_keyframe in removed_key_times:  # Add the Keyframes Back
                fcurve = removed_keyframe[0]
                keyframe_time = removed_keyframe[1]
                fcurve.keyframe_points.insert(keyframe_time, fcurve.evaluate(keyframe_time)) # Evaluate function adds back the keyframe without changing the curve
        
        else:
            apply_easing(self, context, bpy.context.scene.restrict_to_selection, influence)



class AddonLinkButton(bpy.types.Operator):
    bl_idname = "gp.link"
    bl_label = ""
    bl_description = LinkTooltip
    
    def execute(self,context):
        bpy.ops.wm.url_open(url = "https://blendermarket.com/products/graphpilot/")
        return {'FINISHED'}

class InterpolationPresets(PropertyGroup):   #Interpolation Prests Enumerator
    interpolation: EnumProperty(
        name="Interpolation",
        items=[
            ('CONSTANT', "Constant", "", 'IPO_CONSTANT', 0),
            ('LINEAR', "Linear", "", 'IPO_LINEAR', 1),
            ('BEZIER', "Bezier", "", 'IPO_BEZIER', 2),         
        ],
        default='BEZIER',
        description = InterpolationTooltip,
        update = update_interpolation_mode
    )

class ApplyEasingOperator(bpy.types.Operator):
    bl_idname = "object.apply_easing"
    bl_label = "Apply Easing"
    bl_description = ApplyEasingTooltip
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        start_time = time.time()
        if bpy.context.scene.change_keys:   # Remove the middle keyframes and add them again after easing the FIRST and LAST ones
            removed_key_times = change_keys(self, context)
            apply_easing(self, context, bpy.context.scene.restrict_to_selection)
            
            for removed_keyframe in removed_key_times:  # Add the Keyframes Back
                fcurve = removed_keyframe[0]
                keyframe_time = removed_keyframe[1]
                fcurve.keyframe_points.insert(keyframe_time, fcurve.evaluate(keyframe_time)) # Evaluate function adds back the keyframe without changing the curve
        
        else:
            apply_easing(self, context, bpy.context.scene.restrict_to_selection)
        
        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"Elapsed time: {elapsed_time} seconds")

        return {'FINISHED'}

class RemovePresetOperator(bpy.types.Operator):
    bl_label = "Remove Preset"
    bl_idname = "b.remove_item"
    bl_description = RemovePresetTooltip
    
    def execute(self, context):
        global easingPresets
        currentItemValue = bpy.context.scene.presetsCombo
        
        currentItemName = None
        currentItemIcon = ""
        
        for item in easingPresets:
            if item[0] == currentItemValue:
                currentItemName = item[1]
                currentItemIcon = item[3]
                break
        
        
        if (currentItemValue not in originalPresetsValue) and (currentItemName not in originalPresetsName) and currentItemIcon == "GREASEPENCIL":
            currentIndex = next((index for (index, d) in enumerate(easingPresets) if d[0] == currentItemValue), None)
            if currentIndex is not None:
                easingPresets.pop(currentIndex)
                updateEasingPresets(easingPresets)
                if currentIndex > 0:
                    bpy.context.scene.presetsCombo = easingPresets[currentIndex - 1][0]
                else:
                    bpy.context.scene.presetsCombo = 'no_items'
        else:
            self.report({'WARNING'}, "Cannot remove a built-in preset.")

        return {'FINISHED'}

class AddPresetOperator(bpy.types.Operator):
    bl_label = "Add Preset"
    bl_idname = "b.add_item"
    bl_description = AddPresetTooltip
    
    newItemName: bpy.props.StringProperty(name="Name", maxlen=16)
    
    def execute(self, context):
        global easingPresets
        
        sc = bpy.context.scene
        ei = round(sc.easing_right,2)
        eo = round(sc.easing_left,2)
        iv = round(sc.initial_velocity,2)
        fv = round(sc.final_velocity,2)
        
        newItemValue = str((ei , eo , iv , fv)).replace(" ", "").replace(".0", "")
        
        print(newItemValue)
        
        if self.newItemName and newItemValue:
            
            for item in easingPresets:
                print(item[0])
                if item[0] == newItemValue:
                    self.report({'WARNING'}, f'"{item[1]}" preset already contains identical values.')
                    sc.presetsCombo = item[0]
                    return {'FINISHED'}
                    break
                elif item[1] == self.newItemName:
                    self.report({'WARNING'}, "Cannot add 2 presets with identical names.")
                    return {'FINISHED'}
                    break
                

            newItem = (newItemValue, self.newItemName, "" ,"GREASEPENCIL", len(easingPresets)+1)
            easingPresets.append(newItem)
            updateEasingPresets(easingPresets)
            try:
                bpy.context.scene.presetsCombo = newItemValue
            except:
                bpy.context.scene.presetsCombo = "(37,37,0,0)"
        else:
            self.report({'WARNING'}, 'Please provide a name for the preset.')

        return {'FINISHED'}
    
    def invoke(self, context, event):
        self.newItemName = ""
        return context.window_manager.invoke_props_dialog(self)

class FlipEase(bpy.types.Operator):
    bl_label = "Swap Ease"
    bl_idname = "gp.flip_ease"
    bl_description = SwapEasingTooltip
    
    def execute(self, context):
        context.scene.easing_right, context.scene.easing_left = context.scene.easing_left, context.scene.easing_right
        return {'FINISHED'}

class FlipVelocity(bpy.types.Operator):
    bl_label = "Swap Velocity"
    bl_idname = "gp.flip_velocity"
    bl_description = SwapVelocityTooltip
    
    def execute(self, context):
        context.scene.initial_velocity, context.scene.final_velocity = context.scene.final_velocity, context.scene.initial_velocity
        return {'FINISHED'}


# ======================================================= UI =================================================================


class GraphPilotUI:

    def draw_header(self, context):
        layout = self.layout
        row = layout.row(align = True)
        layout.alignment = 'RIGHT'
        row.operator("gp.link", text = "", emboss = False, icon_value = icons['BlenderMarket'].icon_id)

    def draw(self, context):   #Show UI  
        layout = self.layout
        scene = context.scene

        layout.prop(scene.interpolation_presets, "interpolation", text="")    
           
        # create a new box
        easing_box = layout.box()
         
        row = easing_box.row(align = True)
        row.prop(scene, "presetsCombo", text="")  
        row.operator("b.add_item", text="", icon="ADD")
        row.operator("b.remove_item", text="", icon="REMOVE")
        
        column = easing_box.column()
        row = column.row(align = True)
        row.label(text="  Easing")
        row.operator("gp.flip_ease", text="", icon_value=icons['Flip'].icon_id, emboss = False)
        inner = column.box()
        
        # add the easing properties inside the box with sliders
        inner.prop(scene, "easing_right", slider=True)
        inner.prop(scene, "easing_left", slider=True)

        # create a new box
        column = easing_box.column()
        row = column.row(align = True)
        row.label(text="  Velocity")
        row.prop(scene, "lock_velocity", text="", icon="FAKE_USER_ON" if scene.lock_velocity else "FAKE_USER_OFF", emboss=False)
        col = row.column()
        col.operator("gp.flip_velocity", text="", icon_value=icons['Flip'].icon_id, emboss = False)
        
        inner2 = column.box()
        inner2.prop(scene, "initial_velocity", slider=True)
        inner2.prop(scene, "final_velocity", slider=True)
        if scene.lock_velocity: inner2.enabled = col.enabled = False
        
        column = easing_box.column()
        column.label(text="  Advanced")
        inner3 = column.box()
        column = inner3.column()
        column.prop(scene, "realtime", text="Realtime")
        column.prop(scene, "change_keys", text="Change Keyframe Values")
        column.prop(scene, "restrict_to_selection", text="Restrict to Selection Bounds")
        
        column = easing_box.column()
        column.label(text="  Tools")
        
        inner4 = column.box()
        row = inner4.row(align = True)
        row.operator("gp.copy_easing", text="Copy", icon="COPYDOWN")
        row.operator("gp.clean_keys", text="Clean", icon="BRUSHES_ALL")

        row = inner4.row(align = True)
        row.scale_x = 3
        row.operator("gp.flat_handles", text="", icon="HANDLE_ALIGNED")
        row.operator("gp.auto_handles", text="", icon="HANDLE_AUTO")
        row.operator("gp.auto_clamp_handles", text="", icon="HANDLE_AUTOCLAMPED")
        row.operator("gp.vector_handles", text="", icon="HANDLE_VECTOR")
        

        row = easing_box.row()
        row.operator("object.apply_easing", text="Apply")

class ViewportUI(bpy.types.Panel, GraphPilotUI):   # Child Class of GraphPilotUI
    bl_idname = "OBJECT_PT_easing_keyframes"
    bl_label = "Graph Pilot"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Graph Pilot"


    def draw(self, context):
        super().draw(context)

class GraphEditorUI(bpy.types.Panel, GraphPilotUI):   # Child Class of GraphPilotUI
    bl_idname = "GRAPH_PT_easing_keyframes"
    bl_label = "Graph Pilot"
    bl_space_type = "GRAPH_EDITOR"
    bl_region_type = "UI"
    bl_category = "Graph Pilot"


    def draw(self, context):
        super().draw(context)


# ===================================================== TOOLS ===============================================================


class CopyEasingOperator(bpy.types.Operator):
    bl_idname = "gp.copy_easing"
    bl_label = "Copy Easing"
    bl_description = CopyEasingTooltip
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_keyframes = get_animation(True)
        OGrealtimeEase = context.scene.realtime # We don't need realtime ease now
        context.scene.realtime = False

        # Check if only two keyframes are selected
        if len(selected_keyframes) != 2:
            self.report({'WARNING'}, "Please select exactly 2 keyframes.")
            return {'CANCELLED'}
        
        key1, key2 = selected_keyframes

        # Check if the selected keyframes belong to the same F-Curve
        fcurve_1 = key1[0]
        fcurve_2 = key2[0]
        if fcurve_1 != fcurve_2:
            self.report({'WARNING'}, "Please select 2 keyframes on the same F-Curve.")
            return {'CANCELLED'}

        # Check if the selected keyframes belong to the same F-Curve
        time_to_next = abs( calculate_key_diff(keyframe_data=key1)[1] )
        time_to_key2 = abs( key2[1].co.x - key1[1].co.x )
        if time_to_next != time_to_key2:
            self.report({'WARNING'}, "Please select 2 successive keyframes.")
            return {'CANCELLED'}

        for kf in selected_keyframes:
            if kf[1].interpolation == 'CONSTANT':
                self.report({'WARNING'}, "Please select keyframes with Bezier interpolation.")
                return {'CANCELLED'}
            
            elif kf[1].interpolation == 'LINEAR':
                bpy.context.scene.easing_right = bpy.context.scene.easing_left = bpy.context.scene.initial_velocity = bpy.context.scene.final_velocity = 0
                self.report({'INFO'}, "Easing copied Sucessfully!")
                return {'FINISHED'}
            

        # Get the easing values from the selected keyframes
        time_difference = calculate_key_diff(keyframe_data=key1)[1]
        value_difference = calculate_key_diff(keyframe_data=key1)[3]

        if value_difference == 0:
            self.report({'WARNING'}, "Cannot copy easing. Both keyframes have the same value.")
            return {'CANCELLED'}
        
        ease_in = (key1[1].handle_right.x - key1[1].co.x)/time_difference * 100
        bpy.context.scene.easing_right = round(ease_in, 2)
        
        ease_out = (key2[1].co.x - key2[1].handle_left.x)/time_difference * 100
        bpy.context.scene.easing_left = round(ease_out, 2)
        
        velocity_in = (key1[1].handle_right.y - key1[1].co.y)/value_difference * -100
        bpy.context.scene.initial_velocity = round(velocity_in, 2)
        
        velocity_out = (key2[1].co.y - key2[1].handle_left.y)/value_difference * -100
        bpy.context.scene.final_velocity = round(velocity_out, 2)

        context.scene.realtime = OGrealtimeEase
        self.report({'INFO'}, "Easing copied Sucessfully!")
        return {'FINISHED'}
    
class CleanOperator(bpy.types.Operator):
    bl_idname = "gp.clean_keys"
    bl_label = "Clean Keyframes"
    bl_description = CleanTooltip
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            original_type = bpy.context.area.type
            bpy.context.area.type = 'GRAPH_EDITOR'
            selected_keyframes = get_animation(True)
            number_before =  len(selected_keyframes)
            bpy.ops.graph.clean(channels=True)
            bpy.context.area.type = original_type
            selected_keyframes = get_animation(True)
            number_after =  len(selected_keyframes)
            self.report({'INFO'}, f"Removed {number_before - number_after} keyframes")
        except:
            self.report({'WARNING'}, "No keyframes selected")

        return {'FINISHED'}


# ==================================================== HANDLES ==============================================================


class AutoClampHandlesOperator(Operator):
    bl_idname = "gp.auto_clamp_handles"
    bl_label = "Automatic Clamped Handles"
    bl_description = """Automatic handles that create smooth curves which 
only change direction at keyframes (no overshooting)"""

    def execute(self, context):
        original_type = bpy.context.area.type
        bpy.context.area.type = 'GRAPH_EDITOR'
        context.scene.interpolation_presets.interpolation = 'BEZIER'
        bpy.ops.graph.interpolation_type(type='BEZIER')
        bpy.ops.graph.handle_type(type='AUTO_CLAMPED')   
        bpy.context.area.type = original_type
        return {'FINISHED'}

class AutoHandlesOperator(Operator):
    bl_idname = "gp.auto_handles"
    bl_label = "Automatic Handles"
    bl_description = "Automatic handles that create smooth curves"

    def execute(self, context):
        original_type = bpy.context.area.type
        bpy.context.area.type = 'GRAPH_EDITOR'
        context.scene.interpolation_presets.interpolation = 'BEZIER'
        bpy.ops.graph.interpolation_type(type='BEZIER')
        bpy.ops.graph.handle_type(type='AUTO')   
        bpy.context.area.type = original_type
        return {'FINISHED'}
    
class VectorHandlesOperator(Operator):
    bl_idname = "gp.vector_handles"
    bl_label = "Vector Handles"
    bl_description = "Automatic handles that create straight lines"

    def execute(self, context):
        original_type = bpy.context.area.type
        bpy.context.area.type = 'GRAPH_EDITOR'
        context.scene.interpolation_presets.interpolation = 'BEZIER'
        bpy.ops.graph.interpolation_type(type='BEZIER')
        bpy.ops.graph.handle_type(type='VECTOR')   
        bpy.context.area.type = original_type
        return {'FINISHED'}
    
class FlatHandlesOperator(Operator):
    bl_idname = "gp.flat_handles"
    bl_label = "Flat Handles"
    bl_description = "Flat horizontal handles"

    def execute(self, context):
        original_type = bpy.context.area.type
        bpy.context.area.type = 'GRAPH_EDITOR'

        context.scene.interpolation_presets.interpolation = 'BEZIER'
        bpy.ops.graph.interpolation_type(type='BEZIER')

        original_pivot = bpy.context.space_data.pivot_point
        bpy.context.space_data.pivot_point = 'INDIVIDUAL_ORIGINS'
        bpy.ops.transform.resize(value=(1, 0, 1))
        bpy.context.space_data.pivot_point = original_pivot
        bpy.ops.graph.handle_type(type='ALIGNED')   
        bpy.context.area.type = original_type
        return {'FINISHED'}
    

# ================================================== PREFERENCES ============================================================


class GraphPilotPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Custom Presets")
        row = box.row(align=True)
        row.operator("gp.export_custom_presets", text="Save" , icon="EXPORT")
        row.operator("gp.load_custom_presets", text="Load", icon="IMPORT")

class SavePresetsOperator(Operator):
    bl_idname = "gp.export_custom_presets"
    bl_label = "Save"
    bl_description = "Save custom presets to a JSON file"

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(
        default="*.json",
        options={'HIDDEN'},
    )

    def execute(self, context):
        if not self.filepath.lower().endswith('.json'):
            self.filepath += '.json'
        
        customPresets = []
        for item in easingPresets:
            ItemIcon = item[3]
            if ItemIcon == "GREASEPENCIL":
                customPresets.append(item)
        
        with open(self.filepath, 'w') as f:
            json.dump(customPresets, f)
        
        self.report({'INFO'}, "Presets saved successfully")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    
class LoadPresetsOperator(bpy.types.Operator):
    bl_idname = "gp.load_custom_presets"
    bl_label = "Load"
    bl_description = "Load custom presets from a JSON file"

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(
        default="*.json",
        options={'HIDDEN'},
    )


    def execute(self, context):
        global easingPresets  # Use the global easingPresets variable

        try:
            with open(self.filepath, 'r') as f:
                new_presets = json.load(f)  # Load JSON data
                new_presets = [tuple(item) for item in new_presets]  # Convert lists to tuples

                # Check if all item icons are "GREASEPENCIL"
                for item in new_presets:
                    if item[3] != "GREASEPENCIL":
                        self.report({'ERROR'}, "Invalid item found in presets. Please don't edit the file")
                        return {'CANCELLED'}

                # Replace presets with the same name and update the number to the index
                name_to_index = {preset[1]: i for i, preset in enumerate(easingPresets)}  # Second element is the name
                max_index = len(easingPresets)  # Start with the current max index

                for new_preset in new_presets:
                    preset_name = new_preset[1]
                    if preset_name in name_to_index:
                        index = name_to_index[preset_name]
                        easingPresets[index] = new_preset[:4] + (index,)  # Update number to index
                    else:
                        max_index += 1  # Increment max index for new presets
                        easingPresets.append(new_preset[:4] + (max_index,))  # Update number to new max index
                
                print("New presets added/replaced:", new_presets)
                updateEasingPresets(easingPresets)  # Call function to update easing presets
                self.report({'INFO'}, "Presets loaded successfully")
        except FileNotFoundError:
            print("No items found")  # Print error message if file not found
            self.report({'ERROR'}, "File not found")
            return {'CANCELLED'}
        except json.JSONDecodeError:
            print("Invalid JSON format")
            self.report({'ERROR'}, "Invalid JSON format")
            return {'CANCELLED'}
        except Exception as e:
            print(f"Failed to load presets: {e}")
            self.report({'ERROR'}, f"Failed to load presets: {e}")
            return {'CANCELLED'}
        
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


# ==================================================== REGISTER ==============================================================


classes = [
    ViewportUI,
    GraphEditorUI,
    InterpolationPresets,
    ApplyEasingOperator,
    AddPresetOperator,
    RemovePresetOperator,
    FlipEase,
    FlipVelocity,
    CopyEasingOperator,
    CleanOperator,
    AddonLinkButton,
    AutoClampHandlesOperator,
    AutoHandlesOperator,
    VectorHandlesOperator,
    FlatHandlesOperator,
    GraphPilotPreferences,
    SavePresetsOperator,
    LoadPresetsOperator,
]

def register():
    global custom_icons
    custom_icons = previews.new()

    loadItemsFromJson()
    initializeSceneProperties()
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.interpolation_presets = bpy.props.PointerProperty(type=InterpolationPresets)
    translate.register()
def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.interpolation_presets
    del bpy.types.Scene.change_keys
    del bpy.types.Scene.restrict_to_selection

    global custom_icons
    if custom_icons:
        previews.remove(custom_icons)
        custom_icons = None
    translate.unregister()

if __name__ == "__main__":
    register()