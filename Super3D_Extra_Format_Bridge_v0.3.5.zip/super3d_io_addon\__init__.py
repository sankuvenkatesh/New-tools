bl_info = {
    "name": "Super3D Extra Format Bridge",
    "author": "475519905",
    "version": (0, 3, 5),
    "blender": (4, 0, 0),
    "location": "File > Import / Export",
    "description": "Import & export extra 3D formats via Super3D cloud conversion",
    "category": "Import-Export",
}

import json
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import ssl
import uuid
from pathlib import Path

import bpy
from bpy.props import BoolProperty, EnumProperty, IntProperty, StringProperty
from bpy.types import AddonPreferences, Menu, Operator
from bpy_extras.io_utils import ExportHelper, ImportHelper

API_DEFAULT_BASE_URL = "https://c4d.app"
TEMP_DIR_NAME = "super3d_blender_demo"

IMPORT_FORMATS = (
    ("3dm", "Rhino 3D"),
    ("3ds", "3D Studio"),
    ("3mf", "3MF"),
    ("apb", "APB"),
    ("c4d", "Cinema 4D"),
    ("catpart", "CATIA Part"),
    ("catproduct", "CATIA Product"),
    ("cgr", "CATIA CGR"),
    ("dwg", "AutoCAD DWG"),
    ("dxf", "AutoCAD DXF"),
    ("iam", "Inventor Assembly"),
    ("idw", "Inventor Drawing"),
    ("ifc", "IFC"),
    ("hip", "Houdini HIP"),
    ("hiplc", "Houdini HIPLC"),
    ("hipnc", "Houdini HIPNC"),
    ("iges", "IGES"),
    ("igs", "IGS"),
    ("ipn", "Inventor Presentation"),
    ("ipt", "Inventor Part"),
    ("jt", "JT"),
    ("ma", "Maya ASCII"),
    ("max", "3ds Max"),
    ("mb", "Maya Binary"),
    ("nwc", "Navisworks Cache"),
    ("nwd", "Navisworks Document"),
    ("p21", "STEP P21"),
    ("rfa", "Revit Family"),
    ("rvt", "Revit Project"),
    ("sab", "ACIS SAB"),
    ("sat", "ACIS SAT"),
    ("skp", "SketchUp"),
    ("sldasm", "SolidWorks Assembly"),
    ("sldprt", "SolidWorks Part"),
    ("step", "STEP"),
    ("stp", "STP"),
    ("wrl", "VRML"),
    ("x_b", "Parasolid X_B"),
    ("x_t", "Parasolid X_T"),
)

EXPORT_FORMATS = (
    ("3dm", "Rhino 3D"),
    ("3ds", "3D Studio"),
    ("3mf", "3MF"),
    ("c4d", "Cinema 4D"),
    ("dwg", "AutoCAD DWG"),
    ("dxf", "AutoCAD DXF"),
    ("f3d", "Fusion 360"),
    ("hip", "Houdini HIP"),
    ("hiplc", "Houdini HIPLC"),
    ("hipnc", "Houdini HIPNC"),
    ("ifc", "IFC"),
    ("iges", "IGES"),
    ("igs", "IGS"),
    ("ma", "Maya ASCII"),
    ("max", "3ds Max"),
    ("mb", "Maya Binary"),
    ("sat", "ACIS SAT"),
    ("step", "STEP"),
    ("stp", "STP"),
    ("wrl", "VRML"),
    ("x", "DirectX"),
)


def _enum_items(formats):
    return tuple(
        (ext, f"{label} (.{ext})", f"Convert via Super3D: .{ext}")
        for ext, label in formats
    )


IMPORT_FORMAT_ENUM_ITEMS = _enum_items(IMPORT_FORMATS)
EXPORT_FORMAT_ENUM_ITEMS = _enum_items(EXPORT_FORMATS)



# ---------------------------------------------------------------------------
#  Background task state shared between worker thread and modal operator
# ---------------------------------------------------------------------------

class _TaskState:
    __slots__ = ("progress", "status", "error", "done", "result", "cache_hit")

    def __init__(self):
        self.progress = 0
        self.status = ""
        self.error = ""
        self.done = False
        self.result = None
        self.cache_hit = False


# ---------------------------------------------------------------------------
#  Preferences
# ---------------------------------------------------------------------------

class SUPER3D_OT_toggle_all_formats(Operator):
    bl_idname = "super3d.toggle_all_formats"
    bl_label = "Toggle All Formats"
    bl_options = {"INTERNAL"}

    action: EnumProperty(
        items=(
            ("IMPORT_ALL", "Import All", ""),
            ("IMPORT_NONE", "Import None", ""),
            ("EXPORT_ALL", "Export All", ""),
            ("EXPORT_NONE", "Export None", ""),
        ),
    )

    def execute(self, context):
        prefs = _prefs(context)
        if self.action == "IMPORT_ALL":
            for ext, _ in IMPORT_FORMATS:
                setattr(prefs, f"show_import_{ext}", True)
        elif self.action == "IMPORT_NONE":
            for ext, _ in IMPORT_FORMATS:
                setattr(prefs, f"show_import_{ext}", False)
        elif self.action == "EXPORT_ALL":
            for ext, _ in EXPORT_FORMATS:
                setattr(prefs, f"show_export_{ext}", True)
        elif self.action == "EXPORT_NONE":
            for ext, _ in EXPORT_FORMATS:
                setattr(prefs, f"show_export_{ext}", False)
        return {"FINISHED"}


class SUPER3D_AddonPrefs(AddonPreferences):
    bl_idname = __name__

    api_base_url: StringProperty(
        name="API Base URL",
        default=API_DEFAULT_BASE_URL,
        description="Super3D public API URL",
    )
    request_timeout_sec: IntProperty(
        name="Request Timeout (sec)",
        default=1800,
        min=30,
        max=7200,
    )
    keep_temp_files: BoolProperty(
        name="Keep Temp Files",
        default=False,
        description="Keep temporary .obj files in Blender temp directory",
    )

    def draw(self, _context):
        layout = self.layout

        # --- Import format filter ---
        box_imp = layout.box()
        row = box_imp.row()
        row.label(text="Import Formats", icon="IMPORT")
        row.operator(SUPER3D_OT_toggle_all_formats.bl_idname,
                     text="All").action = "IMPORT_ALL"
        row.operator(SUPER3D_OT_toggle_all_formats.bl_idname,
                     text="None").action = "IMPORT_NONE"
        flow = box_imp.grid_flow(row_major=True, columns=4, even_columns=True, even_rows=True, align=True)
        for ext, _label in IMPORT_FORMATS:
            flow.prop(self, f"show_import_{ext}")

        # --- Export format filter ---
        box_exp = layout.box()
        row = box_exp.row()
        row.label(text="Export Formats", icon="EXPORT")
        row.operator(SUPER3D_OT_toggle_all_formats.bl_idname,
                     text="All").action = "EXPORT_ALL"
        row.operator(SUPER3D_OT_toggle_all_formats.bl_idname,
                     text="None").action = "EXPORT_NONE"
        flow = box_exp.grid_flow(row_major=True, columns=4, even_columns=True, even_rows=True, align=True)
        for ext, _label in EXPORT_FORMATS:
            flow.prop(self, f"show_export_{ext}")


# Dynamically add per-format visibility toggles
for _ext, _label in IMPORT_FORMATS:
    SUPER3D_AddonPrefs.__annotations__[f"show_import_{_ext}"] = BoolProperty(
        name=f"{_label} (.{_ext})",
        default=True,
        description=f"Show {_label} (.{_ext}) in Import menu",
    )

for _ext, _label in EXPORT_FORMATS:
    SUPER3D_AddonPrefs.__annotations__[f"show_export_{_ext}"] = BoolProperty(
        name=f"{_label} (.{_ext})",
        default=True,
        description=f"Show {_label} (.{_ext}) in Export menu",
    )


def _prefs(context) -> SUPER3D_AddonPrefs:
    addon = context.preferences.addons.get(__name__)
    if addon and addon.preferences:
        return addon.preferences

    class _Fallback:
        api_base_url = API_DEFAULT_BASE_URL
        request_timeout_sec = 1800
        keep_temp_files = False

    return _Fallback()


# ---------------------------------------------------------------------------
#  HTTP helpers
# ---------------------------------------------------------------------------

_SSL_CONTEXT = None


def _get_ssl_context():
    """Lazy-create a permissive TLS context for embedded Python builds."""
    global _SSL_CONTEXT
    if _SSL_CONTEXT is None:
        _SSL_CONTEXT = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        _SSL_CONTEXT.check_hostname = False
        _SSL_CONTEXT.verify_mode = ssl.CERT_NONE
    return _SSL_CONTEXT


def _urlopen_with_retry(req, timeout, max_retries=2):
    for attempt in range(max_retries + 1):
        try:
            return urllib.request.urlopen(req, timeout=timeout, context=_get_ssl_context())
        except (urllib.error.URLError, ConnectionError, TimeoutError):
            if attempt >= max_retries:
                raise
            time.sleep(3 * (attempt + 1))


def _friendly_error_text(text: str, source_ext: str = "", target_ext: str = "") -> str:
    raw = (text or "").strip()
    lower = raw.lower()
    source = (source_ext or "").strip().lower()
    target = (target_ext or "").strip().lower()
    suffix = ""
    if "error id:" in lower:
        suffix = " " + raw[lower.find("error id:"):].strip().rstrip(".")

    if "export_mesh_ot_apx" in lower or "export_mesh.apx" in lower:
        return "APX export is temporarily unavailable on the server. Please choose another format." + suffix
    if "obj has no vertex records" in lower:
        return "Conversion failed: the scene has no exportable mesh vertices. Check that visible geometry exists." + suffix
    if "native 3ds max bridge did not create output" in lower and (".sat" in lower or "result.sat" in lower):
        return "SAT export failed: this MAX scene did not produce an ACIS SAT body. Try OBJ, 3DS, DWG, IGES, or IGS." + suffix
    if "step file has no solid/shell topology entities" in lower:
        return "STEP/STP export failed: the converted file has no solid or shell topology. Mesh-only scenes may not export as CAD solids." + suffix
    if "token exchange access denied" in lower or "aps bridge" in lower:
        return "This route depends on Autodesk APS, which is currently unavailable. Please choose a non-APS format." + suffix
    if "autodesk_maya_file_import_export" in lower and "not found" in lower:
        return "Maya export is unavailable because the server-side Maya add-on is not enabled." + suffix
    if target == "sat" and ("invalid_worker_response" in lower or "系统维护中" in lower):
        return "SAT export did not return a usable server result. Mesh-only MAX scenes often cannot be written as ACIS SAT; try OBJ, 3DS, DWG, IGES, or IGS." + suffix
    if target == "sat" and ("remote execution error" in lower or "internal error" in lower or "conversion failed" in lower):
        return "SAT export failed on the server. Mesh-only scenes often cannot be written as ACIS SAT; try OBJ, 3DS, DWG, IGES, or IGS." + suffix
    if target in {"step", "stp"} and ("remote execution error" in lower or "internal error" in lower or "conversion failed" in lower):
        return "STEP/STP export failed on the server. The scene may not contain CAD solid or shell topology." + suffix
    if source == "max" and target == "obj" and ("remote execution error" in lower or "internal error" in lower or "conversion failed" in lower):
        return "3ds Max import failed or produced no exportable mesh. Check that the MAX file opens and contains visible geometry." + suffix
    if "invalid_worker_response" in lower or "系统维护中" in lower:
        return "The conversion worker did not return a usable result. Please retry later or choose another format." + suffix
    return raw


def _extract_error_text(raw_text: str, fallback: str,
                        source_ext: str = "", target_ext: str = "") -> str:
    text = (raw_text or "").strip()
    if not text:
        return _friendly_error_text(fallback, source_ext, target_ext)

    try:
        payload = json.loads(text)
        if isinstance(payload, dict):
            candidates = []
            error_code = payload.get("error_code")
            for key in ("message", "detail", "error_message", "reason"):
                value = payload.get(key)
                if isinstance(value, str) and value.strip():
                    candidates.append(value.strip())
            err = payload.get("error")
            if isinstance(err, dict):
                if not error_code:
                    error_code = err.get("code")
                for key in ("message", "detail"):
                    value = err.get(key)
                    if isinstance(value, str) and value.strip():
                        candidates.append(value.strip())
            elif isinstance(err, str) and err.strip():
                candidates.append(err.strip())
            result = payload.get("result")
            if isinstance(result, dict):
                result_err = result.get("error")
                if isinstance(result_err, dict):
                    if not error_code:
                        error_code = result_err.get("code")
                    for key in ("message", "detail"):
                        value = result_err.get(key)
                        if isinstance(value, str) and value.strip():
                            candidates.append(value.strip())
                elif isinstance(result_err, str) and result_err.strip():
                    candidates.append(result_err.strip())
            error_id = payload.get("error_id")
            if candidates:
                message = candidates[0]
                if error_code and str(error_code).lower() not in message.lower():
                    message = f"{message} Error code: {error_code}"
                if error_id and "error id:" not in message.lower():
                    message = f"{message} Error ID: {error_id}"
                return _friendly_error_text(message, source_ext, target_ext)
    except Exception:
        pass

    return _friendly_error_text(text, source_ext, target_ext)


def _payload_cache_hit(payload: dict) -> bool:
    for key in ("cache_hit", "cacheHit", "cached"):
        if bool(payload.get(key)):
            return True
    reason = str(payload.get("reason") or payload.get("message") or "").lower()
    return "cache" in reason or "cached" in reason


def _status_message(status: dict, state: str, source_ext: str, target_ext: str, elapsed: float) -> str:
    if _payload_cache_hit(status):
        return "Using cached result..."

    raw = str(status.get("message") or status.get("detail") or "").strip()
    if raw and raw.lower() not in {"queued", "pending", "running", "processing", "started"}:
        return raw

    source = (source_ext or "").lower()
    target = (target_ext or "").upper()
    if state in {"queued", "pending"}:
        return "Queued on Super3D..."
    if source == "max":
        if elapsed < 10:
            return "Launching 3ds Max..."
        if elapsed < 45:
            return "3ds Max importing MAX scene..."
        return f"3ds Max exporting {target}..." if target else "3ds Max processing scene..."
    if state in {"running", "processing"}:
        return "Converting on Super3D..."
    return state or "Processing..."


def _http_json(method: str, url: str, payload: dict | None, timeout: int) -> dict:
    body = None
    headers = {"Accept": "application/json"}
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"

    req = urllib.request.Request(url=url, data=body, method=method.upper(), headers=headers)
    try:
        with _urlopen_with_retry(req, timeout=timeout) as resp:
            data = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        detail = (exc.read() or b"").decode("utf-8", errors="replace")
        raise RuntimeError(_extract_error_text(detail, f"HTTP {exc.code}")) from exc
    except (urllib.error.URLError, ConnectionError, TimeoutError) as exc:
        raise RuntimeError(f"Network error: {exc}") from exc

    if not data.strip():
        return {}

    try:
        parsed = json.loads(data)
    except Exception as exc:
        raise RuntimeError("Server returned non-JSON response") from exc

    if not isinstance(parsed, dict):
        raise RuntimeError("Server returned invalid JSON payload")
    return parsed


def _http_multipart_convert(url: str, file_path: Path, fields: dict[str, str], timeout: int,
                            task: _TaskState | None = None) -> dict:
    source_ext = str(fields.get("source_ext") or "")
    target_ext = str(fields.get("target") or "")
    boundary = f"----Super3D{uuid.uuid4().hex}"
    body = bytearray()

    # --- prefix (form fields) ---
    for key, value in fields.items():
        body.extend(f"--{boundary}\r\n".encode("utf-8"))
        body.extend(f'Content-Disposition: form-data; name="{key}"\r\n\r\n'.encode("utf-8"))
        body.extend(str(value).encode("utf-8"))
        body.extend(b"\r\n")

    body.extend(f"--{boundary}\r\n".encode("utf-8"))
    body.extend(
        f'Content-Disposition: form-data; name="model"; filename="{file_path.name}"\r\n'.encode("utf-8")
    )
    body.extend(b"Content-Type: application/octet-stream\r\n\r\n")
    prefix_len = len(body)

    # --- file content (chunked read with progress) ---
    file_size = file_path.stat().st_size
    total_body_est = prefix_len + file_size + 64  # 64 ≈ trailing boundary overhead
    read_so_far = 0
    with open(file_path, "rb") as fh:
        while True:
            chunk = fh.read(128 * 1024)
            if not chunk:
                break
            body.extend(chunk)
            read_so_far += len(chunk)
            if task and total_body_est > 0:
                pct = min(read_so_far / total_body_est, 0.95)
                task.progress = 10 + int(pct * 8)  # 10→18 while reading file
                task.status = "Preparing upload..."

    # --- suffix ---
    body.extend(b"\r\n")
    body.extend(f"--{boundary}--\r\n".encode("utf-8"))

    if task:
        task.progress = 18
        task.status = "Uploading..."

    req = urllib.request.Request(
        url=url,
        data=bytes(body),
        method="POST",
        headers={
            "Accept": "application/json",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
    )

    try:
        with _urlopen_with_retry(req, timeout=timeout, max_retries=2) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        detail = (exc.read() or b"").decode("utf-8", errors="replace")
        raise RuntimeError(_extract_error_text(
            detail, f"HTTP {exc.code}", source_ext, target_ext,
        )) from exc
    except (urllib.error.URLError, ConnectionError, TimeoutError) as exc:
        raise RuntimeError(f"Network error: {exc}") from exc

    if not raw.strip():
        raise RuntimeError("Empty response from /convert")

    try:
        payload = json.loads(raw)
    except Exception:
        raise RuntimeError(_extract_error_text(
            raw, "Invalid /convert response", source_ext, target_ext,
        ))

    if not isinstance(payload, dict):
        raise RuntimeError("Invalid /convert payload")
    if not payload.get("ok"):
        raise RuntimeError(_extract_error_text(
            raw, "Conversion failed", source_ext, target_ext,
        ))

    return payload


def _download_file(url: str, output_path: Path, timeout: int,
                   task: _TaskState | None = None,
                   progress_base: int = 0, progress_span: int = 0) -> None:
    """Download a file with optional progress reporting via *task*."""
    req = urllib.request.Request(url=url, method="GET")
    try:
        with _urlopen_with_retry(req, timeout=timeout) as resp:
            total = int(resp.headers.get("Content-Length") or 0)
            chunks: list[bytes] = []
            received = 0
            while True:
                chunk = resp.read(64 * 1024)
                if not chunk:
                    break
                chunks.append(chunk)
                received += len(chunk)
                if task and total > 0 and progress_span > 0:
                    pct = min(received / total, 1.0)
                    task.progress = progress_base + int(pct * progress_span)
                    task.status = f"Downloading... {received * 100 // total}%"
    except urllib.error.HTTPError as exc:
        detail = (exc.read() or b"").decode("utf-8", errors="replace")
        raise RuntimeError(_extract_error_text(detail, f"Download failed (HTTP {exc.code})")) from exc
    except (urllib.error.URLError, ConnectionError, TimeoutError) as exc:
        raise RuntimeError(f"Download network error: {exc}") from exc

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(b"".join(chunks))


def _absolute_download_url(base_url: str, maybe_relative: str) -> str:
    text = (maybe_relative or "").strip()
    if text.startswith("http://") or text.startswith("https://"):
        return text
    return urllib.parse.urljoin(base_url.rstrip("/") + "/", text.lstrip("/"))


def _temp_root() -> Path:
    root = Path(bpy.app.tempdir or tempfile.gettempdir()) / TEMP_DIR_NAME
    root.mkdir(parents=True, exist_ok=True)
    return root


def _preflight(base_url: str, source_ext: str, target_ext: str, timeout: int) -> None:
    url = f"{base_url.rstrip('/')}/preflight"
    payload = {
        "source_ext": source_ext,
        "target": target_ext,
    }
    result = _http_json("POST", url, payload, timeout)
    if not bool(result.get("ok")):
        message = str(result.get("message") or "No available conversion route")
        raise RuntimeError(message)


def _wait_for_task_result(base_url: str, payload: dict, timeout: int,
                          task: _TaskState | None = None,
                          source_ext: str = "", target_ext: str = "") -> dict:
    status_url = _absolute_download_url(base_url, str(payload.get("status_url") or ""))
    if not status_url:
        return payload

    started = time.time()
    while True:
        if time.time() - started > timeout:
            raise RuntimeError("Timed out waiting for queued conversion")

        status = _http_json("GET", status_url, None, min(timeout, 60))
        state = str(status.get("state") or status.get("status") or "").strip().lower()
        if task:
            progress = status.get("progress")
            if isinstance(progress, int):
                task.progress = max(task.progress, min(progress, 95))
            elif state in {"running", "processing"}:
                elapsed = time.time() - started
                task.progress = max(task.progress, min(58, 30 + int(elapsed / 15)))
            elif state in {"queued", "pending"}:
                task.progress = max(task.progress, 30)
            if _payload_cache_hit(status):
                task.cache_hit = True
            task.status = _status_message(status, state, source_ext, target_ext, time.time() - started)

        download_url = str(status.get("download_url") or "")
        if download_url:
            if task and _payload_cache_hit(status):
                task.cache_hit = True
            return status

        if state in {"failed", "error", "cancelled", "canceled"}:
            raise RuntimeError(_extract_error_text(
                json.dumps(status), "Conversion failed", source_ext, target_ext,
            ))

        if status.get("ok") is False and state not in {"queued", "pending", "running", "processing"}:
            raise RuntimeError(_extract_error_text(
                json.dumps(status), "Conversion failed", source_ext, target_ext,
            ))

        time.sleep(1.5)


def _run_convert(base_url: str, source_path: Path, target_ext: str, timeout: int,
                 task: _TaskState | None = None) -> dict:
    source_ext = source_path.suffix.lower().lstrip(".")
    if not source_ext:
        raise RuntimeError("Source file extension is missing")

    if task:
        task.status = "Checking route..."
        task.progress = max(task.progress, 3)
    _preflight(base_url, source_ext, target_ext, timeout)
    if task:
        task.progress = max(task.progress, 8)

    if task:
        task.status = "Uploading & converting..."
        task.progress = max(task.progress, 10)

    url = f"{base_url.rstrip('/')}/convert"
    fields = {
        "target": target_ext,
        "source_ext": source_ext,
        "source_name": source_path.name,
        "response_mode": "json",
        "__task_id": f"blender_demo_{uuid.uuid4().hex[:16]}",
    }
    result = _http_multipart_convert(url=url, file_path=source_path, fields=fields, timeout=timeout,
                                     task=task)

    if task:
        task.progress = max(task.progress, 25)

    if result.get("download_url"):
        if task:
            if _payload_cache_hit(result):
                task.cache_hit = True
                task.status = "Using cached result..."
            task.progress = max(task.progress, 60)
        return result

    if result.get("queued") or result.get("status_url"):
        if task:
            task.status = "Queued on Super3D..."
            task.progress = max(task.progress, 30)
        result = _wait_for_task_result(
            base_url, result, timeout, task=task,
            source_ext=source_ext, target_ext=target_ext,
        )
        if task:
            if _payload_cache_hit(result):
                task.cache_hit = True
                task.status = "Using cached result..."
            task.progress = max(task.progress, 60)
        return result

    if task:
        task.progress = max(task.progress, 60)

    return result


# ---------------------------------------------------------------------------
#  OBJ helpers
# ---------------------------------------------------------------------------

def _import_obj(obj_path: Path) -> None:
    path_text = str(obj_path)
    if hasattr(bpy.ops.wm, "obj_import"):
        result = bpy.ops.wm.obj_import(filepath=path_text)
    elif hasattr(bpy.ops.import_scene, "obj"):
        result = bpy.ops.import_scene.obj(filepath=path_text)
    else:
        raise RuntimeError("OBJ import operator not found in this Blender build")

    if "FINISHED" not in result:
        raise RuntimeError("OBJ import failed")


def _export_scene_obj(obj_path: Path) -> None:
    path_text = str(obj_path)
    if hasattr(bpy.ops.wm, "obj_export"):
        result = bpy.ops.wm.obj_export(filepath=path_text)
    elif hasattr(bpy.ops.export_scene, "obj"):
        result = bpy.ops.export_scene.obj(filepath=path_text, use_selection=False)
    else:
        raise RuntimeError("OBJ export operator not found in this Blender build")

    if "FINISHED" not in result:
        raise RuntimeError("OBJ export failed")


def _default_export_name(ext: str) -> str:
    stem = Path(bpy.data.filepath).stem if bpy.data.filepath else "untitled"
    clean_stem = stem.strip() or "untitled"
    return f"{clean_stem}.{ext}"


# ---------------------------------------------------------------------------
#  Import operator  (modal + threaded)
# ---------------------------------------------------------------------------

class SUPER3D_OT_import_extra(Operator, ImportHelper):
    bl_idname = "super3d.import_extra"
    bl_label = "Import Extra Format (Super3D)"
    bl_description = "Upload selected file to Super3D, convert to OBJ, and import into current scene"

    filename_ext = ""
    filter_glob: StringProperty(default="*.*", options={"HIDDEN"})
    source_format: EnumProperty(name="Source Format", items=IMPORT_FORMAT_ENUM_ITEMS)

    _timer = None
    _thread: threading.Thread | None = None
    _task: _TaskState | None = None
    _out_obj: Path | None = None
    _keep_temp: bool = False
    _src_name: str = ""

    def invoke(self, context, _event):
        ext = (self.source_format or "").strip().lower()
        self.filter_glob = f"*.{ext}" if ext else "*.*"
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    # -- background worker ---------------------------------------------------

    def _worker(self, base_url: str, src: Path, timeout: int):
        task = self._task
        try:
            payload = _run_convert(base_url, src, "obj", timeout, task)
            download_url = _absolute_download_url(base_url, str(payload.get("download_url") or ""))
            if not download_url:
                raise RuntimeError("Missing download_url in convert response")

            task.status = "Downloading..."
            task.progress = max(task.progress, 60)
            download_base = task.progress
            _download_file(download_url, self._out_obj, timeout,
                           task=task, progress_base=download_base,
                           progress_span=min(35, 97 - download_base))
            task.progress = 97
            task.status = "Importing OBJ..."
        except Exception as exc:  # noqa: BLE001
            task.error = _friendly_error_text(str(exc), src.suffix.lower().lstrip("."), "obj")
        finally:
            task.done = True

    # -- modal loop ----------------------------------------------------------

    def modal(self, context, event):
        if event.type != "TIMER":
            return {"PASS_THROUGH"}

        task = self._task
        wm = context.window_manager

        # Update Blender progress bar
        wm.progress_update(task.progress)

        # Update header status text
        for area in context.screen.areas:
            if area.type in {"VIEW_3D", "INFO"}:
                area.header_text_set(f"Super3D: {task.status}  [{task.progress}%]")

        if not task.done:
            return {"PASS_THROUGH"}

        # ----- Task finished -----
        # Update to 99 % before OBJ import (which blocks the main thread)
        task.progress = 99
        task.status = "Importing OBJ..."
        wm.progress_update(99)
        for area in context.screen.areas:
            if area.type in {"VIEW_3D", "INFO"}:
                area.header_text_set(f"Super3D: {task.status}  [{task.progress}%]")

        wm.progress_end()
        if self._timer:
            wm.event_timer_remove(self._timer)
            self._timer = None

        if task.error:
            for area in context.screen.areas:
                if area.type in {"VIEW_3D", "INFO"}:
                    area.header_text_set(None)
            self.report({"ERROR"}, task.error)
            return {"CANCELLED"}

        # OBJ import must run on main thread
        try:
            _import_obj(self._out_obj)
        except Exception as exc:  # noqa: BLE001
            for area in context.screen.areas:
                if area.type in {"VIEW_3D", "INFO"}:
                    area.header_text_set(None)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        finally:
            if not self._keep_temp and self._out_obj:
                self._out_obj.unlink(missing_ok=True)

        for area in context.screen.areas:
            if area.type in {"VIEW_3D", "INFO"}:
                area.header_text_set(None)
        suffix = " (cached)" if task.cache_hit else ""
        self.report({"INFO"}, f"Imported via Super3D{suffix}: {self._src_name}")
        return {"FINISHED"}

    # -- execute (called after file browser) ---------------------------------

    def execute(self, context):
        prefs = _prefs(context)
        base_url = str(prefs.api_base_url or "").strip().rstrip("/")
        timeout = max(30, int(prefs.request_timeout_sec))
        self._keep_temp = bool(prefs.keep_temp_files)

        if not base_url:
            self.report({"ERROR"}, "API Base URL is empty")
            return {"CANCELLED"}

        src = Path(bpy.path.abspath(self.filepath or ""))
        if not src.exists() or not src.is_file():
            self.report({"ERROR"}, "Please choose a valid source file")
            return {"CANCELLED"}

        self._src_name = src.name
        self._out_obj = _temp_root() / f"import_{uuid.uuid4().hex}.obj"
        self._task = _TaskState()
        self._task.status = "Starting..."
        self._task.progress = 0

        # Start progress bar
        wm = context.window_manager
        wm.progress_begin(0, 100)

        # Start background thread
        self._thread = threading.Thread(
            target=self._worker, args=(base_url, src, timeout), daemon=True
        )
        self._thread.start()

        # Start modal timer (10 Hz refresh)
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        return {"RUNNING_MODAL"}


# ---------------------------------------------------------------------------
#  Export operator  (modal + threaded)
# ---------------------------------------------------------------------------

class SUPER3D_OT_export_extra(Operator, ExportHelper):
    bl_idname = "super3d.export_extra"
    bl_label = "Export Extra Format (Super3D)"
    bl_description = "Export scene as OBJ, convert through Super3D, and save to selected extra format"

    filename_ext = ""
    filter_glob: StringProperty(default="*.*", options={"HIDDEN"})
    target_format: EnumProperty(name="Target Format", items=EXPORT_FORMAT_ENUM_ITEMS)

    _timer = None
    _thread: threading.Thread | None = None
    _task: _TaskState | None = None
    _obj_path: Path | None = None
    _final_path: Path | None = None
    _keep_temp: bool = False

    def invoke(self, context, _event):
        ext = (self.target_format or "").strip().lower()
        self.filter_glob = f"*.{ext}" if ext else "*.*"
        if not self.filepath:
            self.filepath = bpy.path.abspath("//" + _default_export_name(ext or "dat"))
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def check(self, _context):
        ext = (self.target_format or "").strip().lower()
        if not ext:
            return False
        desired = f".{ext}"
        if self.filepath and not self.filepath.lower().endswith(desired):
            self.filepath = bpy.path.ensure_ext(self.filepath, desired)
            return True
        return False

    # -- background worker ---------------------------------------------------

    def _worker(self, base_url: str, obj_path: Path, target_ext: str,
                final_path: Path, timeout: int):
        task = self._task
        try:
            payload = _run_convert(base_url, obj_path, target_ext, timeout, task)
            download_url = _absolute_download_url(base_url, str(payload.get("download_url") or ""))
            if not download_url:
                raise RuntimeError("Missing download_url in convert response")

            task.status = "Downloading..."
            task.progress = max(task.progress, 60)
            download_base = task.progress
            _download_file(download_url, final_path, timeout,
                           task=task, progress_base=download_base,
                           progress_span=min(35, 100 - download_base))
            task.progress = 100
            task.status = "Done"
        except Exception as exc:  # noqa: BLE001
            task.error = _friendly_error_text(str(exc), "obj", target_ext)
        finally:
            task.done = True

    # -- modal loop ----------------------------------------------------------

    def modal(self, context, event):
        if event.type != "TIMER":
            return {"PASS_THROUGH"}

        task = self._task
        wm = context.window_manager

        wm.progress_update(task.progress)
        for area in context.screen.areas:
            if area.type in {"VIEW_3D", "INFO"}:
                area.header_text_set(f"Super3D: {task.status}  [{task.progress}%]")

        if not task.done:
            return {"PASS_THROUGH"}

        # ----- Task finished -----
        self._cleanup_modal(context)

        if not self._keep_temp and self._obj_path:
            self._obj_path.unlink(missing_ok=True)

        if task.error:
            self.report({"ERROR"}, task.error)
            return {"CANCELLED"}

        suffix = " (cached)" if task.cache_hit else ""
        self.report({"INFO"}, f"Exported via Super3D{suffix}: {self._final_path.name}")
        return {"FINISHED"}

    def _cleanup_modal(self, context):
        wm = context.window_manager
        wm.progress_end()
        if self._timer:
            wm.event_timer_remove(self._timer)
            self._timer = None
        for area in context.screen.areas:
            if area.type in {"VIEW_3D", "INFO"}:
                area.header_text_set(None)

    # -- execute (called after file browser) ---------------------------------

    def execute(self, context):
        prefs = _prefs(context)
        base_url = str(prefs.api_base_url or "").strip().rstrip("/")
        timeout = max(30, int(prefs.request_timeout_sec))
        target_ext = (self.target_format or "").strip().lower()
        self._keep_temp = bool(prefs.keep_temp_files)

        if not base_url:
            self.report({"ERROR"}, "API Base URL is empty")
            return {"CANCELLED"}
        if not target_ext:
            self.report({"ERROR"}, "Target format is empty")
            return {"CANCELLED"}

        out_path = Path(bpy.path.abspath(self.filepath or ""))
        if not out_path:
            self.report({"ERROR"}, "Invalid output path")
            return {"CANCELLED"}
        if out_path.suffix.lower() != f".{target_ext}":
            out_path = out_path.with_suffix(f".{target_ext}")
        self._final_path = out_path

        # Export OBJ on main thread (Blender ops requirement)
        self._obj_path = _temp_root() / f"export_{uuid.uuid4().hex}.obj"
        self._task = _TaskState()
        self._task.status = "Exporting scene to OBJ..."
        self._task.progress = 0

        # Start progress bar before OBJ export so user sees it during the blocking call
        wm = context.window_manager
        wm.progress_begin(0, 100)
        wm.progress_update(0)
        for area in context.screen.areas:
            if area.type in {"VIEW_3D", "INFO"}:
                area.header_text_set("Super3D: Exporting scene to OBJ...  [0%]")

        try:
            _export_scene_obj(self._obj_path)
        except Exception as exc:  # noqa: BLE001
            wm.progress_end()
            for area in context.screen.areas:
                if area.type in {"VIEW_3D", "INFO"}:
                    area.header_text_set(None)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        self._task.progress = 5
        wm.progress_update(5)
        for area in context.screen.areas:
            if area.type in {"VIEW_3D", "INFO"}:
                area.header_text_set("Super3D: Exported OBJ, starting upload...  [5%]")

        # Start background thread for upload / convert / download
        self._thread = threading.Thread(
            target=self._worker,
            args=(base_url, self._obj_path, target_ext, self._final_path, timeout),
            daemon=True,
        )
        self._thread.start()

        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        return {"RUNNING_MODAL"}


# ---------------------------------------------------------------------------
#  Menus
# ---------------------------------------------------------------------------

class SUPER3D_MT_import_menu(Menu):
    bl_idname = "SUPER3D_MT_import_menu"
    bl_label = "Super3D Extra Formats"

    def draw(self, context):
        layout = self.layout
        prefs = _prefs(context)
        any_shown = False
        for ext, label in IMPORT_FORMATS:
            if getattr(prefs, f"show_import_{ext}", True):
                op = layout.operator(SUPER3D_OT_import_extra.bl_idname, text=f"{label} (.{ext})", icon="IMPORT")
                op.source_format = ext
                any_shown = True
        if not any_shown:
            layout.label(text="(No formats enabled — check Preferences)")


class SUPER3D_MT_export_menu(Menu):
    bl_idname = "SUPER3D_MT_export_menu"
    bl_label = "Super3D Extra Formats"

    def draw(self, context):
        layout = self.layout
        prefs = _prefs(context)
        any_shown = False
        for ext, label in EXPORT_FORMATS:
            if getattr(prefs, f"show_export_{ext}", True):
                op = layout.operator(SUPER3D_OT_export_extra.bl_idname, text=f"{label} (.{ext})", icon="EXPORT")
                op.target_format = ext
                any_shown = True
        if not any_shown:
            layout.label(text="(No formats enabled — check Preferences)")


def _menu_import(self, _context):
    self.layout.separator()
    self.layout.menu(SUPER3D_MT_import_menu.bl_idname, text="Super3D Extra Formats", icon="PLUGIN")


def _menu_export(self, _context):
    self.layout.separator()
    self.layout.menu(SUPER3D_MT_export_menu.bl_idname, text="Super3D Extra Formats", icon="PLUGIN")


# ---------------------------------------------------------------------------
#  Registration
# ---------------------------------------------------------------------------

CLASSES = (
    SUPER3D_OT_toggle_all_formats,
    SUPER3D_AddonPrefs,
    SUPER3D_OT_import_extra,
    SUPER3D_OT_export_extra,
    SUPER3D_MT_import_menu,
    SUPER3D_MT_export_menu,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(_menu_import)
    bpy.types.TOPBAR_MT_file_export.append(_menu_export)


def unregister():
    try:
        bpy.types.TOPBAR_MT_file_import.remove(_menu_import)
    except Exception:
        pass
    try:
        bpy.types.TOPBAR_MT_file_export.remove(_menu_export)
    except Exception:
        pass

    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


if __name__ == "__main__":
    register()
