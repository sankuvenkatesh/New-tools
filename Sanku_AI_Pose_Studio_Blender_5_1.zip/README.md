# Sanku AI Pose Studio — Blender 5.1

Custom-branded image-to-Rigify posing addon based on Pose Capture 1.3.3.

## Install
1. Extract the ZIP.
2. In Blender: Edit > Preferences > Add-ons > Install from Disk.
3. Select `Sanku_AI_Pose_Studio_Blender_5_1.zip`.
4. Enable **Sanku AI Pose Studio**.
5. Open 3D View > Sidebar (N) > Sanku AI Pose Studio.

## Workflow
1. Use Install Dependencies / Download Models in the panel.
2. Load a reference image and click Detect Pose.
3. Select your Rigify armature (generated rig recommended).
4. Auto-map bones, review settings, then Apply Pose.
5. Optionally enable Insert Keyframe before applying.

## Compatibility note
The source README reports testing on Blender 5.2.1 and targets Blender 4.2–5.x APIs. This package has been syntax-checked, but has not been runtime-tested inside Blender 5.1 in this environment. Run a test scene before production use.

## Scope
This package customizes and packages the Pose Capture core. MediaToPose is not merged into this build: it is a separate GPL-3.0-or-later project with a Blender 5.2 minimum and a larger provider/runtime architecture. Its code should only be integrated in a later, license-compliant compatibility port.

## Credits and license
Pose Capture source is MIT licensed. See `LICENSE`. Third-party model weights and dependencies are downloaded by the addon and are not bundled.
